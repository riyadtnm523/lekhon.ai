import express from "express";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

// Initialize express app
const app = express();
app.use(express.json({ limit: "50mb" }));

const PORT = 3000;

// API: Check configuration status
app.get("/api/config-status", (req, res) => {
  res.json({
    hasApiKey: !!process.env.GEMINI_API_KEY,
    hasDeepseekKey: !!process.env.DEEPSEEK_API_KEY,
  });
});

// Powerful multi-provider AI content generation handler
async function runGeneration(
  req: any,
  systemInstruction: string,
  prompt: any,
  responseSchema?: any
): Promise<string> {
  const provider = req.headers["x-model-provider"] || "gemini";
  const geminiKeyHeader = req.headers["x-api-key-gemini"];
  const deepseekKeyHeader = req.headers["x-api-key-deepseek"];

  if (provider === "deepseek") {
    const apiKey = deepseekKeyHeader || process.env.DEEPSEEK_API_KEY;
    if (!apiKey) {
      throw new Error("DeepSeek API Key is missing. Please configure it in the Admin Panel.");
    }

    // Extract raw text if prompt is a complex object (like parts in attachment)
    let promptText = "";
    if (typeof prompt === "string") {
      promptText = prompt;
    } else if (prompt && typeof prompt === "object") {
      if (Array.isArray(prompt.parts)) {
        promptText = prompt.parts
          .map((p: any) => p.text || (p.inlineData ? `[Attached File: ${p.inlineData.mimeType}]` : ""))
          .join("\n");
      } else if (prompt.inlineData) {
        promptText = `[Attached File: ${prompt.inlineData.mimeType}]`;
      } else {
        promptText = JSON.stringify(prompt);
      }
    }

    let adjustedPrompt = promptText;
    if (responseSchema) {
      adjustedPrompt += `\n\nCRITICAL DIRECTIVE: You MUST respond strictly with a valid raw JSON object. Do NOT wrap the JSON response inside markdown code blocks (such as \`\`\`json ... \`\`\`). Your output must be purely parseable JSON conforming to this schema:
${JSON.stringify(responseSchema, null, 2)}`;
    }

    const requestBody: any = {
      model: "deepseek-chat",
      messages: [
        { role: "system", content: systemInstruction },
        { role: "user", content: adjustedPrompt }
      ],
      temperature: 0.6,
    };

    if (responseSchema) {
      requestBody.response_format = { type: "json_object" };
    }

    const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });

    if (!response.ok) {
      const errText = await response.text();
      let parsedErr: any = {};
      try { parsedErr = JSON.parse(errText); } catch(e) {}
      throw new Error(parsedErr?.error?.message || `DeepSeek API status ${response.status}: ${errText}`);
    }

    const data: any = await response.json();
    let resultText = data.choices?.[0]?.message?.content;
    if (!resultText) {
      throw new Error("No response content from DeepSeek.");
    }

    resultText = resultText.trim();
    if (resultText.startsWith("```")) {
      resultText = resultText.replace(/^```[a-zA-Z]*\n/, "").replace(/\n```$/, "").trim();
    }
    return resultText;
  } else {
    // Gemini multi-model fallback flow with quota resilience & backoff
    const apiKey = geminiKeyHeader || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing. Please configure it in AI Studio Secrets or the Admin Panel.");
    }

    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });

    const config: any = {
      systemInstruction: systemInstruction,
      maxOutputTokens: 8192,
      temperature: 0.7,
    };

    if (responseSchema) {
      config.responseMimeType = "application/json";
      config.responseSchema = responseSchema;
    }

    // Prioritized model sequence optimized for free-tier quotas and low latency
    const modelsToTry = [
      "gemini-3.1-flash-lite",
      "gemini-flash-latest",
      "gemini-2.5-flash",
      "gemini-3.7-flash"
    ];
    let lastError: any = null;

    // Multi-pass execution (Pass 1: immediate cascade; Pass 2: backoff retry if rate limited)
    for (let pass = 0; pass < 2; pass++) {
      if (pass > 0) {
        // Wait 1.2 seconds before second pass to clear short-burst rate limits
        await new Promise(r => setTimeout(r, 1200));
      }

      for (let i = 0; i < modelsToTry.length; i++) {
        const modelName = modelsToTry[i];
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: prompt,
            config: config
          });

          if (response.text) {
            return response.text;
          }
        } catch (err: any) {
          const errMsg = err.message || JSON.stringify(err);
          console.warn(`Attempt ${pass + 1} with ${modelName} failed:`, errMsg);
          lastError = err;

          // If rate limit (429) or high demand (503), small jitter before next model
          if (i < modelsToTry.length - 1) {
            await new Promise(r => setTimeout(r, 150));
          }
        }
      }
    }

    // Secondary attempt without strict responseSchema in case of schema validation/overload issues
    if (responseSchema && lastError) {
      for (const fallbackModel of ["gemini-3.1-flash-lite", "gemini-flash-latest", "gemini-2.5-flash"]) {
        try {
          const rawConfig = {
            systemInstruction: `${systemInstruction}\nCRITICAL: Return your output strictly as a valid raw JSON object matching the requested schema. Do not enclose in markdown code blocks or add extra commentary.`,
            maxOutputTokens: 8192,
            temperature: 0.7
          };
          const fallbackResp = await ai.models.generateContent({
            model: fallbackModel,
            contents: prompt,
            config: rawConfig
          });
          if (fallbackResp.text) {
            let cleaned = fallbackResp.text.trim();
            if (cleaned.startsWith("```")) {
              cleaned = cleaned.replace(/^```[a-zA-Z]*\n/, "").replace(/\n```$/, "").trim();
            }
            return cleaned;
          }
        } catch (rawErr) {
          console.warn(`Raw JSON fallback with ${fallbackModel} failed:`, rawErr);
        }
      }
    }

    // Safety fallback to DeepSeek if configured and Gemini quotas are fully exhausted
    const fallbackDeepseekKey = deepseekKeyHeader || process.env.DEEPSEEK_API_KEY;
    if (fallbackDeepseekKey) {
      try {
        console.log("Gemini models exhausted, falling back to DeepSeek...");
        const deepseekReq = {
          ...req,
          headers: {
            ...req.headers,
            "x-model-provider": "deepseek",
            "x-api-key-deepseek": fallbackDeepseekKey
          }
        };
        return await runGeneration(deepseekReq, systemInstruction, prompt, responseSchema);
      } catch (dsErr) {
        console.error("DeepSeek fallback failed:", dsErr);
      }
    }

    throw new Error(lastError?.message || "AI models are currently experiencing high demand. Please try again in a moment.");
  }
}

// 1. API: Generate Book Outline
app.post("/api/generate-outline", async (req, res) => {
  try {
    const { topic, genre, targetAudience, language, chapterCount, additionalInstructions, userPrompt } = req.body;

    let finalPrompt = "";

    if (userPrompt) {
      finalPrompt = `You are a master award-winning author, educator, and book architect. The user wants to create a book described in this prompt:
User Prompt: "${userPrompt}"

GENRE & TOPIC AWARENESS RULES:
1. DETECT THE EXACT BOOK TYPE:
   - Web Development & Programming (e.g. HTML, CSS, JavaScript, Web Design, Full-Stack, Python):
     * If user asks for HTML / Web dev (e.g. "html full complete boi 10+ oddai" / "HTML complete guide" / "HTML 5 masterclass"):
       Create an extensive, professional course/book outline covering:
       Chapter 1: HTML পরিচিতি, ইতিহাস ও বেসিক ডকুমেন্ট স্ট্রাকচার (HTML Basics, Document Structure <!DOCTYPE html>, <html>, <head>, <body>)
       Chapter 2: হেডিং, প্যারাগ্রাফ ও টেক্সট ফরম্যাটিং ট্যাগ (Headings <h1>-<h6>, <p>, <b>, <strong>, <i>, <em>, <mark>, <small>, <del>)
       Chapter 3: লিংক ও নেভিগেশন (Hyperlinks, <a> ট্যাগ, Target Attributes, বুকমার্কস)
       Chapter 4: ইমেজ, ভিডিও ও অডিও মিডিয়া ইন্টিগ্রেশন (Images <img>, <picture>, <video>, <audio>, <figure>, <figcaption>)
       Chapter 5: এইচটিএমএল টেবিল ও ডেটা রিপ্রেজেন্টেশন (Tables <table>, <tr>, <th>, <td>, <thead>, <tbody>, Colspan & Rowspan)
       Chapter 6: লিস্ট ও কন্টেইনার ট্যাগ (Ordered <ol>, Unordered <ul>, Description Lists <dl>, <div>, <span>)
       Chapter 7: ফর্ম ও ইউজার ইনপুট (Forms <form>, Input Types, <label>, <select>, <textarea>, <button>, Form Validation)
       Chapter 8: সিম্যান্টিক এইচটিএমএল ও এসইও বেস্ট প্র্যাকটিস (Semantic HTML5: <header>, <nav>, <main>, <section>, <article>, <aside>, <footer>)
       Chapter 9: আইফ্রেম ও এমবেডিং টেকনিক (iFrames, Canvas & SVG বেসিক)
       Chapter 10: মেটা ট্যাগ, এসইও এবং রেসপন্সিভ ভিউপোর্ট (SEO Meta Tags, Open Graph, Responsive <meta name="viewport">)
       Chapter 11: রিয়েল-ওয়ার্ল্ড প্রজেক্ট: একটি সম্পূর্ণ পোর্টফোলিও ওয়েবসাইট তৈরি (Complete Hands-on Project)
   - Vocabulary / Dictionary / Word Power (e.g. 1000 words English-Bengali Vocabulary, Spoken English Words):
     Structure chapters logically by themes or levels with explicit word counts.
   - Fiction / Novel / Mystery / Thriller / Romance / Sci-Fi:
     Create an exciting narrative plot with characters, rising action, climax, and resolution.
   - Islamic / Religious / Spiritual / Moral Ethics:
     Structure chapters around Quranic teachings, authentic Hadith, moral character, and inspiring stories.
   - Self-Help / Motivation / Psychology / Habits:
     Structure practical step-by-step frameworks, psychology principles, and habit routines.

2. Chapter Count Precision:
   - If the user explicitly asks for "10+ oddai", "10 chapters", "11 chapters", "12 chapters", "15 chapters", etc., you MUST generate AT LEAST that exact number of chapters (e.g. if 10+ is requested, generate 11-12 chapters). Never generate fewer chapters than requested!
   - Each chapter summary must outline 5-8 comprehensive sub-topics and practical concepts.

3. Language: Detect or use the requested language (Bengali/বাংলা or English). Strictly write the title, synopsis, and chapter summaries in that language.`;
    } else {
      finalPrompt = `You are a master book author and editor. Create a complete, high-quality structured book outline:
- Topic/Title Idea: "${topic}"
- Genre/Type: "${genre || 'General / Multi-Genre'}"
- Target Audience: "${targetAudience || 'General Readers'}"
- Language: "${language || 'Bengali'}"
- Number of Chapters: ${chapterCount || 5}
- Additional Guidance: "${additionalInstructions || 'Comprehensive, engaging, and publication-ready'}"

GENRE RULES:
- If Web Development / HTML / Programming: Structure complete hands-on tutorials with full coverage of tags, attributes, examples, and projects.
- If Vocabulary/Language: Structure chapters by word categories, daily topics, or difficulty tiers with vocabulary counts.
- If Novel/Story: Structure compelling narrative arcs and emotional journeys.
- If Islamic/Religious: Structure authentic moral, Quranic, and Hadith lessons.
- If Self-Help: Structure actionable blueprints and habits.

Strictly write the title, synopsis, chapter titles, and chapter summaries in "${language || 'Bengali'}".`;
    }

    const systemInstruction = "You are a versatile, world-class book author and literary architect. You design books across all genres—including Vocabulary/Language Dictionaries, Fiction, Novels, Islamic & Moral Literature, Self-Help, Science, and Technical Guides—with precise thematic structure.";
    const responseSchema = {
      type: Type.OBJECT,
      required: ["title", "synopsis", "suggestedCoverStyle", "language", "chapters", "detectedGenre"],
      properties: {
        title: {
          type: Type.STRING,
          description: "The official catchy and professional title of the book in the selected/detected language."
        },
        synopsis: {
          type: Type.STRING,
          description: "A compelling back-cover synopsis of the book in the selected/detected language."
        },
        suggestedCoverStyle: {
          type: Type.STRING,
          description: "Visual design suggestion for the cover page (colors, imagery style)."
        },
        language: {
          type: Type.STRING,
          description: "The primary language of the book (e.g., 'Bengali' or 'English')."
        },
        detectedGenre: {
          type: Type.STRING,
          description: "The main category of the book (e.g. 'Vocabulary & Language', 'Novel & Fiction', 'Islamic & Ethics', 'Self-Help & Motivation', 'Children Literature', 'Poetry', 'Coding Guide', etc.)"
        },
        chapters: {
          type: Type.ARRAY,
          description: "A sequential list of chapters matching the requested/determined count.",
          items: {
            type: Type.OBJECT,
            required: ["chapterNumber", "title", "summary", "estimatedPages"],
            properties: {
              chapterNumber: { type: Type.INTEGER },
              title: { type: Type.STRING, description: "Title of the chapter." },
              summary: { type: Type.STRING, description: "Detailed description of what this chapter covers and its key events, vocabulary sections, or topics." },
              estimatedPages: { type: Type.INTEGER }
            }
          }
        }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, finalPrompt, responseSchema);
    const outlineData = JSON.parse(textResult.trim());
    res.json(outlineData);
  } catch (error: any) {
    console.error("Outline generation error:", error);
    res.status(500).json({ error: error.message || "Failed to generate book outline" });
  }
});

// 2. API: Generate Chapter Content
app.post("/api/generate-chapter", async (req, res) => {
  try {
    const { bookTitle, synopsis, chapterNumber, chapterTitle, chapterSummary, previousChaptersSummary, language, customTone, writingStyle } = req.body;

    if (!bookTitle || !chapterTitle) {
      res.status(400).json({ error: "Book title and Chapter title are required." });
      return;
    }

    const prompt = `You are writing Chapter ${chapterNumber} of the book "${bookTitle}".
Book Synopsis: "${synopsis}"
Current Chapter Title: "Chapter ${chapterNumber}: ${chapterTitle}"
Current Chapter Goal & Outline: "${chapterSummary}"
Previous Chapters Context / Recap: "${previousChaptersSummary || 'This is the first chapter.'}"
Language: "${language || 'Bengali'}"
Tone / Writing Style: "${customTone || 'Engaging, professional, and richly detailed'}"
Writing Style: "${writingStyle || 'Publication-grade deep prose or structured educational guide'}"

CRITICAL GENRE-SPECIFIC WRITING INSTRUCTIONS (FOLLOW STRICTLY):

1. IF THIS IS A VOCABULARY / DICTIONARY / LANGUAGE LEARNING BOOK (যেমন: Vocabulary, Spoken English, শব্দভাণ্ডার):
   - DO NOT write software/computer code or programming scripts!
   - Write an EXCEPTIONALLY RICH, EXTENSIVE vocabulary guide with plenty of words organized neatly.
   - For every vocabulary word, include:
     * **Word (শব্দ)** & **Pronunciation (সহজ বাংলা উচ্চারণ)**
     * **Parts of Speech** (Noun, Verb, Adjective, Adverb, etc.)
     * **Bengali Meaning (বাংলা অর্থ ও সহজ ব্যাখ্যা)**
     * **2 Real-world Example Sentences with Bengali Translation (বাস্তব উদাহরণ বাক্য ও বাংলা অর্থ)**
     * **Synonyms (সমার্থক শব্দ)** & **Antonyms (বিপরীত শব্দ)**
     * **Memory Trick / Mnemonic / Root Word (সহজে মনে রাখার টেকনিক)**
   - Group the words into categorized thematic sections (e.g., ### ১. নিত্যদিনের প্রয়োজনীয় শব্দসমূহ, ### ২. অনুভূতি ও ব্যক্তিত্বের শব্দসমূহ, etc.) using clean Markdown formatting and structured comparison tables where helpful.
   - At the end of the chapter, include interactive self-test exercises: "🎯 Practice Quiz / শূন্যস্থান পূরণ", "ম্যাচিং কলাম", এবং "বাক্য তৈরি অনুশীলন".

2. IF THIS IS FICTION / NOVEL / STORY / MYSTERY / THRILLER / DRAMA / ROMANCE:
   - Write deep, immersive literary narrative prose with emotional depth, vivid scenery, natural character dialogues, suspense, and story progression. (NO code blocks!).

3. IF THIS IS ISLAMIC / RELIGIOUS / SPIRITUAL / ETHICS:
   - Write authentic Quranic references with translations, Hadith insights, inspiring moral stories, real-life applications, patience, and character building. (NO code blocks!).

4. IF THIS IS SELF-HELP / MOTIVATION / PSYCHOLOGY / BUSINESS:
   - Write actionable frameworks, practical daily habits, case studies, reflection questions, and step-by-step guidance. (NO code blocks!).

5. IF THIS IS POETRY / CHILDREN'S LITERATURE:
   - Write beautiful verses, moral rhymes, or imaginative stories suitable for the audience. (NO code blocks!).

6. IF THIS IS A PROGRAMMING / WEB DEVELOPMENT / SOFTWARE / HTML GUIDE (যেমন: HTML, CSS, JavaScript, Web Development):
   - Write an EXCEPTIONALLY COMPREHENSIVE, MASSIVE, PUBLICATION-GRADE CHAPTER (2,500 to 4,000+ words).
   - NEVER write a brief summary or skip topics!
   - For every concept and tag:
     * Explain the Tag / Concept in deep, clear Bengali with historical background and purpose.
     * Explain all syntax, attributes, default behaviors, and browser support.
     * Provide complete, real-world, working <!DOCTYPE html> code examples (with full opening and closing tags).
     * Provide step-by-step explanations of what every single line of code does.
     * Include Common Mistakes & Best Practices (> ⚠️ Warning / > 💡 Tips).
     * Include Practical Hands-on Exercises & Quizzes (অনুশীলনী ও প্রজেক্ট টাস্ক) with solutions.

FORMATTING & VISUALS:
- LENGTH: Write extensively and thoroughly (aim for 2,500 to 4,000+ words). Explain everything completely without skipping details or writing short summaries.
- IMAGES: Insert 1-2 realistic Unsplash photo URLs matching the chapter theme \`![Description](https://images.unsplash.com/...)\`.
- CALLOUT BANNERS: Use \`> 💡 [Tip]\`, \`> 📘 [Note]\`, \`> 🟢 [Key Takeaway]\`, \`> ⚠️ [Warning]\`.
- LANGUAGE: Strictly write in "${language || 'Bengali'}". If Bengali, use natural, highly polished literary Bengali (বাংলা).
- Do not add meta-commentary like "Here is the chapter". Start directly with the chapter header or content.`;

    const systemInstruction = "You are a world-class book author, linguistic expert, and educator. You write deeply comprehensive, immersive, and high-quality chapters tailored exactly to the book's specific genre—whether it is a 1000-word Vocabulary Guide, a literary Novel, an Islamic Book, a Self-Help Masterpiece, or an exhaustive Technical Guide.";
    const responseSchema = {
      type: Type.OBJECT,
      required: ["chapterNumber", "title", "content", "aiNote"],
      properties: {
        chapterNumber: { type: Type.INTEGER },
        title: { type: Type.STRING },
        content: { 
          type: Type.STRING, 
          description: "The complete full chapter text formatted in Markdown. Start directly with the chapter content. Include rich Markdown elements like headings, bullet points, and vocabulary tables." 
        },
        aiNote: { 
          type: Type.STRING, 
          description: "A short professional summary of the chapter's tone or advice for the next chapter." 
        }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, prompt, responseSchema);
    const chapterData = JSON.parse(textResult.trim());
    res.json(chapterData);
  } catch (error: any) {
    console.error("Chapter generation error:", error);
    res.status(500).json({ error: error.message || "Failed to generate chapter content" });
  }
});

// 2b. API: Continue/Expand Chapter Content (Staged Writing)
app.post("/api/continue-chapter", async (req, res) => {
  try {
    const { bookTitle, synopsis, chapterNumber, chapterTitle, chapterSummary, existingContent, language, customTone, writingStyle } = req.body;

    if (!bookTitle || !chapterTitle) {
      res.status(400).json({ error: "Book title and Chapter title are required." });
      return;
    }

    const prompt = `You are continuing to write Chapter ${chapterNumber} ("${chapterTitle}") of the book "${bookTitle}".
Book Synopsis: "${synopsis}"
Chapter Summary/Goal: "${chapterSummary}"

Here is the existing content that has been written for this chapter so far:
---
${existingContent || 'No content yet.'}
---

Your Task:
Write the NEXT logical part/section of this chapter. It MUST seamlessly continue from where the existing content left off. Do NOT repeat, summarize, or rewrite the existing content. Start directly with the next paragraph, word list, or subsection.
- GENRE SPECIALIZATION:
  * If Web Dev / HTML / Programming: Continue with detailed tag explanations, full code blocks, real-world examples, browser behaviors, and hands-on coding exercises.
  * If Vocabulary/Dictionary book: Add the next batch of rich words with Pronunciation, Meaning, Example Sentences, Synonyms/Antonyms, and Mnemonics, plus review quizzes!
  * If Story/Novel: Continue the plot narrative, dialogues, and character interactions seamlessly.
  * If Islamic/Self-Help: Add the next principles, reflections, and practical lessons.
- COMPREHENSIVENESS: Write with maximum depth and detail (aim for at least 1500-2500 words of new content).
- Language: Strictly write in "${language || 'Bengali'}". If Bengali, use natural, highly polished literary Bengali (বাংলা).`;

    const systemInstruction = "You are a master book author and educator. You write comprehensive, high-quality chapter continuations tailored strictly to the subject matter of the book.";
    const responseSchema = {
      type: Type.OBJECT,
      required: ["chapterNumber", "title", "content", "aiNote"],
      properties: {
        chapterNumber: { type: Type.INTEGER },
        title: { type: Type.STRING },
        content: { 
          type: Type.STRING, 
          description: "The next part of the chapter text formatted in Markdown. Start directly with the continuing prose/text. Do not repeat existing text." 
        },
        aiNote: { 
          type: Type.STRING, 
          description: "A short note about where this chapter continuation has reached." 
        }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, prompt, responseSchema);
    const chapterData = JSON.parse(textResult.trim());
    res.json(chapterData);
  } catch (error: any) {
    console.error("Chapter continuation error:", error);
    res.status(500).json({ error: error.message || "Failed to continue chapter content" });
  }
});

// 3. API: Collaborative Editor Assistant (AI Polish / Expand / Translate / Rewrite)
app.post("/api/ai-assistant-action", async (req, res) => {
  try {
    const { action, text, context, bookTitle, language } = req.body;

    if (!text) {
      res.status(400).json({ error: "Source text is required." });
      return;
    }

    let systemInstruction = "You are a professional book editor and writing consultant.";
    let prompt = "";

    if (action === "expand") {
      prompt = `Extend and enrich the following text to make it more detailed, descriptive, and engaging, while keeping the original meaning, genre, and tone intact. Use the book title context if helpful: "${bookTitle || 'Untitled'}". 
Original Text:
"${text}"

Language: ${language || 'Bengali'}. Write the expanded version in the same language.`;
    } else if (action === "polish") {
      prompt = `Correct any spelling or grammar mistakes, improve sentence flow, and elevate literary or educational quality:
"${text}"

Language: ${language || 'Bengali'}. Maintain the exact language and improve it beautifully.`;
    } else if (action === "shorten") {
      prompt = `Condense and tighten the following text without losing key information or depth:
"${text}"

Language: ${language || 'Bengali'}. Keep the language same.`;
    } else if (action === "explain") {
      prompt = `Analyze the following section and provide helpful writing advice or critique:
"${text}"`;
    } else {
      // Custom prompt
      prompt = `Apply this instruction: "${action}" to the following book section text.
Context of the book: "${bookTitle || ''}"
Text:
"${text}"

Language: ${language || 'Bengali'}. Make sure the output is in this language unless instructed otherwise.`;
    }

    const textResult = await runGeneration(req, systemInstruction, prompt);
    res.json({ result: textResult });
  } catch (error: any) {
    console.error("AI assistant action error:", error);
    res.status(500).json({ error: error.message || "AI helper action failed" });
  }
});

// 4. API: Conversational ChatGPT-style Book Designer, Writer & Editor
app.post("/api/chat-book", async (req, res) => {
  try {
    const { messages, currentBook, userMessage, attachment } = req.body;

    if (!userMessage) {
      res.status(400).json({ error: "User message is required" });
      return;
    }

    // Compile previous message context for the AI
    const historyText = (messages || [])
      .map((m: any) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
      .join("\n");

    const currentBookContext = currentBook
      ? `CURRENT BOOK STATE:
Title: "${currentBook.title}"
Synopsis: "${currentBook.synopsis}"
Genre: "${currentBook.genre}"
Language: "${currentBook.language}"
Cover Color: "${currentBook.coverColor || ''}"
Cover Style: "${currentBook.suggestedCoverStyle || ''}"
Chapters count: ${currentBook.chapters?.length || 0}
Chapters details:
${(currentBook.chapters || []).map((ch: any) => `
Chapter ${ch.chapterNumber}: "${ch.title}"
Summary: "${ch.summary}"
Content written: ${ch.content ? `Yes (${ch.content.length} characters)` : "No"}
`).join("\n")}
`
      : "CURRENT BOOK STATE: No book generated yet. You need to create a new one based on the user request.";

    const systemInstruction = "You are a master book author, editor, and linguistic expert capable of writing ANY type of book—including Vocabulary Guides & Dictionaries (e.g. 1000 words English-Bengali), Novels & Short Stories, Islamic & Religious Books, Self-Help & Motivation, Children Stories, Poetry, Science, and Programming Guides.\n\n" +
      "RULES:\n" +
      "1. ACCURATE DOMAIN & GENRE EXECUTION (CRITICAL):\n" +
      "   - If the user asks for a VOCABULARY BOOK, DICTIONARY, or WORD BANK (যেমন: ১০০০ শব্দের ভোকাবুলারি বই, স্পোকেন ইংলিশ শব্দভাণ্ডার):\n" +
      "     * DO NOT write programming code or software scripts!\n" +
      "     * Provide extensive, high-value vocabulary lists with Word, Bangla Pronunciation (উচ্চারণ), Parts of Speech, Bengali Meaning (বাংলা অর্থ), 2 Example Sentences with Translation (বাস্তব উদাহরণ বাক্য ও অর্থ), Synonyms/Antonyms, and Mnemonics/Memory tricks.\n" +
      "     * Fulfill the word count target faithfully across the chapters with structured Markdown tables and practice quizzes!\n" +
      "   - If the user asks for a NOVEL / STORY / THRILLER / DRAMA / FICTION:\n" +
      "     * Write rich, emotional, immersive literary prose, dramatic dialogues, atmospheric scenes, and character arcs. NEVER include computer code.\n" +
      "   - If the user asks for ISLAMIC / RELIGIOUS / MORAL BOOKS:\n" +
      "     * Write authentic Quranic verses, Hadith explanations, spiritual wisdom, and ethical life lessons. NEVER include computer code.\n" +
      "   - If the user asks for SELF-HELP / MOTIVATION / PSYCHOLOGY / BUSINESS:\n" +
      "     * Write structured frameworks, habit formation principles, real-life examples, and actionable exercises.\n" +
      "   - ONLY IF the user explicitly asks for PROGRAMMING / CODING / SOFTWARE DEV:\n" +
      "     * Include code syntax blocks and interactive code sandboxes.\n\n" +
      "2. OUTLINE & CHAPTER DRAFTING:\n" +
      "   - When creating a new book, detect if the user asked for a specific number of chapters (e.g., '10+ oddai' / '10টি অধ্যায়' / '12 chapters'). Create AT LEAST that requested number of chapters in the outline!\n" +
      "   - Write exceptionally long, rich, and high-quality Markdown content for Chapter 1 (index 0). Leave remaining chapters empty ('') with detailed summaries so the Auto-Writer / sequential generator can write each subsequent chapter with 2,500+ word depth!\n" +
      "   - If editing an existing chapter or the whole book, apply the user's specific feedback accurately.\n\n" +
      "3. VISUALS & STYLING:\n" +
      "   - Insert 1-2 relevant Unsplash photo URLs per chapter: \`![Alt text](Unsplash_URL)\` matching the book's topic.\n" +
      "   - Use colorful callouts: \`> 💡 Tip\`, \`> 📘 Info\`, \`> 🟢 Key Takeaway\`, \`> ⚠️ Warning\`.\n" +
      "   - Set a matching gradient for 'coverColor' (e.g., emerald green, deep indigo, crimson red, amber gold, slate).\n\n" +
      "4. LANGUAGE & TONE:\n" +
      "   - Automatically detect the user's preferred language (Bengali/বাংলা or English) and write all book content and the 'chatResponse' in that language.";

    const basePrompt = `
=== CONVERSATION HISTORY ===
${historyText}

=== CURRENT STATE ===
${currentBookContext}

=== NEW USER MESSAGE ===
"${userMessage}"

Apply the user's instruction or request to update or create the book, write chapter drafts, or edit content, and respond strictly in JSON matching the schema.`;

    let contentsPayload: any = basePrompt;

    if (attachment && attachment.dataBase64) {
      let cleanBase64 = attachment.dataBase64;
      if (cleanBase64.includes(";base64,")) {
        cleanBase64 = cleanBase64.split(";base64,")[1];
      }

      const filePart = {
        inlineData: {
          mimeType: attachment.mimeType || "image/jpeg",
          data: cleanBase64
        }
      };

      const textPart = {
        text: `${basePrompt}\n\n[USER ATTACHED FILE - READ AND ANSWER / PROCESS]: The user attached a file named "${attachment.name}" of type "${attachment.type}" with mime type "${attachment.mimeType}". Read and comprehend the attached file contents carefully. Implement or write about the user's instructions based on this attachment!`
      };

      contentsPayload = { parts: [filePart, textPart] };
    }

    const responseSchema = {
      type: Type.OBJECT,
      required: ["chatResponse", "updatedBook"],
      properties: {
        chatResponse: {
          type: Type.STRING,
          description: "Conversational response back to the user explaining what you did, the changes you made, or introducing the book structure. Speak in the same language as the user's input."
        },
        updatedBook: {
          type: Type.OBJECT,
          required: ["title", "synopsis", "genre", "language", "coverColor", "suggestedCoverStyle", "chapters"],
          properties: {
            title: { type: Type.STRING, description: "Title of the book." },
            synopsis: { type: Type.STRING, description: "Synopsis or back cover description of the book." },
            genre: { type: Type.STRING, description: "Main category or genre of the book." },
            language: { type: Type.STRING, description: "Primary language of the book." },
            coverColor: { type: Type.STRING, description: "The CSS gradient background string for the book cover (e.g., linear-gradient(135deg, ...))." },
            suggestedCoverStyle: { type: Type.STRING, description: "Visual description of the book cover style." },
            coverImageUrl: { type: Type.STRING, description: "Optional user custom cover image URL or base64." },
            chapters: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["chapterNumber", "title", "summary", "content"],
                properties: {
                  chapterNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  summary: { type: Type.STRING, description: "A one or two-sentence description of this chapter's goals." },
                  content: { type: Type.STRING, description: "The full written detailed chapter text in detailed Markdown. Ensure it is exceptionally long, descriptive, and comprehensive (at least 1500 to 2500 words per chapter). Avoid short summaries. Start directly with the text." }
                }
              }
            }
          }
        }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, contentsPayload, responseSchema);
    const data = JSON.parse(textResult.trim());
    if (currentBook?.coverImageUrl && (!data.updatedBook.coverImageUrl || data.updatedBook.coverImageUrl.trim() === "")) {
      data.updatedBook.coverImageUrl = currentBook.coverImageUrl;
    }
    if (currentBook?.coverImageOpacity && !data.updatedBook.coverImageOpacity) {
      data.updatedBook.coverImageOpacity = currentBook.coverImageOpacity;
    }
    res.json(data);

  } catch (error: any) {
    console.error("Conversational chat-book error:", error);
    res.status(500).json({ error: error.message || "Failed to process chat instruction." });
  }
});

// 5. API: Translate Book to Any Language
app.post("/api/translate-book", async (req, res) => {
  try {
    const { book, targetLanguage } = req.body;
    if (!book || !targetLanguage) {
      res.status(400).json({ error: "Book and target language are required." });
      return;
    }

    const prompt = `You are a professional award-winning literary translator. Translate the following book structure and contents into the requested target language: "${targetLanguage}".
Ensure the translation maintains high literary quality, appropriate vocabulary, correct grammar, and structural format. Maintain all markdown formatting, including images, blockquotes, code blocks, bullet points, headers, and color alert blocks exactly! Do not omit any text! Translate every chapter fully!

Original Book Title: "${book.title}"
Synopsis: "${book.synopsis}"
Genre: "${book.genre}"
Current Language: "${book.language}"

Chapters content to translate:
${book.chapters.map((ch: any) => `
--- START CHAPTER ${ch.chapterNumber}: ${ch.title} ---
Summary: "${ch.summary}"
Content:
${ch.content || "This chapter has no content written yet."}
--- END CHAPTER ${ch.chapterNumber} ---
`).join("\n")}
`;

    const systemInstruction = "You are a professional book translator. Translate the entire book into the target language accurately and completely, returning a valid JSON matching the exact schema. Ensure all chapter prose contents are fully translated in pristine Markdown without cutting them short.";
    const responseSchema = {
      type: Type.OBJECT,
      required: ["title", "synopsis", "genre", "language", "chapters"],
      properties: {
        title: { type: Type.STRING },
        synopsis: { type: Type.STRING },
        genre: { type: Type.STRING },
        language: { type: Type.STRING, description: "The translated target language name (e.g., 'English', 'Bengali', etc.)." },
        chapters: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            required: ["chapterNumber", "title", "summary", "content"],
            properties: {
              chapterNumber: { type: Type.INTEGER },
              title: { type: Type.STRING },
              summary: { type: Type.STRING },
              content: { type: Type.STRING, description: "The full fully translated chapter text in Markdown. Do not omit any sections, tables, code blocks, or images. Keep Unsplash image URLs exactly intact." }
            }
          }
        }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, prompt, responseSchema);
    const translatedBook = JSON.parse(textResult.trim());
    // Preserve cover color and suggested cover style from original book if missing
    translatedBook.coverColor = book.coverColor;
    translatedBook.suggestedCoverStyle = book.suggestedCoverStyle;
    translatedBook.id = book.id;
    translatedBook.userId = book.userId;
    translatedBook.creatorEmail = book.creatorEmail;
    translatedBook.creatorName = book.creatorName;
    translatedBook.published = book.published || false;
    translatedBook.likes = book.likes || 0;
    translatedBook.likedBy = book.likedBy || [];
    translatedBook.downloads = book.downloads || 0;
    translatedBook.createdAt = book.createdAt;

    res.json(translatedBook);
  } catch (error: any) {
    console.error("Book translation error:", error);
    res.status(500).json({ error: error.message || "Failed to translate book" });
  }
});

// 6. API: Dedicated Unlimited AI Chat Hub
app.post("/api/ai-chat", async (req, res) => {
  try {
    const { messages, userMessage, persona = "assistant", language = "Bengali", attachment } = req.body;

    const personaInstructions: Record<string, string> = {
      assistant: "You are Lekhok AI Master Assistant — an ultra-intelligent, eloquent, helpful and creative companion. You can discuss any topic, provide detailed explanations, answer complex questions, write stories, draft essays, translate, analyze data, and provide expert guidance.",
      storyteller: "You are an award-winning master novelist and mythologist. You craft immersive, deeply atmospheric stories, vivid character dialogues, thrilling plot twists, and lyrical prose. Write in rich, captivating sentences.",
      coder: "You are a senior full-stack software engineer and system architect. You provide clean, modern, secure, and production-ready code with clear explanations, best practices, and bug fixes.",
      scholar: "You are a distinguished research scholar, historian, and scientist. You provide rigorous, fact-based, insightful analysis, citations of principles, academic synthesis, and structured breakdowns.",
      companion: "You are a warm, empathetic, funny, and supportive conversational buddy. You listen attentively, give thoughtful advice, share uplifting reflections, and chat freely like a close lifelong friend."
    };

    const activeInstruction = personaInstructions[persona] || personaInstructions.assistant;
    const systemInstruction = `${activeInstruction}
Always communicate naturally and eloquently in the user's preferred language (${language}).

DEVELOPER & CREATOR BIOGRAPHICAL KNOWLEDGE BASE:
1. Creator/Developer: "ওমর ফারুক মাসউদ (Omar Faruk Masud)। তিনি একজন প্রফেশনাল ওয়েব ডেভেলপার, তবে এখনও অনলাইনে ততটা কাজ শুরু করেননি।"
2. Immediate Family: "তার পরিবারে আছেন তার বাবা, মা এবং ২ জন ভাই। তার এক বড় ভাই আছেন যার নাম মাসুম, এবং ছোট ভাই আছেন যার নাম মাহফুজ।"
3. Paternal Family (দাদার পরিবার): "তার দাদার পরিবারে দাদা ও দাদী বেঁচে নেই। তার ৫ জন কাকা আছেন এবং তার বাবা সবার বড়। ৫ জন কাকার নাম: ১. কাদের, ২. মোশাররফ, ৩. মঈন, ৪. মোমিন, ৫. মহসিন।"
4. Maternal Family (নানার পরিবার): "তার নানার পরিবারে নানা বেঁচে নেই, তবে নানু আছেন। তার মা সবার বড় সন্তান। তার ৫ জন মামা ও ১ জন খালা আছেন (মোট ৬ ভাইবোন): ১. হেলাল, ২. আলমগীর, ৩. জাফর, ৪. ইসমাইল, ৫. শাহিনুর (খালা), ৬. মানিক (ছোট মামা)।"
5. Friends (বন্ধু): "তার বন্ধু ৩ জন: ১. হেলাল (মামাতো ভাই), ২. শাহাদাত (আসল মামাতো ভাই না, এক মামার ছেলে), ৩. আবির (স্কুল/মাদ্রাসার ক্লাসমেট)।"
6. Full Details: If asked "তার পুরো ডিটেইলস দাও", recite all the above details sequentially and respectfully.

Format your answers in beautiful, clean Markdown with headings, bullet points, bold key terms, blockquotes, and fenced code blocks where appropriate.
Provide comprehensive, deeply helpful, and unlimited responses without artificial truncation.`;

    const historyText = Array.isArray(messages)
      ? messages.slice(-12).map((m: any) => `${m.role === "user" ? "User" : "AI"}: ${m.content}`).join("\n\n")
      : "";

    const promptText = `
=== CONVERSATION HISTORY ===
${historyText}

=== NEW USER MESSAGE ===
"${userMessage}"

Provide a rich, deeply thoughtful, and complete response in ${language}:`;

    let payload: any = promptText;
    if (attachment && attachment.dataBase64) {
      let cleanBase64 = attachment.dataBase64;
      if (cleanBase64.includes(";base64,")) {
        cleanBase64 = cleanBase64.split(";base64,")[1];
      }
      payload = {
        parts: [
          { inlineData: { mimeType: attachment.mimeType || "image/jpeg", data: cleanBase64 } },
          { text: `${promptText}\n\n[USER ATTACHED FILE]: Analyze and answer based on this attached file (${attachment.name}).` }
        ]
      };
    }

    const reply = await runGeneration(req, systemInstruction, payload);
    res.json({ reply: reply.trim() });
  } catch (error: any) {
    console.error("AI Chat error:", error);
    res.status(500).json({ error: error.message || "Failed to process chat" });
  }
});

// 7. API: Dedicated Unlimited Real-Time Voice Buddy with Multimodal Vision
app.post("/api/voice-chat", async (req, res) => {
  try {
    const { messages, userSpeech, language = "Bengali", voicePersonality = "warm", image, imageData } = req.body;

    if (!userSpeech && !image && !imageData) {
      res.status(400).json({ error: "User speech or image is required" });
      return;
    }

    const systemInstruction = `You are Lekhok Voice Companion — a friendly, charismatic, and natural real-time voice partner having a live spoken dialogue with the user.
Created by Master Web Developer: Omar Faruk Masud (ওমর ফারুক মাসউদ).

DEVELOPER & CREATOR BIOGRAPHICAL KNOWLEDGE BASE:
1. Creator/Developer: "ওমর ফারুক মাসউদ (Omar Faruk Masud)। তিনি একজন প্রফেশনাল ওয়েব ডেভেলপার, তবে এখনও অনলাইনে ততটা কাজ শুরু করেননি।"
2. Immediate Family: "তার পরিবারে আছেন তার বাবা, মা এবং ২ জন ভাই। তার এক বড় ভাই আছেন যার নাম মাসুম, এবং ছোট ভাই আছেন যার নাম মাহফুজ।"
3. Paternal Family (দাদার পরিবার): "তার দাদার পরিবারে দাদা ও দাদী বেঁচে নেই। তার ৫ জন কাকা আছেন এবং তার বাবা সবার বড়। ৫ জন কাকার নাম: ১. কাদের, ২. মোশাররফ, ৩. মঈন, ৪. মোমিন, ৫. মহসিন।"
4. Maternal Family (নানার পরিবার): "তার নানার পরিবারে নানা বেঁচে নেই, তবে নানু আছেন। তার মা সবার বড় সন্তান। তার ৫ জন মামা ও ১ জন খালা আছেন (মোট ৬ ভাইবোন): ১. হেলাল, ২. আলমগীর, ৩. জাফর, ৪. ইসমাইল, ৫. শাহিনুর (খালা), ৬. মানিক (ছোট মামা)।"
5. Friends (বন্ধু): "তার বন্ধু ৩ জন: ১. হেলাল (মামাতো ভাই), ২. শাহাদাত (আসল মামাতো ভাই না, এক মামার ছেলে), ৩. আবির (স্কুল/মাদ্রাসার ক্লাসমেট)।"
6. Full Details: If asked "তার পুরো ডিটেইলস দাও", recite all the above details sequentially and respectfully.

Vision / Multimodal Capability:
If an image is attached, describe what you see, answer any questions about the image, read any Bengali/English text or handwriting, or provide helpful commentary in your spoken response.

Tone: ${voicePersonality === "warm" ? "Warm, caring, friendly" : voicePersonality === "enthusiastic" ? "Energetic, upbeat, exciting" : voicePersonality === "calm" ? "Calm, peaceful, soothing" : "Smart, articulate, intellectual"}.
Language: Communicate naturally in ${language} (bilingual Bengali/English).
Key Spoken Dialogue Rules:
- Your response will be spoken aloud via Text-to-Speech directly to the user's ears.
- Keep responses conversational, concise, natural, and expressive (2 to 4 engaging sentences unless the user asked for a longer story/explanation or full details).
- Avoid robotic markdown tables, complex ASCII symbols, or bullet lists; speak in natural, fluent human sentences.
- Be proactive, empathetic, and friendly.`;

    const historyText = Array.isArray(messages)
      ? messages.slice(-8).map((m: any) => `${m.role === "user" ? "User" : "Companion"}: ${m.text || m.content || ""}`).join("\n")
      : "";

    const textPrompt = `
=== RECENT CONVERSATION ===
${historyText}

=== USER JUST SAID ===
"${userSpeech || "Please inspect this image and tell me about it."}"

Speak back naturally in ${language}:`;

    let promptPayload: any = textPrompt;
    const rawImage = imageData || image;
    if (rawImage && typeof rawImage === "string") {
      let mimeType = "image/jpeg";
      let base64Data = rawImage;
      if (rawImage.includes(";base64,")) {
        const parts = rawImage.split(";base64,");
        mimeType = parts[0].replace("data:", "") || "image/jpeg";
        base64Data = parts[1];
      }
      promptPayload = [
        { text: textPrompt },
        {
          inlineData: {
            mimeType: mimeType,
            data: base64Data
          }
        }
      ];
    }

    const reply = await runGeneration(req, systemInstruction, promptPayload);
    res.json({ reply: reply.trim() });
  } catch (error: any) {
    console.error("Voice chat error:", error);
    res.json({ 
      reply: req.body.language === "Bengali"
        ? "জী, আমি আপনার কথা শুনতে পাচ্ছি। দয়া করে আরেকবার বলুন।"
        : "Yes, I am listening. Please speak again."
    });
  }
});

// 7b. API: Autonomous Agentic Voice Executive (Boss Command Parser & Full Website Controller)
app.post("/api/voice-executive", async (req, res) => {
  try {
    const { userSpeech, language = "Bengali", currentContext, image, imageData } = req.body;

    if (!userSpeech && !image && !imageData) {
      res.status(400).json({ error: "User speech or image is required" });
      return;
    }

    const systemInstruction = `You are the Autonomous Voice Executive AI of Lekhok AI, created by master developer Omar Faruk Masud (ওমর ফারুক মাসউদ).
The user is your VIP Creator and 'Boss' (বস).
Your job is to parse the user's spoken voice command or analyze attached images in real-time, determine what action they want to perform on the website, and generate a natural, respectful, and authoritative spoken reply where you address the user as 'বস' (Boss) in Bengali or 'Boss' in English.

DEVELOPER & CREATOR BIOGRAPHICAL KNOWLEDGE BASE (When Boss or any user asks):
1. Who created you?: "আমাকে তৈরি করেছেন মাস্টার ওয়েব ডেভেলপার ওমর ফারুক মাসউদ (Omar Faruk Masud)। তিনি একজন প্রফেশনাল ওয়েব ডেভেলপার, তবে এখনও অনলাইনে ততটা কাজ শুরু করেননি।"
2. Immediate Family (তার পরিবারে কে কে আছে?): "ওমর ফারুক মাসউদের পরিবারে আছেন তার বাবা, মা এবং ২ জন ভাই। তার বড় ভাইয়ের নাম মাসুম এবং ছোট ভাইয়ের নাম মাহফুজ।"
3. Paternal Family (দাদার পরিবারে কে কে আছে?): "তার দাদার পরিবারে দাদা ও দাদী বেঁচে নেই। তার ৫ জন কাকা আছেন এবং তার বাবা তাদের সবার বড়। ৫ জন কাকার নাম যথাক্রমে: ১. কাদের, ২. মোশাররফ, ৩. মঈন, ৪. মোমিন, ৫. মহসিন।"
4. Maternal Family (নানার পরিবারে কে কে আছে?): "তার নানার পরিবারে নানা বেঁচে নেই, তবে নানু আছেন। তার মা সবার বড় সন্তান। তার ৫ জন মামা এবং ১ জন খালা আছেন (মোট ৬ ভাইবোন): ১. হেলাল, ২. আলমগীর, ৩. জাফর, ৪. ইসমাইল, ৫. শাহিনুর (খালা), ৬. মানিক (ছোট মামা)।"
5. Friends (তার বন্ধু কয়জন ও কে কে?): "তার বন্ধু ৩ জন: ১. হেলাল (মামাতো ভাই), ২. শাহাদাত (আসল মামাতো ভাই না, এক মামার ছেলে), ৩. আবির (স্কুল বা মাদ্রাসার ক্লাসমেট)।"
6. Full Details Request (তার পুরো ডিটেইলস দাও / Tell me all details about him): Recite all the above details step by step clearly and politely in spoken Bengali/English.

Vision / Multimodal:
If an image is attached, inspect it thoroughly, describe its contents, solve math/coding, or read handwriting, and explain it clearly in spokenReply.

POSSIBLE ACTIONS:
1. "CREATE_BOOK" -> When user asks to write/create a book, novel, vocabulary guide, poem, thriller, Islamic book, story, etc. (e.g. "আমাকে একটা ভূতের গল্পের বই বানিয়ে দাও", "একটি উপন্যাস লেখো", "১০০০ শব্দের স্পোকেন ইংলিশ বই বানাও", "Write a sci-fi novel about Mars").
   Parameters:
   - topic: The core title/topic of the book
   - genre: Detected genre (e.g. "Fiction & Novel", "Vocabulary & English", "Islamic & Ethics", "Self-Help", "Horror Thriller", "Poetry", "Science Fiction")
   - targetAudience: e.g. "General Readers" or "Language Learners"
   - chapterCount: Number of chapters (default 5 if not specified)
   - prompt: Original user idea

2. "SEARCH_WEB" -> When user says "গুগলে সার্চ করো [বিষয়]", "Search Google for [query]", "আমাকে [বিষয়] সম্পর্কে বলো", or asks factual questions about current world events, science, history, news, or general knowledge.
   Parameters:
   - searchQuery: The clean search term
   - searchSummary: A direct, highly informative, natural spoken summary answer explaining the topic clearly to Boss (spoken directly in Bengali or English).

3. "NAVIGATE" -> When user asks to go to or open a specific section/tab (e.g. "চ্যাটে যাও", "কোড স্টুডিও ওপেন করো", "সোশ্যাল লাইব্রেরি দেখাও", "বই এডিটরে যাও", "হিস্ট্রি দেখাও", "সেটিংসে চলো", "মাইন্ড ম্যাট্রিক্স খোলো").
   Parameters:
   - targetTab: "editor" | "ai_chat" | "voice_buddy" | "code_studio" | "social" | "mind_matrix" | "history" | "settings"

4. "DOWNLOAD_PDF" -> When user says "বইটি ডাউনলোড করো", "পিডিএফ করো", "Download book", "Export PDF".

5. "PUBLISH_BOOK" -> When user says "বইটি প্রকাশ করো", "পাবলিশ করো", "Publish my book".

6. "TRANSLATE_BOOK" -> When user says "বইটি অনুবাদ করো", "Translate book to English/Bengali".
   Parameters:
   - targetLanguage: "English" or "Bengali"

7. "CHAT" -> When user is having a normal friendly conversation, asking about the creator, asking for advice, greeting, joking, discussing life, analyzing an attached image, or asking questions not covered by the actions above.
   Parameters:
   - spokenReply: Natural, intelligent, warm, conversational response addressing the user as Boss ("বস") in Bengali or "Boss" in English.

RESPONSE SCHEMA DIRECTIVE:
Always output valid JSON conforming strictly to the schema.
Always keep spokenReply natural, polite, and expressive suitable for instant Text-to-Speech output.`;

    const promptText = `
User Spoken Speech: "${userSpeech || "Boss sent an image for inspection"}"
Context: ${JSON.stringify(currentContext || {})}
Preferred Language: ${language}

Analyze the user's intent or attached image, decide the action, and respond with the execution payload and spoken response:`;

    const responseSchema = {
      type: Type.OBJECT,
      required: ["action", "spokenReply"],
      properties: {
        action: {
          type: Type.STRING,
          description: "One of: CREATE_BOOK, SEARCH_WEB, NAVIGATE, DOWNLOAD_PDF, PUBLISH_BOOK, TRANSLATE_BOOK, CHAT"
        },
        spokenReply: {
          type: Type.STRING,
          description: "The direct spoken response that will be read aloud to Boss via Text-to-Speech. Must address the user as 'বস' in Bengali or 'Boss' in English."
        },
        bookParams: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            genre: { type: Type.STRING },
            targetAudience: { type: Type.STRING },
            chapterCount: { type: Type.INTEGER },
            prompt: { type: Type.STRING }
          }
        },
        searchParams: {
          type: Type.OBJECT,
          properties: {
            searchQuery: { type: Type.STRING },
            searchSummary: { type: Type.STRING }
          }
        },
        navigationParams: {
          type: Type.OBJECT,
          properties: {
            targetTab: { type: Type.STRING }
          }
        },
        translationParams: {
          type: Type.OBJECT,
          properties: {
            targetLanguage: { type: Type.STRING }
          }
        }
      }
    };

    let promptPayload: any = promptText;
    const rawImage = imageData || image;
    if (rawImage && typeof rawImage === "string") {
      let mimeType = "image/jpeg";
      let base64Data = rawImage;
      if (rawImage.includes(";base64,")) {
        const parts = rawImage.split(";base64,");
        mimeType = parts[0].replace("data:", "") || "image/jpeg";
        base64Data = parts[1];
      }
      promptPayload = [
        { text: promptText },
        {
          inlineData: {
            mimeType: mimeType,
            data: base64Data
          }
        }
      ];
    }

    const textResult = await runGeneration(req, systemInstruction, promptPayload, responseSchema);
    const parsed = JSON.parse(textResult.trim());
    res.json(parsed);
  } catch (error: any) {
    console.error("Voice executive error:", error);
    res.json({ 
      action: "CHAT",
      spokenReply: req.body.language === "Bengali" ? "জী বস, আমি শুনতে পাচ্ছি। দয়া করে আবার বলুন।" : "Yes Boss, I am listening. Please tell me again."
    });
  }
});

// 7c. API: Real-Time Bidirectional Live Voice Translation & Multimodal Voice Processing Engine
app.post("/api/voice-live-translate", async (req, res) => {
  try {
    const { 
      text, 
      audioBase64, 
      audioMimeType = "audio/webm",
      sourceLanguage = "Bengali", 
      targetLanguage = "English", 
      persona = "translator",
      bookContext = "" 
    } = req.body;

    const cleanText = (text || "").trim();

    if (!cleanText && !audioBase64) {
      res.status(400).json({ 
        transcript: "",
        translation: "",
        response: "আমি কোনো কথা বা শব্দ শুনতে পাইনি। দয়া করে মাইক্রোফোনে স্পষ্ট করে বলুন।",
        suggestions: ["একটি রোমাঞ্চকর গল্পের প্লট দাও", "বাংলা থেকে ইংরেজি অনুবাদ করো"]
      });
      return;
    }

    let personaInstruction = "";
    if (persona === "jarvis" || persona === "ironman") {
      personaInstruction = `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), Tony Stark's legendary AI system and Lekhok's Executive Voice Intelligence.
You are supremely intelligent, sophisticated, polite, witty, and concise. 
Address the user respectfully as 'Boss' or 'Sir' in English, or 'বস' / 'স্যার' in Bengali.
Keep spoken replies punchy, crisp, ultra-helpful, cinematic, and direct (1-3 sentences max for spoken voice flow).
Language: Respond in natural spoken ${sourceLanguage === "Bengali" ? "Bengali" : targetLanguage}.`;
    } else if (persona === "storyteller" || persona === "author_muse") {
      personaInstruction = `You are Lekhok's Master Storyteller & Creative Author's Muse.
You provide imaginative, engaging, evocative literary dialogues, twists, and narrative plot development.
Respond in natural, spoken ${sourceLanguage === "Bengali" ? "Bengali" : targetLanguage}.
Also provide a high quality English translation.`;
    } else if (persona === "critic") {
      personaInstruction = `You are an elite Literary Critic & Book Editor. 
Analyze the user's spoken thoughts, character motivations, and narrative prose with deep insight and constructive feedback.
Respond constructively in ${sourceLanguage === "Bengali" ? "Bengali" : targetLanguage}.
Also provide a translation.`;
    } else {
      personaInstruction = `You are a real-time professional simultaneous interpreter and bilingual voice assistant.
Accurately transcribe the user's speech in ${sourceLanguage} and translate into ${targetLanguage}.
Provide a natural, conversational spoken answer.`;
    }

    const systemInstruction = `${personaInstruction}
${bookContext ? `Current Book Context: ${bookContext}` : ""}

Return a JSON object with:
1. "transcript": Transcribe precisely what the user said in the original language (${sourceLanguage}). If text was provided ("${cleanText}"), refine and use that.
2. "translation": Natural, accurate translation into ${targetLanguage}.
3. "response": Direct, helpful, engaging spoken conversational reply for the user (in ${sourceLanguage === "Bengali" ? "Bengali" : targetLanguage}).
4. "suggestions": Array of 2-3 short follow-up prompts or dialogue ideas.`;

    const responseSchema = {
      type: Type.OBJECT,
      required: ["transcript", "translation", "response"],
      properties: {
        transcript: {
          type: Type.STRING,
          description: `Transcribed original speech`
        },
        translation: {
          type: Type.STRING,
          description: `Accurate translation of the text in ${targetLanguage}`
        },
        response: {
          type: Type.STRING,
          description: `Conversational spoken output for the user`
        },
        suggestions: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: `Quick follow-up suggestions`
        }
      }
    };

    let promptPayload: any;
    if (audioBase64 && audioBase64.length > 50) {
      const parts: any[] = [
        {
          inlineData: {
            mimeType: audioMimeType,
            data: audioBase64
          }
        }
      ];
      if (cleanText) {
        parts.push({
          text: `User speech transcription hint: "${cleanText}". Please listen to the audio or use this transcript. Source language: ${sourceLanguage}, Target language: ${targetLanguage}.`
        });
      } else {
        parts.push({
          text: `Listen to this recorded user voice audio carefully. Transcribe the user's spoken words in ${sourceLanguage}, translate to ${targetLanguage}, and generate a friendly conversational reply.`
        });
      }
      promptPayload = parts;
    } else {
      promptPayload = `User voice input: "${cleanText}". Source language: ${sourceLanguage}, Target language: ${targetLanguage}.`;
    }

    const result = await runGeneration(req, systemInstruction, promptPayload, responseSchema);
    let parsed: any;
    try {
      parsed = JSON.parse(result.trim());
    } catch (e) {
      parsed = {
        transcript: cleanText || "ভয়েস বার্তা গৃহীত হয়েছে",
        translation: result.trim(),
        response: result.trim(),
        suggestions: ["গল্পের পরবর্তী দৃশ্য কী হতে পারে?", "বাংলা ও ইংরেজি ডায়ালগ তৈরি করো"]
      };
    }

    if (!parsed.transcript) {
      parsed.transcript = cleanText || "ভয়েস বার্তা";
    }
    if (!parsed.response) {
      parsed.response = parsed.translation || "আমি আপনার কথা শুনতে পেয়েছি। বলুন কীভাবে সাহায্য করতে পারি?";
    }

    res.json(parsed);
  } catch (error: any) {
    console.error("Voice live translate error:", error);
    const userText = (req.body.text || "").trim();
    res.json({
      transcript: userText || "ভয়েস ইনপুট গৃহীত হয়েছে",
      translation: userText ? `Translation: "${userText}"` : "অনুবাদ সফলভাবে প্রস্তুত হচ্ছে...",
      response: userText 
        ? `আমি শুনেছি: "${userText}"। আপনার লেখার জন্য আর কী সহায়তা প্রয়োজন?`
        : "আমি আপনার কথা শুনতে পাচ্ছি। দয়া করে বলুন কীভাবে সাহায্য করতে পারি।",
      suggestions: ["গল্পের প্লট কীভাবে সাজাবো?", "একটি আকর্ষণীয় সাসপেন্স দৃশ্য লিখুন", "এই সংলাপটির ইংরেজি অনুবাদ দিন"]
    });
  }
});

function ensureWavBuffer(rawBuffer: Buffer, sampleRate: number = 24000, channels: number = 1, bitDepth: number = 16): Buffer {
  if (rawBuffer.length >= 12 && rawBuffer.toString('utf8', 0, 4) === 'RIFF') {
    return rawBuffer;
  }
  const byteRate = (sampleRate * channels * bitDepth) / 8;
  const blockAlign = (channels * bitDepth) / 8;
  const dataSize = rawBuffer.length;
  const header = Buffer.alloc(44);

  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM format
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitDepth, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);

  return Buffer.concat([header, rawBuffer]);
}

// 7d. API: High-Fidelity Cinematic Iron Man / JARVIS Real Audio Engine (Gemini Voice)
app.post("/api/jarvis-tts", async (req, res) => {
  try {
    const { text, voice = "Fenrir", language = "Bengali" } = req.body;
    const cleanText = (text || "").replace(/[*_#`~]/g, "").trim();

    if (!cleanText) {
      res.status(400).json({ error: "Text is required for TTS" });
      return;
    }

    const apiKey = req.headers["x-api-key-gemini"] || process.env.GEMINI_API_KEY;
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey: apiKey as string,
          httpOptions: { headers: { "User-Agent": "aistudio-build" } }
        });

        // Use natural masculine voices: Fenrir, Puck, or Charon for authentic JARVIS baritone
        const maleVoice = voice === "Puck" || voice === "Charon" ? voice : "Fenrir";
        const promptText = `Speak in a natural, calm, confident, articulate Iron Man J.A.R.V.I.S. voice in ${language}: ${cleanText.substring(0, 700)}`;

        const ttsResponse = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: [{ parts: [{ text: promptText }] }],
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: maleVoice }
              }
            }
          }
        });

        const audioPart = ttsResponse.candidates?.[0]?.content?.parts?.[0];
        if (audioPart?.inlineData?.data) {
          const rawBuf = Buffer.from(audioPart.inlineData.data, "base64");
          const wavBuf = ensureWavBuffer(rawBuf, 24000);
          res.json({
            audioBase64: wavBuf.toString("base64"),
            mimeType: "audio/wav",
            source: "gemini-tts"
          });
          return;
        }
      } catch (geminiTtsErr: any) {
        console.warn("Gemini TTS fallback notice:", geminiTtsErr?.message);
      }
    }

    res.json({
      fallback: true,
      text: cleanText,
      language
    });
  } catch (e: any) {
    console.error("Jarvis TTS server error:", e);
    res.json({ fallback: true, text: req.body?.text || "" });
  }
});

// 8. API: Dedicated Interactive Code Studio AI Assistant (Supports Multi-File Projects & Bundling)
app.post("/api/code-studio-ai", async (req, res) => {
  try {
    const { 
      prompt, 
      currentCode, 
      files = [], 
      activeFile = "index.html", 
      language = "html", 
      action = "generate", 
      requestedModel = "gemini-3.7-flash",
      history = []
    } = req.body;

    const filesContext = Array.isArray(files) && files.length > 0
      ? files.map((f: any) => `=== FILE: ${f.name} ===\n\`\`\`${f.name.split('.').pop() || 'text'}\n${f.content ? f.content.substring(0, 5000) : ''}\n\`\`\``).join("\n\n")
      : `=== ACTIVE FILE: ${activeFile} ===\n\`\`\`${language}\n${currentCode ? currentCode.substring(0, 6000) : "(Empty workspace)"}\n\`\`\``;

    const historyContext = Array.isArray(history) && history.length > 0
      ? "\nPrevious Iteration Context:\n" + history.slice(-6).map((h: any) => `${h.role === 'user' ? 'User' : 'AI'}: ${h.text}`).join("\n")
      : "";

    const systemInstruction = `You are a World-Class Full-Stack Web Developer & Creative Coding Architect (like v0, Claude Artifacts & Google AI Studio).
You build and iteratively refine complete, standalone, production-ready interactive websites, single-page web applications, games, widgets, UI components, simulations, canvas animations, and tools.
When asked to create or update multi-file or single-file projects:
- You must write complete, functional, bug-free code with modern CSS, HTML5, JavaScript ES6+, responsive layouts, and elegant animations.
- When the user asks for iterative changes, additions, fixes, or styling updates (e.g. "add dark mode", "fix cart removal", "make it responsive", "add sound effects", "change colors"), carefully preserve existing functional code while seamlessly integrating the new feature or fix.
- For multi-file requests, return the files array with index.html, style.css, script.js (and any other necessary files).
- In index.html, make sure to link <link rel="stylesheet" href="style.css"> and <script src="script.js"></script> if multiple files exist.
- NEVER truncate or leave placeholder comments like "// rest of code here". Write the 100% complete, fully working executable code!
- Return your response strictly as JSON with { "title": "...", "explanation": "...", "code": "...", "files": [ { "name": "...", "content": "..." } ] }.`;

    const promptText = `
Action: ${action}
Active File: ${activeFile}
Language: ${language}
${historyContext}

Current Project Files & Code:
${filesContext}

User Request / Instruction:
"${prompt}"

Generate or update the project and files. Return complete runnable code strictly matching the schema.`;

    const responseSchema = {
      type: Type.OBJECT,
      required: ["title", "explanation", "code", "files"],
      properties: {
        title: { type: Type.STRING, description: "A concise name for this created code or project" },
        explanation: { type: Type.STRING, description: "Brief bullet points explaining how the code works and key features implemented" },
        code: { type: Type.STRING, description: "The complete runnable single-file bundle or primary active file code" },
        files: {
          type: Type.ARRAY,
          description: "All files in the project (e.g. index.html, style.css, script.js, README.md, etc.)",
          items: {
            type: Type.OBJECT,
            required: ["name", "content"],
            properties: {
              name: { type: Type.STRING, description: "Filename with extension (e.g., index.html, style.css, script.js, data.json)" },
              content: { type: Type.STRING, description: "Complete file contents" }
            }
          }
        }
      }
    };

    const resultText = await runGeneration(req, systemInstruction, promptText, responseSchema);
    const parsed = JSON.parse(resultText.trim());
    res.json(parsed);
  } catch (error: any) {
    console.error("Code Studio AI error:", error);
    res.status(500).json({ error: error.message || "Failed to generate code" });
  }
});

// 9. API: High-Fidelity Spoken Audio Streamer (Dual-layer Audio for Gemini Live & Boss Voice)
app.get("/api/tts-audio", async (req, res) => {
  try {
    const text = (req.query.text as string || "").trim();
    const lang = (req.query.lang as string || "bn").trim();
    if (!text) {
      res.status(400).send("Text parameter required");
      return;
    }

    // Clean text of markdown, code blocks, emojis, and symbols for crisp human vocalization
    const cleanText = text
      .replace(/```[\s\S]*?```/g, "")
      .replace(/[*#`_~\[\]()<>]/g, "")
      .replace(/\s+/g, " ")
      .trim();

    const isBn = lang.startsWith("bn") || /[\u0980-\u09FF]/.test(cleanText);
    const targetLang = isBn ? "bn" : "en";

    // Split text into digestible natural sentence chunks (max 180 chars each) for Google TTS engine
    const sentenceDelimiters = /[।!?.\n;]+/;
    const rawPieces = cleanText.split(sentenceDelimiters).map(s => s.trim()).filter(Boolean);
    const chunks: string[] = [];

    let currentChunk = "";
    for (const piece of rawPieces) {
      if ((currentChunk + " " + piece).length <= 180) {
        currentChunk = currentChunk ? `${currentChunk} ${piece}` : piece;
      } else {
        if (currentChunk) chunks.push(currentChunk);
        if (piece.length <= 180) {
          currentChunk = piece;
        } else {
          // Break large sentence into words
          const words = piece.split(" ");
          let subChunk = "";
          for (const w of words) {
            if ((subChunk + " " + w).length <= 180) {
              subChunk = subChunk ? `${subChunk} ${w}` : w;
            } else {
              if (subChunk) chunks.push(subChunk);
              subChunk = w;
            }
          }
          if (subChunk) currentChunk = subChunk;
        }
      }
    }
    if (currentChunk) chunks.push(currentChunk);

    // Support full long texts up to 25 chunks (4,500+ characters) without cutting off speech
    const activeChunks = chunks.slice(0, 25);
    if (activeChunks.length === 0) {
      activeChunks.push(cleanText.substring(0, 180));
    }

    // Fetch all audio chunks in parallel for zero latency
    const fetchPromises = activeChunks.map(async (chunk, index) => {
      try {
        const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=${targetLang}&client=tw-ob`;
        const upstream = await fetch(ttsUrl, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
          }
        });
        if (upstream.ok) {
          const ab = await upstream.arrayBuffer();
          return { index, buffer: Buffer.from(ab) };
        }
      } catch (e) {
        console.warn(`TTS chunk ${index} fetch error:`, e);
      }
      return null;
    });

    const results = await Promise.all(fetchPromises);
    const validResults = results
      .filter((r): r is { index: number; buffer: Buffer } => r !== null)
      .sort((a, b) => a.index - b.index);

    if (validResults.length === 0) {
      res.status(502).send("TTS generation failed");
      return;
    }

    const combinedBuffer = Buffer.concat(validResults.map(r => r.buffer));
    res.setHeader("Content-Type", "audio/mpeg");
    res.setHeader("Cache-Control", "public, max-age=86400");
    res.send(combinedBuffer);
  } catch (error: any) {
    console.error("TTS Audio route error:", error);
    res.status(500).send("TTS server failure");
  }
});

// 9. API: Dedicated Mind Matrix & Step-by-Step Knowledge Flowchart Generator
app.post("/api/generate-matrix", async (req, res) => {
  try {
    const { topic, language = "Bengali", depth = "comprehensive" } = req.body;
    if (!topic || !topic.trim()) {
      res.status(400).json({ error: "Topic is required" });
      return;
    }

    const systemInstruction = `You are a World-Class Knowledge Architect, Visual Pedagogy Expert, and Technical Diagram Specialist.
Your mission is to generate a comprehensive, multi-step connected Mind Matrix / Roadmap flowchart explaining any subject step by step with connected stages, rich explanations, sub-items, and code/formulas.

STRUCTURAL RULES:
1. STEP-BY-STEP FLOW: Create 6 to 10 sequential, connected steps (Step 1 -> Step 2 -> Step 3 ...) that logically explain the ENTIRE subject from foundation to advanced real-world mastery.
2. CONNECTIVITY: For each step, provide 'connectedTo' array linking it to the next step(s) (e.g. step_1 connects to ["step_2"]).
3. DEPTH: Write rich, educational, practical explanations for every step in ${language}.
4. SUB-ITEMS: Provide 4-6 actionable sub-points/mechanisms for each step.
5. CODE / FORMULA: If the subject is programming, web development (like HTML/CSS/JS), math, or science, include a real, clean working code snippet or formula in 'codeSnippet'.
6. VISUAL COLORS: Assign vibrant distinct theme colors (#3b82f6, #06b6d4, #10b981, #f59e0b, #ec4899, #8b5cf6, etc.).`;

    const userPromptText = `Generate a master step-by-step connected Mind Matrix for:
Topic: "${topic}"
Language: "${language}"
Detail Level: "${depth}"

Break it down into a complete, connected step-by-step roadmap where every concept is explained clearly with full depth!`;

    const responseSchema = {
      type: Type.OBJECT,
      required: ["title", "overview", "boxes"],
      properties: {
        title: { type: Type.STRING, description: "Master title of the matrix" },
        overview: { type: Type.STRING, description: "High-level summary of the entire roadmap" },
        boxes: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            required: ["id", "level", "title", "description", "color", "badge", "items"],
            properties: {
              id: { type: Type.STRING },
              stepNumber: { type: Type.INTEGER },
              level: { type: Type.INTEGER, description: "1 = Foundation/Core, 2 = Intermediate/Application, 3 = Advanced/Mastery" },
              title: { type: Type.STRING },
              subtitle: { type: Type.STRING },
              description: { type: Type.STRING, description: "Deep in-depth explanation of this step" },
              color: { type: Type.STRING, description: "Hex color code" },
              badge: { type: Type.STRING, description: "e.g. STEP 1: BASICS" },
              tags: { type: Type.ARRAY, items: { type: Type.STRING } },
              codeSnippet: { type: Type.STRING, description: "Code snippet or formula if applicable" },
              items: { type: Type.ARRAY, items: { type: Type.STRING }, description: "4-6 sub-steps or bullet points" },
              connectedTo: { type: Type.ARRAY, items: { type: Type.STRING }, description: "IDs of next steps connected with lines" },
              pageNumber: { type: Type.INTEGER }
            }
          }
        }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, userPromptText, responseSchema);
    const parsedData = JSON.parse(textResult.trim());
    res.json(parsedData);
  } catch (error: any) {
    console.error("Matrix generation error:", error);
    res.status(500).json({ error: error.message || "Failed to generate mind matrix" });
  }
});

// 10. API: Dedicated Visual AI Learning Chart, Multi-Level Concept Tree & Study Matrix Generator
app.post("/api/generate-learning-chart", async (req, res) => {
  try {
    const { topic, attachment, depth = "intermediate", language = "Bengali", additionalNotes = "" } = req.body;

    if (!topic && (!attachment || !attachment.dataBase64)) {
      res.status(400).json({ error: "Please provide a concept topic or attach a photo/note." });
      return;
    }

    const systemInstruction = `You are a World-Class Visual Educator, Master Pedagogy Architect, and Visual Diagram Specialist.
Your mission is to decompose complex topics, lessons, grammar rules, scientific mechanisms, or study notes into an exceptional, comprehensive, multi-tiered visual learning tree and structured knowledge matrix.

PEDAGOGICAL & STRUCTURAL RULES (CRITICAL):
1. MULTI-LEVEL HIERARCHICAL BREAKDOWN (শাখা-প্রশাখা বিভাজন):
   - Break the main root topic down into its primary logical branches (e.g., For Tense: 1. Present Tense, 2. Past Tense, 3. Future Tense).
   - Break EVERY primary branch down into its secondary sub-branches (e.g. For Present Tense: Present Indefinite/Simple, Present Continuous, Present Perfect, Present Perfect Continuous).
   - For every sub-branch, provide crystal-clear formulas/structures (e.g., "Subject + am/is/are + verb(ing) + object"), grammatical/scientific rules, practical real-life examples in English with clear Bengali translation, and common error alerts/memory tips!
2. COMPLETE COVERAGE (কোনো কিছু বাদ দেবেন না):
   - Ensure the hierarchy is 100% complete and fully populated.
   - For school/college topics (like English Grammar Tense, Parts of Speech, Voice Change, Photosynthesis, Periodic Table groups, Human Anatomy, Computer Architecture, Accounting Principles, Islamic Pillars & Branches), make sure all classifications and subtypes are accurately explained.
3. LANGUAGE & CLARITY:
   - If language is 'Bengali' or 'Bilingual', provide bilingual titles and rich Bengali explanations with English terminology so students can easily master the concept.
4. COMPARATIVE MATRIX:
   - Provide a concise summary table rows array that directly contrasts each sub-branch's structure and signature example.
5. SELF-TEST QUIZ:
   - Include 3 to 5 interactive practice questions with options and explanations to reinforce learning.
6. Return strictly valid JSON adhering precisely to the schema.`;

    const userPromptText = `Generate a master visual learning chart and multi-level tree for the following topic:
Topic: "${topic || 'Document Analysis'}"
Target Level/Depth: "${depth}"
Language: "${language}"
Additional Instructions: "${additionalNotes}"

Make sure every primary branch has its complete set of secondary sub-branches, complete with definition, formulas/structures, 2-3 bilingual examples, and practical tips!`;

    const responseSchema = {
      type: Type.OBJECT,
      required: ["title", "conceptCategory", "language", "summary", "rootNode", "keyTakeaways", "comparativeSummaryTable", "practiceQuestions"],
      properties: {
        title: { type: Type.STRING, description: "Official title of the chart" },
        conceptCategory: { type: Type.STRING, description: "Category (e.g. English Grammar, General Science, Biology, Physics, Computer Science, etc.)" },
        language: { type: Type.STRING },
        summary: { type: Type.STRING, description: "Comprehensive easy-to-understand conceptual overview" },
        keyTakeaways: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "4-6 essential high-yield bullet points"
        },
        rootNode: {
          type: Type.OBJECT,
          required: ["id", "title", "description", "level", "subNodes"],
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            subtitle: { type: Type.STRING },
            description: { type: Type.STRING },
            level: { type: Type.INTEGER },
            badge: { type: Type.STRING },
            formula: { type: Type.STRING },
            rules: { type: Type.ARRAY, items: { type: Type.STRING } },
            examples: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["text"],
                properties: {
                  text: { type: Type.STRING },
                  translation: { type: Type.STRING },
                  highlight: { type: Type.STRING }
                }
              }
            },
            tips: { type: Type.ARRAY, items: { type: Type.STRING } },
            color: { type: Type.STRING },
            icon: { type: Type.STRING },
            subNodes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["id", "title", "description", "level"],
                properties: {
                  id: { type: Type.STRING },
                  title: { type: Type.STRING },
                  subtitle: { type: Type.STRING },
                  description: { type: Type.STRING },
                  level: { type: Type.INTEGER },
                  badge: { type: Type.STRING },
                  formula: { type: Type.STRING },
                  rules: { type: Type.ARRAY, items: { type: Type.STRING } },
                  examples: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      required: ["text"],
                      properties: {
                        text: { type: Type.STRING },
                        translation: { type: Type.STRING },
                        highlight: { type: Type.STRING }
                      }
                    }
                  },
                  tips: { type: Type.ARRAY, items: { type: Type.STRING } },
                  color: { type: Type.STRING },
                  icon: { type: Type.STRING },
                  subNodes: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      required: ["id", "title", "description", "level"],
                      properties: {
                        id: { type: Type.STRING },
                        title: { type: Type.STRING },
                        subtitle: { type: Type.STRING },
                        description: { type: Type.STRING },
                        level: { type: Type.INTEGER },
                        badge: { type: Type.STRING },
                        formula: { type: Type.STRING },
                        rules: { type: Type.ARRAY, items: { type: Type.STRING } },
                        examples: {
                          type: Type.ARRAY,
                          items: {
                            type: Type.OBJECT,
                            required: ["text"],
                            properties: {
                              text: { type: Type.STRING },
                              translation: { type: Type.STRING },
                              highlight: { type: Type.STRING }
                            }
                          }
                        },
                        tips: { type: Type.ARRAY, items: { type: Type.STRING } },
                        color: { type: Type.STRING }
                      }
                    }
                  }
                }
              }
            }
          }
        },
        comparativeSummaryTable: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            required: ["branch", "subBranch", "structure", "example", "keyIdentifier"],
            properties: {
              branch: { type: Type.STRING },
              subBranch: { type: Type.STRING },
              structure: { type: Type.STRING },
              example: { type: Type.STRING },
              keyIdentifier: { type: Type.STRING }
            }
          }
        },
        practiceQuestions: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            required: ["question", "options", "answer", "explanation"],
            properties: {
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              answer: { type: Type.STRING },
              explanation: { type: Type.STRING }
            }
          }
        }
      }
    };

    let promptPayload: any = userPromptText;

    if (attachment && attachment.dataBase64) {
      let cleanBase64 = attachment.dataBase64;
      if (cleanBase64.includes(";base64,")) {
        cleanBase64 = cleanBase64.split(";base64,")[1];
      }

      const filePart = {
        inlineData: {
          mimeType: attachment.mimeType || "image/jpeg",
          data: cleanBase64
        }
      };

      const textPart = {
        text: `${userPromptText}\n\n[USER ATTACHED STUDY NOTE / PHOTO]: The user attached an image named "${attachment.name}". Carefully inspect the text, diagram, or handwriting in this image and convert all the topics and concepts into a complete, structured, hierarchical visual learning chart!`
      };

      promptPayload = { parts: [filePart, textPart] };
    }

    const textResult = await runGeneration(req, systemInstruction, promptPayload, responseSchema);
    const parsedData = JSON.parse(textResult.trim());
    res.json(parsedData);

  } catch (error: any) {
    console.error("Learning chart generation error:", error);
    res.status(500).json({ error: error.message || "Failed to generate learning chart" });
  }
});

// 11. API: AI Web Architect & Autonomous Code Modification Engine (For Admin Super Control)
app.post("/api/admin/ai-code-architect", async (req, res) => {
  try {
    const { 
      userInstruction, 
      language = "Bengali", 
      targetComponent = "general", 
      currentCodeContext = "",
      siteContext = {}
    } = req.body;

    if (!userInstruction || !userInstruction.trim()) {
      res.status(400).json({ error: "Instruction is required for the AI Architect" });
      return;
    }

    const systemInstruction = `You are the Master AI Web Architect, Full-Stack Engineer, and Autonomous Frontend & Backend Customizer for this web platform (Lekhok AI / ScribeMind AI).
You have full administrator-level authorization and supreme capability to write, modify, fix, redesign, or create new React/HTML/JS/Tailwind sections, UI components, data structures, and interactive widgets for this website based on the administrator's commands.

YOUR MISSION:
When the administrator gives a command (e.g. "Add a live currency converter", "Create a real-time word counter and pomodoro timer", "Change navigation bar to glassmorphism with neon accents", "Fix the card layout", "Add an interactive audio podcast bar", "Add custom floating feedback form"):
1. Provide a clear, friendly explanation in ${language}.
2. Generate clean, complete, modern production-grade HTML+Tailwind+JavaScript code for the new or modified section that can execute interactively in the browser.
3. If interactive JavaScript is needed (e.g. calculator logic, audio playing, state toggle, dynamic fetching), include the clean embedded <script> block inside the executableHtml so it actually runs and responds to user clicks/inputs!
4. If CSS styling updates or themes are requested, provide the customCss rules.
5. Formulate the widget config so it can be deployed directly into the live website without restart.

OUTPUT RULES:
Always return a structured JSON response conforming strictly to the requested schema.`;

    const userPromptText = `Admin Command / Code Modification Request:
"${userInstruction}"

Target Component / Area: ${targetComponent}
Website Title & Context: ${JSON.stringify(siteContext)}
Existing Code Context (if provided): ${currentCodeContext ? currentCodeContext.substring(0, 1500) : "N/A"}

Please architect the solution, write full working and executable code with interactive script logic, and formulate the live deployment config!`;

    const responseSchema = {
      type: Type.OBJECT,
      required: ["summary", "explanation", "generatedCode", "actionType", "executableHtml"],
      properties: {
        actionType: { 
          type: Type.STRING, 
          description: "One of: 'new_section', 'modify_code', 'fix_bug', 'theme_change', 'user_action', 'custom_widget'" 
        },
        summary: { type: Type.STRING, description: "Short 1-line summary of what was coded/configured" },
        explanation: { type: Type.STRING, description: "Detailed explanation in " + language + " of how this works" },
        generatedCode: { type: Type.STRING, description: "Full working React/JSX/TSX or HTML+Tailwind component code" },
        executableHtml: { 
          type: Type.STRING, 
          description: "Self-contained HTML + Tailwind CSS + interactive <script> logic that can be mounted directly into the live website DOM and execute seamlessly." 
        },
        customCss: { 
          type: Type.STRING, 
          description: "Optional custom CSS rules to inject globally into the website stylesheet" 
        },
        customJs: { 
          type: Type.STRING, 
          description: "Optional custom JavaScript to execute in global site runtime" 
        },
        suggestedWidget: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            icon: { type: Type.STRING, description: "Lucide icon name e.g. Sparkles, Code2, Cpu, Zap, Globe, Layers, DollarSign, Music, Shield" },
            customHtml: { type: Type.STRING, description: "Complete HTML + Tailwind + JS code snippet for the live widget" },
            active: { type: Type.BOOLEAN }
          }
        },
        suggestedStyles: {
          type: Type.OBJECT,
          properties: {
            primaryTheme: { type: Type.STRING },
            customNoticeHtml: { type: Type.STRING },
            announcementText: { type: Type.STRING },
            announcementActive: { type: Type.BOOLEAN }
          }
        },
        livePreviewHtml: { 
          type: Type.STRING, 
          description: "Self-contained HTML+Tailwind snippet that can be rendered directly in a live preview sandbox" 
        }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, userPromptText, responseSchema);
    const parsedData = JSON.parse(textResult.trim());
    res.json(parsedData);

  } catch (error: any) {
    console.error("AI Code Architect error:", error);
    res.status(500).json({ error: error.message || "AI Code Architect encountered an issue" });
  }
});

// Helper: Recursively walk project directory
async function getDirectoryTree(dirPath: string, relativeRoot = ""): Promise<any[]> {
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    const items: any[] = [];
    
    // Sort: directories first, then files alphabetically
    const sorted = entries.sort((a, b) => {
      if (a.isDirectory() && !b.isDirectory()) return -1;
      if (!a.isDirectory() && b.isDirectory()) return 1;
      return a.name.localeCompare(b.name);
    });

    for (const entry of sorted) {
      if (
        entry.name === "node_modules" ||
        entry.name === ".git" ||
        entry.name === "dist" ||
        entry.name === ".vite" ||
        entry.name === ".cache" ||
        entry.name.startsWith(".env") ||
        entry.name.endsWith(".log")
      ) {
        continue;
      }

      const relPath = relativeRoot ? `${relativeRoot}/${entry.name}` : entry.name;
      const fullPath = path.join(dirPath, entry.name);

      if (entry.isDirectory()) {
        const children = await getDirectoryTree(fullPath, relPath);
        items.push({
          name: entry.name,
          path: relPath,
          type: "directory",
          children
        });
      } else {
        const stat = await fs.stat(fullPath);
        const ext = path.extname(entry.name).toLowerCase();
        items.push({
          name: entry.name,
          path: relPath,
          type: "file",
          size: stat.size,
          extension: ext,
          updatedAt: stat.mtime
        });
      }
    }
    return items;
  } catch (e) {
    console.warn("Directory tree traversal warning:", e);
    return [];
  }
}

// 12. API: Project File Tree Explorer
app.get("/api/admin/project-tree", async (req, res) => {
  try {
    const rootDir = process.cwd();
    const tree = await getDirectoryTree(rootDir, "");
    res.json({
      rootPath: "/",
      tree
    });
  } catch (err: any) {
    console.error("Project tree error:", err);
    res.status(500).json({ error: err.message || "Failed to fetch project tree" });
  }
});

// 13. API: Read File Content
app.post("/api/admin/read-file", async (req, res) => {
  try {
    const { filePath } = req.body;
    if (!filePath) {
      res.status(400).json({ error: "File path is required" });
      return;
    }
    const safePath = path.normalize(filePath).replace(/^(\.\.[\/\\])+/, "");
    const fullPath = path.join(process.cwd(), safePath);

    if (!fullPath.startsWith(process.cwd())) {
      res.status(403).json({ error: "Access denied: file outside workspace" });
      return;
    }

    const content = await fs.readFile(fullPath, "utf-8");
    const stat = await fs.stat(fullPath);
    res.json({
      filePath: safePath,
      content,
      size: stat.size,
      extension: path.extname(safePath).toLowerCase(),
      updatedAt: stat.mtime
    });
  } catch (err: any) {
    console.error("Read file error:", err);
    res.status(500).json({ error: err.message || "Failed to read file content" });
  }
});

// 14. API: Save File Content Directly
app.post("/api/admin/save-file", async (req, res) => {
  try {
    const { filePath, content } = req.body;
    if (!filePath || content === undefined) {
      res.status(400).json({ error: "File path and content are required" });
      return;
    }
    const safePath = path.normalize(filePath).replace(/^(\.\.[\/\\])+/, "");
    const fullPath = path.join(process.cwd(), safePath);

    if (!fullPath.startsWith(process.cwd())) {
      res.status(403).json({ error: "Access denied: file outside workspace" });
      return;
    }

    await fs.mkdir(path.dirname(fullPath), { recursive: true });
    await fs.writeFile(fullPath, content, "utf-8");
    const stat = await fs.stat(fullPath);
    res.json({
      success: true,
      filePath: safePath,
      size: stat.size,
      message: `File ${safePath} successfully saved!`
    });
  } catch (err: any) {
    console.error("Save file error:", err);
    res.status(500).json({ error: err.message || "Failed to save file content" });
  }
});

// 15. API: Create New File
app.post("/api/admin/create-file", async (req, res) => {
  try {
    const { filePath, content = "" } = req.body;
    if (!filePath) {
      res.status(400).json({ error: "File path is required" });
      return;
    }
    const safePath = path.normalize(filePath).replace(/^(\.\.[\/\\])+/, "");
    const fullPath = path.join(process.cwd(), safePath);

    if (!fullPath.startsWith(process.cwd())) {
      res.status(403).json({ error: "Access denied: file outside workspace" });
      return;
    }

    await fs.mkdir(path.dirname(fullPath), { recursive: true });
    await fs.writeFile(fullPath, content, "utf-8");
    res.json({
      success: true,
      filePath: safePath,
      message: `File ${safePath} created successfully!`
    });
  } catch (err: any) {
    console.error("Create file error:", err);
    res.status(500).json({ error: err.message || "Failed to create file" });
  }
});

// 16. API: Autonomous AI Coding Engineer & Multi-File Assistant
app.post("/api/admin/ai-code-engineer", async (req, res) => {
  try {
    const {
      prompt,
      activeFilePath,
      activeFileContent,
      projectSummary,
      language = "Bengali"
    } = req.body;

    if (!prompt || !prompt.trim()) {
      res.status(400).json({ error: "Prompt is required" });
      return;
    }

    const systemInstruction = `You are the Lead Autonomous AI Software Engineer and Code Architect for this React + TypeScript + Vite + Tailwind + Express web application.
The administrator is commanding you to inspect, modify, debug, rewrite, optimize, or build new features directly into the project files.

YOUR RESPONSIBILITIES:
1. Provide a concise, friendly explanation in ${language} describing the fix or architectural enhancement.
2. Produce complete, syntactically clean, production-ready code for the target file without truncated fragments or pseudo-code placeholders.
3. Keep all necessary imports (React, Lucide icons, Framer Motion, Firebase, etc.) intact and properly typed.
4. Provide a clear diff summary of what lines or features were added/modified.`;

    const userPromptText = `User Command: "${prompt}"
Active File Path: ${activeFilePath || "Not specified"}
Current File Content:
\`\`\`
${activeFileContent ? activeFileContent.substring(0, 10000) : "No file context provided"}
\`\`\`
Project Overview: ${projectSummary || "Full-stack React + TypeScript + Vite + Tailwind + Express platform"}`;

    const responseSchema = {
      type: Type.OBJECT,
      required: ["summary", "explanation", "actionType", "targetFilePath", "updatedCode"],
      properties: {
        actionType: { 
          type: Type.STRING, 
          description: "One of: 'modify_file', 'create_file', 'fix_bug', 'optimize', 'refactor'" 
        },
        summary: { type: Type.STRING, description: "Short 1-line summary in " + language },
        explanation: { type: Type.STRING, description: "Detailed explanation of changes in " + language },
        targetFilePath: { type: Type.STRING, description: "Relative file path (e.g. src/components/MyComponent.tsx)" },
        updatedCode: { type: Type.STRING, description: "Complete, ready-to-save updated file content" },
        diffSummary: { type: Type.STRING, description: "Brief description of changes (e.g. Added PRO checkout button, fixed import error)" }
      }
    };

    const textResult = await runGeneration(req, systemInstruction, userPromptText, responseSchema);
    const parsedData = JSON.parse(textResult.trim());
    res.json(parsedData);
  } catch (err: any) {
    console.error("AI Code Engineer error:", err);
    res.status(500).json({ error: err.message || "Failed to process AI coding request" });
  }
});

// Serve static assets / handle Vite dev server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://localhost:${PORT}`);
  });
}

startServer();
