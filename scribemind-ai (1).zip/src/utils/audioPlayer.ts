// Shared Global High-Fidelity Audio Player Engine with Touch/Click Autoplay Unlock & Echo-Safe Lifecycle

let globalAudio: HTMLAudioElement | null = null;
let isAudioUnlocked = false;
let activeCancelFn: (() => void) | null = null;
let sharedAudioCtx: AudioContext | null = null;
let isCurrentlySpeaking = false;

function getSharedAudioContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!sharedAudioCtx || sharedAudioCtx.state === "closed") {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioCtx) {
      sharedAudioCtx = new AudioCtx();
    }
  }
  if (sharedAudioCtx && sharedAudioCtx.state === "suspended") {
    sharedAudioCtx.resume().catch(() => {});
  }
  return sharedAudioCtx;
}

// Play Iron Man / JARVIS futuristic HUD sound effect
export function playJarvisHudChime(type: "start_speaking" | "start_listening" | "acknowledge" = "start_speaking") {
  try {
    const ctx = getSharedAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === "start_speaking") {
      // 2-tone futuristic HUD chirp (880Hz -> 1320Hz)
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.exponentialRampToValueAtTime(1320, now + 0.07);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.start(now);
      osc.stop(now + 0.12);
    } else if (type === "start_listening") {
      // Soft high-tech ping (587Hz -> 880Hz)
      osc.type = "triangle";
      osc.frequency.setValueAtTime(587, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.08);
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
      osc.start(now);
      osc.stop(now + 0.14);
    } else {
      // Quick acknowledge click
      osc.type = "sine";
      osc.frequency.setValueAtTime(950, now);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
      osc.start(now);
      osc.stop(now + 0.06);
    }
  } catch (e) {}
}

// Unlock Autoplay on User Touch / Interaction
export function unlockAudioAutoplay() {
  if (!globalAudio) {
    globalAudio = new Audio();
    globalAudio.src = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA";
  }

  try {
    const playPromise = globalAudio.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          isAudioUnlocked = true;
          if (globalAudio && !isCurrentlySpeaking) {
            globalAudio.pause();
            globalAudio.currentTime = 0;
          }
        })
        .catch(() => {});
    }
  } catch (e) {}

  getSharedAudioContext();

  // Prime SpeechSynthesis ONLY if not already speaking
  if (typeof window !== "undefined" && "speechSynthesis" in window && !isCurrentlySpeaking) {
    try {
      window.speechSynthesis.resume();
    } catch (e) {}
  }
}

export function stopAllSpokenAudio() {
  isCurrentlySpeaking = false;
  if (activeCancelFn) {
    activeCancelFn();
    activeCancelFn = null;
  }

  if (globalAudio) {
    try {
      globalAudio.pause();
      globalAudio.currentTime = 0;
      globalAudio.onended = null;
      globalAudio.onerror = null;
      globalAudio.onplay = null;
      globalAudio.ontimeupdate = null;
      globalAudio.onwaiting = null;
      globalAudio.removeAttribute("src");
    } catch (e) {}
  }

  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    try {
      window.speechSynthesis.cancel();
    } catch (e) {}
  }
}

export function playSpokenAudioAloud(
  text: string,
  lang: "bn" | "en" | string,
  callbacks?: {
    onStart?: () => void;
    onEnd?: () => void;
    onError?: (err?: any) => void;
    isJarvisVoice?: boolean;
  }
): () => void {
  // Clean markdown, markdown syntax, symbols, and emojis
  const clean = text
    .replace(/```[\s\S]*?```/g, "")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/#{1,6}\s+/g, "")
    .replace(/!\[.*?\]\(.*?\)/g, "")
    .replace(/\[(.*?)\]\(.*?\)/g, "$1")
    .replace(/>\s*/g, "")
    .replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, "")
    .replace(/\s+/g, " ")
    .trim();

  if (!clean) {
    callbacks?.onEnd?.();
    return () => {};
  }

  stopAllSpokenAudio();
  isCurrentlySpeaking = true;

  const isBn = lang.startsWith("bn") || /[\u0980-\u09FF]/.test(clean);
  let isFinished = false;
  let hasTriggeredStart = false;
  let keepAliveInterval: any = null;

  const triggerStart = () => {
    if (!isFinished && !hasTriggeredStart) {
      hasTriggeredStart = true;
      playJarvisHudChime("start_speaking");
      callbacks?.onStart?.();
    }
  };

  const triggerEnd = () => {
    if (!isFinished) {
      isFinished = true;
      isCurrentlySpeaking = false;
      if (keepAliveInterval) clearInterval(keepAliveInterval);
      activeCancelFn = null;
      callbacks?.onEnd?.();
    }
  };

  // Robust Web Speech API fallback with Iron Man JARVIS deep masculine acoustic profile
  const playViaSpeechSynthesis = () => {
    if (isFinished) return;
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      triggerEnd();
      return;
    }

    try {
      window.speechSynthesis.cancel();
      window.speechSynthesis.resume();

      // Split into complete sentences
      const sentences = clean.match(/[^।!?.\n]+[।!?.\n]*/g) || [clean];
      let currentSentenceIdx = 0;

      const speakNextSentence = () => {
        if (isFinished) return;
        if (currentSentenceIdx >= sentences.length) {
          triggerEnd();
          return;
        }

        const sentenceText = sentences[currentSentenceIdx].trim();
        if (!sentenceText) {
          currentSentenceIdx++;
          speakNextSentence();
          return;
        }

        const utterance = new SpeechSynthesisUtterance(sentenceText);
        // Retain reference on window to prevent Chrome garbage collector bug
        (window as any).__currentSpeechUtterance = utterance;

        utterance.lang = isBn ? "bn-BD" : "en-US";
        // Iron Man / JARVIS deep articulate acoustic tuning:
        // Deep masculine baritone pitch (0.82) and crisp confident delivery rate (1.0)
        utterance.rate = 1.0;
        utterance.pitch = 0.82;

        const voices = window.speechSynthesis.getVoices();
        if (isBn) {
          // Look for male Bengali or South Asian voice, avoiding female named voices
          const bnVoice = voices.find((v) =>
            (v.lang.toLowerCase().includes("bn") || v.lang.toLowerCase().includes("bd") || v.lang.toLowerCase().includes("in")) &&
            !v.name.toLowerCase().includes("female") && !v.name.toLowerCase().includes("zira") && !v.name.toLowerCase().includes("swara")
          ) || voices.find((v) =>
            v.lang.toLowerCase().includes("bn") || v.lang.toLowerCase().includes("bd") || v.lang.toLowerCase().includes("in")
          );
          if (bnVoice) utterance.voice = bnVoice;
        } else {
          // Look for British English (UK / JARVIS style) or deep male English voice
          const jarvisVoice = voices.find((v) =>
            (v.lang.toLowerCase().includes("en-gb") || v.lang.toLowerCase().includes("en_gb")) &&
            (v.name.toLowerCase().includes("male") || v.name.toLowerCase().includes("george") || v.name.toLowerCase().includes("daniel") || v.name.toLowerCase().includes("arthur") || v.name.toLowerCase().includes("uk"))
          ) || voices.find((v) =>
            v.lang.toLowerCase().includes("en-gb") || v.lang.toLowerCase().includes("en_gb")
          ) || voices.find((v) =>
            v.lang.toLowerCase().includes("en") &&
            (v.name.toLowerCase().includes("male") || v.name.toLowerCase().includes("david") || v.name.toLowerCase().includes("guy") || v.name.toLowerCase().includes("mark") || v.name.toLowerCase().includes("google uk english male"))
          ) || voices.find((v) => v.lang.toLowerCase().startsWith("en") && !v.name.toLowerCase().includes("female") && !v.name.toLowerCase().includes("zira"));

          if (jarvisVoice) utterance.voice = jarvisVoice;
        }

        utterance.onstart = () => {
          triggerStart();
        };

        utterance.onend = () => {
          currentSentenceIdx++;
          speakNextSentence();
        };

        utterance.onerror = (e) => {
          console.warn("SpeechSynthesis utterance notice:", e);
          currentSentenceIdx++;
          speakNextSentence();
        };

        window.speechSynthesis.speak(utterance);
      };

      // Keepalive interval without aggressive pausing
      keepAliveInterval = setInterval(() => {
        if (window.speechSynthesis.speaking && window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      }, 2000);

      speakNextSentence();
    } catch (e) {
      console.warn("SpeechSynthesis error:", e);
      triggerEnd();
    }
  };

  // Primary: Attempt high-fidelity Gemini AI Deep Male JARVIS Voice ("Fenrir" / "Charon") first
  fetch("/api/jarvis-tts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      text: clean,
      voice: "Fenrir",
      language: isBn ? "Bengali" : "English"
    })
  })
    .then((res) => (res.ok ? res.json() : null))
    .then((data) => {
      if (isFinished) return;

      if (data?.audioBase64 && !data.fallback) {
        if (!globalAudio) globalAudio = new Audio();
        const audio = globalAudio;
        const mime = data.mimeType || "audio/wav";
        audio.src = `data:${mime};base64,${data.audioBase64}`;

        audio.onplay = () => triggerStart();
        audio.onended = () => triggerEnd();
        audio.onerror = () => playViaSpeechSynthesis();

        const playPromise = audio.play();
        if (playPromise !== undefined) {
          playPromise.catch(() => playViaSpeechSynthesis());
        }
      } else {
        // Fallback to masculine pitched SpeechSynthesis
        playViaSpeechSynthesis();
      }
    })
    .catch(() => {
      if (!isFinished) playViaSpeechSynthesis();
    });

  const cancelFn = () => {
    isFinished = true;
    isCurrentlySpeaking = false;
    if (keepAliveInterval) clearInterval(keepAliveInterval);
    
    if (globalAudio) {
      try {
        globalAudio.pause();
        globalAudio.currentTime = 0;
        globalAudio.onended = null;
        globalAudio.onerror = null;
        globalAudio.onplay = null;
        globalAudio.removeAttribute("src");
      } catch (e) {}
    }

    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {}
    }
  };

  activeCancelFn = cancelFn;
  return cancelFn;
}

export const globalAudioPlayer = {
  speakText: (
    text: string,
    lang: string = "Bengali",
    onEnded?: () => void,
    _rate?: number,
    _pitch?: number
  ) => {
    return playSpokenAudioAloud(text, lang, {
      onEnd: onEnded,
      onError: onEnded,
      isJarvisVoice: true
    });
  },
  stop: () => {
    stopAllSpokenAudio();
  },
  playChime: (type: "start_speaking" | "start_listening" | "acknowledge" = "start_speaking") => {
    playJarvisHudChime(type);
  }
};


