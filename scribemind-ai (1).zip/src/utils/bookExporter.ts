import { Book } from "../types";

/**
 * Converts markdown text into structured, clean, well-spaced HTML.
 * Correctly renders images, links, blockquotes, lists, headings, and paragraph spacing
 * so words are never lumped together and images are cleanly presented.
 */
export function formatMarkdownToRichHtml(raw: string = ""): string {
  if (!raw) return "<p class='prose-empty'><em>No content written for this chapter yet.</em></p>";

  // Normalize line breaks
  let text = raw.replace(/\r\n/g, "\n");

  // Handle image markdown: ![alt text](url)
  text = text.replace(/!\[([^\]]*)\]\((https?:\/\/[^\s\)]+)\)/g, (match, alt, url) => {
    return `<figure class="book-img-figure">
      <img src="${url}" alt="${alt || 'Book Illustration'}" class="book-embedded-img" loading="lazy" onerror="this.style.display='none'" />
      ${alt ? `<figcaption class="book-img-caption">${alt}</figcaption>` : ''}
    </figure>`;
  });

  // Handle standard link markdown: [text](url)
  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s\)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="book-link">$1</a>');

  // Handle custom tags like {color:#7c2d12}text{/color}
  text = text.replace(/\{color:([^}]+)\}([\s\S]*?)\{\/color\}/g, '<span style="color:$1;">$2</span>');
  text = text.replace(/\{size:([^}]+)\}([\s\S]*?)\{\/size\}/g, '<span style="font-size:$1;">$2</span>');
  text = text.replace(/\{bg:([^}]+)\}([\s\S]*?)\{\/bg\}/g, '<mark style="background-color:$1; padding: 2px 4px; border-radius: 3px;">$2</mark>');

  // Split into blocks by double newlines or paragraph breaks
  const blocks = text.split(/\n\s*\n/);

  const htmlBlocks = blocks.map(block => {
    const trimmed = block.trim();
    if (!trimmed) return "";

    // Code blocks
    if (trimmed.startsWith("```")) {
      const codeContent = trimmed.replace(/^```[a-zA-Z]*\n?/, "").replace(/```$/, "");
      return `<pre class="book-code-block"><code>${escapeHtml(codeContent)}</code></pre>`;
    }

    // Headings
    if (trimmed.startsWith("### ")) {
      return `<h4 class="book-h3">${formatInlineStyles(trimmed.slice(4))}</h4>`;
    }
    if (trimmed.startsWith("## ")) {
      return `<h3 class="book-h2">${formatInlineStyles(trimmed.slice(3))}</h3>`;
    }
    if (trimmed.startsWith("# ")) {
      return `<h2 class="book-h1">${formatInlineStyles(trimmed.slice(2))}</h2>`;
    }

    // Blockquote
    if (trimmed.startsWith("> ")) {
      const quoteText = trimmed.split("\n").map(l => l.replace(/^>\s*/, "")).join(" ");
      return `<blockquote class="book-blockquote">${formatInlineStyles(quoteText)}</blockquote>`;
    }

    // Unordered lists
    if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
      const items = trimmed.split("\n").map(line => {
        const itemText = line.replace(/^[-*]\s+/, "").trim();
        return `<li>${formatInlineStyles(itemText)}</li>`;
      }).join("");
      return `<ul class="book-list">${items}</ul>`;
    }

    // Ordered lists
    if (/^\d+\.\s+/.test(trimmed)) {
      const items = trimmed.split("\n").map(line => {
        const itemText = line.replace(/^\d+\.\s+/, "").trim();
        return `<li>${formatInlineStyles(itemText)}</li>`;
      }).join("");
      return `<ol class="book-ordered-list">${items}</ol>`;
    }

    // Standalone figures/images
    if (trimmed.startsWith("<figure")) {
      return trimmed;
    }

    // Standard paragraphs with inline formatting
    const lines = trimmed.split("\n").map(l => formatInlineStyles(l)).join("<br />\n");
    return `<p class="book-paragraph">${lines}</p>`;
  });

  return htmlBlocks.filter(Boolean).join("\n\n");
}

function formatInlineStyles(str: string): string {
  return str
    .replace(/\*\*\*([^*]+)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>')
    .replace(/`([^`]+)`/g, '<code class="book-inline-code">$1</code>');
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/**
 * Builds a complete, standalone A4-formatted HTML document for offline reading and PDF printing.
 */
export function generateA4BookHtml(book: Book, lang: "bn" | "en" = "bn"): string {
  const isBn = book.language?.toLowerCase().includes("bengali") || book.language?.toLowerCase().includes("bangla") || lang === "bn";
  const authorName = book.creatorName || (isBn ? "লেখক এআই পাবলিকেশন" : "Lekhok AI Publications");
  const coverBg = book.coverColor || "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)";

  return `<!DOCTYPE html>
<html lang="${isBn ? 'bn' : 'en'}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${book.title} — ${isBn ? 'সম্পূর্ণ বই' : 'Complete Book'}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Noto+Serif+Bengali:wght@400;500;600;700;800&family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-color: #7c2d12;
      --primary-light: #9a3412;
      --text-main: #1f2937;
      --text-muted: #6b7280;
      --bg-page: #ffffff;
      --bg-paper: #fcfbf9;
      --border-color: #e5e7eb;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Lora', 'Noto Serif Bengali', Georgia, serif;
      background-color: #f3f4f6;
      color: var(--text-main);
      line-height: 1.85;
      font-size: 16px;
      -webkit-font-smoothing: antialiased;
      padding-bottom: 60px;
    }

    /* Interactive Top Utility Bar (Hidden during PDF print) */
    .top-action-bar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background: #111827;
      color: #f9fafb;
      padding: 12px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      font-family: 'Inter', sans-serif;
    }

    .top-action-bar .brand {
      display: flex;
      align-items: center;
      gap: 10px;
      font-weight: 700;
      font-size: 14px;
      color: #fde68a;
    }

    .top-action-bar .actions {
      display: flex;
      gap: 12px;
    }

    .top-btn {
      background: #7c2d12;
      color: #ffffff;
      border: 1px solid #9a3412;
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all 0.2s ease;
      text-decoration: none;
    }

    .top-btn:hover {
      background: #9a3412;
      transform: translateY(-1px);
    }

    .top-btn-secondary {
      background: #374151;
      border-color: #4b5563;
    }

    .top-btn-secondary:hover {
      background: #4b5563;
    }

    /* Container for A4 Book Pages */
    .book-container {
      max-width: 820px;
      margin: 30px auto;
      padding: 0 16px;
    }

    .a4-page {
      background: var(--bg-page);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 60px 50px;
      margin-bottom: 30px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
      position: relative;
      min-height: 1000px;
      display: flex;
      flex-direction: column;
    }

    /* Cover Page Styling */
    .a4-cover-page {
      background: ${book.coverImageUrl ? `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.85)), url("${book.coverImageUrl}") center/cover no-repeat` : coverBg};
      color: #ffffff;
      border: none;
      border-radius: 16px;
      padding: 80px 50px;
      text-align: center;
      justify-content: space-between;
      min-height: 1050px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
      position: relative;
      overflow: hidden;
    }

    .cover-badge {
      display: inline-block;
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(8px);
      padding: 6px 18px;
      border-radius: 9999px;
      font-family: 'Inter', sans-serif;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 2px;
      text-transform: uppercase;
      margin-bottom: 20px;
    }

    .cover-title {
      font-size: 42px;
      font-weight: 800;
      line-height: 1.2;
      letter-spacing: -0.5px;
      margin-bottom: 24px;
      font-family: 'Noto Serif Bengali', 'Lora', serif;
      text-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }

    .cover-synopsis {
      font-size: 17px;
      line-height: 1.8;
      max-width: 600px;
      margin: 0 auto 30px auto;
      opacity: 0.92;
      font-style: italic;
    }

    .cover-footer {
      border-top: 1px solid rgba(255, 255, 255, 0.2);
      padding-top: 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: 'Inter', sans-serif;
      font-size: 12px;
      opacity: 0.85;
    }

    .cover-author-pill {
      background: rgba(255, 255, 255, 0.2);
      padding: 6px 16px;
      border-radius: 999px;
      font-weight: 700;
    }

    /* Table of Contents & Synopsis Page */
    .toc-title, .chapter-main-title {
      font-size: 28px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 12px;
      font-family: 'Noto Serif Bengali', 'Lora', serif;
    }

    .chapter-eyebrow {
      font-family: 'Inter', sans-serif;
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 2px;
      color: var(--primary-color);
      margin-bottom: 6px;
      display: block;
    }

    .chapter-divider {
      height: 3px;
      width: 60px;
      background: var(--primary-color);
      margin: 12px 0 28px 0;
      border-radius: 2px;
    }

    .synopsis-box {
      background: #fef8ee;
      border-left: 4px solid var(--primary-color);
      padding: 20px 24px;
      border-radius: 0 8px 8px 0;
      margin: 20px 0 36px 0;
      font-style: italic;
      color: #451a03;
      line-height: 1.8;
    }

    .toc-list {
      list-style: none;
      margin: 20px 0;
      border: 1px solid var(--border-color);
      border-radius: 8px;
      overflow: hidden;
      font-family: 'Inter', sans-serif;
    }

    .toc-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 14px 20px;
      border-bottom: 1px solid var(--border-color);
      text-decoration: none;
      color: var(--text-main);
      font-size: 14px;
      font-weight: 600;
      transition: background 0.15s ease;
    }

    .toc-item:last-child {
      border-bottom: none;
    }

    .toc-item:hover {
      background: #f9fafb;
      color: var(--primary-color);
    }

    .toc-ch-num {
      color: var(--primary-color);
      font-weight: 800;
      margin-right: 10px;
    }

    /* Chapter Content Typography */
    .chapter-body {
      flex: 1;
      font-size: 16.5px;
      line-height: 1.9;
      color: #27272a;
      text-align: justify;
    }

    .book-paragraph {
      margin-bottom: 1.6em;
      text-indent: 1.8em;
    }

    .book-h1 {
      font-size: 24px;
      font-weight: 700;
      margin: 32px 0 16px 0;
      color: #18181b;
    }

    .book-h2 {
      font-size: 20px;
      font-weight: 700;
      margin: 28px 0 14px 0;
      color: #27272a;
    }

    .book-h3 {
      font-size: 17px;
      font-weight: 700;
      margin: 22px 0 10px 0;
      color: #3f3f46;
    }

    .book-blockquote {
      border-left: 3.5px solid var(--primary-color);
      background: #fafaf9;
      padding: 14px 20px;
      margin: 24px 0;
      border-radius: 0 6px 6px 0;
      font-style: italic;
      color: #44403c;
    }

    .book-list, .book-ordered-list {
      margin: 18px 0 18px 30px;
      line-height: 1.8;
    }

    .book-list li, .book-ordered-list li {
      margin-bottom: 8px;
    }

    .book-code-block {
      background: #18181b;
      color: #f4f4f5;
      padding: 16px 20px;
      border-radius: 8px;
      font-family: monospace;
      font-size: 13px;
      margin: 24px 0;
      overflow-x: auto;
      line-height: 1.6;
    }

    .book-inline-code {
      background: #f4f4f5;
      color: #7c2d12;
      padding: 2px 6px;
      border-radius: 4px;
      font-family: monospace;
      font-size: 13.5px;
      border: 1px solid #e4e4e7;
    }

    /* Embedded Images in A4 book */
    .book-img-figure {
      margin: 30px auto;
      text-align: center;
      max-width: 90%;
    }

    .book-embedded-img {
      max-width: 100%;
      height: auto;
      max-height: 380px;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.08);
      display: block;
      margin: 0 auto;
      border: 1px solid var(--border-color);
    }

    .book-img-caption {
      font-family: 'Inter', sans-serif;
      font-size: 11.5px;
      color: var(--text-muted);
      margin-top: 8px;
      font-style: italic;
    }

    .book-link {
      color: var(--primary-color);
      text-decoration: underline;
      text-underline-offset: 3px;
    }

    .page-footer-num {
      border-top: 1px solid var(--border-color);
      padding-top: 16px;
      margin-top: 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-family: 'Inter', sans-serif;
      font-size: 11px;
      color: var(--text-muted);
      font-weight: 500;
    }

    /* PRINT AND PDF GENERATION STYLES (A4 PORTRAIT) */
    @media print {
      @page {
        size: A4 portrait;
        margin: 16mm 14mm 16mm 14mm;
      }

      * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
      }

      body {
        background: #ffffff !important;
        padding: 0 !important;
        font-size: 13.5pt;
        line-height: 1.75;
      }

      .top-action-bar {
        display: none !important;
      }

      .book-container {
        max-width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
      }

      .a4-page {
        box-shadow: none !important;
        border: none !important;
        padding: 0 !important;
        margin: 0 !important;
        min-height: 0 !important;
        page-break-before: always;
        page-break-after: always;
        break-before: page;
        break-after: page;
      }

      .a4-cover-page {
        page-break-before: avoid;
        page-break-after: always;
        break-after: page;
        min-height: 100vh !important;
        height: 100vh !important;
        padding: 40mm 20mm !important;
        box-sizing: border-box;
      }

      .cover-title {
        font-size: 32pt !important;
      }

      .cover-synopsis {
        font-size: 14pt !important;
      }

      .book-embedded-img {
        max-height: 280px !important;
        page-break-inside: avoid;
      }

      .book-blockquote, .book-code-block, .book-img-figure {
        page-break-inside: avoid;
      }
    }
  </style>
</head>
<body>

  <!-- Top Offline Reader & Print Bar -->
  <header class="top-action-bar">
    <div class="brand">
      <span>📖 Lekhok AI</span>
      <span>•</span>
      <span>${book.title}</span>
    </div>
    <div class="actions">
      <button onclick="window.print()" class="top-btn" title="Save as A4 PDF or Print">
        🖨️ ${isBn ? 'A4 PDF সেভ / প্রিন্ট করুন' : 'Print / Save A4 PDF'}
      </button>
    </div>
  </header>

  <main class="book-container">

    <!-- A4 COVER PAGE -->
    <section class="a4-page a4-cover-page">
      <div>
        <div class="cover-badge">${book.genre}</div>
        <h1 class="cover-title">${book.title}</h1>
        <p class="cover-synopsis">"${book.synopsis}"</p>
      </div>

      <div class="cover-footer">
        <div>
          <strong>Lekhok AI Publishing House</strong><br />
          <span>${isBn ? 'অত্যাধুনিক নিউরাল সাহিত্য ইঞ্জিন' : 'High-Fidelity Neural Manuscript'}</span>
        </div>
        <div class="cover-author-pill">
          ${authorName}
        </div>
      </div>
    </section>

    <!-- A4 TABLE OF CONTENTS & SYNOPSIS PAGE -->
    <section class="a4-page">
      <div>
        <span class="chapter-eyebrow">${isBn ? 'ভূমিকা ও সূচিপত্র' : 'Overview & Table of Contents'}</span>
        <h2 class="toc-title">${book.title}</h2>
        <div class="chapter-divider"></div>

        <div class="synopsis-box">
          <strong>${isBn ? 'সারসংক্ষেপ (Synopsis):' : 'Synopsis:'}</strong><br />
          ${book.synopsis}
        </div>

        <h3 class="book-h2" style="margin-top: 30px;">${isBn ? 'অধ্যায়সমূহের সূচি' : 'Table of Chapters'}</h3>
        <ul class="toc-list">
          ${book.chapters.map((ch, idx) => `
            <a href="#chapter-${idx + 1}" class="toc-item">
              <div>
                <span class="toc-ch-num">${isBn ? 'অধ্যায় ' + ch.chapterNumber : 'Chapter ' + ch.chapterNumber}</span>
                <span>${ch.title}</span>
              </div>
              <span style="color: var(--text-muted); font-size: 12px;">→</span>
            </a>
          `).join("")}
        </ul>
      </div>

      <div class="page-footer-num">
        <span>${book.title}</span>
        <span>${isBn ? 'সূচিপত্র' : 'Contents'}</span>
      </div>
    </section>

    <!-- A4 CHAPTERS -->
    ${book.chapters.map((ch, idx) => `
      <section id="chapter-${idx + 1}" class="a4-page">
        <header>
          <span class="chapter-eyebrow">${isBn ? `অধ্যায় ${ch.chapterNumber}` : `Chapter ${ch.chapterNumber}`}</span>
          <h2 class="chapter-main-title">${ch.title}</h2>
          <div class="chapter-divider"></div>
        </header>

        <article class="chapter-body">
          ${formatMarkdownToRichHtml(ch.content)}
        </article>

        <footer class="page-footer-num">
          <span>${book.title} — ${isBn ? `অধ্যায় ${ch.chapterNumber}` : `Ch ${ch.chapterNumber}`}</span>
          <span>${idx + 1} / ${book.chapters.length}</span>
        </footer>
      </section>
    `).join("")}

  </main>

</body>
</html>`;
}

/**
 * Directly downloads the book as a complete, styled A4 offline HTML document.
 */
export function downloadBookAsA4HTML(book: Book, lang: "bn" | "en" = "bn") {
  const htmlContent = generateA4BookHtml(book, lang);
  const blob = new Blob([htmlContent], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  const cleanTitle = (book.title || "Lekhok_Book").replace(/[^a-zA-Z0-9_\u0980-\u09FF]+/g, "_");
  anchor.href = url;
  anchor.download = `${cleanTitle}_A4_Book.html`;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
