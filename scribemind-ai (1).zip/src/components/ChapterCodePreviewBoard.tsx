import React, { useState, useEffect, useRef } from "react";
import { Play, Code, Eye, RefreshCw, X, ChevronDown, ChevronUp, Copy, Check, Terminal } from "lucide-react";

interface ChapterCodePreviewBoardProps {
  lang: "bn" | "en";
  chapterContent?: string;
  bookGenre?: string;
  bookTitle?: string;
  onClose?: () => void;
}

export const ChapterCodePreviewBoard: React.FC<ChapterCodePreviewBoardProps> = ({
  lang,
  chapterContent = "",
  bookGenre = "",
  bookTitle = "",
  onClose
}) => {
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("html");
  const [isOpen, setIsOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<"preview" | "code">("preview");
  const [copied, setCopied] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Automatically extract code from chapter markdown if available
  useEffect(() => {
    if (!chapterContent) return;

    // 1. Look for ```html ... ``` or ```xml ... ```
    const htmlMatch = chapterContent.match(/```(?:html|xml|htm)([\s\S]*?)```/i);
    if (htmlMatch && htmlMatch[1]?.trim()) {
      setCode(htmlMatch[1].trim());
      setLanguage("html");
      return;
    }

    // 2. Look for ```javascript ... ``` or ```js ... ```
    const jsMatch = chapterContent.match(/```(?:javascript|js|ts|typescript)([\s\S]*?)```/i);
    if (jsMatch && jsMatch[1]?.trim()) {
      setCode(jsMatch[1].trim());
      setLanguage("javascript");
      return;
    }

    // 3. Look for ```css ... ```
    const cssMatch = chapterContent.match(/```(?:css|scss)([\s\S]*?)```/i);
    if (cssMatch && cssMatch[1]?.trim()) {
      setCode(cssMatch[1].trim());
      setLanguage("css");
      return;
    }

    // 4. Any other code block
    const anyCodeMatch = chapterContent.match(/```(?:\w+)?([\s\S]*?)```/);
    if (anyCodeMatch && anyCodeMatch[1]?.trim()) {
      setCode(anyCodeMatch[1].trim());
      setLanguage("html");
      return;
    }

    // 5. Default fallback if this is a coding / HTML book
    const isCodingContext = 
      bookGenre.toLowerCase().includes("code") || 
      bookGenre.toLowerCase().includes("program") || 
      bookGenre.toLowerCase().includes("web") ||
      bookTitle.toLowerCase().includes("html") ||
      bookTitle.toLowerCase().includes("css") ||
      bookTitle.toLowerCase().includes("javascript");

    if (isCodingContext && !code) {
      setCode(`<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <title>HTML লাইভ প্রিভিউ</title>
  <style>
    body { font-family: 'Segoe UI', system-ui, sans-serif; padding: 24px; background: #0f172a; color: #f8fafc; text-align: center; }
    .card { background: #1e293b; border-radius: 16px; padding: 24px; max-width: 480px; margin: 0 auto; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
    h1 { color: #38bdf8; font-size: 24px; margin-bottom: 8px; }
    p { color: #94a3b8; font-size: 14px; line-height: 1.6; }
    button { background: #0284c7; color: white; border: none; padding: 10px 20px; font-weight: bold; border-radius: 8px; cursor: pointer; margin-top: 16px; transition: 0.2s; }
    button:hover { background: #0369a1; transform: translateY(-2px); }
  </style>
</head>
<body>
  <div class="card">
    <h1>🚀 লাইভ কোড প্রিভিউ বোর্ড</h1>
    <p>অধ্যায়ের কোড স্বয়ংক্রিয়ভাবে এখানে এক্সিকিউট হচ্ছে। এডিটর ট্যাবে গিয়ে কোড সরাসরি পরিবর্তনও করতে পারেন।</p>
    <button onclick="alert('অভিনন্দন! আপনার HTML কোড কাজ করছে!')">ক্লিক করুন</button>
  </div>
</body>
</html>`);
      setLanguage("html");
    }
  }, [chapterContent, bookGenre, bookTitle]);

  // If there is no code and not a coding context, don't render board
  const isCodingBook = 
    Boolean(code.trim()) ||
    bookGenre.toLowerCase().includes("code") || 
    bookGenre.toLowerCase().includes("program") || 
    bookGenre.toLowerCase().includes("web") ||
    bookTitle.toLowerCase().includes("html") ||
    bookTitle.toLowerCase().includes("css") ||
    bookTitle.toLowerCase().includes("javascript");

  if (!isCodingBook && !code) {
    return null;
  }

  // Update iframe preview content
  useEffect(() => {
    if (!iframeRef.current || !code) return;
    const iframe = iframeRef.current;
    
    // Prepare HTML template
    let fullHtml = code;
    const isFullHtml = code.toLowerCase().includes("<html") || code.toLowerCase().includes("<!doctype");
    
    if (!isFullHtml) {
      if (language.toLowerCase() === "javascript" || language.toLowerCase() === "js") {
        fullHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"/><style>body { font-family: system-ui, -apple-system, sans-serif; background: #090d16; color: #f8fafc; padding: 20px; margin: 0; } pre { background: #020617; padding: 12px; border-radius: 8px; border: 1px solid #1e293b; color: #38bdf8; overflow-x: auto; font-family: monospace; }</style></head><body><div id="app"></div><div id="console-logs"></div><script>
const oldLog = console.log;
const logContainer = document.getElementById('console-logs');
console.log = function(...args) {
  oldLog.apply(console, args);
  const p = document.createElement('pre');
  p.textContent = '› ' + args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a)).join(' ');
  logContainer.appendChild(p);
};
try {
  ${code}
} catch (err) {
  const errDiv = document.createElement('pre');
  errDiv.style.color = '#ef4444';
  errDiv.style.borderColor = '#ef4444';
  errDiv.textContent = '❌ Execution Error: ' + err.message;
  logContainer.appendChild(errDiv);
}
</script></body></html>`;
      } else if (language.toLowerCase() === "css") {
        fullHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"/><style>${code}</style></head><body><div class="demo-box" style="padding: 20px; text-align: center;"><h1>Sample Heading</h1><p>This is styled using your CSS code snippet.</p><button style="padding: 8px 16px;">Sample Button</button></div></body></html>`;
      } else {
        fullHtml = `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><script src="https://cdn.tailwindcss.com"></script><style>body { font-family: system-ui, -apple-system, sans-serif; margin: 0; padding: 16px; background: #0f172a; color: #f8fafc; }</style></head><body>${code}</body></html>`;
      }
    }

    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(fullHtml);
      doc.close();
    }
  }, [code, language, refreshKey, activeTab]);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full my-4 rounded-2xl overflow-hidden border-2 border-cyan-500/30 bg-[#070b14] shadow-xl text-left font-sans transition-all">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#0b1120] border-b border-slate-800 text-slate-200 select-none flex-wrap gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center font-black">
            <Terminal size={14} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-white tracking-wide">
                {lang === "bn" ? "বইয়ের লাইভ প্রিভিউ বোর্ড (Live Board)" : "Chapter Live Preview Board"}
              </span>
              <span className="text-[9px] px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 font-mono font-bold uppercase">
                {language}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 block">
              {lang === "bn" ? "অধ্যায়ের কোড স্বয়ংক্রিয়ভাবে এখানে লাইভ প্রদর্শিত ও এক্সিকিউট হচ্ছে" : "Chapter code is automatically loaded and executed live here"}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* View Mode Toggle */}
          <div className="flex bg-[#040711] p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab("preview")}
              className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                activeTab === "preview"
                  ? "bg-cyan-500 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Eye size={12} />
              <span>{lang === "bn" ? "প্রিভিউ" : "Preview"}</span>
            </button>
            <button
              onClick={() => setActiveTab("code")}
              className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                activeTab === "code"
                  ? "bg-cyan-500 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Code size={12} />
              <span>{lang === "bn" ? "কোড এডিটর" : "Edit Code"}</span>
            </button>
          </div>

          <button
            onClick={() => setRefreshKey(k => k + 1)}
            title="Refresh preview"
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 rounded-lg transition cursor-pointer"
          >
            <RefreshCw size={14} />
          </button>

          <button
            onClick={handleCopy}
            title="Copy code"
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 rounded-lg transition cursor-pointer"
          >
            {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
          </button>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
          >
            {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-rose-400 rounded-lg transition cursor-pointer"
            >
              <X size={15} />
            </button>
          )}
        </div>
      </div>

      {/* Main Body */}
      {isOpen && (
        <div className="p-3 bg-[#03060d]">
          {activeTab === "preview" ? (
            <div className="w-full bg-[#090d16] rounded-xl overflow-hidden border border-slate-800 min-h-[220px] max-h-[380px] relative shadow-inner">
              <iframe
                ref={iframeRef}
                title="Chapter Code Preview Frame"
                sandbox="allow-scripts allow-modals allow-forms allow-same-origin"
                className="w-full h-[260px] border-none block bg-transparent"
              />
            </div>
          ) : (
            <div className="w-full">
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                rows={10}
                className="w-full bg-[#050811] text-cyan-300 font-mono text-xs p-3.5 rounded-xl border border-slate-800 focus:outline-none focus:border-cyan-500 leading-relaxed resize-y"
                placeholder="Paste or write HTML / JS / CSS code here..."
              />
              <div className="flex justify-end gap-2 mt-2">
                <button
                  onClick={() => {
                    setActiveTab("preview");
                    setRefreshKey(k => k + 1);
                  }}
                  className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs rounded-xl shadow transition cursor-pointer flex items-center gap-1.5"
                >
                  <Play size={12} />
                  <span>{lang === "bn" ? "কোড রান করুন" : "Run Code"}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
