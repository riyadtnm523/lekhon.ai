import React, { useState, useRef, useEffect, useCallback } from "react";
import { 
  Code2, Play, RefreshCw, Download, Copy, Check, Sparkles, 
  Monitor, Tablet, Smartphone, Maximize2, Minimize2, Terminal, 
  Layers, Zap, Cpu, FileCode, CheckCircle2, AlertCircle, Wrench,
  Plus, Trash2, FolderArchive, Save, FolderOpen, FileText, ChevronRight,
  Settings2, Eye, Compass, Mic, MicOff, MessageSquare, History,
  Send, CornerDownLeft, Volume2, ShieldCheck, ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import JSZip from "jszip";
import { db } from "../firebase";
import { collection, addDoc, doc, deleteDoc } from "firebase/firestore";

interface ProjectFile {
  name: string;
  content: string;
}

interface SavedProject {
  id: string;
  name: string;
  description?: string;
  files: ProjectFile[];
  updatedAt: string;
}

interface AiChatEntry {
  id: string;
  role: "user" | "assistant";
  text: string;
  title?: string;
  timestamp: string;
}

interface CodeStudioPlaygroundProps {
  lang: "bn" | "en";
  currentUser: any;
  modelProvider?: string;
  customGeminiKey?: string;
  customDeepseekKey?: string;
}

export const PRESET_CODE_TEMPLATES = [
  {
    id: "luxury_store",
    name: "🛍️ Modern Luxury Watch & Tech Store",
    desc: "Complete e-commerce store with product grid, live search filter, cart drawer & checkout modal",
    files: [
      {
        name: "index.html",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Aura Luxury Watch Atelier</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
  <header class="navbar">
    <div class="logo">AURA<span>HOROLOGY</span></div>
    <div class="nav-links">
      <a href="#collection" class="active">Collection</a>
      <a href="#about">Craftsmanship</a>
      <a href="#contact">Concierge</a>
    </div>
    <div class="nav-actions">
      <button class="cart-btn" onclick="toggleCart()">
        <i class="fa-solid fa-bag-shopping"></i>
        <span class="cart-count" id="cart-count">0</span>
      </button>
    </div>
  </header>

  <section class="hero">
    <div class="hero-content">
      <span class="hero-tag">2026 Haute Horlogerie</span>
      <h1>Precision Engineered For Eternity</h1>
      <p>Hand-crafted celestial timepieces forged in grade-5 titanium and sapphire crystals.</p>
      <button class="btn-primary" onclick="scrollToProducts()">Explore Collection</button>
    </div>
  </section>

  <main class="container" id="collection">
    <div class="section-head">
      <h2>Master Collection</h2>
      <div class="filter-bar">
        <button class="filter-btn active" onclick="filterCategory('all', this)">All Watches</button>
        <button class="filter-btn" onclick="filterCategory('chronograph', this)">Chronographs</button>
        <button class="filter-btn" onclick="filterCategory('astronomical', this)">Astronomical</button>
        <button class="filter-btn" onclick="filterCategory('skeleton', this)">Tourbillon</button>
      </div>
    </div>
    <div class="product-grid" id="product-grid"></div>
  </main>

  <div class="cart-drawer" id="cart-drawer">
    <div class="cart-head">
      <h3>Your Bag</h3>
      <button onclick="toggleCart()" class="close-btn">&times;</button>
    </div>
    <div class="cart-items" id="cart-items">
      <p class="empty-msg">Your shopping bag is currently empty.</p>
    </div>
    <div class="cart-footer">
      <div class="cart-total">
        <span>Total:</span>
        <span id="cart-total-val">$0</span>
      </div>
      <button class="btn-checkout" onclick="checkout()">Proceed to Checkout</button>
    </div>
  </div>

  <script src="script.js"></script>
</body>
</html>`
      },
      {
        name: "style.css",
        content: `* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', system-ui, -apple-system, sans-serif; }
body { background: #07090e; color: #f1f5f9; overflow-x: hidden; }
.navbar { display: flex; justify-content: space-between; align-items: center; padding: 1.5rem 3rem; background: rgba(7,9,14,0.85); backdrop-filter: blur(16px); position: sticky; top: 0; z-index: 100; border-bottom: 1px solid rgba(255,255,255,0.06); }
.logo { font-size: 1.25rem; font-weight: 900; letter-spacing: 2px; color: #fff; }
.logo span { color: #f59e0b; font-weight: 300; margin-left: 4px; font-size: 0.85rem; }
.nav-links a { color: #94a3b8; text-decoration: none; margin: 0 1.25rem; font-size: 0.85rem; font-weight: 600; transition: 0.2s; }
.nav-links a:hover, .nav-links a.active { color: #f59e0b; }
.cart-btn { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #fff; padding: 0.6rem 1rem; border-radius: 9999px; cursor: pointer; display: flex; align-items: center; gap: 8px; font-size: 0.9rem; transition: 0.2s; }
.cart-btn:hover { background: rgba(245,158,11,0.2); border-color: #f59e0b; }
.cart-count { background: #f59e0b; color: #000; font-size: 0.75rem; font-weight: 900; padding: 2px 7px; border-radius: 9999px; }

.hero { min-height: 70vh; display: flex; align-items: center; justify-content: center; text-align: center; padding: 4rem 2rem; background: radial-gradient(circle at center, #1e1b4b 0%, #07090e 70%); }
.hero-content { max-width: 750px; }
.hero-tag { display: inline-block; background: rgba(245,158,11,0.15); color: #fcd34d; font-size: 0.75rem; font-weight: 800; letter-spacing: 2px; text-transform: uppercase; padding: 6px 16px; border-radius: 9999px; border: 1px solid rgba(245,158,11,0.3); margin-bottom: 1.5rem; }
.hero h1 { font-size: 3rem; font-weight: 900; line-height: 1.15; margin-bottom: 1.25rem; background: linear-gradient(135deg, #fff 0%, #94a3b8 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.hero p { color: #94a3b8; font-size: 1.1rem; line-height: 1.6; margin-bottom: 2rem; }
.btn-primary { background: linear-gradient(135deg, #f59e0b, #d97706); color: #000; border: 0; padding: 0.9rem 2.2rem; font-size: 0.95rem; font-weight: 800; border-radius: 12px; cursor: pointer; transition: 0.2s; box-shadow: 0 10px 25px rgba(245,158,11,0.3); }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 15px 35px rgba(245,158,11,0.5); }

.container { max-width: 1200px; margin: 0 auto; padding: 4rem 2rem; }
.section-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2.5rem; flex-wrap: wrap; gap: 1rem; }
.section-head h2 { font-size: 2rem; font-weight: 800; }
.filter-bar { display: flex; gap: 0.5rem; flex-wrap: wrap; }
.filter-btn { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); color: #94a3b8; padding: 0.5rem 1.1rem; border-radius: 8px; font-size: 0.8rem; font-weight: 700; cursor: pointer; transition: 0.2s; }
.filter-btn.active, .filter-btn:hover { background: #f59e0b; color: #000; border-color: #f59e0b; }

.product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 2rem; }
.product-card { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 20px; overflow: hidden; transition: 0.3s; display: flex; flex-direction: column; }
.product-card:hover { transform: translateY(-6px); border-color: rgba(245,158,11,0.5); box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
.card-img { height: 200px; display: flex; align-items: center; justify-content: center; font-size: 4.5rem; background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.01)); }
.card-body { padding: 1.5rem; flex-1; display: flex; flex-direction: column; justify-content: space-between; }
.card-body h4 { font-size: 1.1rem; font-weight: 800; margin-bottom: 0.5rem; color: #fff; }
.card-body p { color: #64748b; font-size: 0.8rem; line-height: 1.5; margin-bottom: 1rem; }
.card-footer { display: flex; justify-content: space-between; align-items: center; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.06); }
.price { font-size: 1.25rem; font-weight: 900; color: #f59e0b; }
.btn-add { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 0.5rem 1rem; border-radius: 8px; font-weight: 700; font-size: 0.8rem; cursor: pointer; transition: 0.2s; }
.btn-add:hover { background: #f59e0b; color: #000; border-color: #f59e0b; }

.cart-drawer { position: fixed; top: 0; right: -420px; width: 400px; max-width: 90vw; height: 100vh; background: #0b0f19; border-left: 1px solid rgba(255,255,255,0.1); z-index: 200; transition: right 0.35s cubic-bezier(0.16, 1, 0.3, 1); display: flex; flex-direction: column; box-shadow: -20px 0 50px rgba(0,0,0,0.8); }
.cart-drawer.open { right: 0; }
.cart-head { display: flex; justify-content: space-between; align-items: center; padding: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.08); }
.cart-head h3 { font-size: 1.2rem; font-weight: 800; }
.close-btn { background: transparent; border: 0; color: #94a3b8; font-size: 1.5rem; cursor: pointer; }
.cart-items { flex: 1; padding: 1.5rem; overflow-y: auto; display: flex; flex-direction: column; gap: 1rem; }
.cart-item { display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.04); padding: 1rem; border-radius: 12px; border: 1px solid rgba(255,255,255,0.06); }
.cart-item-info h5 { font-size: 0.9rem; font-weight: 700; }
.cart-item-info span { color: #f59e0b; font-size: 0.85rem; font-weight: 800; }
.btn-del { background: transparent; border: 0; color: #ef4444; cursor: pointer; font-size: 1rem; }
.cart-footer { padding: 1.5rem; border-top: 1px solid rgba(255,255,255,0.08); background: rgba(0,0,0,0.3); }
.cart-total { display: flex; justify-content: space-between; font-size: 1.1rem; font-weight: 800; margin-bottom: 1rem; }
.btn-checkout { width: 100%; background: #f59e0b; color: #000; border: 0; padding: 1rem; font-size: 0.95rem; font-weight: 900; border-radius: 12px; cursor: pointer; transition: 0.2s; }
.btn-checkout:hover { background: #d97706; }`
      },
      {
        name: "script.js",
        content: `const products = [
  { id: 1, name: "Aura Celestial Chrono", cat: "chronograph", price: 4200, icon: "⏱️", desc: "Forged in brushed titanium with double chronograph complication." },
  { id: 2, name: "Orion Orbit Tourbillon", cat: "skeleton", price: 9800, icon: "🪐", desc: "Floating 60-second tourbillon with sapphire crystal exhibition back." },
  { id: 3, name: "Lunar Eclipse Moonphase", cat: "astronomical", price: 6500, icon: "🌙", desc: "Genuine meteorite dial with hand-painted perpetual moonphase." },
  { id: 4, name: "Vanguard Black Carbon", cat: "chronograph", price: 3900, icon: "⚡", desc: "Ultralight forged carbon chassis with ceramic tachymeter bezel." },
  { id: 5, name: "Cosmic Odyssey Skeleton", cat: "skeleton", price: 8400, icon: "✨", desc: "Hand-engraved skeleton movement with 72-hour power reserve." },
  { id: 6, name: "Solstice Gold Edition", cat: "astronomical", price: 12500, icon: "☀️", desc: "18k solid rose gold casing with grand feu enamel solar dial." }
];

let cart = [];

function renderProducts(items) {
  const grid = document.getElementById('product-grid');
  grid.innerHTML = items.map(p => \`
    <div class="product-card">
      <div class="card-img">\${p.icon}</div>
      <div class="card-body">
        <div>
          <h4>\${p.name}</h4>
          <p>\${p.desc}</p>
        </div>
        <div class="card-footer">
          <span class="price">$\${p.price.toLocaleString()}</span>
          <button class="btn-add" onclick="addToCart(\${p.id})">Add to Bag</button>
        </div>
      </div>
    </div>
  \`).join('');
}

function filterCategory(cat, btn) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  if (cat === 'all') {
    renderProducts(products);
  } else {
    renderProducts(products.filter(p => p.cat === cat));
  }
}

function toggleCart() {
  document.getElementById('cart-drawer').classList.toggle('open');
}

function addToCart(id) {
  const p = products.find(i => i.id === id);
  if (p) {
    cart.push(p);
    updateCartUI();
    document.getElementById('cart-drawer').classList.add('open');
  }
}

function removeFromCart(idx) {
  cart.splice(idx, 1);
  updateCartUI();
}

function updateCartUI() {
  document.getElementById('cart-count').innerText = cart.length;
  const itemsContainer = document.getElementById('cart-items');
  
  if (cart.length === 0) {
    itemsContainer.innerHTML = '<p class="empty-msg" style="color:#64748b; text-align:center; padding:2rem 0;">Your shopping bag is currently empty.</p>';
    document.getElementById('cart-total-val').innerText = '$0';
    return;
  }

  itemsContainer.innerHTML = cart.map((p, idx) => \`
    <div class="cart-item">
      <div class="cart-item-info">
        <h5>\${p.name}</h5>
        <span>$\${p.price.toLocaleString()}</span>
      </div>
      <button class="btn-del" onclick="removeFromCart(\${idx})">&times;</button>
    </div>
  \`).join('');

  const total = cart.reduce((sum, p) => sum + p.price, 0);
  document.getElementById('cart-total-val').innerText = '$' + total.toLocaleString();
}

function checkout() {
  if (cart.length === 0) {
    alert("Please add items to your cart first!");
    return;
  }
  alert("🎉 Thank you for your luxury order! Our concierge will contact you shortly.");
  cart = [];
  updateCartUI();
  toggleCart();
}

function scrollToProducts() {
  document.getElementById('collection').scrollIntoView({ behavior: 'smooth' });
}

renderProducts(products);`
      }
    ]
  },
  {
    id: "solar_3d",
    name: "🪐 3D Solar System Simulation",
    desc: "Interactive Orbiting Planets & Starfield with physics engine",
    files: [
      {
        name: "index.html",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cosmic Planetary Simulation</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div id="info">
    <h3>Cosmic Planetary Simulation</h3>
    <p>Move cursor to rotate & interact with gravity</p>
  </div>
  <canvas id="c"></canvas>
  <script src="script.js"></script>
</body>
</html>`
      },
      {
        name: "style.css",
        content: `* { box-sizing: border-box; }
body { margin: 0; background: #030712; overflow: hidden; font-family: system-ui, sans-serif; color: #fff; }
canvas { display: block; }
#info { position: absolute; top: 15px; left: 15px; background: rgba(0,0,0,0.65); backdrop-filter: blur(10px); padding: 12px 18px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.12); box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
h3 { margin: 0 0 4px 0; font-size: 15px; color: #f59e0b; font-weight: 700; }
p { margin: 0; font-size: 11px; opacity: 0.8; }`
      },
      {
        name: "script.js",
        content: `const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
let w, h;
function resize() {
  w = canvas.width = window.innerWidth;
  h = canvas.height = window.innerHeight;
}
window.addEventListener('resize', resize);
resize();

const planets = [
  { name: 'Mercury', r: 4, dist: 55, speed: 0.04, color: '#94a3b8' },
  { name: 'Venus', r: 7, dist: 85, speed: 0.025, color: '#f59e0b' },
  { name: 'Earth', r: 8, dist: 125, speed: 0.018, color: '#38bdf8' },
  { name: 'Mars', r: 6, dist: 165, speed: 0.014, color: '#ef4444' },
  { name: 'Jupiter', r: 16, dist: 225, speed: 0.009, color: '#eab308' },
  { name: 'Saturn', r: 13, dist: 290, speed: 0.006, color: '#fcd34d', ring: true }
];

let angle = 0;
function draw() {
  ctx.fillStyle = 'rgba(3, 7, 18, 0.2)';
  ctx.fillRect(0, 0, w, h);

  const cx = w / 2;
  const cy = h / 2;

  // Draw Sun with glowing rays
  const sunGrad = ctx.createRadialGradient(cx, cy, 5, cx, cy, 35);
  sunGrad.addColorStop(0, '#fef08a');
  sunGrad.addColorStop(0.5, '#f59e0b');
  sunGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, 35, 0, Math.PI * 2);
  ctx.fill();

  // Orbits & Planets
  planets.forEach((p, idx) => {
    ctx.beginPath();
    ctx.arc(cx, cy, p.dist, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.stroke();

    const a = angle * p.speed * 2 + idx;
    const px = cx + Math.cos(a) * p.dist;
    const py = cy + Math.sin(a) * p.dist;

    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(px, py, p.r, 0, Math.PI * 2);
    ctx.fill();

    if (p.ring) {
      ctx.beginPath();
      ctx.ellipse(px, py, p.r * 2.2, p.r * 0.7, Math.PI / 4, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(252, 211, 77, 0.6)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  });

  angle += 0.02;
  requestAnimationFrame(draw);
}
draw();`
      }
    ]
  },
  {
    id: "neon_calc",
    name: "🧮 Cyber Neon Glass Calculator",
    desc: "Responsive scientific calculator with sleek glassmorphism and sound",
    files: [
      {
        name: "index.html",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cyber Neon Calculator</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="calc">
    <div class="screen">
      <div class="prev" id="prev"></div>
      <div class="curr" id="curr">0</div>
    </div>
    <div class="grid">
      <button class="clear" onclick="clearAll()">AC</button>
      <button class="op" onclick="del()">DEL</button>
      <button class="op" onclick="setOp('%')">%</button>
      <button class="op" onclick="setOp('/')">÷</button>
      <button onclick="num('7')">7</button>
      <button onclick="num('8')">8</button>
      <button onclick="num('9')">9</button>
      <button class="op" onclick="setOp('*')">×</button>
      <button onclick="num('4')">4</button>
      <button onclick="num('5')">5</button>
      <button onclick="num('6')">6</button>
      <button class="op" onclick="setOp('-')">-</button>
      <button onclick="num('1')">1</button>
      <button onclick="num('2')">2</button>
      <button onclick="num('3')">3</button>
      <button class="op" onclick="setOp('+')">+</button>
      <button onclick="num('0')">0</button>
      <button onclick="num('.')">.</button>
      <button class="eq" onclick="calc()">=</button>
    </div>
  </div>
  <script src="script.js"></script>
</body>
</html>`
      },
      {
        name: "style.css",
        content: `* { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, sans-serif; }
body { background: linear-gradient(135deg, #090d16, #17132a); min-height: 100vh; display: flex; align-items: center; justify-content: center; color: #fff; padding: 20px; }
.calc { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(20px); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 28px; padding: 24px; width: 330px; box-shadow: 0 20px 50px rgba(0,0,0,0.5); }
.screen { background: rgba(0, 0, 0, 0.45); border-radius: 18px; padding: 18px; text-align: right; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.08); }
.screen .prev { font-size: 13px; color: #94a3b8; min-height: 18px; }
.screen .curr { font-size: 28px; font-weight: 800; color: #38bdf8; word-break: break-all; }
.grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
button { background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.1); color: #fff; padding: 16px; font-size: 18px; font-weight: 700; border-radius: 16px; cursor: pointer; transition: 0.15s; }
button:hover { background: rgba(255, 255, 255, 0.18); transform: translateY(-2px); }
button:active { transform: translateY(0); }
.op { background: rgba(245, 158, 11, 0.2); color: #fbbf24; border-color: rgba(245, 158, 11, 0.3); }
.eq { background: linear-gradient(135deg, #0284c7, #38bdf8); color: #fff; grid-column: span 2; }
.clear { background: rgba(239, 68, 68, 0.2); color: #f87171; }`
      },
      {
        name: "script.js",
        content: `let curr = '0', prev = '', op = '';
const currEl = document.getElementById('curr');
const prevEl = document.getElementById('prev');
function update() {
  currEl.innerText = curr;
  prevEl.innerText = prev + (op ? ' ' + op : '');
}
function num(n) {
  if (curr === '0' && n !== '.') curr = n;
  else curr += n;
  update();
}
function setOp(o) {
  if (curr === '') return;
  op = o;
  prev = curr;
  curr = '';
  update();
}
function calc() {
  if (!op || !prev || !curr) return;
  let a = parseFloat(prev), b = parseFloat(curr), res = 0;
  if (op === '+') res = a + b;
  if (op === '-') res = a - b;
  if (op === '*') res = a * b;
  if (op === '/') res = b === 0 ? 'Error' : a / b;
  if (op === '%') res = a % b;
  curr = res.toString();
  prev = '';
  op = '';
  update();
}
function clearAll() { curr = '0'; prev = ''; op = ''; update(); }
function del() { curr = curr.slice(0, -1) || '0'; update(); }`
      }
    ]
  }
];

export const CodeStudioPlayground: React.FC<CodeStudioPlaygroundProps> = ({
  lang,
  currentUser,
  customGeminiKey,
  customDeepseekKey
}) => {
  const [projectName, setProjectName] = useState("Aura Luxury Watch Atelier");
  const [files, setFiles] = useState<ProjectFile[]>(PRESET_CODE_TEMPLATES[0].files);
  const [activeFileName, setActiveFileName] = useState("index.html");
  const [deviceView, setDeviceView] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showAiAssistant, setShowAiAssistant] = useState(true);
  const [activeTab, setActiveTab] = useState<"editor" | "saved_projects" | "templates">("editor");

  // AI Architect State
  const [aiPrompt, setAiPrompt] = useState("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [selectedAiModel, setSelectedAiModel] = useState<"gemini-3.7-flash" | "gemini-2.5-flash" | "deepseek">("gemini-3.7-flash");
  const [aiHistory, setAiHistory] = useState<AiChatEntry[]>(() => {
    return [
      {
        id: "entry_init",
        role: "assistant",
        text: lang === "bn" 
          ? "নমস্কার! আমি কোড স্টুডিও এআই আর্কিটেক্ট। আপনি আমাকে যা বানাতে বলবেন (যেমন: ওয়েবসাইট, গেম, ড্যাশবোর্ড, ক্যালকুলেটর), আমি সম্পূর্ণ কোড লিখে বানিয়ে দেব এবং পরবর্তীতে আপনার নির্দেশমতো সংশোধন বা নতুন ফিচার যোগ করে দেব।" 
          : "Hello! I am your AI Web & Code Architect. Tell me what website, game, or tool to build, and I will write complete production code and iteratively refine it as you instruct!",
        title: "Aura Luxury Watch Atelier",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      }
    ];
  });

  // Voice Dictation for Prompts
  const [isVoiceDictating, setIsVoiceDictating] = useState(false);
  const dictationRef = useRef<any>(null);

  // New File Modal
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newFileNameInput, setNewFileNameInput] = useState("");

  // Saved Projects in LocalStorage
  const [savedProjects, setSavedProjects] = useState<SavedProject[]>(() => {
    const saved = localStorage.getItem("lekhok_saved_code_projects");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [];
  });
  const [isSavingProject, setIsSavingProject] = useState(false);
  const [copied, setCopied] = useState(false);

  const iframeRef = useRef<HTMLIFrameElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const activeFile = files.find(f => f.name === activeFileName) || files[0] || { name: "index.html", content: "" };

  // Scroll chat to bottom on new AI interaction
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [aiHistory]);

  // Generate Bundled HTML for preview
  const generateBundledHTML = useCallback(() => {
    const htmlFile = files.find(f => f.name.endsWith(".html")) || { name: "index.html", content: "<h1>No HTML file</h1>" };
    const cssFiles = files.filter(f => f.name.endsWith(".css"));
    const jsFiles = files.filter(f => f.name.endsWith(".js"));

    let fullHTML = htmlFile.content;

    // Inject all CSS files inline
    if (cssFiles.length > 0) {
      const combinedCSS = cssFiles.map(c => `/* --- ${c.name} --- */\n${c.content}`).join("\n\n");
      if (fullHTML.includes("</head>")) {
        fullHTML = fullHTML.replace("</head>", `<style>\n${combinedCSS}\n</style>\n</head>`);
      } else {
        fullHTML = `<style>\n${combinedCSS}\n</style>\n` + fullHTML;
      }
    }

    // Inject all JS files inline
    if (jsFiles.length > 0) {
      const combinedJS = jsFiles.map(j => `/* --- ${j.name} --- */\n${j.content}`).join("\n\n");
      if (fullHTML.includes("</body>")) {
        fullHTML = fullHTML.replace("</body>", `<script>\n${combinedJS}\n</script>\n</body>`);
      } else {
        fullHTML = fullHTML + `\n<script>\n${combinedJS}\n</script>`;
      }
    }

    return fullHTML;
  }, [files]);

  // Render iframe preview safely
  const renderBundledPreview = useCallback(() => {
    if (!iframeRef.current) return;
    const bundledHTML = generateBundledHTML();
    const doc = iframeRef.current.contentDocument || iframeRef.current.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(bundledHTML);
      doc.close();
    }
  }, [generateBundledHTML]);

  // Re-render preview whenever files change
  useEffect(() => {
    const timer = setTimeout(() => {
      renderBundledPreview();
    }, 200);
    return () => clearTimeout(timer);
  }, [files, renderBundledPreview]);

  // Content changes in active file
  const handleContentChange = (newVal: string) => {
    setFiles(prev => prev.map(f => f.name === activeFileName ? { ...f, content: newVal } : f));
  };

  // Create new file
  const handleCreateFile = () => {
    if (!newFileNameInput.trim()) return;
    const sanitized = newFileNameInput.trim();
    if (files.some(f => f.name.toLowerCase() === sanitized.toLowerCase())) {
      alert(lang === "bn" ? "এই নামের ফাইল ইতিমধ্যে বিদ্যমান!" : "A file with this name already exists!");
      return;
    }
    const defaultContent = sanitized.endsWith(".html")
      ? `<!DOCTYPE html>\n<html>\n<head>\n  <title>New Page</title>\n</head>\n<body>\n  <h1>New Page</h1>\n</body>\n</html>`
      : sanitized.endsWith(".css")
      ? `/* Styles for ${sanitized} */\n`
      : sanitized.endsWith(".js")
      ? `// JavaScript for ${sanitized}\n`
      : "";

    const updated = [...files, { name: sanitized, content: defaultContent }];
    setFiles(updated);
    setActiveFileName(sanitized);
    setNewFileNameInput("");
    setShowNewFileModal(false);
  };

  // Delete file
  const handleDeleteFile = (fileName: string) => {
    if (files.length <= 1) {
      alert(lang === "bn" ? "কমপক্ষে একটি ফাইল থাকতে হবে!" : "You must have at least one file!");
      return;
    }
    if (confirm(lang === "bn" ? `আপনি কি '${fileName}' ফাইলটি মুছে ফেলতে চান?` : `Are you sure you want to delete '${fileName}'?`)) {
      const remaining = files.filter(f => f.name !== fileName);
      setFiles(remaining);
      if (activeFileName === fileName) {
        setActiveFileName(remaining[0].name);
      }
    }
  };

  // Voice Dictation for prompt input
  const toggleVoiceDictation = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(lang === "bn" ? "ভয়েস ডিকটেশনের জন্য গুগল ক্রোম ব্যবহার করুন।" : "Please use Google Chrome for voice dictation.");
      return;
    }

    if (isVoiceDictating) {
      if (dictationRef.current) {
        try { dictationRef.current.stop(); } catch (e) {}
      }
      setIsVoiceDictating(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = lang === "bn" ? "bn-BD" : "en-US";

    recognition.onstart = () => setIsVoiceDictating(true);
    recognition.onresult = (event: any) => {
      let transcript = "";
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setAiPrompt(prev => (prev ? prev + " " : "") + transcript);
    };
    recognition.onend = () => setIsVoiceDictating(false);
    recognition.onerror = () => setIsVoiceDictating(false);

    dictationRef.current = recognition;
    try {
      recognition.start();
    } catch (e) {
      setIsVoiceDictating(false);
    }
  };

  // AI Generation with Gemini 3.7 Flash & Iterative Refinement
  const handleAiGenerate = async (action: "generate" | "fix" | "enhance", overridePrompt?: string) => {
    const promptToSend = overridePrompt || aiPrompt;
    if (!promptToSend.trim() && action === "generate") return;
    setIsAiLoading(true);

    const userEntry: AiChatEntry = {
      id: "usr_" + Date.now(),
      role: "user",
      text: promptToSend.trim() || (action === "fix" ? "Fix code bugs & errors" : "Enhance UI design & responsiveness"),
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setAiHistory(prev => [...prev, userEntry]);
    setAiPrompt("");

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (selectedAiModel === "deepseek") {
        headers["x-model-provider"] = "deepseek";
      } else {
        headers["x-model-provider"] = "gemini";
      }
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const res = await fetch("/api/code-studio-ai", {
        method: "POST",
        headers,
        body: JSON.stringify({
          prompt: promptToSend || "Enhance code with modern UI, robust error handling, animations and responsive design.",
          currentCode: activeFile.content,
          files,
          activeFile: activeFileName,
          action,
          language: activeFileName.split('.').pop() || "html",
          requestedModel: selectedAiModel,
          history: aiHistory.slice(-6)
        })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to generate code with AI");
      }

      const data = await res.json();
      
      if (data.title && (!projectName || projectName === "Aura Luxury Watch Atelier" || projectName === "Cyber Space Web App")) {
        setProjectName(data.title);
      }

      if (Array.isArray(data.files) && data.files.length > 0) {
        setFiles(data.files);
        if (data.files.some((f: any) => f.name === activeFileName)) {
          // Keep active
        } else {
          setActiveFileName(data.files[0].name);
        }
      } else if (data.code) {
        handleContentChange(data.code);
      }

      const aiEntry: AiChatEntry = {
        id: "ai_" + Date.now(),
        role: "assistant",
        text: data.explanation || (lang === "bn" ? "আমি কোড তৈরি এবং আপডেট সম্পন্ন করেছি। লাইভ প্রিভিউতে পরিবর্তন দেখুন।" : "I have generated and updated the project code. Check the live preview!"),
        title: data.title,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      setAiHistory(prev => [...prev, aiEntry]);
    } catch (err: any) {
      console.error("AI Code error:", err);
      const errEntry: AiChatEntry = {
        id: "err_" + Date.now(),
        role: "assistant",
        text: lang === "bn" ? `ত্রুটি: ${err.message}` : `Error: ${err.message}`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };
      setAiHistory(prev => [...prev, errEntry]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Download ZIP Archive containing all project files
  const handleDownloadZip = async () => {
    try {
      const zip = new JSZip();
      files.forEach(f => {
        zip.file(f.name, f.content);
      });
      zip.file("README.md", `# ${projectName}\n\nGenerated with Lekhok AI Code Studio (Powered by Gemini 3.7 Flash & Google AI Studio).\n\nFiles included:\n${files.map(f => `- ${f.name}`).join("\n")}`);

      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${projectName.replace(/\s+/g, "_")}_Project.zip`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err: any) {
      console.error("ZIP download failed:", err);
      alert("Failed to generate ZIP archive: " + err.message);
    }
  };

  // Download Single Bundled HTML
  const handleDownloadSingleHTML = () => {
    const bundled = generateBundledHTML();
    const blob = new Blob([bundled], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${projectName.replace(/\s+/g, "_")}_standalone.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Save Project to Profile / Firestore
  const handleSaveProjectToProfile = async () => {
    setIsSavingProject(true);
    const projId = `proj-${Date.now()}`;
    const newProj: SavedProject = {
      id: projId,
      name: projectName,
      files: files,
      updatedAt: new Date().toLocaleDateString()
    };

    // Save to LocalStorage
    const updatedLocal = [newProj, ...savedProjects.filter(p => p.name !== projectName)];
    localStorage.setItem("lekhok_saved_code_projects", JSON.stringify(updatedLocal));
    setSavedProjects(updatedLocal);

    // Save to Firestore if available
    if (currentUser?.uid && db) {
      try {
        await addDoc(collection(db, "user_code_projects"), {
          userId: currentUser.uid,
          userEmail: currentUser.email || "anonymous",
          name: projectName,
          files: files,
          updatedAt: new Date().toLocaleDateString(),
          createdAt: new Date().toISOString()
        });
      } catch (err) {
        console.warn("Firestore project save error:", err);
      }
    }

    setIsSavingProject(false);
    alert(lang === "bn" ? `💾 '${projectName}' প্রজেক্টটি আপনার প্রোফাইলে সফলভাবে সংরক্ষিত হয়েছে!` : `💾 Project '${projectName}' saved to your profile!`);
  };

  // Load project from list
  const handleLoadProject = (proj: SavedProject) => {
    setProjectName(proj.name);
    setFiles(proj.files);
    setActiveFileName(proj.files[0]?.name || "index.html");
    setActiveTab("editor");
  };

  // Delete project from list
  const handleDeleteSavedProject = async (projId: string) => {
    if (!confirm(lang === "bn" ? "প্রজেক্টটি ডিলিট করতে চান?" : "Delete this saved project?")) return;
    const updated = savedProjects.filter(p => p.id !== projId);
    setSavedProjects(updated);
    localStorage.setItem("lekhok_saved_code_projects", JSON.stringify(updated));
    if (currentUser?.uid && db) {
      try {
        await deleteDoc(doc(db, "user_code_projects", projId));
      } catch (e) {}
    }
  };

  const handleCopyActiveCode = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`flex-1 w-full max-w-7xl mx-auto flex flex-col font-sans text-left transition-all duration-300 ${
      isFullscreen 
        ? "fixed inset-0 z-50 bg-slate-950 p-3 sm:p-5" 
        : "h-[calc(100vh-4.2rem)] p-2 sm:p-4"
    }`}>
      
      {/* TOP HEADER: BRANDING + PROJECT TITLE + RUN + DOWNLOAD ZIP + PROFILE SAVE */}
      <div className="bg-white border border-amber-200/90 rounded-2xl p-3 sm:p-4 shadow-sm mb-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#7c2d12] via-amber-700 to-amber-600 flex items-center justify-center text-white shadow-md">
            <Code2 size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="text-sm sm:text-base font-black text-slate-900 bg-transparent hover:bg-slate-50 focus:bg-white border border-transparent focus:border-amber-400 rounded-lg px-1.5 py-0.5 outline-none transition"
                title="Click to rename project"
              />
              <span className="text-[9px] font-black uppercase tracking-wider bg-amber-100 text-[#7c2d12] px-2.5 py-0.5 rounded-full border border-amber-300 shadow-2xs">
                AI Web Architect
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              {lang === "bn" ? "প্রম্পট লিখুন বা কথা বলুন — এআই ওয়েবসাইট বানিয়ে দেবে ও যেকোনো অংশ ঠিক করে দেবে" : "Prompt or speak — AI generates full websites & iteratively updates any feature"}
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          
          {/* Toggle AI Architect Assistant Panel */}
          <button
            onClick={() => setShowAiAssistant(!showAiAssistant)}
            className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer border ${
              showAiAssistant
                ? "bg-amber-500 text-slate-950 border-amber-400 shadow-xs"
                : "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200"
            }`}
          >
            <Sparkles size={13} className={showAiAssistant ? "animate-pulse text-slate-950" : "text-amber-600"} />
            <span>{lang === "bn" ? "এআই আর্কিটেক্ট" : "AI Architect"}</span>
          </button>

          {/* Navigation Tabs */}
          <button
            onClick={() => setActiveTab(activeTab === "saved_projects" ? "editor" : "saved_projects")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
              activeTab === "saved_projects"
                ? "bg-[#7c2d12] text-white border-[#7c2d12]"
                : "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200"
            }`}
          >
            <FolderOpen size={13} />
            <span>{lang === "bn" ? `প্রজেক্ট (${savedProjects.length})` : `Projects (${savedProjects.length})`}</span>
          </button>

          <button
            onClick={() => setActiveTab(activeTab === "templates" ? "editor" : "templates")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border ${
              activeTab === "templates"
                ? "bg-[#7c2d12] text-white border-[#7c2d12]"
                : "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200"
            }`}
          >
            <Layers size={13} />
            <span>{lang === "bn" ? "টেমপ্লেট" : "Presets"}</span>
          </button>

          {/* Save to Profile */}
          <button
            onClick={handleSaveProjectToProfile}
            disabled={isSavingProject}
            className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-[#7c2d12] border border-amber-300 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            title="Save Project to Profile & Local Storage"
          >
            <Save size={13} />
            <span>{lang === "bn" ? "সংরক্ষণ" : "Save"}</span>
          </button>

          {/* Run Sandbox */}
          <button
            onClick={renderBundledPreview}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            title="Compile & Run Live Sandbox"
          >
            <Play size={13} className="fill-current" />
            <span>{lang === "bn" ? "রান করুন" : "Run Live"}</span>
          </button>

          {/* Download ZIP button */}
          <button
            onClick={handleDownloadZip}
            className="px-3.5 py-1.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
            title="Download full project as ZIP archive"
          >
            <FolderArchive size={13} />
            <span>ZIP</span>
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition cursor-pointer"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen Workspace"}
          >
            {isFullscreen ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
          </button>
        </div>
      </div>

      {/* SAVED PROJECTS MODAL / DRAWER */}
      {activeTab === "saved_projects" && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-amber-200 rounded-2xl p-5 mb-3 shadow-md space-y-4 shrink-0"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <FolderOpen className="text-[#7c2d12]" size={18} />
              <h3 className="text-sm font-black text-slate-900">
                {lang === "bn" ? "আপনার সংরক্ষিত কোডিং প্রজেক্টসমূহ" : "Saved Code Projects in Profile"}
              </h3>
            </div>
            <button
              onClick={() => setActiveTab("editor")}
              className="p-1 hover:bg-slate-100 rounded-lg text-slate-500 font-bold text-xs cursor-pointer"
            >
              ✕ {lang === "bn" ? "বন্ধ করুন" : "Close"}
            </button>
          </div>

          {savedProjects.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs font-bold">
              {lang === "bn" ? "কোনো সংরক্ষিত প্রজেক্ট পাওয়া যায়নি। বর্তমান প্রজেক্ট সংরক্ষণ করতে 'Save' বাটনে ক্লিক করুন।" : "No saved projects yet. Click 'Save' to store your current project!"}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {savedProjects.map(proj => (
                <div key={proj.id} className="p-3.5 bg-slate-50 hover:bg-amber-50/40 border border-slate-200 rounded-xl flex flex-col justify-between space-y-3 transition">
                  <div>
                    <h4 className="text-xs font-black text-slate-900 truncate">{proj.name}</h4>
                    <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                      {proj.files.length} {lang === "bn" ? "টি ফাইল" : "files"} • {proj.updatedAt}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-200/60">
                    <button
                      onClick={() => handleLoadProject(proj)}
                      className="flex-1 py-1.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 shadow-2xs cursor-pointer"
                    >
                      <Eye size={12} />
                      <span>{lang === "bn" ? "লোড করুন" : "Load"}</span>
                    </button>
                    <button
                      onClick={() => handleDeleteSavedProject(proj.id)}
                      className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg border border-rose-200 transition cursor-pointer"
                      title="Delete project"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      )}

      {/* PRESET TEMPLATES DRAWER */}
      {activeTab === "templates" && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border border-amber-200 rounded-2xl p-5 mb-3 shadow-md space-y-4 shrink-0"
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Sparkles className="text-amber-500" size={16} />
              <span>{lang === "bn" ? "রেডিমেড ইন্টারঅ্যাক্টিভ কোড টেমপ্লেট" : "Ready-to-Run Interactive Code Presets"}</span>
            </h3>
            <button
              onClick={() => setActiveTab("editor")}
              className="p-1 hover:bg-slate-100 rounded-lg text-slate-500 font-bold text-xs cursor-pointer"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {PRESET_CODE_TEMPLATES.map(t => (
              <div
                key={t.id}
                onClick={() => {
                  setProjectName(t.name.replace(/^[^\w]+/, "").trim());
                  setFiles(t.files);
                  setActiveFileName(t.files[0].name);
                  setActiveTab("editor");
                }}
                className="p-4 bg-slate-50 hover:bg-amber-50/50 border border-slate-200 hover:border-amber-400 rounded-xl cursor-pointer transition space-y-2 group"
              >
                <h4 className="text-xs font-black text-slate-900 group-hover:text-[#7c2d12]">{t.name}</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed font-medium">{t.desc}</p>
                <span className="inline-block text-[10px] text-amber-700 font-bold bg-amber-100/70 px-2 py-0.5 rounded-md">
                  {t.files.length} {lang === "bn" ? "ফাইল বিশিষ্ট প্রজেক্ট" : "files"}
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* MAIN WORKSPACE: 3-PANE / 2-PANE DYNAMIC GRID */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 overflow-hidden min-h-0">
        
        {/* LEFT COLUMN: MULTI-FILE CODE EDITOR (6 or 7 COLS) */}
        <div className={`${showAiAssistant ? "lg:col-span-4" : "lg:col-span-6"} flex flex-col bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 shadow-sm h-full`}>
          
          {/* FILE TABS HEADER */}
          <div className="bg-slate-950 border-b border-slate-800 px-3 py-2 flex items-center justify-between gap-2 overflow-x-auto select-none">
            
            {/* File List Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
              {files.map(f => {
                const isActive = f.name === activeFileName;
                return (
                  <div
                    key={f.name}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer border ${
                      isActive
                        ? "bg-slate-800 text-amber-400 border-amber-500/40 shadow-xs"
                        : "bg-slate-900/60 text-slate-400 hover:text-slate-200 border-transparent hover:bg-slate-800/40"
                    }`}
                    onClick={() => setActiveFileName(f.name)}
                  >
                    <FileCode size={13} className={isActive ? "text-amber-400" : "text-slate-500"} />
                    <span>{f.name}</span>
                    {files.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteFile(f.name);
                        }}
                        className="opacity-40 hover:opacity-100 hover:text-red-400 ml-1 cursor-pointer"
                        title="Delete file"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                );
              })}

              {/* Add New File Button */}
              <button
                onClick={() => setShowNewFileModal(true)}
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold transition flex items-center gap-1 border border-slate-700 cursor-pointer"
                title="Create a new file"
              >
                <Plus size={13} />
                <span>{lang === "bn" ? "ফাইল" : "File"}</span>
              </button>
            </div>

            {/* Quick Copy & Download single file */}
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={handleCopyActiveCode}
                className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition cursor-pointer"
                title="Copy current file code"
              >
                {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              </button>
              <button
                onClick={handleDownloadSingleHTML}
                className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition cursor-pointer"
                title="Download bundled single HTML"
              >
                <Download size={14} />
              </button>
            </div>
          </div>

          {/* NEW FILE MODAL PROMPT */}
          {showNewFileModal && (
            <div className="bg-slate-800 border-b border-slate-700 p-3 flex items-center gap-2 animate-fadeIn">
              <input
                type="text"
                value={newFileNameInput}
                onChange={(e) => setNewFileNameInput(e.target.value)}
                placeholder="e.g. styles.css, app.js, data.json"
                className="flex-1 bg-slate-900 border border-slate-700 text-slate-100 text-xs px-3 py-1.5 rounded-lg outline-none focus:border-amber-400"
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleCreateFile();
                  if (e.key === "Escape") setShowNewFileModal(false);
                }}
                autoFocus
              />
              <button
                onClick={handleCreateFile}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                Add
              </button>
              <button
                onClick={() => setShowNewFileModal(false)}
                className="px-2 py-1.5 text-slate-400 hover:text-slate-200 text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
            </div>
          )}

          {/* CODE EDITOR TEXTAREA WITH MONOSPACE */}
          <div className="flex-1 relative flex overflow-hidden">
            <textarea
              value={activeFile.content}
              onChange={(e) => handleContentChange(e.target.value)}
              placeholder="Write your code here..."
              spellCheck={false}
              className="w-full h-full bg-slate-900 text-slate-100 font-mono text-xs sm:text-[13px] p-4 leading-relaxed outline-none resize-none selection:bg-amber-500/30 overflow-y-auto"
            />
          </div>

          {/* CODE EDITOR FOOTER */}
          <div className="bg-slate-950 border-t border-slate-800 px-3 py-1.5 flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>{activeFile.name} • {activeFile.content.split('\n').length} lines</span>
            <span>{activeFile.content.length} chars</span>
          </div>

        </div>

        {/* MIDDLE / DEDICATED AI ARCHITECT ITERATIVE ASSISTANT PANEL */}
        {showAiAssistant && (
          <div className="lg:col-span-4 flex flex-col bg-slate-950 rounded-2xl overflow-hidden border border-indigo-950/80 shadow-md h-full">
            
            {/* AI Assistant Header */}
            <div className="bg-slate-900/90 border-b border-slate-800 px-3.5 py-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-slate-950">
                  <Sparkles size={13} />
                </div>
                <div>
                  <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                    <span>{lang === "bn" ? "এআই আর্কিটেক্ট চ্যাট" : "AI Architect Chat"}</span>
                    <span className="text-[8px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30">
                      Live
                    </span>
                  </h3>
                </div>
              </div>

              {/* Model selector */}
              <select
                value={selectedAiModel}
                onChange={(e) => setSelectedAiModel(e.target.value as any)}
                className="bg-slate-800 text-amber-300 border border-slate-700 rounded-lg px-2 py-0.5 text-[10px] font-bold outline-none cursor-pointer"
              >
                <option value="gemini-3.7-flash">Gemini 3.7 Flash</option>
                <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
                <option value="deepseek">DeepSeek V3</option>
              </select>
            </div>

            {/* AI Conversation & Instruction Feed */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3 text-xs leading-relaxed">
              {aiHistory.map((item) => (
                <div
                  key={item.id}
                  className={`p-3 rounded-2xl flex flex-col space-y-1 ${
                    item.role === "user"
                      ? "bg-amber-500/10 text-amber-100 border border-amber-500/20 ml-4"
                      : "bg-slate-900/80 text-slate-200 border border-slate-800 mr-4"
                  }`}
                >
                  <div className="flex items-center justify-between text-[9px] font-bold opacity-60">
                    <span>{item.role === "user" ? (lang === "bn" ? "আপনি" : "You") : "AI Architect"}</span>
                    <span>{item.timestamp}</span>
                  </div>
                  <p className="whitespace-pre-wrap">{item.text}</p>
                </div>
              ))}
              <div ref={chatBottomRef} />
            </div>

            {/* Quick Prompt Starters */}
            <div className="px-3 pt-2 pb-1 bg-slate-900/50 border-t border-slate-800/80 flex items-center gap-1.5 overflow-x-auto select-none">
              <button
                onClick={() => handleAiGenerate("enhance", "Add dark mode toggle, smooth animations, and sound effects")}
                disabled={isAiLoading}
                className="shrink-0 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[10px] font-bold border border-slate-700 transition cursor-pointer"
              >
                🌙 {lang === "bn" ? "ডার্ক মোড যোগ করো" : "Add Dark Mode"}
              </button>
              <button
                onClick={() => handleAiGenerate("fix", "Fix any layout bugs, broken buttons, and console errors")}
                disabled={isAiLoading}
                className="shrink-0 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[10px] font-bold border border-slate-700 transition cursor-pointer"
              >
                🛠️ {lang === "bn" ? "বাগ ফিক্স করো" : "Auto Fix"}
              </button>
              <button
                onClick={() => handleAiGenerate("enhance", "Make the UI ultra-modern with neon glow, glassmorphism and mobile responsive layout")}
                disabled={isAiLoading}
                className="shrink-0 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[10px] font-bold border border-slate-700 transition cursor-pointer"
              >
                ✨ {lang === "bn" ? "ডিজাইন সুন্দর করো" : "Upgrade Design"}
              </button>
            </div>

            {/* Input prompt area with Voice Dictation & Send Button */}
            <div className="p-3 bg-slate-900 border-t border-slate-800 space-y-2">
              <div className="relative flex items-center">
                <textarea
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  placeholder={lang === "bn" ? "কী বানাতে চান বা কী পরিবর্তন করতে চান বলুন..." : "Instruct AI what to build or what to modify/fix..."}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 text-slate-100 text-xs p-2.5 pr-20 rounded-xl outline-none transition placeholder:text-slate-500 resize-none font-sans"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      if (!isAiLoading) handleAiGenerate("generate");
                    }
                  }}
                />

                <div className="absolute right-2.5 bottom-2.5 flex items-center gap-1.5">
                  {/* Voice Dictation Button */}
                  <button
                    onClick={toggleVoiceDictation}
                    className={`p-1.5 rounded-lg transition cursor-pointer ${
                      isVoiceDictating 
                        ? "bg-rose-600 text-white animate-pulse" 
                        : "bg-slate-800 hover:bg-slate-700 text-slate-300"
                    }`}
                    title={isVoiceDictating ? "Stop voice dictation" : "Speak your prompt"}
                  >
                    {isVoiceDictating ? <MicOff size={13} /> : <Mic size={13} />}
                  </button>

                  {/* Send Button */}
                  <button
                    onClick={() => handleAiGenerate("generate")}
                    disabled={isAiLoading || !aiPrompt.trim()}
                    className="p-1.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 rounded-lg font-bold transition cursor-pointer"
                    title="Send prompt to AI"
                  >
                    {isAiLoading ? (
                      <RefreshCw size={13} className="animate-spin" />
                    ) : (
                      <Send size={13} />
                    )}
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* RIGHT COLUMN: LIVE BUNDLED SANDBOX PREVIEW (4 or 6 COLS) */}
        <div className={`${showAiAssistant ? "lg:col-span-4" : "lg:col-span-6"} flex flex-col bg-white rounded-2xl border border-amber-200/90 overflow-hidden shadow-sm h-full`}>
          
          {/* PREVIEW TOOLBAR */}
          <div className="bg-slate-100/90 border-b border-slate-200 px-3 py-2 flex items-center justify-between select-none">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-black text-slate-800">
                {lang === "bn" ? "লাইভ প্রিভিউ" : "Live Sandbox"}
              </span>
            </div>

            {/* Device Switcher */}
            <div className="flex items-center gap-1 bg-slate-200/70 p-0.5 rounded-lg">
              <button
                onClick={() => setDeviceView("desktop")}
                className={`p-1 rounded-md transition cursor-pointer ${deviceView === "desktop" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-900"}`}
                title="Desktop View"
              >
                <Monitor size={13} />
              </button>
              <button
                onClick={() => setDeviceView("tablet")}
                className={`p-1 rounded-md transition cursor-pointer ${deviceView === "tablet" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-900"}`}
                title="Tablet View"
              >
                <Tablet size={13} />
              </button>
              <button
                onClick={() => setDeviceView("mobile")}
                className={`p-1 rounded-md transition cursor-pointer ${deviceView === "mobile" ? "bg-white text-slate-900 shadow-2xs" : "text-slate-500 hover:text-slate-900"}`}
                title="Mobile View"
              >
                <Smartphone size={13} />
              </button>
            </div>
          </div>

          {/* IFRAME STAGE */}
          <div className="flex-1 bg-slate-950 flex items-center justify-center p-2 overflow-hidden">
            <div 
              className={`h-full bg-white rounded-xl overflow-hidden transition-all duration-300 border border-slate-800 shadow-xl ${
                deviceView === "desktop" 
                  ? "w-full" 
                  : deviceView === "tablet" 
                    ? "w-[480px] max-w-full" 
                    : "w-[340px] max-w-full"
              }`}
            >
              <iframe
                ref={iframeRef}
                title="Sandbox Preview"
                className="w-full h-full border-0 bg-white"
                sandbox="allow-scripts allow-modals allow-same-origin allow-forms"
              />
            </div>
          </div>

          {/* FOOTER STATUS */}
          <div className="bg-slate-50 border-t border-slate-200 px-3 py-1.5 flex items-center justify-between text-[10px] text-slate-500 font-bold">
            <span>{files.length} {lang === "bn" ? "টি ফাইল সংযুক্ত" : "files bundled in sandbox"}</span>
            <button
              onClick={renderBundledPreview}
              className="text-[#7c2d12] hover:underline flex items-center gap-1 cursor-pointer font-bold"
            >
              <RefreshCw size={11} />
              <span>{lang === "bn" ? "রিফ্রেশ" : "Refresh"}</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
