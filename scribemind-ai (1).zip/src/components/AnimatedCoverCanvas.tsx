import React, { useEffect, useRef, useState } from "react";
import { Sparkles, Wand2, Star, Flame, Waves, Terminal, Image as ImageIcon, Upload, Trash2, Sliders, ExternalLink } from "lucide-react";

export type AnimatedCoverStyle =
  | "tilt_3d"
  | "starfield"
  | "matrix_rain"
  | "golden_stardust"
  | "nebula_aurora"
  | "wave_ripple"
  | "hologram";

interface AnimatedCoverCanvasProps {
  title: string;
  genre?: string;
  authorName?: string;
  synopsis?: string;
  baseGradient?: string;
  styleType?: AnimatedCoverStyle;
  coverImageUrl?: string;
  coverImageOpacity?: number;
  onUploadCoverImage?: (url: string) => void;
  onRemoveCoverImage?: () => void;
  onUpdateCoverOpacity?: (opacity: number) => void;
  lang?: "bn" | "en";
}

const PRESET_COVER_IMAGES = [
  { name: "Sci-Fi Galaxy", url: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=1000&auto=format&fit=crop" },
  { name: "Deep Tech & Code", url: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=1000&auto=format&fit=crop" },
  { name: "Vintage Library", url: "https://images.unsplash.com/photo-1507842229451-9f01ab71c8b8?q=80&w=1000&auto=format&fit=crop" },
  { name: "Mystic Forest", url: "https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=1000&auto=format&fit=crop" },
  { name: "Mountain Peak", url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1000&auto=format&fit=crop" },
  { name: "Gold Sunset", url: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=1000&auto=format&fit=crop" }
];

export const AnimatedCoverCanvas: React.FC<AnimatedCoverCanvasProps> = ({
  title,
  genre = "Fiction & Adventure",
  authorName = "Lekhok AI Author",
  baseGradient = "linear-gradient(135deg, #1e1b4b 0%, #311042 100%)",
  styleType = "tilt_3d",
  coverImageUrl,
  coverImageOpacity = 0.85,
  onUploadCoverImage,
  onRemoveCoverImage,
  onUpdateCoverOpacity,
  lang = "bn"
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const cardRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [activeStyle, setActiveStyle] = useState<AnimatedCoverStyle>(styleType);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [showImageControls, setShowImageControls] = useState(false);
  const [customUrlInput, setCustomUrlInput] = useState("");

  // Handle 3D Tilt Effect on mouse / touch move
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: y * -22, y: x * 22 });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  // Handle local file upload with smart automatic compression for instant persistence
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert(lang === "bn" ? "অনুগ্রহ করে একটি সঠিক ছবি ফাইল (JPG/PNG/WEBP) আপলোড করুন।" : "Please select a valid image file (JPG/PNG/WEBP).");
      return;
    }

    try {
      // Compress to optimal dimensions and size for instant cloud storage & fast rendering
      const compressedDataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          const img = new Image();
          img.onload = () => {
            const canvas = document.createElement("canvas");
            let width = img.width;
            let height = img.height;
            const maxDimension = 1000;
            if (width > maxDimension || height > maxDimension) {
              if (width > height) {
                height = Math.round((height * maxDimension) / width);
                width = maxDimension;
              } else {
                width = Math.round((width * maxDimension) / height);
                height = maxDimension;
              }
            }
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext("2d");
            if (!ctx) {
              resolve(event.target?.result as string);
              return;
            }
            ctx.drawImage(img, 0, 0, width, height);
            const compressed = canvas.toDataURL("image/jpeg", 0.84);
            resolve(compressed);
          };
          img.onerror = () => resolve(event.target?.result as string);
          img.src = event.target?.result as string;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      if (onUploadCoverImage && compressedDataUrl) {
        onUploadCoverImage(compressedDataUrl);
      }
    } catch (err) {
      console.error("Cover upload error:", err);
      alert(lang === "bn" ? "ছবি আপলোড করতে সমস্যা হয়েছে।" : "Failed to upload image.");
    } finally {
      e.target.value = "";
    }
  };

  const handleApplyUrl = () => {
    const trimmed = customUrlInput.trim();
    if (!trimmed) return;
    if (onUploadCoverImage) {
      onUploadCoverImage(trimmed);
      setCustomUrlInput("");
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const resize = () => {
      if (canvas && cardRef.current) {
        canvas.width = cardRef.current.clientWidth * (window.devicePixelRatio || 1);
        canvas.height = cardRef.current.clientHeight * (window.devicePixelRatio || 1);
        ctx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);
      }
    };
    resize();
    window.addEventListener("resize", resize);

    // Matrix characters
    const matrixChars = "010101ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789কখগঘঙচছজঝঞটঠডঢণতথদধনপফবভমযরলশষসহ";
    const matrixDrops: number[] = [];
    const cols = Math.floor(400 / 14);
    for (let i = 0; i < cols; i++) {
      matrixDrops[i] = Math.random() * -50;
    }

    const render = () => {
      if (!cardRef.current || !canvas) return;
      const w = cardRef.current.clientWidth;
      const h = cardRef.current.clientHeight;

      ctx.clearRect(0, 0, w, h);
      time += 0.03;

      // 1. STARFIELD PARTICLES
      if (activeStyle === "starfield" || activeStyle === "tilt_3d") {
        ctx.fillStyle = "rgba(255, 255, 255, 0.75)";
        for (let i = 0; i < 45; i++) {
          const x = ((Math.sin(i * 77 + time * 0.1) * 0.5 + 0.5) * w);
          const y = ((Math.cos(i * 44 + time * 0.15) * 0.5 + 0.5) * h);
          const size = (Math.sin(i * 13 + time * 2) * 0.5 + 0.5) * 2.2 + 0.5;
          ctx.beginPath();
          ctx.arc(x, y, size, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 2. MATRIX RAIN
      else if (activeStyle === "matrix_rain") {
        ctx.fillStyle = "rgba(0, 0, 0, 0.18)";
        ctx.fillRect(0, 0, w, h);

        ctx.fillStyle = "#22c55e";
        ctx.font = "11px monospace";

        for (let i = 0; i < matrixDrops.length; i++) {
          const char = matrixChars[Math.floor(Math.random() * matrixChars.length)];
          const x = i * 14;
          const y = matrixDrops[i] * 14;

          ctx.fillText(char, x, y);

          if (y > h && Math.random() > 0.975) {
            matrixDrops[i] = 0;
          }
          matrixDrops[i] += 0.4;
        }
      }

      // 3. GOLDEN SHIMMERING STARDUST
      else if (activeStyle === "golden_stardust") {
        for (let i = 0; i < 50; i++) {
          const x = ((Math.sin(i * 88 + time * 0.2) * 0.5 + 0.5) * w);
          const y = ((Math.cos(i * 55 + time * 0.25) * 0.5 + 0.5) * h);
          const rad = (Math.sin(i * 20 + time * 3) * 0.5 + 0.5) * 3 + 1;

          const goldGlow = ctx.createRadialGradient(x, y, 0, x, y, rad * 2);
          goldGlow.addColorStop(0, "rgba(254, 240, 138, 0.9)");
          goldGlow.addColorStop(0.5, "rgba(234, 179, 8, 0.5)");
          goldGlow.addColorStop(1, "rgba(202, 138, 4, 0)");

          ctx.fillStyle = goldGlow;
          ctx.beginPath();
          ctx.arc(x, y, rad * 2, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 4. NEBULA AURORA WAVES
      else if (activeStyle === "nebula_aurora" || activeStyle === "wave_ripple") {
        for (let wave = 0; wave < 3; wave++) {
          ctx.beginPath();
          ctx.moveTo(0, h * 0.6);
          for (let x = 0; x <= w; x += 15) {
            const y = h * 0.65 + Math.sin(x * 0.015 + time + wave) * 35 + Math.cos(x * 0.02 - time * 0.8) * 20;
            ctx.lineTo(x, y);
          }
          ctx.lineTo(w, h);
          ctx.lineTo(0, h);
          ctx.closePath();

          const auroraGrad = ctx.createLinearGradient(0, 0, w, h);
          if (wave === 0) {
            auroraGrad.addColorStop(0, "rgba(168, 85, 247, 0.25)");
            auroraGrad.addColorStop(1, "rgba(59, 130, 246, 0.1)");
          } else if (wave === 1) {
            auroraGrad.addColorStop(0, "rgba(56, 189, 248, 0.2)");
            auroraGrad.addColorStop(1, "rgba(236, 72, 153, 0.15)");
          } else {
            auroraGrad.addColorStop(0, "rgba(244, 63, 94, 0.18)");
            auroraGrad.addColorStop(1, "rgba(251, 191, 36, 0.08)");
          }

          ctx.fillStyle = auroraGrad;
          ctx.fill();
        }
      }

      // 5. HOLOGRAM SCANLINES
      else if (activeStyle === "hologram") {
        const scanY = (time * 60) % h;
        ctx.fillStyle = "rgba(56, 189, 248, 0.25)";
        ctx.fillRect(0, scanY, w, 4);

        ctx.strokeStyle = "rgba(56, 189, 248, 0.08)";
        ctx.lineWidth = 1;
        for (let y = 0; y < h; y += 8) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();
        }
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animId);
    };
  }, [activeStyle]);

  return (
    <div className="flex flex-col items-center gap-5 select-none w-full max-w-lg mx-auto">
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* 3D Animated Book Cover Card */}
      <div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        style={{
          background: baseGradient,
          transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
          transition: "transform 0.12s ease-out, box-shadow 0.2s ease"
        }}
        className="relative w-full max-w-[340px] h-[490px] rounded-2xl overflow-hidden p-7 flex flex-col justify-between text-white shadow-2xl border-2 border-white/20 cursor-pointer group"
      >
        {/* User Custom Uploaded Background Image */}
        {coverImageUrl && (
          <div 
            className="absolute inset-0 z-0 bg-cover bg-center transition-all duration-500"
            style={{ 
              backgroundImage: `url(${coverImageUrl})`,
              opacity: coverImageOpacity
            }}
          />
        )}

        {/* Dynamic Dark Gradient Overlay to ensure maximum text readability */}
        {coverImageUrl && (
          <div className="absolute inset-0 z-[1] bg-gradient-to-t from-black/85 via-black/45 to-black/75 pointer-events-none" />
        )}

        {/* Animated Canvas Layer */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full pointer-events-none z-10"
        />

        {/* Ambient Gloss & Light Sheen Effect */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent opacity-60 group-hover:opacity-100 transition-opacity pointer-events-none z-10" />

        {/* Spine line simulation */}
        <div className="absolute top-0 bottom-0 left-4 w-[2px] bg-white/20 shadow-sm z-20" />

        {/* Header content */}
        <div className="relative z-30 pl-4">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-white/25 backdrop-blur-md border border-white/30 text-amber-200 shadow-xs">
              {genre}
            </span>
          </div>
          <p className="text-[11px] text-white/80 font-mono tracking-widest uppercase drop-shadow-xs">
            Official Manuscript
          </p>
        </div>

        {/* Center Title Display */}
        <div className="relative z-30 pl-4 my-auto text-center py-4">
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight leading-snug drop-shadow-lg text-white font-serif">
            {title}
          </h1>
          <div className="w-12 h-1 bg-amber-400 mx-auto mt-3 rounded-full shadow-md" />
        </div>

        {/* Footer Author & Publisher */}
        <div className="relative z-30 pl-4 pt-3 border-t border-white/25 flex items-center justify-between backdrop-blur-xs">
          <div>
            <p className="text-[10px] text-white/70 uppercase tracking-wider">Author</p>
            <p className="text-xs font-bold text-white drop-shadow-md">{authorName}</p>
          </div>
          <div className="flex items-center gap-1 bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/20 text-[10px] font-medium text-amber-300 shadow-xs">
            <Sparkles className="w-3 h-3" />
            <span>Lekhok AI</span>
          </div>
        </div>
      </div>

      {/* Cover Custom Image & Controls Action Bar */}
      <div className="w-full max-w-[360px] space-y-2">
        <div className="flex items-center justify-between gap-2 p-2 bg-white rounded-xl border border-[#ede7db] shadow-xs">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 py-1.5 px-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-lg text-[11px] font-bold transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{lang === "bn" ? "নিজের ছবি আপলোড করুন" : "Upload Custom Cover Image"}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowImageControls(!showImageControls)}
            className={`p-1.5 rounded-lg border text-xs font-bold transition cursor-pointer ${
              showImageControls 
                ? "bg-amber-100 border-amber-300 text-[#7c2d12]" 
                : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
            }`}
            title={lang === "bn" ? "কভার ছবি সেটিংস ও প্রিসেট" : "Cover settings & presets"}
          >
            <ImageIcon className="w-4 h-4" />
          </button>

          {coverImageUrl && onRemoveCoverImage && (
            <button
              type="button"
              onClick={onRemoveCoverImage}
              className="p-1.5 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-lg text-xs font-bold transition cursor-pointer"
              title={lang === "bn" ? "কভার ছবি সরান" : "Remove cover image"}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Detailed Image & Preset Controls Drawer */}
        {showImageControls && (
          <div className="p-3.5 bg-white rounded-xl border border-amber-200 shadow-sm space-y-3 font-sans text-xs">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                {lang === "bn" ? "🌐 ছবির ওয়েব লিংক (Image URL):" : "🌐 Paste Image Web Link:"}
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/..."
                  value={customUrlInput}
                  onChange={(e) => setCustomUrlInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleApplyUrl()}
                  className="flex-1 px-2.5 py-1 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500 bg-[#faf9f6]"
                />
                <button
                  type="button"
                  onClick={handleApplyUrl}
                  disabled={!customUrlInput.trim()}
                  className="px-3 py-1 bg-[#7c2d12] hover:bg-[#63220c] disabled:opacity-40 text-white rounded-lg text-xs font-bold cursor-pointer transition"
                >
                  {lang === "bn" ? "যুক্ত করুন" : "Set URL"}
                </button>
              </div>
            </div>

            {/* Presets Gallery */}
            <div>
              <span className="block text-[10.5px] font-bold text-slate-600 uppercase tracking-wider mb-1.5">
                {lang === "bn" ? "🎨 রেডিমেড কভার গ্যালারি:" : "🎨 Preset Cover Photos:"}
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {PRESET_COVER_IMAGES.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => onUploadCoverImage && onUploadCoverImage(preset.url)}
                    className="group relative h-14 rounded-lg overflow-hidden border border-slate-200 hover:border-amber-500 transition text-left cursor-pointer"
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-1 flex items-end">
                      <span className="text-[9px] font-bold text-white leading-tight line-clamp-1">
                        {preset.name}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Opacity slider if image active */}
            {coverImageUrl && onUpdateCoverOpacity && (
              <div className="pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 mb-1">
                  <span>{lang === "bn" ? "ছবির গাঢ়তা (Opacity):" : "Cover Opacity:"}</span>
                  <span className="text-amber-700">{Math.round(coverImageOpacity * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="1"
                  step="0.05"
                  value={coverImageOpacity}
                  onChange={(e) => onUpdateCoverOpacity(parseFloat(e.target.value))}
                  className="w-full accent-amber-600 cursor-pointer"
                />
              </div>
            )}
          </div>
        )}

        {/* Style Selector Toolbar */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700 shadow-md">
          <span className="text-[11px] font-semibold text-slate-300 px-1.5 flex items-center gap-1">
            <Wand2 className="w-3 h-3 text-amber-400" />
            {lang === "bn" ? "ইফেক্ট:" : "FX:"}
          </span>
          {[
            { id: "tilt_3d", label: "3D Tilt", icon: Sparkles },
            { id: "starfield", label: "Stars", icon: Star },
            { id: "golden_stardust", label: "Gold", icon: Flame },
            { id: "matrix_rain", label: "Matrix", icon: Terminal },
            { id: "nebula_aurora", label: "Aurora", icon: Waves }
          ].map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveStyle(item.id as AnimatedCoverStyle)}
                className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-medium transition-all cursor-pointer ${
                  activeStyle === item.id
                    ? "bg-amber-600 text-white shadow-xs"
                    : "text-slate-300 hover:text-white hover:bg-slate-800"
                }`}
              >
                <Icon className="w-3 h-3" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
