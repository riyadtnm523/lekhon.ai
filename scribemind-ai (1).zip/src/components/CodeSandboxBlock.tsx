import React, { useState, useEffect, useRef } from "react";
import { RotateCcw, Copy, Check, Eye, Code, Sparkles, CheckCircle2, Play } from "lucide-react";

interface CodeSandboxBlockProps {
  initialCode: string;
  language?: string;
  lang?: "bn" | "en";
}

// Safely convert any node or object to string
const sanitizeCodeString = (val: any): string => {
  if (val === null || val === undefined) return "";
  if (typeof val === "string") return val;
  if (typeof val === "number" || typeof val === "boolean") return String(val);
  if (Array.isArray(val)) return val.map(sanitizeCodeString).join("");
  if (typeof val === "object") {
    if (val.props && val.props.children) {
      return sanitizeCodeString(val.props.children);
    }
  }
  return String(val);
};

export const CodeSandboxBlockComponent: React.FC<CodeSandboxBlockProps> = ({
  initialCode,
  language = "javascript",
  lang = "bn"
}) => {
  const cleanLang = (language || "javascript").toLowerCase();
  const rawInitialCode = sanitizeCodeString(initialCode);

  const [code, setCode] = useState(rawInitialCode);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"code" | "preview" | "split">("split");
  const [isTaskCompleted, setIsTaskCompleted] = useState(false);
  const [userTaskInput, setUserTaskInput] = useState("");
  const [taskFeedback, setTaskFeedback] = useState<string | null>(null);
  const [nonWebConsoleOutput, setNonWebConsoleOutput] = useState<string | null>(null);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  // Sync state if props change
  useEffect(() => {
    const sanitized = sanitizeCodeString(initialCode);
    if (sanitized) {
      setCode(sanitized);
    }
  }, [initialCode]);

  // Detect if this code block contains a practice exercise or quiz question
  const isPracticeExercise = rawInitialCode.includes("[PRACTICE]") || rawInitialCode.includes("TODO:") || rawInitialCode.includes("// Task:") || rawInitialCode.includes("# Task:") || rawInitialCode.includes("/* Exercise");

  // Determine preview capability (HTML, JS, React, CSS, SVG, Three.js, Canvas, Tailwind, Angular, Vue, Web)
  const isWebPreviewable = [
    "html", "htm", "jsx", "tsx", "react", "js", "javascript", "css", "svg", "web", "canvas", "three", "threejs", "tailwind", "angular", "vue"
  ].some(l => cleanLang.includes(l)) || rawInitialCode.includes("<html") || rawInitialCode.includes("<!DOCTYPE") || rawInitialCode.includes("<div") || rawInitialCode.includes("<h1") || rawInitialCode.includes("React.") || rawInitialCode.includes("document.");

  // Reset code to original author code
  const handleReset = () => {
    const sanitized = sanitizeCodeString(initialCode);
    setCode(sanitized);
    setIsTaskCompleted(false);
    setTaskFeedback(null);
    setNonWebConsoleOutput(null);
  };

  // Copy code
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Run non-web code simulator (e.g. Python, C++, Java, SQL, Rust, PHP)
  const handleRunSimulatedCode = () => {
    let output = "";
    if (cleanLang.includes("py") || cleanLang.includes("python")) {
      output = ">>> [Python Simulator Output]\nRunning script...\n" + 
        (code.includes("print") 
          ? code.split("\n").filter(l => l.includes("print")).map(l => l.replace(/.*print\s*\((.*?)\).*/, "$1").replace(/['"]/g, "")).join("\n") 
          : "Script executed successfully with exit code 0.");
    } else if (cleanLang.includes("sql")) {
      output = "SQL Query Executed Successfully:\n+----+------------------+--------+\n| ID | Query Status     | Rows   |\n+----+------------------+--------+\n| 1  | Executed OK      | 5 rows |\n+----+------------------+--------+";
    } else {
      output = `[${cleanLang.toUpperCase()} Compiler Simulator]\nCompiling source code...\nBuild successful!\nExecution finished without errors.`;
    }
    setNonWebConsoleOutput(output);
  };

  // Generate html iframe content for live preview
  const generatePreviewDoc = (codeToRender: string) => {
    if (codeToRender.includes("<html") || codeToRender.includes("<!DOCTYPE")) {
      return codeToRender;
    }

    const isReact = cleanLang.includes("jsx") || cleanLang.includes("tsx") || cleanLang.includes("react") || codeToRender.includes("React.") || codeToRender.includes("ReactDOM.");
    const isThree = codeToRender.includes("THREE.") || cleanLang.includes("three");
    const isCss = cleanLang.includes("css") && !codeToRender.includes("<");
    const isSvg = codeToRender.trim().startsWith("<svg") || cleanLang.includes("svg");
    const isHtml = cleanLang.includes("html") || cleanLang.includes("htm") || (codeToRender.includes("<") && !isReact && !isSvg);

    if (isCss) {
      return `<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script><style>${codeToRender}</style></head><body class="p-4 bg-white text-slate-800"><h3 class="text-sm font-bold text-slate-900 mb-2">CSS Styling Live Preview</h3><div class="p-4 border border-slate-200 rounded-xl bg-slate-50 shadow-xs"><p class="font-medium text-xs text-slate-700">Preview styled with custom CSS:</p><button class="mt-3 px-4 py-2 bg-amber-600 text-white rounded-lg font-medium shadow-xs hover:bg-amber-700 text-xs">Sample Button</button></div></body></html>`;
    }

    if (isSvg) {
      return `<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script></head><body class="p-4 bg-white flex items-center justify-center min-h-[180px]">${codeToRender}</body></html>`;
    }

    if (isHtml) {
      return `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="https://cdn.tailwindcss.com"></script>
            ${isThree ? `<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>` : ''}
            <style>
              body { font-family: ui-sans-serif, system-ui, -apple-system, sans-serif; padding: 1rem; margin: 0; background: #ffffff; color: #0f172a; }
            </style>
          </head>
          <body>
            ${codeToRender}
          </body>
        </html>
      `;
    }

    if (isReact) {
      return `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="https://cdn.tailwindcss.com"></script>
            <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
            <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
            <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
            <style>
              body { font-family: ui-sans-serif, system-ui, -apple-system, sans-serif; padding: 1rem; margin: 0; background: #ffffff; color: #0f172a; }
              .error-box { background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; padding: 0.75rem; border-radius: 0.5rem; font-family: monospace; font-size: 0.8rem; margin-top: 0.5rem; }
            </style>
          </head>
          <body>
            <div id="root"></div>
            <script type="text/babel">
              try {
                ${codeToRender}
                if (typeof App !== 'undefined') {
                  const root = ReactDOM.createRoot(document.getElementById('root'));
                  root.render(<App />);
                }
              } catch (err) {
                const errDiv = document.createElement('div');
                errDiv.className = 'error-box';
                errDiv.innerText = '⚠️ React Render Error: ' + err.message;
                document.body.appendChild(errDiv);
              }
            </script>
          </body>
        </html>
      `;
    }

    // Default pure JavaScript runner
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <script src="https://cdn.tailwindcss.com"></script>
          ${isThree ? `<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>` : ''}
          <style>
            body { font-family: ui-sans-serif, system-ui, -apple-system, sans-serif; padding: 1rem; margin: 0; background: #ffffff; color: #0f172a; }
            #console-log-output { padding: 0.75rem; background: #0f172a; color: #38bdf8; border-radius: 0.5rem; font-family: monospace; font-size: 0.8rem; max-height: 180px; overflow-y: auto; white-space: pre-wrap; }
            .error-box { background: #fef2f2; border: 1px solid #fca5a5; color: #991b1b; padding: 0.75rem; border-radius: 0.5rem; font-family: monospace; font-size: 0.8rem; margin-top: 0.5rem; }
          </style>
        </head>
        <body>
          <div id="root"></div>
          <div id="app"></div>
          <div id="console-log-output"><strong>[Console Log Output]</strong><br/></div>
          <script>
            (function() {
              var consoleBox = document.getElementById('console-log-output');
              var oldLog = console.log;
              console.log = function() {
                var args = Array.prototype.slice.call(arguments);
                oldLog.apply(console, args);
                consoleBox.innerHTML += '<div>&gt; ' + args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') + '</div>';
              };
              window.onerror = function(msg, url, line) {
                var errDiv = document.createElement('div');
                errDiv.className = 'error-box';
                errDiv.innerText = '⚠️ Error: ' + msg + ' (Line ' + line + ')';
                document.body.appendChild(errDiv);
                return false;
              };
            })();
            try {
              ${codeToRender}
            } catch (err) {
              var errDiv = document.createElement('div');
              errDiv.className = 'error-box';
              errDiv.innerText = '⚠️ Execution Error: ' + err.message;
              document.body.appendChild(errDiv);
            }
          </script>
        </body>
      </html>
    `;
  };

  // Check practice task
  const handleVerifyTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userTaskInput.trim()) return;

    if (userTaskInput.trim().length >= 3) {
      setIsTaskCompleted(true);
      setTaskFeedback(lang === "bn" 
        ? "🎉 চমৎকার উত্তর! আপনি অনুশীলনের এই কোডিং টাস্কটি সঠিকভাবে সম্পন্ন করেছেন।" 
        : "🎉 Fantastic job! You have successfully completed this practice code task."
      );
    }
  };

  return (
    <div className="my-6 rounded-2xl overflow-hidden border border-amber-400/80 bg-slate-950 text-slate-100 shadow-xl font-sans font-normal text-left">
      {/* CODE TOP BAR */}
      <div className="flex flex-wrap items-center justify-between px-3.5 py-2.5 bg-slate-900 border-b border-slate-800 select-none gap-2">
        <div className="flex items-center gap-2">
          <div className="flex space-x-1.5">
            <span className="w-2.5 h-2.5 bg-rose-500 rounded-full inline-block" />
            <span className="w-2.5 h-2.5 bg-amber-500 rounded-full inline-block" />
            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full inline-block" />
          </div>
          <span className="text-amber-400 font-black uppercase text-[10px] tracking-wider font-mono flex items-center gap-1.5 pl-2">
            <Code size={12} className="text-amber-400" />
            <span>{cleanLang.toUpperCase()}</span>
            <span className="text-slate-500 font-normal">|</span>
            <span className="text-emerald-400 text-[9px] font-bold">
              {isWebPreviewable 
                ? (lang === "bn" ? "লাইভ ওয়েব স্যান্ডবক্স" : "Live Web Sandbox") 
                : (lang === "bn" ? "স্যান্ডবক্স কোড রানার" : "Sandbox Code Runner")}
            </span>
          </span>
        </div>

        {/* CONTROLS */}
        <div className="flex items-center gap-1.5 font-sans">
          {/* TAB SWITCHER FOR WEB CODE */}
          {isWebPreviewable ? (
            <div className="bg-slate-800 p-0.5 rounded-lg flex items-center border border-slate-700/80">
              <button
                type="button"
                onClick={() => setActiveTab("code")}
                className={`px-2 py-1 rounded text-[10px] font-bold transition ${activeTab === "code" ? "bg-amber-500 text-slate-950 shadow-xs" : "text-slate-400 hover:text-slate-200"}`}
              >
                {lang === "bn" ? "কোড" : "Code"}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("preview")}
                className={`px-2 py-1 rounded text-[10px] font-bold transition ${activeTab === "preview" ? "bg-amber-500 text-slate-950 shadow-xs" : "text-slate-400 hover:text-slate-200"}`}
              >
                {lang === "bn" ? "প্রিভিউ" : "Preview"}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("split")}
                className={`px-2 py-1 rounded text-[10px] font-bold transition ${activeTab === "split" ? "bg-amber-500 text-slate-950 shadow-xs" : "text-slate-400 hover:text-slate-200"}`}
              >
                {lang === "bn" ? "উভয়ই" : "Both"}
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={handleRunSimulatedCode}
              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold transition flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <Play size={11} />
              <span>{lang === "bn" ? "রান করুন" : "Run Code"}</span>
            </button>
          )}

          {/* RESET BUTTON */}
          <button
            type="button"
            onClick={handleReset}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg text-[10px] font-bold transition flex items-center gap-1 border border-slate-700 cursor-pointer"
            title={lang === "bn" ? "মূল কোডে ফিরে যান" : "Reset Code to Original"}
          >
            <RotateCcw size={11} />
            <span>{lang === "bn" ? "রিসেট" : "Reset"}</span>
          </button>

          {/* COPY BUTTON */}
          <button
            type="button"
            onClick={handleCopy}
            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-[10px] font-bold transition flex items-center gap-1 border border-amber-500/30 cursor-pointer"
          >
            {copied ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            <span>{copied ? (lang === "bn" ? "কপি হয়েছে!" : "Copied!") : (lang === "bn" ? "কপি" : "Copy")}</span>
          </button>
        </div>
      </div>

      {/* CODE EDITOR AND PREVIEW DISPLAY AREA */}
      <div className={`grid ${activeTab === "split" && isWebPreviewable ? "grid-cols-1 md:grid-cols-2" : "grid-cols-1"} divide-y md:divide-y-0 md:divide-x divide-slate-800`}>
        
        {/* EDITABLE CODE TEXTAREA */}
        {(activeTab === "code" || activeTab === "split" || !isWebPreviewable) && (
          <div className="p-3 bg-slate-950 flex flex-col space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 select-none pb-1 border-b border-slate-900">
              <span className="flex items-center gap-1">
                <Sparkles size={11} className="text-amber-400" />
                {lang === "bn" ? "পাঠক সরাসরি এই কোড পরিবর্তন বা এডিট করতে পারবেন:" : "Editable Live Reader Code Sandbox:"}
              </span>
              <span className="text-[9px] text-amber-300 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                {lang === "bn" ? "এডিটেবল" : "Editable"}
              </span>
            </div>

            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              spellCheck={false}
              className="w-full h-56 p-3 bg-slate-900/95 text-amber-100 font-mono text-xs leading-relaxed rounded-xl border border-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500 resize-y"
            />
          </div>
        )}

        {/* LIVE PREVIEW IFRAME FOR WEB */}
        {(activeTab === "preview" || activeTab === "split") && isWebPreviewable && (
          <div className="p-3 bg-slate-900 flex flex-col space-y-2">
            <div className="flex items-center justify-between text-[10px] font-sans font-bold text-slate-300 select-none pb-1 border-b border-slate-800">
              <span className="flex items-center gap-1 text-emerald-400">
                <Eye size={12} />
                {lang === "bn" ? "লাইভ আউটপুট প্রিভিউ (Live Preview):" : "Live Output Preview:"}
              </span>
              <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                Auto Render
              </span>
            </div>

            <div className="w-full h-56 rounded-xl border border-slate-800 bg-white overflow-hidden shadow-inner">
              <iframe
                ref={iframeRef}
                title="Code Sandbox Live Output"
                srcDoc={generatePreviewDoc(code)}
                className="w-full h-full border-0 bg-white"
                sandbox="allow-scripts allow-modals allow-same-origin"
              />
            </div>
          </div>
        )}

        {/* SIMULATED CONSOLE FOR NON-WEB CODE */}
        {!isWebPreviewable && nonWebConsoleOutput && (
          <div className="p-3 bg-slate-900 font-mono text-xs text-emerald-400 space-y-1">
            <div className="text-[10px] text-slate-400 pb-1 border-b border-slate-800 font-sans">
              {lang === "bn" ? "সিমুলেটেড কনসোল আউটপুট:" : "Simulated Console Output:"}
            </div>
            <pre className="p-2 bg-slate-950 rounded-lg overflow-x-auto text-[11px] font-mono leading-relaxed">
              {nonWebConsoleOutput}
            </pre>
          </div>
        )}
      </div>

      {/* PRACTICE EXERCISE / QUIZ INPUT TASK SECTION IF DETECTED */}
      {isPracticeExercise && (
        <div className="p-3.5 bg-amber-950/40 border-t border-amber-800/60 font-sans space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-amber-300 flex items-center gap-1.5 uppercase tracking-wide">
              <Sparkles size={13} className="text-amber-400 animate-pulse" />
              <span>{lang === "bn" ? "ইন্টারেক্টিভ পাঠক অনুশীলন (Practice Task)" : "Interactive Reader Practice Task"}</span>
            </span>
            {isTaskCompleted && (
              <span className="text-[10px] font-extrabold px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full flex items-center gap-1">
                <CheckCircle2 size={11} />
                <span>{lang === "bn" ? "সম্পন্ন হয়েছে!" : "Completed!"}</span>
              </span>
            )}
          </div>

          <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
            💡 {lang === "bn" 
              ? "উপরের কোডের উত্তর বা অনুশীলনের ফলাফলটি পরীক্ষা করতে নিচে আপনার তৈরি করা সমাধান লিখুন:" 
              : "Test your understanding by typing your code answer or solution below:"}
          </p>

          <form onSubmit={handleVerifyTask} className="flex gap-2 pt-1">
            <input
              type="text"
              value={userTaskInput}
              onChange={(e) => setUserTaskInput(e.target.value)}
              placeholder={lang === "bn" ? "আপনার উত্তর বা অনুশীলনের কোড আউটপুট লিখুন..." : "Type your answer or output here..."}
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <button
              type="submit"
              className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-extrabold rounded-xl transition flex items-center gap-1 cursor-pointer shrink-0"
            >
              <span>{lang === "bn" ? "যাচাই করুন" : "Submit Answer"}</span>
            </button>
          </form>

          {taskFeedback && (
            <div className={`p-2 rounded-xl text-xs font-bold border ${isTaskCompleted ? "bg-emerald-950/80 border-emerald-500/50 text-emerald-300" : "bg-rose-950/80 border-rose-500/50 text-rose-300"}`}>
              {taskFeedback}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export const CodeSandboxBlock = React.memo(CodeSandboxBlockComponent);
