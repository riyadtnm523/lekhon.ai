import React, { useRef, useEffect } from "react";

export type AmbientAnimationType = "none" | "stars" | "golden_sparkles" | "matrix_cyber" | "zen_ripples" | "aurora_waves";

interface AmbientChatAnimationProps {
  type: AmbientAnimationType;
  opacity?: number;
  className?: string;
}

export const AmbientChatAnimation: React.FC<AmbientChatAnimationProps> = ({
  type,
  opacity = 0.65,
  className = ""
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (type === "none") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 800);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 600);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };

    window.addEventListener("resize", handleResize);

    // 1. STARS & COSMIC PARTICLES SETUP
    interface StarParticle {
      x: number;
      y: number;
      radius: number;
      alpha: number;
      speed: number;
      twinkleSpeed: number;
      color: string;
    }
    const starColors = ["#ffffff", "#fef08a", "#bae6fd", "#fbcfe8", "#c7d2fe"];
    const stars: StarParticle[] = Array.from({ length: 45 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      radius: Math.random() * 2 + 0.8,
      alpha: Math.random() * 0.8 + 0.2,
      speed: Math.random() * 0.3 + 0.1,
      twinkleSpeed: Math.random() * 0.03 + 0.01,
      color: starColors[Math.floor(Math.random() * starColors.length)]
    }));

    // 2. GOLDEN LITERARY SPARKLES SETUP
    interface GoldenMote {
      x: number;
      y: number;
      size: number;
      vy: number;
      vx: number;
      alpha: number;
      maxAlpha: number;
      hue: number;
    }
    const sparkles: GoldenMote[] = Array.from({ length: 35 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 3 + 1,
      vy: -(Math.random() * 0.6 + 0.2),
      vx: (Math.random() - 0.5) * 0.3,
      alpha: Math.random() * 0.6 + 0.1,
      maxAlpha: Math.random() * 0.7 + 0.3,
      hue: Math.random() * 30 + 35 // Golden amber range
    }));

    // 3. MATRIX CYBER DATA PARTICLES SETUP
    interface CyberNode {
      x: number;
      y: number;
      chars: string[];
      currentChar: string;
      speed: number;
      fontSize: number;
      alpha: number;
    }
    const cyberChars = ["0", "1", "α", "β", "λ", "✦", "AI", "◈", "01", "7", "4"];
    const cyberNodes: CyberNode[] = Array.from({ length: 28 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      chars: cyberChars,
      currentChar: cyberChars[Math.floor(Math.random() * cyberChars.length)],
      speed: Math.random() * 1.5 + 0.8,
      fontSize: Math.floor(Math.random() * 5) + 11,
      alpha: Math.random() * 0.6 + 0.2
    }));

    // 4. ZEN RIPPLES SETUP
    interface Ripple {
      x: number;
      y: number;
      radius: number;
      maxRadius: number;
      alpha: number;
      growthRate: number;
      color: string;
    }
    const ripples: Ripple[] = [];
    const rippleColors = ["rgba(217, 119, 6, 0.4)", "rgba(124, 45, 18, 0.3)", "rgba(59, 130, 246, 0.3)"];
    let lastRippleTime = 0;

    // 5. AURORA WAVES SETUP
    let waveOffset = 0;

    let time = 0;
    const render = () => {
      time += 0.02;
      ctx.clearRect(0, 0, width, height);

      if (type === "stars") {
        stars.forEach((s) => {
          s.y -= s.speed;
          if (s.y < 0) s.y = height;
          s.alpha += Math.sin(time * 5 + s.x) * s.twinkleSpeed;
          const currentAlpha = Math.max(0.1, Math.min(0.9, s.alpha));

          ctx.save();
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
          ctx.fillStyle = s.color;
          ctx.globalAlpha = currentAlpha * opacity;
          ctx.shadowBlur = s.radius * 4;
          ctx.shadowColor = s.color;
          ctx.fill();
          ctx.restore();
        });
      } else if (type === "golden_sparkles") {
        sparkles.forEach((p) => {
          p.y += p.vy;
          p.x += p.vx + Math.sin(time + p.y * 0.05) * 0.2;
          if (p.y < -10) {
            p.y = height + 10;
            p.x = Math.random() * width;
          }
          ctx.save();
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = `hsla(${p.hue}, 90%, 65%, ${p.alpha * opacity})`;
          ctx.shadowBlur = p.size * 5;
          ctx.shadowColor = `hsl(${p.hue}, 90%, 60%)`;
          ctx.fill();

          // Little cross spark
          if (p.size > 2.2) {
            ctx.strokeStyle = `hsla(${p.hue}, 90%, 80%, ${p.alpha * opacity * 0.7})`;
            ctx.lineWidth = 0.8;
            ctx.beginPath();
            ctx.moveTo(p.x - p.size * 1.5, p.y);
            ctx.lineTo(p.x + p.size * 1.5, p.y);
            ctx.moveTo(p.x, p.y - p.size * 1.5);
            ctx.lineTo(p.x, p.y + p.size * 1.5);
            ctx.stroke();
          }
          ctx.restore();
        });
      } else if (type === "matrix_cyber") {
        ctx.save();
        ctx.font = "bold 12px monospace";
        cyberNodes.forEach((node) => {
          node.y += node.speed;
          if (node.y > height + 20) {
            node.y = -10;
            node.x = Math.random() * width;
            node.currentChar = node.chars[Math.floor(Math.random() * node.chars.length)];
          }
          if (Math.random() < 0.03) {
            node.currentChar = node.chars[Math.floor(Math.random() * node.chars.length)];
          }
          ctx.fillStyle = `rgba(245, 158, 11, ${node.alpha * opacity})`;
          ctx.shadowBlur = 6;
          ctx.shadowColor = "#f59e0b";
          ctx.fillText(node.currentChar, node.x, node.y);
        });
        ctx.restore();
      } else if (type === "zen_ripples") {
        if (Date.now() - lastRippleTime > 1400) {
          lastRippleTime = Date.now();
          ripples.push({
            x: Math.random() * (width * 0.8) + width * 0.1,
            y: Math.random() * (height * 0.8) + height * 0.1,
            radius: 5,
            maxRadius: Math.random() * 80 + 50,
            alpha: 0.5,
            growthRate: Math.random() * 0.8 + 0.6,
            color: rippleColors[Math.floor(Math.random() * rippleColors.length)]
          });
        }
        for (let i = ripples.length - 1; i >= 0; i--) {
          const r = ripples[i];
          r.radius += r.growthRate;
          r.alpha = Math.max(0, 0.5 * (1 - r.radius / r.maxRadius));
          if (r.radius >= r.maxRadius || r.alpha <= 0) {
            ripples.splice(i, 1);
            continue;
          }
          ctx.save();
          ctx.beginPath();
          ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2);
          ctx.strokeStyle = r.color;
          ctx.globalAlpha = r.alpha * opacity;
          ctx.lineWidth = 1.8;
          ctx.shadowBlur = 8;
          ctx.shadowColor = r.color;
          ctx.stroke();
          ctx.restore();
        }
      } else if (type === "aurora_waves") {
        waveOffset += 0.008;
        ctx.save();
        for (let w = 0; w < 3; w++) {
          ctx.beginPath();
          const gradient = ctx.createLinearGradient(0, 0, width, height);
          if (w === 0) {
            gradient.addColorStop(0, "rgba(245, 158, 11, 0.18)");
            gradient.addColorStop(0.5, "rgba(234, 88, 12, 0.12)");
            gradient.addColorStop(1, "rgba(124, 45, 18, 0)");
          } else if (w === 1) {
            gradient.addColorStop(0, "rgba(99, 102, 241, 0.14)");
            gradient.addColorStop(0.5, "rgba(168, 85, 247, 0.1)");
            gradient.addColorStop(1, "rgba(236, 72, 153, 0)");
          } else {
            gradient.addColorStop(0, "rgba(16, 185, 129, 0.12)");
            gradient.addColorStop(0.5, "rgba(6, 182, 212, 0.1)");
            gradient.addColorStop(1, "rgba(59, 130, 246, 0)");
          }

          ctx.moveTo(0, height);
          for (let x = 0; x <= width; x += 20) {
            const y = Math.sin(x * 0.004 + waveOffset + w) * 45 + Math.cos(x * 0.008 - waveOffset * 0.8) * 30 + (height * 0.45 + w * 40);
            ctx.lineTo(x, y);
          }
          ctx.lineTo(width, height);
          ctx.closePath();
          ctx.fillStyle = gradient;
          ctx.globalAlpha = opacity;
          ctx.fill();
        }
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [type, opacity]);

  if (type === "none") return null;

  return (
    <canvas
      ref={canvasRef}
      className={`absolute inset-0 pointer-events-none z-1 w-full h-full ${className}`}
      style={{ mixBlendMode: "screen" }}
    />
  );
};
