import React, { useState, useEffect } from "react";
import { X, BookOpen, Star, Heart, Award, Share2, Check, UserCheck, UserPlus, Sparkles, ExternalLink, ShieldCheck, Mail, Calendar } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Animated3DProfileCard } from "./Animated3DProfileCard";
import { db, doc, getDoc, updateDoc, arrayUnion, arrayRemove } from "../firebase";

export interface AuthorProfileData {
  userId: string;
  name: string;
  email?: string;
  photoURL?: string;
  bio?: string;
  role?: string;
  joinedDate?: string;
  booksCount?: number;
  totalChapters?: number;
  totalWordsEstimated?: number;
  followers?: string[];
}

interface PublicAuthorProfileModalProps {
  author: AuthorProfileData | null;
  isOpen: boolean;
  onClose: () => void;
  lang: "bn" | "en";
  currentUserId?: string;
  authorBooks: any[];
  onSelectBook: (book: any) => void;
}

export const PublicAuthorProfileModal: React.FC<PublicAuthorProfileModalProps> = ({
  author,
  isOpen,
  onClose,
  lang,
  currentUserId,
  authorBooks,
  onSelectBook
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);

  useEffect(() => {
    if (author) {
      const followers = author.followers || [];
      setIsFollowing(currentUserId ? followers.includes(currentUserId) : false);
      setFollowersCount(followers.length);
    }
  }, [author, currentUserId]);

  if (!isOpen || !author) return null;

  const handleToggleFollow = async () => {
    if (!currentUserId || !author.userId) {
      alert(lang === "bn" ? "অনুসরণ করতে লগইন করুন।" : "Please sign in to follow authors.");
      return;
    }

    try {
      const authorRef = doc(db, "users", author.userId);
      if (isFollowing) {
        setIsFollowing(false);
        setFollowersCount(prev => Math.max(0, prev - 1));
        await updateDoc(authorRef, {
          followers: arrayRemove(currentUserId)
        });
      } else {
        setIsFollowing(true);
        setFollowersCount(prev => prev + 1);
        await updateDoc(authorRef, {
          followers: arrayUnion(currentUserId)
        });
      }
    } catch (err) {
      console.error("Follow error:", err);
    }
  };

  const handleShareProfile = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const totalWords = authorBooks.reduce((acc, b) => {
    return acc + (b.chapters ? b.chapters.reduce((sum: number, c: any) => sum + (c.content ? c.content.split(/\s+/).length : 0), 0) : 3500);
  }, 0);

  const totalChapters = authorBooks.reduce((acc, b) => acc + (b.chapters?.length || 0), 0);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/60 backdrop-blur-sm animate-fadeIn">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="bg-white rounded-3xl shadow-2xl border border-amber-200/80 w-full max-w-2xl overflow-hidden relative text-left my-auto"
        >
          {/* Header Bar */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-amber-100 bg-amber-50/50">
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-[#7c2d12]" />
              <h3 className="text-base font-black text-slate-900">
                {lang === "bn" ? "লেখক প্রোফাইল ও জীবনী" : "Author Public Profile"}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleShareProfile}
                className="p-1.5 hover:bg-amber-100 rounded-xl text-slate-600 transition flex items-center gap-1 text-xs font-bold cursor-pointer"
                title={lang === "bn" ? "প্রোফাইল লিংক কপি করুন" : "Share Profile Link"}
              >
                {copiedLink ? <Check size={14} className="text-emerald-600" /> : <Share2 size={14} />}
                <span className="hidden sm:inline">{copiedLink ? (lang === "bn" ? "কপি হয়েছে!" : "Copied!") : (lang === "bn" ? "শেয়ার" : "Share")}</span>
              </button>
              <button
                onClick={onClose}
                className="p-1.5 hover:bg-rose-100 hover:text-rose-600 rounded-xl text-slate-400 transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
            {/* 3D Interactive Profile Hologram Card */}
            <Animated3DProfileCard
              displayName={author.name}
              loginId={author.userId ? author.userId.substring(0, 10) : undefined}
              email={author.email}
              role={author.role || "Featured Author"}
              photoURL={author.photoURL}
              booksCount={authorBooks.length || author.booksCount || 1}
              totalChapters={totalChapters || author.totalChapters || 4}
              totalWordsEstimated={totalWords || author.totalWordsEstimated || 12000}
              lang={lang}
              isReadOnly={true}
            />

            {/* Actions: Follow / Author Bio */}
            <div className="bg-amber-50/40 p-4 rounded-2xl border border-amber-200/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-extrabold text-slate-800 flex items-center gap-1">
                    <ShieldCheck size={14} className="text-amber-700" />
                    {author.name}
                  </span>
                  <span className="text-[10px] font-bold bg-amber-200/70 text-amber-950 px-2 py-0.5 rounded-full">
                    {followersCount} {lang === "bn" ? "জন ফলোয়ার" : "Followers"}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 font-medium">
                  {author.bio || (lang === "bn" ? "লেখক এআই প্ল্যাটফর্মের সক্রিয় গল্পকার ও সাহিত্যস্রষ্টা।" : "Dedicated creative storyteller and published writer on Lekhok AI.")}
                </p>
              </div>

              {currentUserId && currentUserId !== author.userId && (
                <button
                  onClick={handleToggleFollow}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 shadow-xs ${
                    isFollowing
                      ? "bg-slate-200 hover:bg-slate-300 text-slate-800"
                      : "bg-[#7c2d12] hover:bg-[#63220c] text-amber-50"
                  }`}
                >
                  {isFollowing ? <UserCheck size={14} /> : <UserPlus size={14} />}
                  <span>{isFollowing ? (lang === "bn" ? "অনুসরণ করছেন" : "Following") : (lang === "bn" ? "+ ফলো করুন" : "+ Follow")}</span>
                </button>
              )}
            </div>

            {/* Published Books by this Author */}
            <div className="space-y-3">
              <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <BookOpen size={14} className="text-[#7c2d12]" />
                <span>{lang === "bn" ? "লেখকের প্রকাশিত বইসমূহ" : "Books by this Author"} ({authorBooks.length})</span>
              </h4>

              {authorBooks.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-xs text-slate-400 font-bold">
                  {lang === "bn" ? "এই লেখকের এখনও কোনো বই পাবলিকলি প্রকাশিত নেই।" : "No public books found for this author yet."}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {authorBooks.map((b) => (
                    <div
                      key={b.id}
                      className="bg-white border border-amber-200/80 rounded-2xl p-3.5 hover:shadow-md transition flex flex-col justify-between space-y-3 group"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-bold uppercase tracking-wider bg-amber-100 text-amber-900 px-2 py-0.5 rounded-md">
                            {b.genre || "Fiction"}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {b.chapters?.length || 0} {lang === "bn" ? "অধ্যায়" : "Chs"}
                          </span>
                        </div>
                        <h5 className="text-xs font-extrabold text-slate-900 line-clamp-1 group-hover:text-[#7c2d12] transition">
                          {b.title}
                        </h5>
                        <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">
                          {b.synopsis}
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          onSelectBook(b);
                          onClose();
                        }}
                        className="w-full py-2 bg-amber-50 hover:bg-[#7c2d12] hover:text-white text-[#7c2d12] border border-amber-300/80 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <BookOpen size={12} />
                        <span>{lang === "bn" ? "বইটি পড়ুন" : "Read Book"}</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
