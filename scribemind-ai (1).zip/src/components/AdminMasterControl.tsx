import React, { useState, useEffect } from "react";
import { 
  ShieldAlert, Users, Palette, BookOpen, Settings,
  Trash2, Ban, CheckCircle, Edit3, Plus, Search, 
  Sparkles, RefreshCw, Eye, EyeOff, Save, Lock, 
  Layers, Megaphone, Check, X, Sliders, Globe,
  Terminal, ShieldCheck, UserPlus, AlertTriangle, Cloud, Download,
  CreditCard, Smartphone, Crown, DollarSign, CheckCircle2, XCircle,
  Code2, Cpu, Wrench
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Book } from "../types";
import { db, collection, getDocs, doc, setDoc, updateDoc, deleteDoc } from "../firebase";
import { DEFAULT_PAYMENT_CONFIG, PaymentConfig } from "./PremiumStoreModal";
import { AdminAICodeArchitect } from "./AdminAICodeArchitect";

export interface AdminUser {
  uid: string;
  loginId?: string;
  username?: string;
  email?: string;
  displayName: string;
  photoURL?: string;
  password?: string;
  role: "admin" | "author" | "vip" | "user";
  isBanned?: boolean;
  banReason?: string;
  createdAt: string;
  booksCount: number;
  followersCount: number;
  totalLikes: number;
  isGuest?: boolean;
}

export interface SiteDesignConfig {
  appTitle: string;
  tagline: string;
  announcementText: string;
  announcementActive: boolean;
  announcementBg: string;
  primaryTheme: "amber" | "sapphire" | "emerald" | "rose" | "dark" | "crimson";
  proModeActive?: boolean;
  proBadgeText?: string;
  enabledTabs: {
    editor: boolean;
    ai_chat: boolean;
    voice_buddy: boolean;
    code_studio: boolean;
    mind_matrix: boolean;
    social: boolean;
    history: boolean;
    pro_voice?: boolean;
    code_board?: boolean;
  };
  customNoticeHtml?: string;
  customBannerImageUrl?: string;
  customCss?: string;
  customJs?: string;
  maintenanceMode: boolean;
  footerNote: string;
  customWidgets: Array<{
    id: string;
    title: string;
    description: string;
    icon: string;
    actionUrl?: string;
    customHtml?: string;
    active: boolean;
  }>;
}

interface AdminMasterControlProps {
  lang: "bn" | "en";
  adminBooks: Book[];
  onDeleteBook: (bookId: string) => void;
  onUnpublishBook: (book: Book) => void;
  onUpdateBook?: (book: Book) => void;
  currentUser?: any;
  siteConfig: SiteDesignConfig;
  onUpdateSiteConfig: (newConfig: SiteDesignConfig) => void;
  onClose: () => void;
}

export const AdminMasterControl: React.FC<AdminMasterControlProps> = ({
  lang,
  adminBooks,
  onDeleteBook,
  onUnpublishBook,
  onUpdateBook,
  currentUser,
  siteConfig,
  onUpdateSiteConfig,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<"ai_architect" | "users" | "design" | "books" | "widgets" | "security" | "payments">("ai_architect");
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const [bookSearchQuery, setBookSearchQuery] = useState("");
  const [isLoadingFirestoreUsers, setIsLoadingFirestoreUsers] = useState(false);

  // Payment Management State
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig>(() => {
    const saved = localStorage.getItem("lekhok_payment_config");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return DEFAULT_PAYMENT_CONFIG;
  });
  const [paymentRequests, setPaymentRequests] = useState<any[]>(() => {
    const saved = localStorage.getItem("lekhok_pending_payments");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [];
  });
  const [paymentSavedToast, setPaymentSavedToast] = useState(false);

  // Sync Payment Requests from Firestore
  const syncPaymentRequests = async () => {
    try {
      const snap = await getDocs(collection(db, "payment_requests"));
      const list: any[] = [];
      snap.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() });
      });
      if (list.length > 0) {
        setPaymentRequests(list);
        localStorage.setItem("lekhok_pending_payments", JSON.stringify(list));
      }
    } catch (e) {
      console.warn("Firestore payment requests fetch notice:", e);
    }
  };

  useEffect(() => {
    syncPaymentRequests();
  }, []);

  const handleSavePaymentConfig = async () => {
    try {
      await setDoc(doc(db, "system_settings", "payments_config"), paymentConfig);
      localStorage.setItem("lekhok_payment_config", JSON.stringify(paymentConfig));
      setPaymentSavedToast(true);
      setTimeout(() => setPaymentSavedToast(false), 3000);
      alert(lang === "bn" ? "পেমেন্ট সেটিংস সফলভাবে সেভ হয়েছে!" : "Payment configuration saved successfully!");
    } catch (err: any) {
      alert(err.message || "Failed to save payment config.");
    }
  };

  const handleApprovePayment = async (reqItem: any) => {
    try {
      // 1. Upgrade User Role to VIP Pro
      const targetUser = usersList.find(u => u.uid === reqItem.userId || u.loginId === reqItem.userId || u.email === reqItem.userEmail);
      if (targetUser) {
        const updatedUser = { ...targetUser, role: "vip" as const };
        const updatedList = usersList.map(u => u.uid === targetUser.uid ? updatedUser : u);
        saveUsersList(updatedList);
        try {
          await setDoc(doc(db, "users", targetUser.uid), { role: "vip", isPro: true, proGrantedAt: new Date().toISOString() }, { merge: true });
        } catch (e) {}
      }

      // 2. Mark payment request as approved
      const updatedReqs = paymentRequests.map(r => r.trxId === reqItem.trxId ? { ...r, status: "approved" } : r);
      setPaymentRequests(updatedReqs);
      localStorage.setItem("lekhok_pending_payments", JSON.stringify(updatedReqs));

      if (reqItem.id) {
        try {
          await updateDoc(doc(db, "payment_requests", reqItem.id), { status: "approved", approvedAt: new Date().toISOString() });
        } catch (e) {}
      }

      alert(lang === "bn" ? `✅ TrxID ${reqItem.trxId} অ্যাপ্রুভ হয়েছে এবং ইউজারকে ভিআইপি প্রো স্ট্যাটাস দেওয়া হয়েছে!` : `✅ TrxID ${reqItem.trxId} approved & User upgraded to VIP Pro!`);
    } catch (err: any) {
      alert(err.message || "Error approving payment.");
    }
  };

  const handleRejectPayment = async (reqItem: any) => {
    const updatedReqs = paymentRequests.map(r => r.trxId === reqItem.trxId ? { ...r, status: "rejected" } : r);
    setPaymentRequests(updatedReqs);
    localStorage.setItem("lekhok_pending_payments", JSON.stringify(updatedReqs));

    if (reqItem.id) {
      try {
        await updateDoc(doc(db, "payment_requests", reqItem.id), { status: "rejected", rejectedAt: new Date().toISOString() });
      } catch (e) {}
    }
    alert(lang === "bn" ? `❌ TrxID ${reqItem.trxId} বাতিল করা হয়েছে।` : `❌ TrxID ${reqItem.trxId} rejected.`);
  };
  
  // Users state with persistence
  const [usersList, setUsersList] = useState<AdminUser[]>(() => {
    const saved = localStorage.getItem("lekhok_admin_users_db");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      {
        uid: "usr_admin_001",
        loginId: "LKH-ADMIN1",
        username: "superadmin",
        email: "admin@lekhok.ai",
        displayName: "Master Administrator",
        role: "admin",
        isBanned: false,
        createdAt: "2025-01-10",
        booksCount: 12,
        followersCount: 1450,
        totalLikes: 890,
        password: "adminmaster2025"
      }
    ];
  });

  // Fetch real users from Firestore on mount & live refresh
  const syncFirestoreUsers = async () => {
    try {
      setIsLoadingFirestoreUsers(true);
      const userDocs = await getDocs(collection(db, "users"));
      const firestoreUsers: AdminUser[] = [];

      userDocs.forEach((docSnap) => {
        const d = docSnap.data();
        // Ignore duplicate login ID pointer docs
        if (docSnap.id.startsWith("login-")) return;

        firestoreUsers.push({
          uid: d.uid || docSnap.id,
          loginId: d.loginId || `LKH-${docSnap.id.slice(0, 6)}`,
          username: d.username || d.email?.split("@")[0] || d.displayName?.toLowerCase().replace(/\s+/g, "_") || "user",
          email: d.email || `${d.uid}@registered.user`,
          displayName: d.displayName || d.email?.split("@")[0] || "Active Author",
          photoURL: d.photoURL,
          password: d.password || d.demoPassword || "••••••••",
          role: d.isAdmin ? "admin" : (d.role || "author"),
          isBanned: d.isBanned || false,
          banReason: d.banReason,
          createdAt: d.createdAt ? d.createdAt.split("T")[0] : new Date().toISOString().split("T")[0],
          booksCount: d.booksCount || 0,
          followersCount: d.followersCount || (d.followers ? d.followers.length : 0),
          totalLikes: d.totalLikesReceived || 0,
          isGuest: d.isGuest || false
        });
      });

      // Merge with any local demo users
      setUsersList((prev) => {
        const map = new Map<string, AdminUser>();
        prev.forEach(u => map.set(u.uid, u));
        firestoreUsers.forEach(u => map.set(u.uid, u));
        const merged = Array.from(map.values());
        localStorage.setItem("lekhok_admin_users_db", JSON.stringify(merged));
        return merged;
      });
    } catch (err) {
      console.warn("Firestore user sync notice:", err);
    } finally {
      setIsLoadingFirestoreUsers(false);
    }
  };

  useEffect(() => {
    syncFirestoreUsers();
  }, []);

  // Sync users list to localStorage & Firestore
  const saveUsersList = async (updated: AdminUser[]) => {
    setUsersList(updated);
    try {
      localStorage.setItem("lekhok_admin_users_db", JSON.stringify(updated));
    } catch (e) {}
  };

  // Create User Modal State
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [newUserName, setNewUserName] = useState("");
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [newUserRole, setNewUserRole] = useState<"admin" | "author" | "vip" | "user">("author");

  // Edit User Modal State
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [showPasswordMap, setShowPasswordMap] = useState<Record<string, boolean>>({});

  // Local copy of Site Design Config
  const [localConfig, setLocalConfig] = useState<SiteDesignConfig>(siteConfig);
  const [configSavedToast, setConfigSavedToast] = useState(false);

  // New Widget State
  const [newWidgetTitle, setNewWidgetTitle] = useState("");
  const [newWidgetDesc, setNewWidgetDesc] = useState("");
  const [newWidgetIcon, setNewWidgetIcon] = useState("Sparkles");

  // Editing Book State
  const [editingBook, setEditingBook] = useState<Book | null>(null);

  // Sync siteConfig updates
  useEffect(() => {
    setLocalConfig(siteConfig);
  }, [siteConfig]);

  // Handle Ban/Unban Toggle
  const handleToggleBanUser = (uid: string) => {
    const target = usersList.find(u => u.uid === uid);
    if (!target) return;

    if (!target.isBanned) {
      const reason = window.prompt(
        lang === "bn" ? "ইউজারকে ব্যান করার কারণ লিখুন:" : "Enter reason for banning user:",
        "Violated platform rules"
      );
      if (reason === null) return; // Cancelled
      const updated = usersList.map(u => u.uid === uid ? { ...u, isBanned: true, banReason: reason || "Administrative Ban" } : u);
      saveUsersList(updated);
    } else {
      if (window.confirm(lang === "bn" ? "এই ইউজারকে আনব্যান করতে চান?" : "Unban this user?")) {
        const updated = usersList.map(u => u.uid === uid ? { ...u, isBanned: false, banReason: undefined } : u);
        saveUsersList(updated);
      }
    }
  };

  // Handle Delete User
  const handleDeleteUser = (uid: string) => {
    if (window.confirm(lang === "bn" ? "আপনি কি নিশ্চিতভাবে এই ইউজারকে সম্পূর্ণরূপে মুছে ফেলতে চান?" : "Are you sure you want to permanently delete this user?")) {
      const updated = usersList.filter(u => u.uid !== uid);
      saveUsersList(updated);
    }
  };

  // Handle Save New User
  const handleCreateNewUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim()) return;

    const randomId = "LKH-" + Math.floor(100000 + Math.random() * 900000);
    const newUser: AdminUser = {
      uid: "usr_" + Date.now(),
      loginId: randomId,
      username: (newUserEmail.split("@")[0] || newUserName.toLowerCase().replace(/\s+/g, "_")).substring(0, 15),
      email: newUserEmail || `${newUserName.toLowerCase().replace(/\s+/g, "")}@lekhok.ai`,
      displayName: newUserName,
      password: newUserPassword || "pass" + Math.floor(1000 + Math.random() * 9000),
      role: newUserRole,
      isBanned: false,
      createdAt: new Date().toISOString().split("T")[0],
      booksCount: 0,
      followersCount: 0,
      totalLikes: 0
    };

    saveUsersList([newUser, ...usersList]);
    setShowCreateUserModal(false);
    setNewUserName("");
    setNewUserEmail("");
    setNewUserPassword("");
    alert(lang === "bn" ? `✅ নতুন ইউজার '${newUser.displayName}' সফলভাবে তৈরি হয়েছে!` : `✅ User '${newUser.displayName}' created!`);
  };

  // Save Edited User
  const handleSaveEditedUser = () => {
    if (!editingUser) return;
    const updated = usersList.map(u => u.uid === editingUser.uid ? editingUser : u);
    saveUsersList(updated);
    setEditingUser(null);
    alert(lang === "bn" ? "ইউজার তথ্য আপডেট হয়েছে!" : "User updated successfully!");
  };

  // Apply & Save Site Design Config
  const handleSaveDesignConfig = () => {
    onUpdateSiteConfig(localConfig);
    setConfigSavedToast(true);
    setTimeout(() => setConfigSavedToast(false), 3000);
  };

  // Add Custom Widget to layout
  const handleAddWidget = () => {
    if (!newWidgetTitle.trim()) return;
    const newWidget = {
      id: "widget_" + Date.now(),
      title: newWidgetTitle,
      description: newWidgetDesc || "Custom interactive widget created from admin panel.",
      icon: newWidgetIcon,
      active: true
    };
    const updatedWidgets = [...(localConfig.customWidgets || []), newWidget];
    const updatedConfig = { ...localConfig, customWidgets: updatedWidgets };
    setLocalConfig(updatedConfig);
    onUpdateSiteConfig(updatedConfig);
    setNewWidgetTitle("");
    setNewWidgetDesc("");
  };

  // Delete Custom Widget
  const handleDeleteWidget = (widgetId: string) => {
    const updatedWidgets = (localConfig.customWidgets || []).filter(w => w.id !== widgetId);
    const updatedConfig = { ...localConfig, customWidgets: updatedWidgets };
    setLocalConfig(updatedConfig);
    onUpdateSiteConfig(updatedConfig);
  };

  // Filtered Users
  const filteredUsers = usersList.filter(u => 
    u.displayName.toLowerCase().includes(userSearchQuery.toLowerCase()) ||
    (u.email && u.email.toLowerCase().includes(userSearchQuery.toLowerCase())) ||
    (u.username && u.username.toLowerCase().includes(userSearchQuery.toLowerCase())) ||
    (u.loginId && u.loginId.toLowerCase().includes(userSearchQuery.toLowerCase()))
  );

  // Filtered Books
  const filteredBooks = adminBooks.filter(b =>
    b.title.toLowerCase().includes(bookSearchQuery.toLowerCase()) ||
    (b.genre && b.genre.toLowerCase().includes(bookSearchQuery.toLowerCase())) ||
    (b.creatorEmail && b.creatorEmail.toLowerCase().includes(bookSearchQuery.toLowerCase()))
  );

  return (
    <div className="w-full max-w-7xl mx-auto p-4 sm:p-6 font-sans text-left space-y-6 animate-fadeIn pb-16">
      
      {/* HEADER BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-stone-900 to-[#7c2d12] text-white p-6 rounded-3xl shadow-xl border border-amber-500/20 relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="relative z-10 space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 bg-amber-500/20 border border-amber-400/40 rounded-full text-amber-300 text-[10px] font-black tracking-widest uppercase flex items-center gap-1">
              <ShieldAlert size={12} />
              <span>SUPER ADMIN CONTROL CENTER</span>
            </span>
            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full border border-emerald-500/30">
              Master Access Active
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-amber-50">
            {lang === "bn" ? "ওয়েবসাইট সুপার অ্যাডমিন ও কন্ট্রোল প্যানেল" : "Master Website Administration"}
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl font-medium">
            {lang === "bn" 
              ? "এখান থেকে ওয়েবসাইটের যেকোনো ডিজাইন, কন্টেন্ট, ফিচার পরিবর্তন করুন, সকল ইউজারদের পূর্ণ বিবরণ দেখুন, ব্যান করুন এবং নতুন কন্টেন্ট বা উইজেট যুক্ত করুন।" 
              : "Full root-level control: customize site architecture, themes, banners, manage & ban users, edit manuscripts, and add dynamic widgets."}
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-2 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-white/15 cursor-pointer backdrop-blur-xs"
          >
            <X size={14} />
            <span>{lang === "bn" ? "প্যানেল বন্ধ করুন" : "Close Admin"}</span>
          </button>
        </div>

        {/* Decorative Grid BG */}
        <div className="absolute inset-0 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px] opacity-10 pointer-events-none" />
      </div>

      {/* METRICS SUMMARY BAR */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs text-left">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">Total Users</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-slate-900 font-mono">{usersList.length}</span>
            <Users size={20} className="text-[#7c2d12]" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs text-left">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">Total Manuscripts</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-amber-600 font-mono">{adminBooks.length}</span>
            <BookOpen size={20} className="text-amber-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs text-left">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">Banned Accounts</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-black text-rose-600 font-mono">
              {usersList.filter(u => u.isBanned).length}
            </span>
            <Ban size={20} className="text-rose-600" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs text-left">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">Active Theme</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-lg font-black text-emerald-600 uppercase font-mono">{localConfig.primaryTheme}</span>
            <Palette size={20} className="text-emerald-600" />
          </div>
        </div>
      </div>

      {/* ADMIN NAVIGATION TABS */}
      <div className="flex items-center gap-1.5 bg-slate-100/90 p-1.5 rounded-2xl border border-slate-200 overflow-x-auto">
        <button
          onClick={() => setActiveTab("ai_architect")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === "ai_architect" ? "bg-gradient-to-r from-slate-900 to-indigo-950 text-cyan-300 shadow-md border border-cyan-500/40" : "text-slate-700 hover:text-slate-950 font-bold"
          }`}
        >
          <Code2 size={15} className="text-cyan-400 animate-pulse" />
          <span>{lang === "bn" ? "★ এআই কোড আর্কিটেক্ট ও ওয়েবসাইট কন্ট্রোল" : "★ AI Code Architect & Site Builder"}</span>
          <span className="px-1.5 py-0.2 bg-cyan-500/20 text-cyan-300 rounded-full text-[9px] font-mono font-bold border border-cyan-500/30">AI Live</span>
        </button>

        <button
          onClick={() => setActiveTab("users")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === "users" ? "bg-white text-[#7c2d12] shadow-sm border border-slate-200" : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Users size={14} />
          <span>{lang === "bn" ? "১. সকল ইউজার ও মডারেশন" : "1. User Management & Bans"}</span>
          <span className="px-1.5 py-0.2 bg-slate-100 rounded-full text-[9px] font-bold">{usersList.length}</span>
        </button>

        <button
          onClick={() => setActiveTab("design")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === "design" ? "bg-white text-[#7c2d12] shadow-sm border border-slate-200" : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Palette size={14} />
          <span>{lang === "bn" ? "২. ওয়েবসাইট ডিজাইন ও ব্র্যান্ডিং" : "2. Website Design & Branding"}</span>
        </button>

        <button
          onClick={() => setActiveTab("books")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === "books" ? "bg-white text-[#7c2d12] shadow-sm border border-slate-200" : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <BookOpen size={14} />
          <span>{lang === "bn" ? "৩. বইয়ের ডাটাবেস ও কন্টেন্ট" : "3. Books & Content Master"}</span>
          <span className="px-1.5 py-0.2 bg-slate-100 rounded-full text-[9px] font-bold">{adminBooks.length}</span>
        </button>

        <button
          onClick={() => setActiveTab("widgets")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === "widgets" ? "bg-white text-[#7c2d12] shadow-sm border border-slate-200" : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <Layers size={14} />
          <span>{lang === "bn" ? "৪. কাস্টম উইজেট ও ব্যানার" : "4. Custom Widgets & Cards"}</span>
          <span className="px-1.5 py-0.2 bg-slate-100 rounded-full text-[9px] font-bold">{localConfig.customWidgets?.length || 0}</span>
        </button>

        <button
          onClick={() => setActiveTab("security")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === "security" ? "bg-white text-[#7c2d12] shadow-sm border border-slate-200" : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <ShieldCheck size={14} />
          <span>{lang === "bn" ? "৫. সিস্টেম ও সিকিউরিটি" : "5. Security & Maintenance"}</span>
        </button>

        <button
          onClick={() => setActiveTab("payments")}
          className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 cursor-pointer whitespace-nowrap ${
            activeTab === "payments" ? "bg-white text-amber-700 shadow-sm border border-slate-200" : "text-slate-600 hover:text-slate-900"
          }`}
        >
          <CreditCard size={14} className="text-amber-600" />
          <span>{lang === "bn" ? "৬. পেমেন্ট ও প্রো সাবস্ক্রিপশন" : "6. Payments & Pro Plans"}</span>
          {paymentRequests.filter(r => r.status === "pending").length > 0 && (
            <span className="px-1.5 py-0.2 bg-rose-500 text-white rounded-full text-[9px] font-black animate-pulse">
              {paymentRequests.filter(r => r.status === "pending").length}
            </span>
          )}
        </button>
      </div>

      {/* =========================================================
          TAB 0: AI CODE ARCHITECT & AUTONOMOUS SITE CONTROLLER
          ========================================================= */}
      {activeTab === "ai_architect" && (
        <AdminAICodeArchitect
          lang={lang}
          siteConfig={localConfig}
          onUpdateSiteConfig={(newCfg) => {
            setLocalConfig(newCfg);
            onUpdateSiteConfig(newCfg);
          }}
          usersList={usersList}
          onUpdateUsersList={saveUsersList}
          adminBooks={adminBooks}
        />
      )}

      {/* =========================================================
          TAB 1: USER MANAGEMENT & BANNING SYSTEM
          ========================================================= */}
      {activeTab === "users" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="relative flex-1 w-full max-w-md">
              <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={userSearchQuery}
                onChange={(e) => setUserSearchQuery(e.target.value)}
                placeholder={lang === "bn" ? "নাম, ইমেইল, ইউজারনেম বা Login ID দিয়ে খুঁজুন..." : "Search by name, email, handle, or Login ID..."}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={syncFirestoreUsers}
                disabled={isLoadingFirestoreUsers}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-slate-200 cursor-pointer"
                title="Sync users and Google login accounts from Firestore"
              >
                <RefreshCw size={13} className={isLoadingFirestoreUsers ? "animate-spin text-amber-600" : ""} />
                <span>{isLoadingFirestoreUsers ? (lang === "bn" ? "সিঙ্ক হচ্ছে..." : "Syncing...") : (lang === "bn" ? "ফায়ারবেস ইউজার সিঙ্ক" : "Sync Firestore Users")}</span>
              </button>

              <button
                onClick={() => setShowCreateUserModal(true)}
                className="px-4 py-2 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer shrink-0"
              >
                <UserPlus size={14} />
                <span>{lang === "bn" ? "নতুন ইউজার তৈরি করুন" : "Add New User"}</span>
              </button>
            </div>
          </div>

          {/* USERS TABLE */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-4">User Profile</th>
                    <th className="py-3 px-4">Login ID & Credentials</th>
                    <th className="py-3 px-4">Role & Status</th>
                    <th className="py-3 px-4">Stats</th>
                    <th className="py-3 px-4">Joined</th>
                    <th className="py-3 px-4 text-right">Admin Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 font-bold">
                        {lang === "bn" ? "কোনো ইউজার পাওয়া যায়নি" : "No users matched your query."}
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((user) => (
                      <tr key={user.uid} className={`hover:bg-slate-50/80 transition ${user.isBanned ? "bg-red-50/40" : ""}`}>
                        {/* USER PROFILE */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2.5">
                            <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#7c2d12] to-amber-600 text-amber-50 font-black text-xs flex items-center justify-center shrink-0 shadow-2xs">
                              {user.displayName.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="font-extrabold text-slate-900 flex items-center gap-1">
                                <span>{user.displayName}</span>
                                {user.isBanned && (
                                  <span className="px-1.5 py-0.2 bg-red-100 text-red-700 text-[8px] font-black rounded-md border border-red-200">
                                    BANNED
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-slate-400 block font-mono">@{user.username || "user"}</span>
                            </div>
                          </div>
                        </td>

                        {/* CREDENTIALS */}
                        <td className="py-3.5 px-4 font-mono text-[11px]">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1">
                              <span className="text-amber-700 font-extrabold">{user.loginId || "LKH-DEFAULT"}</span>
                            </div>
                            <span className="text-slate-500 text-[10px] block truncate max-w-[150px]">{user.email || "No Email"}</span>
                            <div className="flex items-center gap-1 text-[10px] text-slate-400">
                              <span>Pass:</span>
                              <span className="text-slate-700 font-bold">
                                {showPasswordMap[user.uid] ? (user.password || "••••••••") : "••••••••"}
                              </span>
                              <button
                                onClick={() => setShowPasswordMap(prev => ({ ...prev, [user.uid]: !prev[user.uid] }))}
                                className="text-slate-400 hover:text-slate-600 cursor-pointer"
                              >
                                {showPasswordMap[user.uid] ? <EyeOff size={10} /> : <Eye size={10} />}
                              </button>
                            </div>
                          </div>
                        </td>

                        {/* ROLE & STATUS */}
                        <td className="py-3.5 px-4">
                          <div className="space-y-1">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                              user.role === "admin" ? "bg-purple-100 text-purple-800 border border-purple-200" :
                              user.role === "vip" ? "bg-amber-100 text-amber-800 border border-amber-200" :
                              "bg-slate-100 text-slate-700 border border-slate-200"
                            }`}>
                              {user.role}
                            </span>
                            {user.isBanned && user.banReason && (
                              <p className="text-[9px] text-red-600 italic line-clamp-1 max-w-[160px]">
                                Reason: {user.banReason}
                              </p>
                            )}
                          </div>
                        </td>

                        {/* STATS */}
                        <td className="py-3.5 px-4 font-mono text-[11px] text-slate-600">
                          <div className="space-y-0.5">
                            <div>📖 {user.booksCount} {lang === "bn" ? "বই" : "books"}</div>
                            <div className="text-[10px] text-slate-400">❤️ {user.totalLikes} likes</div>
                          </div>
                        </td>

                        {/* JOINED */}
                        <td className="py-3.5 px-4 text-[10px] text-slate-400 font-mono">
                          {user.createdAt}
                        </td>

                        {/* ACTIONS */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Ban / Unban Toggle Button */}
                            <button
                              onClick={() => handleToggleBanUser(user.uid)}
                              className={`p-1.5 rounded-lg border text-[10px] font-bold transition cursor-pointer flex items-center gap-1 ${
                                user.isBanned
                                  ? "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100"
                                  : "bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100"
                              }`}
                              title={user.isBanned ? "Unban User" : "Ban User"}
                            >
                              <Ban size={12} />
                              <span>{user.isBanned ? (lang === "bn" ? "আনব্যান" : "Unban") : (lang === "bn" ? "ব্যান করুন" : "Ban")}</span>
                            </button>

                            {/* Edit User Button */}
                            <button
                              onClick={() => setEditingUser(user)}
                              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 transition cursor-pointer"
                              title="Edit Details"
                            >
                              <Edit3 size={12} />
                            </button>

                            {/* Delete User Button */}
                            <button
                              onClick={() => handleDeleteUser(user.uid)}
                              className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg border border-red-100 transition cursor-pointer"
                              title="Delete User"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          TAB 2: WEBSITE DESIGN & BRANDING ARCHITECT
          ========================================================= */}
      {activeTab === "design" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-6 text-left">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Palette className="text-[#7c2d12]" size={18} />
                <span>{lang === "bn" ? "ওয়েবসাইট ডিজাইন ও ভিজ্যুয়াল কাস্টমাইজার" : "Website Visual Architect & Layout Settings"}</span>
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {lang === "bn" 
                  ? "ওয়েবসাইটের শিরোনাম, ট্যাগলাইন, থিম কালার, টপ ব্যানার নোটিস এবং সকল মেনু সরাসরি পরিবর্তন করুন।" 
                  : "Customize site title, tagline, global announcement banner, theme palette, and menu visibility."}
              </p>
            </div>

            <button
              onClick={handleSaveDesignConfig}
              className="px-5 py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Save size={14} />
              <span>{lang === "bn" ? "পরিবর্তনগুলো সেভ করুন" : "Apply & Save Design"}</span>
            </button>
          </div>

          {configSavedToast && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-xl flex items-center gap-2"
            >
              <CheckCircle size={15} />
              <span>{lang === "bn" ? "🎉 ওয়েবসাইটের ডিজাইন সেটিংস সফলভাবে আপডেট করা হয়েছে!" : "🎉 Website design settings successfully saved and deployed!"}</span>
            </motion.div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* SECTION 1: GLOBAL BRANDING */}
            <div className="space-y-4 bg-slate-50/60 p-4 rounded-2xl border border-slate-200">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Globe size={14} className="text-[#7c2d12]" />
                <span>{lang === "bn" ? "ব্র্যান্ডিং ও শিরোনাম" : "Brand Identity & Titles"}</span>
              </h4>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">App Title (ওয়েবসাইট নাম)</label>
                <input
                  type="text"
                  value={localConfig.appTitle}
                  onChange={(e) => setLocalConfig(prev => ({ ...prev, appTitle: e.target.value }))}
                  className="w-full bg-white border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Tagline / Subtitle (ট্যাগলাইন)</label>
                <input
                  type="text"
                  value={localConfig.tagline}
                  onChange={(e) => setLocalConfig(prev => ({ ...prev, tagline: e.target.value }))}
                  className="w-full bg-white border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Footer Text (ফুটার টেক্সট)</label>
                <input
                  type="text"
                  value={localConfig.footerNote}
                  onChange={(e) => setLocalConfig(prev => ({ ...prev, footerNote: e.target.value }))}
                  className="w-full bg-white border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            {/* SECTION 2: TOP ANNOUNCEMENT BANNER */}
            <div className="space-y-4 bg-slate-50/60 p-4 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Megaphone size={14} className="text-amber-600" />
                  <span>{lang === "bn" ? "টপ অ্যানাউন্সমেন্ট বার" : "Top Site Announcement Banner"}</span>
                </h4>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={localConfig.announcementActive}
                    onChange={(e) => setLocalConfig(prev => ({ ...prev, announcementActive: e.target.checked }))}
                    className="w-4 h-4 text-[#7c2d12] rounded accent-[#7c2d12]"
                  />
                  <span className="text-[10px] font-bold text-slate-700">Active / সচল</span>
                </label>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Banner Text (ঘোষণার বার্তা)</label>
                <input
                  type="text"
                  value={localConfig.announcementText}
                  onChange={(e) => setLocalConfig(prev => ({ ...prev, announcementText: e.target.value }))}
                  placeholder="e.g. 🎉 নতুন এআই ভয়েস ও ৩ডি বই কভার উন্মোচিত হয়েছে!"
                  className="w-full bg-white border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Banner Gradient Color</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "from-amber-600 to-[#7c2d12]", label: "Amber Warm" },
                    { id: "from-indigo-600 to-purple-800", label: "Sapphire" },
                    { id: "from-emerald-600 to-teal-800", label: "Emerald" }
                  ].map(b => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => setLocalConfig(prev => ({ ...prev, announcementBg: b.id }))}
                      className={`p-2 rounded-xl text-[10px] font-bold text-white bg-gradient-to-r ${b.id} transition ${
                        localConfig.announcementBg === b.id ? "ring-2 ring-slate-900 shadow-sm" : "opacity-75"
                      }`}
                    >
                      {b.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* SECTION 3: THEME PALETTES */}
            <div className="space-y-4 bg-slate-50/60 p-4 rounded-2xl border border-slate-200 md:col-span-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Palette size={14} className="text-[#7c2d12]" />
                <span>{lang === "bn" ? "সাইটের মূল থিম ও কালার স্কিম" : "Master Website Theme Palette"}</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                {[
                  { id: "amber", name: "Amber Vintage", color: "bg-[#7c2d12] text-amber-50" },
                  { id: "sapphire", name: "Royal Sapphire", color: "bg-blue-900 text-blue-50" },
                  { id: "emerald", name: "Cyber Emerald", color: "bg-emerald-900 text-emerald-50" },
                  { id: "rose", name: "Velvet Rose", color: "bg-rose-900 text-rose-50" },
                  { id: "dark", name: "Dark Obsidian", color: "bg-slate-950 text-slate-50" },
                  { id: "crimson", name: "Crimson Silk", color: "bg-red-950 text-red-50" },
                ].map((th) => (
                  <button
                    key={th.id}
                    type="button"
                    onClick={() => setLocalConfig(prev => ({ ...prev, primaryTheme: th.id as any }))}
                    className={`p-3 rounded-2xl border-2 transition cursor-pointer text-center flex flex-col items-center gap-2 ${
                      localConfig.primaryTheme === th.id
                        ? "border-[#7c2d12] bg-white shadow-md scale-102"
                        : "border-slate-200 bg-white/70 hover:border-slate-300"
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full ${th.color} flex items-center justify-center font-bold text-xs shadow-2xs`}>
                      {th.name.charAt(0)}
                    </div>
                    <span className="text-[11px] font-extrabold text-slate-800">{th.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* SECTION 4: NAVIGATION TABS VISIBILITY MANAGER */}
            <div className="space-y-4 bg-slate-50/60 p-4 rounded-2xl border border-slate-200 md:col-span-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <Sliders size={14} className="text-[#7c2d12]" />
                <span>{lang === "bn" ? "ন্যাভিগেশন মেনু শো / হাইড কন্ট্রোলার" : "Navigation Tab Visibility Manager"}</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { key: "editor", label: "Book Editor (বইয়ের এডিটর)" },
                  { key: "ai_chat", label: "AI Chat Hub (এআই চ্যাট)" },
                  { key: "voice_buddy", label: "Gemini Live Voice (ভয়েস)" },
                  { key: "pro_voice", label: "Pro Voice Assistant (প্রো ভয়েস)" },
                  { key: "code_board", label: "Code Preview Board (প্রিভিউ বোর্ড)" },
                  { key: "code_studio", label: "Code Studio IDE (কোড স্টুডিও)" },
                  { key: "mind_matrix", label: "Mind Matrix (প্লট)" },
                  { key: "social", label: "Social Gallery (গ্যালারি)" },
                  { key: "history", label: "Archives (মহাফেজখানা)" }
                ].map((item) => (
                  <label key={item.key} className="flex items-center gap-2 bg-white p-3 rounded-xl border border-slate-200 cursor-pointer shadow-2xs">
                    <input
                      type="checkbox"
                      checked={(localConfig.enabledTabs as any)[item.key] ?? true}
                      onChange={(e) => setLocalConfig(prev => ({
                        ...prev,
                        enabledTabs: {
                          ...prev.enabledTabs,
                          [item.key]: e.target.checked
                        }
                      }))}
                      className="w-4 h-4 text-[#7c2d12] rounded accent-[#7c2d12]"
                    />
                    <span className="text-xs font-bold text-slate-800">{item.label}</span>
                  </label>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* =========================================================
          TAB 3: BOOKS & CONTENT MASTER CONTROLLER
          ========================================================= */}
      {activeTab === "books" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
            <div className="relative flex-1 w-full max-w-md">
              <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={bookSearchQuery}
                onChange={(e) => setBookSearchQuery(e.target.value)}
                placeholder={lang === "bn" ? "বইয়ের নাম বা লেখকের ইমেইল দিয়ে খুঁজুন..." : "Search manuscript by title, genre, author..."}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>
            <span className="text-xs text-slate-400 font-bold">
              Total {filteredBooks.length} manuscripts
            </span>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl shadow-2xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-4">Book Title & Genre</th>
                    <th className="py-3 px-4">Author / Creator</th>
                    <th className="py-3 px-4">Chapters</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Moderation Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredBooks.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-400 font-bold">
                        No manuscripts found in database.
                      </td>
                    </tr>
                  ) : (
                    filteredBooks.map((book) => (
                      <tr key={book.id} className="hover:bg-slate-50/80 transition">
                        <td className="py-3.5 px-4">
                          <div className="space-y-0.5">
                            <h4 className="font-extrabold text-slate-900 font-serif text-sm">{book.title}</h4>
                            <span className="text-[10px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                              {book.genre || "Fiction"}
                            </span>
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-slate-600 font-mono text-[11px]">
                          {book.creatorEmail || "Guest User"}
                        </td>

                        <td className="py-3.5 px-4 font-mono text-[11px]">
                          {book.chapters?.length || 0} chapters
                        </td>

                        <td className="py-3.5 px-4">
                          {book.published ? (
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[9px] font-black rounded-full border border-emerald-200">
                              PUBLISHED
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-slate-100 text-slate-600 text-[9px] font-black rounded-full border border-slate-200">
                              DRAFT
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {book.published && (
                              <button
                                onClick={() => onUnpublishBook(book)}
                                className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg text-[10px] font-bold transition cursor-pointer"
                              >
                                Unpublish
                              </button>
                            )}

                            <button
                              onClick={() => setEditingBook(book)}
                              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 transition cursor-pointer"
                              title="Edit Manuscript Content"
                            >
                              <Edit3 size={12} />
                            </button>

                            <button
                              onClick={() => onDeleteBook(book.id)}
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg border border-rose-200 transition cursor-pointer"
                              title="Delete Manuscript"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          TAB 4: CUSTOM WIDGETS & PROMOTIONAL CARDS
          ========================================================= */}
      {activeTab === "widgets" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-6 text-left">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Layers className="text-[#7c2d12]" size={18} />
                <span>{lang === "bn" ? "কাস্টম উইজেট ও ইন্টারঅ্যাক্টিভ কার্ডস" : "Dynamic Custom Widgets & Promos"}</span>
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {lang === "bn" 
                  ? "ওয়েবসাইটের হোম ও এডিটর পেজে নতুন কাস্টম উইজেট বা অ্যাকশন কার্ড যোগ বা রিমুভ করুন।" 
                  : "Add new custom action cards or promotional widgets anywhere across the site."}
              </p>
            </div>
          </div>

          {/* ADD NEW WIDGET FORM */}
          <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-200 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-[#7c2d12] flex items-center gap-1">
              <Plus size={14} />
              <span>{lang === "bn" ? "নতুন উইজেট কার্ড যোগ করুন" : "Add New Custom Widget Card"}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Widget Title</label>
                <input
                  type="text"
                  value={newWidgetTitle}
                  onChange={(e) => setNewWidgetTitle(e.target.value)}
                  placeholder="e.g. 🌟 বিশেষ ছাড় ও বইমেলা প্রমোশন"
                  className="w-full bg-white border border-amber-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Widget Description</label>
                <input
                  type="text"
                  value={newWidgetDesc}
                  onChange={(e) => setNewWidgetDesc(e.target.value)}
                  placeholder="e.g. আপনার বই সোশ্যাল ফিডে ফিচার করতে এখনই যোগাযোগ করুন।"
                  className="w-full bg-white border border-amber-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>
            </div>

            <button
              onClick={handleAddWidget}
              className="px-4 py-2 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <Plus size={14} />
              <span>{lang === "bn" ? "উইজেট পাবলিশ করুন" : "Publish Widget Card"}</span>
            </button>
          </div>

          {/* ACTIVE WIDGETS LIST */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {(localConfig.customWidgets || []).map((w) => (
              <div key={w.id} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 relative group text-left">
                <div className="flex items-center justify-between">
                  <span className="p-2 bg-amber-100 text-[#7c2d12] rounded-xl font-bold">
                    <Sparkles size={14} />
                  </span>
                  <button
                    onClick={() => handleDeleteWidget(w.id)}
                    className="p-1 text-slate-400 hover:text-red-600 transition cursor-pointer"
                    title="Delete Widget"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
                <h4 className="text-xs font-extrabold text-slate-900">{w.title}</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed font-medium">{w.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================
          TAB 5: SYSTEM SECURITY & MAINTENANCE
          ========================================================= */}
      {activeTab === "security" && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-6 text-left">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="text-[#7c2d12]" size={18} />
                <span>{lang === "bn" ? "সিস্টেম সিকিউরিটি ও মেইনটেন্যান্স" : "System Security & Site Lockdown"}</span>
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {lang === "bn" ? "সাইট রক্ষণাবেক্ষণ মোড এবং সিকিউরিটি অডিট।" : "Site maintenance mode, ban logs, and server controls."}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between">
              <div className="space-y-0.5">
                <h4 className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                  <Lock size={14} className="text-amber-800" />
                  <span>Maintenance Mode (রক্ষণাবেক্ষণ মোড)</span>
                </h4>
                <p className="text-[11px] text-slate-500">
                  {lang === "bn" ? "চালু করলে সাধারণ ইউজাররা নোটিস দেখতে পাবে।" : "When enabled, visitors see a scheduled maintenance notice."}
                </p>
              </div>
              <input
                type="checkbox"
                checked={localConfig.maintenanceMode}
                onChange={(e) => {
                  const updated = { ...localConfig, maintenanceMode: e.target.checked };
                  setLocalConfig(updated);
                  onUpdateSiteConfig(updated);
                }}
                className="w-5 h-5 text-[#7c2d12] rounded accent-[#7c2d12] cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* =========================================================
          TAB 6: PAYMENT METHODS & PRO SUBSCRIPTION CONTROL
          ========================================================= */}
      {activeTab === "payments" && (
        <div className="space-y-6">
          {/* Header & Save Bar */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <CreditCard size={18} className="text-amber-600" />
                <span>{lang === "bn" ? "পেমেন্ট গেটওয়ে, অ্যাকাউন্ট নম্বর ও প্রো প্যাকেজ ম্যানেজমেন্ট" : "Payment Methods & Pro Subscriptions Control"}</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {lang === "bn"
                  ? "এখান থেকে বিকাশ, নগদ, রকেট নম্বর ও নির্দেশনা পরিবর্তন করুন, প্যাকেজের মূল্য নির্ধারণ করুন এবং গ্রাহকদের TrxID রিকোয়েস্ট ভেরিফাই করে প্রো স্ট্যাটাস দিন।"
                  : "Configure bKash, Nagad, Rocket merchant/personal numbers, adjust Pro package pricing, and approve customer TrxID payment requests."}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={syncPaymentRequests}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw size={13} />
                <span>{lang === "bn" ? "রিফ্রেশ" : "Refresh"}</span>
              </button>
              <button
                type="button"
                onClick={handleSavePaymentConfig}
                className="px-5 py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
              >
                <Save size={14} />
                <span>{lang === "bn" ? "পেমেন্ট সেটিংস সেভ করুন" : "Save Payment Config"}</span>
              </button>
            </div>
          </div>

          {/* 1. Account Numbers & Instructions Form */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
            <h4 className="text-sm font-black text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
              <Smartphone size={16} className="text-amber-600" />
              <span>{lang === "bn" ? "১. মোবাইল ব্যাংকিং অ্যাকাউন্ট নম্বর ও প্রকার" : "1. Mobile Banking Accounts & Types"}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* bKash */}
              <div className="p-4 rounded-2xl bg-pink-50/50 border border-pink-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-pink-700">bKash (বিকাশ)</span>
                  <span className="text-[10px] px-2 py-0.5 bg-pink-200 text-pink-900 rounded-full font-bold">MFS</span>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">অ্যাকাউন্ট নম্বর</label>
                  <input
                    type="text"
                    value={paymentConfig.bkashNumber}
                    onChange={(e) => setPaymentConfig({ ...paymentConfig, bkashNumber: e.target.value })}
                    className="w-full bg-white border border-pink-300 px-3 py-2 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-pink-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">অ্যাকাউন্ট টাইপ</label>
                  <select
                    value={paymentConfig.bkashType}
                    onChange={(e) => setPaymentConfig({ ...paymentConfig, bkashType: e.target.value as any })}
                    className="w-full bg-white border border-pink-300 px-3 py-2 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                  >
                    <option value="Personal">Personal (ব্যক্তিগত - Send Money)</option>
                    <option value="Merchant">Merchant (মার্চেন্ট - Make Payment)</option>
                    <option value="Agent">Agent (এজেন্ট - Cash In)</option>
                  </select>
                </div>
              </div>

              {/* Nagad */}
              <div className="p-4 rounded-2xl bg-orange-50/50 border border-orange-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-orange-700">Nagad (নগদ)</span>
                  <span className="text-[10px] px-2 py-0.5 bg-orange-200 text-orange-900 rounded-full font-bold">MFS</span>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">অ্যাকাউন্ট নম্বর</label>
                  <input
                    type="text"
                    value={paymentConfig.nagadNumber}
                    onChange={(e) => setPaymentConfig({ ...paymentConfig, nagadNumber: e.target.value })}
                    className="w-full bg-white border border-orange-300 px-3 py-2 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-orange-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">অ্যাকাউন্ট টাইপ</label>
                  <select
                    value={paymentConfig.nagadType}
                    onChange={(e) => setPaymentConfig({ ...paymentConfig, nagadType: e.target.value as any })}
                    className="w-full bg-white border border-orange-300 px-3 py-2 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                  >
                    <option value="Personal">Personal (ব্যক্তিগত - Send Money)</option>
                    <option value="Merchant">Merchant (মার্চেন্ট - Make Payment)</option>
                  </select>
                </div>
              </div>

              {/* Rocket */}
              <div className="p-4 rounded-2xl bg-purple-50/50 border border-purple-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-purple-700">Rocket (রকেট)</span>
                  <span className="text-[10px] px-2 py-0.5 bg-purple-200 text-purple-900 rounded-full font-bold">DBBL</span>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">অ্যাকাউন্ট নম্বর (১২ ডিজিট)</label>
                  <input
                    type="text"
                    value={paymentConfig.rocketNumber}
                    onChange={(e) => setPaymentConfig({ ...paymentConfig, rocketNumber: e.target.value })}
                    className="w-full bg-white border border-purple-300 px-3 py-2 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">অ্যাকাউন্ট টাইপ</label>
                  <select
                    value={paymentConfig.rocketType}
                    onChange={(e) => setPaymentConfig({ ...paymentConfig, rocketType: e.target.value as any })}
                    className="w-full bg-white border border-purple-300 px-3 py-2 rounded-xl text-xs font-bold text-slate-900 focus:outline-none"
                  >
                    <option value="Personal">Personal (ব্যক্তিগত)</option>
                    <option value="Merchant">Merchant (মার্চেন্ট)</option>
                  </select>
                </div>
              </div>

              {/* Upay */}
              <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-blue-700">Upay (উপায়)</span>
                  <span className="text-[10px] px-2 py-0.5 bg-blue-200 text-blue-900 rounded-full font-bold">UCB</span>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">অ্যাকাউন্ট নম্বর</label>
                  <input
                    type="text"
                    value={paymentConfig.upayNumber}
                    onChange={(e) => setPaymentConfig({ ...paymentConfig, upayNumber: e.target.value })}
                    className="w-full bg-white border border-blue-300 px-3 py-2 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div className="pt-5 text-[11px] text-slate-500">
                  <span>UCB পরিচালিত ডিজিটাল ওয়ালেট</span>
                </div>
              </div>
            </div>

            {/* Instruction Texts */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">বাংলা পেমেন্ট নির্দেশনা</label>
                <textarea
                  rows={4}
                  value={paymentConfig.instructionsBn}
                  onChange={(e) => setPaymentConfig({ ...paymentConfig, instructionsBn: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 p-3 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-amber-500 leading-relaxed font-sans"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600 uppercase block mb-1">English Payment Instructions</label>
                <textarea
                  rows={4}
                  value={paymentConfig.instructionsEn}
                  onChange={(e) => setPaymentConfig({ ...paymentConfig, instructionsEn: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 p-3 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-amber-500 leading-relaxed font-sans"
                />
              </div>
            </div>
          </div>

          {/* 2. Pro Packages Pricing Editor */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h4 className="text-sm font-black text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
              <Crown size={16} className="text-amber-600" />
              <span>{lang === "bn" ? "২. প্রিমিয়াম প্যাকেজের মূল্য ও ফিচার নির্ধারণ" : "2. Pro Packages Pricing & Features"}</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {paymentConfig.packages.map((pkg, pIdx) => (
                <div key={pkg.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-900">{pkg.name}</span>
                    <input
                      type="text"
                      value={pkg.badge}
                      placeholder="Badge"
                      onChange={(e) => {
                        const pkgs = [...paymentConfig.packages];
                        pkgs[pIdx].badge = e.target.value;
                        setPaymentConfig({ ...paymentConfig, packages: pkgs });
                      }}
                      className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full border border-amber-300 w-20 text-center"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1">BDT Price (৳)</label>
                      <input
                        type="number"
                        value={pkg.priceBdt}
                        onChange={(e) => {
                          const pkgs = [...paymentConfig.packages];
                          pkgs[pIdx].priceBdt = Number(e.target.value);
                          setPaymentConfig({ ...paymentConfig, packages: pkgs });
                        }}
                        className="w-full bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold text-amber-600 font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1">USD Price ($)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={pkg.priceUsd}
                        onChange={(e) => {
                          const pkgs = [...paymentConfig.packages];
                          pkgs[pIdx].priceUsd = Number(e.target.value);
                          setPaymentConfig({ ...paymentConfig, packages: pkgs });
                        }}
                        className="w-full bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-700 font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[9px] font-bold text-slate-500 uppercase block mb-1">মেয়াদ / সময়কাল</label>
                    <input
                      type="text"
                      value={pkg.billingPeriod}
                      onChange={(e) => {
                        const pkgs = [...paymentConfig.packages];
                        pkgs[pIdx].billingPeriod = e.target.value;
                        setPaymentConfig({ ...paymentConfig, packages: pkgs });
                      }}
                      className="w-full bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs text-slate-800"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 3. Payment Verification & Approval Hub */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600" />
                  <span>{lang === "bn" ? "৩. গ্রাহকদের সাবমিট করা TrxID ও পেমেন্ট রিকোয়েস্ট" : "3. Customer Payment Requests & TrxID Verification"}</span>
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  {lang === "bn"
                    ? "ইউজারদের বিকাশ/নগদ TrxID যাচাই করে 'Approve' বাটনে চাপলে সেই ইউজার স্বয়ংক্রিয়ভাবে ভিআইপি প্রো হয়ে যাবে।"
                    : "Review submitted TrxIDs. Clicking Approve automatically grants VIP Pro status to the user."}
                </p>
              </div>

              <span className="px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-full text-xs font-bold font-mono">
                {paymentRequests.length} Requests Total
              </span>
            </div>

            {paymentRequests.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200/60 text-slate-400 text-xs">
                {lang === "bn" ? "এখনো কোনো পেন্ডিং পেমেন্ট রিকোয়েস্ট নেই।" : "No payment requests submitted yet."}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100/80 text-slate-600 font-bold uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3 rounded-l-xl">User Info</th>
                      <th className="p-3">Package</th>
                      <th className="p-3">Amount</th>
                      <th className="p-3">Method & TrxID</th>
                      <th className="p-3">Sender Phone</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 rounded-r-xl text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {paymentRequests.map((reqItem, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-50/70 transition">
                        <td className="p-3 font-medium">
                          <div className="font-bold text-slate-900">{reqItem.userName || "User"}</div>
                          <div className="text-[10px] text-slate-500 font-mono">{reqItem.userEmail || reqItem.userId}</div>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-amber-50 text-amber-800 rounded-md font-bold text-[11px] border border-amber-200">
                            {reqItem.packageName || reqItem.packageId}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-slate-900 font-mono">
                          ৳ {reqItem.amountBdt}
                        </td>
                        <td className="p-3 font-mono">
                          <div className="text-[10px] uppercase font-bold text-slate-600">{reqItem.paymentMethod}</div>
                          <div className="font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200 inline-block mt-0.5 select-all">
                            {reqItem.trxId}
                          </div>
                        </td>
                        <td className="p-3 font-mono text-slate-700 font-medium">
                          {reqItem.senderPhone || "-"}
                        </td>
                        <td className="p-3">
                          {reqItem.status === "approved" ? (
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full font-black text-[10px] flex items-center gap-1 w-fit">
                              <Check size={10} /> Approved Pro
                            </span>
                          ) : reqItem.status === "rejected" ? (
                            <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded-full font-black text-[10px] flex items-center gap-1 w-fit">
                              <X size={10} /> Rejected
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-amber-100 text-amber-900 rounded-full font-black text-[10px] animate-pulse w-fit block">
                              Pending Review
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {reqItem.status !== "approved" && (
                              <button
                                type="button"
                                onClick={() => handleApprovePayment(reqItem)}
                                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] transition cursor-pointer flex items-center gap-1 shadow-xs"
                              >
                                <Check size={11} />
                                <span>Approve</span>
                              </button>
                            )}
                            {reqItem.status !== "rejected" && (
                              <button
                                type="button"
                                onClick={() => handleRejectPayment(reqItem)}
                                className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg font-bold text-[11px] transition cursor-pointer"
                              >
                                Reject
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================
          MODAL: CREATE NEW USER
          ========================================================= */}
      <AnimatePresence>
        {showCreateUserModal && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 shadow-2xl max-w-md w-full border border-amber-200 space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                  <UserPlus size={16} className="text-[#7c2d12]" />
                  <span>{lang === "bn" ? "নতুন ইউজার অ্যাকাউন্ট তৈরি" : "Create User Profile"}</span>
                </h3>
                <button onClick={() => setShowCreateUserModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                  <X size={16} />
                </button>
              </div>

              <form onSubmit={handleCreateNewUser} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Full Name (পূর্ণ নাম)</label>
                  <input
                    type="text"
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    placeholder="e.g. Kazi Nazrul Islam"
                    required
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Email / Username</label>
                  <input
                    type="text"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="e.g. writer@lekhok.ai"
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Password (পাসওয়ার্ড)</label>
                  <input
                    type="text"
                    value={newUserPassword}
                    onChange={(e) => setNewUserPassword(e.target.value)}
                    placeholder="e.g. secret1234"
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Role (ভূমিকা)</label>
                  <select
                    value={newUserRole}
                    onChange={(e) => setNewUserRole(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="author">Author (লেখক)</option>
                    <option value="vip">VIP Pro Author</option>
                    <option value="admin">Administrator</option>
                    <option value="user">Standard User</option>
                  </select>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowCreateUserModal(false)}
                    className="px-4 py-2 text-slate-500 text-xs font-bold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold cursor-pointer shadow-xs"
                  >
                    Save User
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================
          MODAL: EDIT USER
          ========================================================= */}
      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 shadow-2xl max-w-md w-full border border-amber-200 space-y-4 text-left"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                  <Edit3 size={16} className="text-[#7c2d12]" />
                  <span>Edit User Details</span>
                </h3>
                <button onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Display Name</label>
                  <input
                    type="text"
                    value={editingUser.displayName}
                    onChange={(e) => setEditingUser({ ...editingUser, displayName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Secret Password</label>
                  <input
                    type="text"
                    value={editingUser.password || ""}
                    onChange={(e) => setEditingUser({ ...editingUser, password: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-mono font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">User Role</label>
                  <select
                    value={editingUser.role}
                    onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value as any })}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold"
                  >
                    <option value="author">Author</option>
                    <option value="vip">VIP Pro</option>
                    <option value="admin">Administrator</option>
                    <option value="user">User</option>
                  </select>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="px-4 py-2 text-slate-500 text-xs font-bold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveEditedUser}
                    className="px-5 py-2 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Update User
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================
          MODAL: EDIT MANUSCRIPT
          ========================================================= */}
      <AnimatePresence>
        {editingBook && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 shadow-2xl max-w-xl w-full border border-amber-200 space-y-4 text-left max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                  <BookOpen size={16} className="text-[#7c2d12]" />
                  <span>Edit Book Manuscript</span>
                </h3>
                <button onClick={() => setEditingBook(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Book Title</label>
                  <input
                    type="text"
                    value={editingBook.title}
                    onChange={(e) => setEditingBook({ ...editingBook, title: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Genre</label>
                  <input
                    type="text"
                    value={editingBook.genre}
                    onChange={(e) => setEditingBook({ ...editingBook, genre: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-bold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Synopsis</label>
                  <textarea
                    rows={4}
                    value={editingBook.synopsis}
                    onChange={(e) => setEditingBook({ ...editingBook, synopsis: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-xs font-serif leading-relaxed"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setEditingBook(null)}
                    className="px-4 py-2 text-slate-500 text-xs font-bold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (onUpdateBook) onUpdateBook(editingBook);
                      setEditingBook(null);
                      alert(lang === "bn" ? "বইটি আপডেট হয়েছে!" : "Book updated successfully!");
                    }}
                    className="px-5 py-2 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
