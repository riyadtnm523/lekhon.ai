import React, { useState, useEffect } from "react";
import {
  Crown, Sparkles, Check, Zap, ShieldCheck, Copy, CheckCircle2,
  CreditCard, Smartphone, ChevronRight, Lock, Star, AlertCircle, RefreshCw, X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { db, doc, setDoc, getDoc, collection, addDoc } from "../firebase";

export interface PaymentConfig {
  bkashNumber: string;
  bkashType: "Merchant" | "Personal" | "Agent";
  nagadNumber: string;
  nagadType: "Merchant" | "Personal";
  rocketNumber: string;
  rocketType: "Personal" | "Merchant";
  upayNumber: string;
  instructionsBn: string;
  instructionsEn: string;
  packages: Array<{
    id: string;
    name: string;
    badge: string;
    priceBdt: number;
    priceUsd: number;
    billingPeriod: string;
    features: string[];
    isPopular?: boolean;
  }>;
}

export const DEFAULT_PAYMENT_CONFIG: PaymentConfig = {
  bkashNumber: "01700000000",
  bkashType: "Personal",
  nagadNumber: "01800000000",
  nagadType: "Personal",
  rocketNumber: "01900000000",
  rocketType: "Personal",
  upayNumber: "01600000000",
  instructionsBn: "১. আপনার বিকাশ/নগদ/রকেট অ্যাপে গিয়ে 'Send Money' বা 'Make Payment' অপশন নির্বাচন করুন।\n২. উপরের নম্বরে নির্ধারিত ফি প্রদান করুন।\n৩. সফল পেমেন্টের পর প্রাপ্ত Transaction ID (TrxID) নিচে প্রদান করে সাবমিট করুন। অ্যাডমিন অবিলম্বে ভেরিফাই করে আপনার প্রো প্যাকেজ চালু করে দেবে।",
  instructionsEn: "1. Open your bKash/Nagad/Rocket app and select Send Money or Payment.\n2. Send the package amount to the number above.\n3. Enter your Transaction ID (TrxID) below and submit. Admin will verify and activate your Pro status immediately.",
  packages: [
    {
      id: "pkg_monthly_pro",
      name: "Pro Author Monthly",
      badge: "জনপ্রিয়",
      priceBdt: 299,
      priceUsd: 4.99,
      billingPeriod: "১ মাস",
      features: [
        "অবিরাম ৫০+ অধ্যায়ের মেগা বই স্বয়ংক্রিয় রচনা",
        "প্রতি অধ্যায়ে ১০-২০ পৃষ্ঠা বিস্তারিত লেখা",
        "লাইভ হিউম্যান কনভার্সেশনাল এআই ভয়েস",
        "মাইন্ড ম্যাট্রিক্স ব্ল্যাক বোর্ড ও নিয়ন আর্কিটেকচার ট্রি",
        "বইয়ের ভেতরে লাইভ কোড প্রিভিউ ও স্যান্ডবক্স",
        "হাই-রেজোলিউশন A4 PDF ও ই-পাব এক্সপোর্ট",
        "বিজ্ঞাপনমুক্ত আল্ট্রা ফাস্ট নিউরাল জেনারেশন"
      ],
      isPopular: true
    },
    {
      id: "pkg_ultra_mega",
      name: "Ultra Mega Creator",
      badge: "সেরা ভ্যালু",
      priceBdt: 799,
      priceUsd: 11.99,
      billingPeriod: "৩ মাস",
      features: [
        "সব Pro ফিচারের সম্পূর্ণ এক্সেস",
        "১০০+ অধ্যায়ের আনলিমিটেড বই প্রকাশনা",
        "JARVIS লেভেল সার্বক্ষণিক অটো ভয়েস কো-পাইলট",
        "সোশ্যাল স্টুডিও আল্ট্রা HD এক্সপোর্ট (Instagram/LinkedIn)",
        "মাল্টি-ফাইল কোড স্টুডিও এআই বান্ডলার",
        "অগ্রাধিকারমূলক ভিআইপি সাপোর্ট ও প্রাইভেট ক্লাউড স্টোরেজ",
        "কাস্টম ব্রান্ডিং ও প্রোফাইল গোল্ডেন ব্যাজ"
      ]
    },
    {
      id: "pkg_lifetime_vip",
      name: "Lifetime Master VIP",
      badge: "লাইফটাইম",
      priceBdt: 1999,
      priceUsd: 29.99,
      billingPeriod: "আজীবন (Lifetime)",
      features: [
        "আজীবন আনলিমিটেড মেগা বুক জেনারেশন",
        "ভবিষ্যতের সকল এআই মডেল ও প্রিমিয়াম টুলের বিনামূল্যে এক্সেস",
        "প্রো অথর ভেরিফাইড মেম্বারশিপ",
        "ডেডিকেটেড এআই কনসালটেন্ট",
        "কাস্টম এআই ভয়েস পার্সোনালাইজেশন",
        "১০০% মানিব্যাক গ্যারান্টি"
      ]
    }
  ]
};

interface PremiumStoreModalProps {
  isOpen?: boolean;
  lang: "bn" | "en";
  currentUser: any;
  onClose: () => void;
  onOpenAuth: () => void;
}

export const PremiumStoreModal: React.FC<PremiumStoreModalProps> = ({
  isOpen = true,
  lang,
  currentUser,
  onClose,
  onOpenAuth
}) => {
  if (!isOpen) return null;
  const [paymentConfig, setPaymentConfig] = useState<PaymentConfig>(() => {
    const saved = localStorage.getItem("lekhok_payment_config");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return DEFAULT_PAYMENT_CONFIG;
  });

  const [selectedPackageId, setSelectedPackageId] = useState<string>("pkg_monthly_pro");
  const [selectedMethod, setSelectedMethod] = useState<"bkash" | "nagad" | "rocket" | "upay" | "card">("bkash");
  const [trxId, setTrxId] = useState("");
  const [senderPhone, setSenderPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [copiedNumber, setCopiedNumber] = useState(false);

  // Sync latest payment config from Firestore
  useEffect(() => {
    const loadConfig = async () => {
      try {
        const snap = await getDoc(doc(db, "system_settings", "payments_config"));
        if (snap.exists()) {
          const cloudData = snap.data() as PaymentConfig;
          setPaymentConfig(cloudData);
          localStorage.setItem("lekhok_payment_config", JSON.stringify(cloudData));
        }
      } catch (e) {
        console.warn("Payment config load notice:", e);
      }
    };
    loadConfig();
  }, []);

  const selectedPkg = paymentConfig.packages.find(p => p.id === selectedPackageId) || paymentConfig.packages[0];

  const getMethodDetails = () => {
    switch (selectedMethod) {
      case "bkash":
        return { name: "bKash (বিকাশ)", number: paymentConfig.bkashNumber, type: paymentConfig.bkashType, color: "#e2136e" };
      case "nagad":
        return { name: "Nagad (নগদ)", number: paymentConfig.nagadNumber, type: paymentConfig.nagadType, color: "#f7941d" };
      case "rocket":
        return { name: "Rocket (রকেট)", number: paymentConfig.rocketNumber, type: paymentConfig.rocketType, color: "#8c3494" };
      case "upay":
        return { name: "Upay (উপায়)", number: paymentConfig.upayNumber, type: "Personal", color: "#0073e6" };
      default:
        return { name: "Card / Online", number: "Online Payment Gateway", type: "Gateway", color: "#0f172a" };
    }
  };

  const currentMethod = getMethodDetails();

  const handleCopyNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleSubmitTrx = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      alert(lang === "bn" ? "পেমেন্ট রিকোয়েস্ট সাবমিট করতে প্রথমে লগইন করুন।" : "Please log in first to submit payment request.");
      onOpenAuth();
      return;
    }

    if (!trxId.trim()) {
      alert(lang === "bn" ? "অনুগ্রহ করে Transaction ID (TrxID) দিন।" : "Please enter your Transaction ID.");
      return;
    }

    setIsSubmitting(true);
    try {
      const requestPayload = {
        userId: currentUser.uid || currentUser.loginId || "guest",
        userName: currentUser.displayName || currentUser.username || "User",
        userEmail: currentUser.email || "",
        packageId: selectedPkg.id,
        packageName: selectedPkg.name,
        amountBdt: selectedPkg.priceBdt,
        amountUsd: selectedPkg.priceUsd,
        paymentMethod: selectedMethod,
        paymentNumber: currentMethod.number,
        senderPhone: senderPhone.trim() || "Not provided",
        trxId: trxId.trim().toUpperCase(),
        status: "pending",
        createdAt: new Date().toISOString(),
        timestamp: new Date().toLocaleDateString()
      };

      // Save to Firestore payment requests
      try {
        await addDoc(collection(db, "payment_requests"), requestPayload);
      } catch (fErr) {
        console.warn("Firestore payment log notice:", fErr);
      }

      // Also save to local storage for instant offline resilience
      const savedRequests = JSON.parse(localStorage.getItem("lekhok_pending_payments") || "[]");
      savedRequests.push(requestPayload);
      localStorage.setItem("lekhok_pending_payments", JSON.stringify(savedRequests));

      setSubmittedSuccess(true);
    } catch (err: any) {
      alert(err.message || "Failed to submit payment.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto font-sans">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl text-slate-100 relative"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-full transition z-20 cursor-pointer"
        >
          <X size={18} />
        </button>

        {/* Hero Header */}
        <div className="relative p-6 sm:p-8 bg-gradient-to-br from-amber-600/30 via-slate-900 to-slate-900 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 rounded-2xl shadow-lg shadow-amber-500/20 font-black">
              <Crown size={28} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  {lang === "bn" ? "লেখক AI প্রো ও আল্ট্রা প্রিমিয়াম মেম্বারশিপ" : "Lekhok AI Pro & Ultra Membership"}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-black uppercase tracking-wider">
                  PRO VIP
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                {lang === "bn"
                  ? "সীমাহীন মেগা বই রচনা, ৫০+ পূর্ণাঙ্গ অধ্যায় (প্রতিটিতে ১০-২০ পৃষ্ঠা), রিয়েল হিউম্যান লাইভ ভয়েস এবং মাইন্ড ম্যাট্রিক্স আনলক করুন।"
                  : "Unlock unlimited 50+ chapter mega books (10-20 pages per chapter), Real Human conversational voice, and Mind Matrix Studio."}
              </p>
            </div>
          </div>
        </div>

        {submittedSuccess ? (
          <div className="p-8 sm:p-12 text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10">
              <CheckCircle2 size={36} />
            </div>
            <div className="space-y-2 max-w-md mx-auto">
              <h3 className="text-xl font-black text-white">
                {lang === "bn" ? "🎉 পেমেন্ট রিকোয়েস্ট সফলভাবে জমা হয়েছে!" : "🎉 Payment Request Submitted!"}
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {lang === "bn"
                  ? `আপনার TrxID (${trxId}) অ্যাডমিন প্যানেলে পাঠানো হয়েছে। ভেরিফিকেশন সম্পন্ন হওয়া মাত্র আপনার অ্যাকাউন্ট স্বয়ংক্রিয়ভাবে প্রো ফিচারে আপগ্রেড হয়ে যাবে।`
                  : `Your TrxID (${trxId}) has been sent for admin verification. Your account will be upgraded immediately upon review.`}
              </p>
            </div>
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs rounded-xl shadow-lg transition cursor-pointer"
            >
              {lang === "bn" ? "ঠিক আছে, ড্যাশবোর্ডে ফিরে যান" : "Done, return to Dashboard"}
            </button>
          </div>
        ) : (
          <div className="p-6 sm:p-8 space-y-8">
            {/* 1. Packages Grid */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Star size={13} className="text-amber-400" />
                <span>{lang === "bn" ? "১. আপনার পছন্দের প্যাকেজ নির্বাচন করুন" : "1. Select your preferred package"}</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {paymentConfig.packages.map((pkg) => {
                  const isSelected = selectedPackageId === pkg.id;
                  return (
                    <div
                      key={pkg.id}
                      onClick={() => setSelectedPackageId(pkg.id)}
                      className={`relative p-5 rounded-2xl border-2 transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? "bg-slate-800/90 border-amber-500 shadow-xl shadow-amber-500/10 scale-[1.02]"
                          : "bg-slate-900/60 border-slate-800 hover:border-slate-700 opacity-90"
                      }`}
                    >
                      {pkg.badge && (
                        <span className={`absolute -top-3 right-4 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          isSelected ? "bg-amber-400 text-slate-950 shadow-md" : "bg-slate-800 text-slate-300 border border-slate-700"
                        }`}>
                          {pkg.badge}
                        </span>
                      )}

                      <div>
                        <h4 className="text-base font-black text-white">{pkg.name}</h4>
                        <div className="mt-2 flex items-baseline gap-1.5">
                          <span className="text-2xl font-black text-amber-400">৳ {pkg.priceBdt}</span>
                          <span className="text-xs text-slate-400 font-semibold">/ {pkg.billingPeriod}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">(${pkg.priceUsd} USD)</span>

                        <ul className="mt-4 space-y-2 border-t border-slate-800/80 pt-3 text-[11px] text-slate-300">
                          {pkg.features.map((feat, fIdx) => (
                            <li key={fIdx} className="flex items-start gap-2">
                              <Check size={12} className="text-amber-400 shrink-0 mt-0.5" />
                              <span>{feat}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="mt-5 pt-3 border-t border-slate-800/60">
                        <div className={`w-full py-2 rounded-xl text-center text-xs font-black transition ${
                          isSelected
                            ? "bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20"
                            : "bg-slate-800 text-slate-400 hover:text-white"
                        }`}>
                          {isSelected ? (lang === "bn" ? "✓ নির্বাচিত" : "✓ Selected") : (lang === "bn" ? "বেছে নিন" : "Select")}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 2. Payment Method Selector */}
            <div className="space-y-4 bg-slate-950/60 p-5 rounded-2xl border border-slate-800">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Smartphone size={13} className="text-amber-400" />
                <span>{lang === "bn" ? "২. পেমেন্ট মেথড বেছে নিন" : "2. Choose payment method"}</span>
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {[
                  { id: "bkash", name: "bKash (বিকাশ)", num: paymentConfig.bkashNumber, color: "from-pink-600 to-pink-700" },
                  { id: "nagad", name: "Nagad (নগদ)", num: paymentConfig.nagadNumber, color: "from-orange-600 to-amber-600" },
                  { id: "rocket", name: "Rocket (রকেট)", num: paymentConfig.rocketNumber, color: "from-purple-600 to-indigo-700" },
                  { id: "upay", name: "Upay (উপায়)", num: paymentConfig.upayNumber, color: "from-blue-600 to-cyan-600" }
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setSelectedMethod(m.id as any)}
                    className={`p-3 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                      selectedMethod === m.id
                        ? "bg-slate-800 border-amber-500 shadow-md"
                        : "bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-400"
                    }`}
                  >
                    <span className="text-xs font-black text-white">{m.name}</span>
                    <span className="text-[10px] text-amber-400/90 font-mono mt-1">{m.num}</span>
                  </button>
                ))}
              </div>

              {/* Method Instructions Box */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                      {currentMethod.name} ({currentMethod.type} Number):
                    </span>
                    <span className="text-base font-black text-amber-400 font-mono tracking-wider select-all">
                      {currentMethod.number}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleCopyNumber(currentMethod.number)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg border border-slate-700 transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    {copiedNumber ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                    <span>{copiedNumber ? (lang === "bn" ? "কপি হয়েছে!" : "Copied!") : (lang === "bn" ? "নম্বর কপি করুন" : "Copy Number")}</span>
                  </button>
                </div>

                <p className="text-[11px] text-slate-300 whitespace-pre-line leading-relaxed">
                  {lang === "bn" ? paymentConfig.instructionsBn : paymentConfig.instructionsEn}
                </p>
              </div>

              {/* 3. Transaction Form */}
              <form onSubmit={handleSubmitTrx} className="space-y-4 pt-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                      {lang === "bn" ? "আপনার ফোন নম্বর (যে নম্বর থেকে টাকা পাঠিয়েছেন)" : "Sender Phone Number"}
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 017XXXXXXXX"
                      value={senderPhone}
                      onChange={(e) => setSenderPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                      {lang === "bn" ? "Transaction ID (TrxID) *" : "Transaction ID (TrxID) *"}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 9J83B2KLM"
                      value={trxId}
                      onChange={(e) => setTrxId(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-900 border border-amber-500/50 rounded-xl text-xs text-amber-300 font-mono uppercase font-bold focus:outline-none focus:border-amber-400 shadow-inner"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800">
                  <div className="text-xs text-slate-400">
                    <span>{lang === "bn" ? "মোট প্রদেয়:" : "Total Payable:"} </span>
                    <strong className="text-white font-black text-sm text-amber-400">৳ {selectedPkg.priceBdt} BDT</strong>
                    <span className="text-slate-500 text-[10px] ml-1">({selectedPkg.name})</span>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-3 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" />
                        <span>{lang === "bn" ? "জমা হচ্ছে..." : "Submitting..."}</span>
                      </>
                    ) : (
                      <>
                        <Zap size={14} />
                        <span>{lang === "bn" ? "পেমেন্ট সাবমিট করুন ও প্রো আনলক করুন" : "Submit Payment & Unlock Pro"}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
