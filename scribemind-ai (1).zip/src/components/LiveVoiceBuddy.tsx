import React, { useState, useRef, useEffect, useCallback } from "react";
import { 
  Mic, MicOff, Sparkles, Volume2, VolumeX, Maximize2, Minimize2, 
  ChevronRight, Radio, RefreshCw, Trash2, ShieldAlert,
  Headphones, History, X, Flame, Zap, AudioWaveform, Image as ImageIcon,
  Camera, Upload, Eye, Send
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { unlockAudioAutoplay, stopAllSpokenAudio, playSpokenAudioAloud } from "../utils/audioPlayer";

export type GeminiVoiceMode = "aoede" | "puck" | "fenrir" | "kore" | "nova";

export interface VoiceMessage {
  id: string;
  role: "user" | "companion";
  text: string;
  image?: string;
  timestamp: string;
}

interface LiveVoiceBuddyProps {
  lang: "bn" | "en";
  currentUser?: any;
  modelProvider?: string;
  customGeminiKey?: string;
  customDeepseekKey?: string;
}

export const LiveVoiceBuddy: React.FC<LiveVoiceBuddyProps> = ({
  lang,
  modelProvider = "gemini",
  customGeminiKey,
  customDeepseekKey
}) => {
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState("");
  const [voiceMode, setVoiceMode] = useState<GeminiVoiceMode>("aoede");
  const [showDrawer, setShowDrawer] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [simulatedLevel, setSimulatedLevel] = useState(0);
  const [browserSupported, setBrowserSupported] = useState(true);
  const [activeSpeechText, setActiveSpeechText] = useState<string>("");
  
  // Multimodal Image Attachment state
  const [attachedImage, setAttachedImage] = useState<string | null>(null);

  const [messages, setMessages] = useState<VoiceMessage[]>(() => {
    const saved = localStorage.getItem("lekhok_voice_buddy_messages");
    if (saved) {
      try { 
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed.slice(-25);
      } catch (e) {}
    }
    return [
      {
        id: "v_welcome",
        role: "companion",
        text: lang === "bn" 
          ? "নমস্কার! আমি জেমিনি লাইভ ভয়েস পার্টনার। কথা বলতে নিচের অন বাটনে একবার ক্লিক করুন, এরপর অটোমেটিকভাবে অবিরাম কথা বলতে ও ছবি পাঠাতে পারবেন।" 
          : "Hello! I am Gemini Live Voice. Tap Start below once to talk continuously hands-free, and you can also send images for visual analysis.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      }
    ];
  });

  // Critical Refs to ensure 100% continuous, auto-resuming listening loops
  const isActiveSessionRef = useRef(false);
  const isAiSpeakingRef = useRef(false);
  const isThinkingRef = useRef(false);
  const recognitionRef = useRef<any>(null);
  const silenceTimerRef = useRef<any>(null);
  const accumulatedSpeechRef = useRef<string>("");
  const transcriptEndRef = useRef<HTMLDivElement>(null);
  const isComponentMounted = useRef(true);
  const cancelAudioRef = useRef<(() => void) | null>(null);
  const waveAnimRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const speechCooldownUntilRef = useRef<number>(0);
  const lastAiSpokenTailRef = useRef<string>("");

  // Sync state refs immediately
  useEffect(() => {
    isActiveSessionRef.current = isSessionActive;
  }, [isSessionActive]);

  useEffect(() => {
    isAiSpeakingRef.current = isAiSpeaking;
  }, [isAiSpeaking]);

  useEffect(() => {
    isThinkingRef.current = isThinking;
  }, [isThinking]);

  useEffect(() => {
    try {
      localStorage.setItem("lekhok_voice_buddy_messages", JSON.stringify(messages.slice(-25)));
    } catch (e) {}
    transcriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Smooth visual audio wave animation with phase shifts
  useEffect(() => {
    let phase = 0;
    const animateWave = () => {
      if (!isComponentMounted.current) return;
      phase += 0.12;

      if (isAiSpeakingRef.current) {
        setSimulatedLevel(0.65 + Math.sin(phase * 1.8) * 0.3);
      } else if (isActiveSessionRef.current && accumulatedSpeechRef.current.length > 0) {
        setSimulatedLevel(0.48 + Math.sin(phase * 2.2) * 0.28);
      } else if (isActiveSessionRef.current) {
        setSimulatedLevel(0.15 + Math.sin(phase * 0.7) * 0.08);
      } else {
        setSimulatedLevel(0);
      }

      waveAnimRef.current = requestAnimationFrame(animateWave);
    };

    waveAnimRef.current = requestAnimationFrame(animateWave);
    return () => {
      if (waveAnimRef.current) cancelAnimationFrame(waveAnimRef.current);
    };
  }, []);

  // Safe Continuous Microphone Listener Spawner (Creates fresh recognition instance)
  const startFreshRecognition = useCallback(() => {
    if (!isActiveSessionRef.current || isAiSpeakingRef.current || isThinkingRef.current || !isComponentMounted.current) {
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
      recognitionRef.current = null;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = lang === "bn" ? "bn-BD" : "en-US";

    recognition.onstart = () => {
      if (isActiveSessionRef.current && isComponentMounted.current && !isAiSpeakingRef.current && !isThinkingRef.current) {
        setIsListening(true);
      }
    };

    recognition.onresult = (event: any) => {
      if (!isActiveSessionRef.current || isAiSpeakingRef.current || isThinkingRef.current || !isComponentMounted.current) return;
      if (Date.now() < speechCooldownUntilRef.current) return;

      let interimTranscript = "";
      let finalTranscript = "";

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }

      const activeText = (finalTranscript || interimTranscript).trim();
      if (activeText && activeText.length >= 2) {
        // Acoustic echo rejection: ignore if the captured text is just an echo of what the AI just spoke
        if (lastAiSpokenTailRef.current && lastAiSpokenTailRef.current.includes(activeText.toLowerCase())) {
          return;
        }

        setLiveTranscript(activeText);
        accumulatedSpeechRef.current = activeText;

        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
        }

        // 1.1s natural silence threshold before sending turn to AI
        silenceTimerRef.current = setTimeout(() => {
          if (accumulatedSpeechRef.current.trim().length >= 2 && isActiveSessionRef.current && !isAiSpeakingRef.current && !isThinkingRef.current) {
            const captured = accumulatedSpeechRef.current.trim();
            accumulatedSpeechRef.current = "";
            sendSpeechToAI(captured);
          }
        }, 1100);
      }
    };

    recognition.onerror = (event: any) => {
      console.log("Live voice speech recognition notice:", event.error);
      if (event.error === "not-allowed") {
        if (!isComponentMounted.current) return;
        setIsListening(false);
        setIsSessionActive(false);
        isActiveSessionRef.current = false;
      }
    };

    recognition.onend = () => {
      if (!isComponentMounted.current) return;
      setIsListening(false);

      // Auto-Resurrect: If session is ON and AI is not speaking/thinking, start fresh recognition immediately!
      if (isActiveSessionRef.current && !isAiSpeakingRef.current && !isThinkingRef.current) {
        setTimeout(() => {
          if (isActiveSessionRef.current && !isAiSpeakingRef.current && !isThinkingRef.current) {
            startFreshRecognition();
          }
        }, 200);
      }
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
    } catch (e) {
      console.warn("Live voice start error:", e);
    }
  }, [lang]);

  // Vocal Output Engine (Auto-plays spoken audio, then seamlessly resumes listening)
  const speakResponse = useCallback((textToSpeak: string) => {
    if (!textToSpeak || !isActiveSessionRef.current) {
      setIsThinking(false);
      isThinkingRef.current = false;
      setIsAiSpeaking(false);
      isAiSpeakingRef.current = false;
      return;
    }

    if (cancelAudioRef.current) {
      cancelAudioRef.current();
      cancelAudioRef.current = null;
    }

    // Stop microphone input during audio vocalization to prevent hearing itself
    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
    }

    setActiveSpeechText(textToSpeak);
    setIsAiSpeaking(true);
    isAiSpeakingRef.current = true;
    setIsThinking(false);
    isThinkingRef.current = false;
    setIsListening(false);

    // Store the tail of the spoken text for acoustic echo rejection
    lastAiSpokenTailRef.current = textToSpeak.toLowerCase().slice(-100);

    cancelAudioRef.current = playSpokenAudioAloud(textToSpeak, lang, {
      onStart: () => {
        if (!isComponentMounted.current) return;
        setIsAiSpeaking(true);
        isAiSpeakingRef.current = true;
        setIsThinking(false);
        isThinkingRef.current = false;
        setIsListening(false);
      },
      onEnd: () => {
        if (!isComponentMounted.current) return;
        setIsAiSpeaking(false);
        isAiSpeakingRef.current = false;
        setIsThinking(false);
        isThinkingRef.current = false;
        setActiveSpeechText("");
        accumulatedSpeechRef.current = "";
        setLiveTranscript("");
        speechCooldownUntilRef.current = Date.now() + 650;

        // AUTOMATIC HANDS-FREE RESUME: Restart microphone safely after speaker finishes!
        if (isActiveSessionRef.current) {
          setTimeout(() => {
            if (isActiveSessionRef.current && !isAiSpeakingRef.current && !isThinkingRef.current) {
              startFreshRecognition();
            }
          }, 650);
        }
      },
      onError: () => {
        if (!isComponentMounted.current) return;
        setIsAiSpeaking(false);
        isAiSpeakingRef.current = false;
        setIsThinking(false);
        isThinkingRef.current = false;
        setActiveSpeechText("");
        speechCooldownUntilRef.current = Date.now() + 500;

        if (isActiveSessionRef.current) {
          setTimeout(() => {
            if (isActiveSessionRef.current && !isAiSpeakingRef.current && !isThinkingRef.current) {
              startFreshRecognition();
            }
          }, 500);
        }
      }
    });
  }, [lang, startFreshRecognition]);

  // Send captured speech or image to AI Companion
  const sendSpeechToAI = useCallback(async (spokenText: string, imageOverride?: string | null) => {
    const textToSend = spokenText.trim();
    const imageToSend = imageOverride !== undefined ? imageOverride : attachedImage;

    if ((!textToSend && !imageToSend) || !isActiveSessionRef.current) return;

    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
    }
    setIsListening(false);
    setIsThinking(true);
    isThinkingRef.current = true;

    const userMsg: VoiceMessage = {
      id: "v_usr_" + Date.now(),
      role: "user",
      text: textToSend || (lang === "bn" ? "[ছবি সংযুক্ত]" : "[Image Attached]"),
      image: imageToSend || undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages(prev => [...prev.slice(-20), userMsg]);
    setLiveTranscript("");
    accumulatedSpeechRef.current = "";

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (modelProvider) headers["x-model-provider"] = modelProvider;
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const res = await fetch("/api/voice-chat", {
        method: "POST",
        headers,
        body: JSON.stringify({
          messages: [...messages.slice(-6), userMsg],
          userSpeech: textToSend || (lang === "bn" ? "দয়া করে এই ছবিটি দেখে বলুন এতে কী আছে।" : "Please look at this image and tell me about it."),
          imageData: imageToSend,
          language: lang === "bn" ? "Bengali" : "English",
          voicePersonality: voiceMode
        })
      });

      if (!res.ok) {
        throw new Error(`Voice API status: ${res.status}`);
      }

      const data = await res.json();
      const aiReply = data.reply || (lang === "bn" ? "আমি আপনার কথা শুনতে পাচ্ছি।" : "I hear you clearly.");

      const aiMsg: VoiceMessage = {
        id: "v_ai_" + Date.now(),
        role: "companion",
        text: aiReply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      setMessages(prev => [...prev.slice(-20), aiMsg]);

      // Automatically speak out loud!
      if (isActiveSessionRef.current) {
        speakResponse(aiReply);
      } else {
        setIsThinking(false);
        isThinkingRef.current = false;
      }
    } catch (err: any) {
      console.warn("Voice conversation warning:", err);
      setIsThinking(false);
      isThinkingRef.current = false;
      
      const fallbackReply = lang === "bn" ? "জী, আমি শুনতে পাচ্ছি। দয়া করে আবার বলুন।" : "Yes, I am listening. Please speak again.";
      if (isActiveSessionRef.current) {
        speakResponse(fallbackReply);
      }
    }
  }, [lang, messages, modelProvider, customGeminiKey, customDeepseekKey, voiceMode, speakResponse, attachedImage]);

  // Image Upload Handler for Gemini Live Buddy
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64Url = reader.result as string;
      setAttachedImage(base64Url);

      const confirmText = lang === "bn" 
        ? "ছবিটি যুক্ত হয়েছে! মুখে বলুন ছবি নিয়ে কী জানতে চান।"
        : "Image attached! Speak your question about the image.";
      speakResponse(confirmText);
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  // Keep-Alive Heartbeat: ensures zero deadlocks during long sessions
  useEffect(() => {
    const heartbeat = setInterval(() => {
      if (isActiveSessionRef.current && !isAiSpeakingRef.current && !isThinkingRef.current && !isListening) {
        startFreshRecognition();
      }
    }, 1500);
    return () => clearInterval(heartbeat);
  }, [isListening, startFreshRecognition]);

  // Master Start Live Voice Handler
  const startVoiceSession = () => {
    // 1. Unlock browser Autoplay Audio
    unlockAudioAutoplay();

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(lang === "bn" ? "ভয়েস ব্যবহারের জন্য গুগল ক্রোম ব্রাউজার সবচেয়ে ভালো কাজ করে।" : "Please use Google Chrome for voice.");
      return;
    }

    isActiveSessionRef.current = true;
    setIsSessionActive(true);
    setIsThinking(false);
    isThinkingRef.current = false;
    setIsAiSpeaking(false);
    isAiSpeakingRef.current = false;
    setLiveTranscript("");
    setActiveSpeechText("");
    accumulatedSpeechRef.current = "";

    startFreshRecognition();
  };

  // Master Stop Live Voice Handler
  const stopVoiceSession = () => {
    isActiveSessionRef.current = false;
    isAiSpeakingRef.current = false;
    isThinkingRef.current = false;
    setIsSessionActive(false);
    setIsListening(false);
    setIsAiSpeaking(false);
    setIsThinking(false);
    setLiveTranscript("");
    setActiveSpeechText("");
    accumulatedSpeechRef.current = "";

    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
    }

    if (cancelAudioRef.current) {
      cancelAudioRef.current();
      cancelAudioRef.current = null;
    }

    stopAllSpokenAudio();

    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
      recognitionRef.current = null;
    }
  };

  // Interrupt AI Speech button (tap to speak right away)
  const interruptAiSpeech = () => {
    if (cancelAudioRef.current) {
      cancelAudioRef.current();
      cancelAudioRef.current = null;
    }
    stopAllSpokenAudio();
    setIsAiSpeaking(false);
    isAiSpeakingRef.current = false;
    setActiveSpeechText("");
    setTimeout(() => {
      startFreshRecognition();
    }, 150);
  };

  const clearHistory = () => {
    if (confirm(lang === "bn" ? "আপনি কি সমস্ত ভয়েস হিস্ট্রি মুছে ফেলতে চান?" : "Are you sure you want to clear voice history?")) {
      setMessages([]);
      localStorage.removeItem("lekhok_voice_buddy_messages");
    }
  };

  const voiceProfiles: { id: GeminiVoiceMode; label: string; desc: string }[] = [
    { id: "aoede", label: "Aoede", desc: lang === "bn" ? "উষ্ণ ও আত্মিক" : "Warm & Expressive" },
    { id: "puck", label: "Puck", desc: lang === "bn" ? "প্রাণবন্ত ও চটপটে" : "Playful & Energetic" },
    { id: "fenrir", label: "Fenrir", desc: lang === "bn" ? "শান্ত ও গম্ভীর" : "Deep & Calming" },
    { id: "kore", label: "Kore", desc: lang === "bn" ? "জ্ঞানগর্ভ ও স্পষ্ট" : "Intellectual & Clear" },
    { id: "nova", label: "Nova", desc: lang === "bn" ? "সৃজনশীল ও দূরদর্শী" : "Inspiring & Creative" }
  ];

  return (
    <div className={`flex-1 w-full max-w-5xl mx-auto flex flex-col font-sans transition-all duration-300 ${
      isFullscreen 
        ? "fixed inset-0 z-50 bg-slate-950 p-4 sm:p-8" 
        : "h-[calc(100vh-4.2rem)] p-3 sm:p-5"
    }`}>
      
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleImageUpload}
      />

      {/* TOP BAR: BRANDING + STATUS + PERSONA + FULLSCREEN */}
      <div className="bg-white/95 backdrop-blur-md border border-amber-200/90 rounded-3xl p-3 sm:p-4 shadow-sm mb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          
          {/* Dynamic 3D Voice Orb Logo */}
          <div className="relative">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-xl transition-all duration-500 relative overflow-hidden ${
              isSessionActive 
                ? (isAiSpeaking 
                    ? "bg-gradient-to-tr from-fuchsia-600 via-purple-600 to-indigo-600 shadow-purple-500/50" 
                    : isListening 
                    ? "bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 shadow-emerald-500/50"
                    : "bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 shadow-blue-500/50")
                : "bg-gradient-to-tr from-[#7c2d12] via-amber-600 to-amber-500 shadow-amber-900/30"
            }`}>
              {/* Sound Wave Dynamic Logo */}
              {isAiSpeaking ? (
                <AudioWaveform size={24} className="animate-pulse text-white" />
              ) : isListening ? (
                <Mic size={24} className="animate-bounce text-white" />
              ) : isSessionActive ? (
                <Zap size={24} className="animate-spin text-white" />
              ) : (
                <Radio size={24} className="text-amber-100" />
              )}

              {/* Shimmer sweep */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full animate-[shimmer_2s_infinite]" />
            </div>

            {isSessionActive && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 border-2 border-white rounded-full animate-ping" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-black text-slate-900 flex items-center gap-1.5">
                <span>{lang === "bn" ? "জেমিনি লাইভ ভয়েস ও ভিশন" : "Gemini Live Voice & Vision"}</span>
                <span className="text-[9px] bg-gradient-to-r from-amber-600 to-rose-600 text-white font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-xs">
                  Auto Hands-Free
                </span>
              </h2>
              
              <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border flex items-center gap-1.5 ${
                isSessionActive 
                  ? (isAiSpeaking
                      ? "bg-fuchsia-100 text-fuchsia-950 border-fuchsia-300 animate-pulse"
                      : isThinking
                      ? "bg-blue-100 text-blue-950 border-blue-300 animate-pulse"
                      : "bg-emerald-100 text-emerald-950 border-emerald-300 animate-pulse")
                  : "bg-slate-100 text-slate-600 border-slate-200"
              }`}>
                <Radio size={10} className={isSessionActive ? "text-emerald-600 animate-ping" : "text-slate-400"} />
                {isSessionActive 
                  ? (isAiSpeaking 
                      ? (lang === "bn" ? "মুখে উত্তর দিচ্ছে..." : "Speaking aloud...") 
                      : isThinking 
                      ? (lang === "bn" ? "চিন্তা করছে..." : "Thinking...")
                      : (lang === "bn" ? "অটো শুনছি (কথা বলুন)..." : "Listening auto..."))
                  : (lang === "bn" ? "বন্ধ আছে" : "Off")}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              {lang === "bn" ? "১০০% হ্যান্ডস-ফ্রি কথোপকথন ও ছবি বিশ্লেষণ" : "100% continuous hands-free dialogue & image analysis"}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Persona selector pill */}
          <div className="hidden md:flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200 gap-1">
            {voiceProfiles.map((v) => (
              <button
                key={v.id}
                onClick={() => setVoiceMode(v.id)}
                className={`px-2.5 py-1 rounded-xl text-[10px] font-black transition cursor-pointer ${
                  voiceMode === v.id
                    ? "bg-white text-slate-900 shadow-sm border border-slate-200/80"
                    : "text-slate-500 hover:text-slate-900"
                }`}
                title={v.desc}
              >
                {v.label}
              </button>
            ))}
          </div>

          {/* Attach Image / Vision Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 border ${
              attachedImage 
                ? "bg-amber-500 text-slate-950 border-amber-400 font-black shadow-sm" 
                : "bg-slate-100 text-slate-700 hover:bg-slate-200 border-slate-200"
            }`}
            title={lang === "bn" ? "ছবি আপলোড করে জেমিনিকে দেখান" : "Upload image for Gemini Vision"}
          >
            <ImageIcon size={14} />
            <span className="hidden sm:inline">{attachedImage ? (lang === "bn" ? "ছবি রেডি" : "Image Ready") : (lang === "bn" ? "ছবি দিন" : "Attach Image")}</span>
          </button>

          <button
            onClick={() => setShowDrawer(!showDrawer)}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
              showDrawer ? "bg-amber-100 text-[#7c2d12] border border-amber-300" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
            }`}
            title="Toggle Transcript History"
          >
            <History size={14} />
            <span className="hidden sm:inline">{lang === "bn" ? "হিস্ট্রি" : "History"}</span>
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 rounded-xl text-slate-700 bg-slate-100 hover:bg-slate-200 cursor-pointer"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen Live Mode"}
          >
            {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
          </button>
        </div>
      </div>

      {!browserSupported && (
        <div className="bg-amber-50 border border-amber-300 p-3 rounded-2xl mb-4 text-xs text-amber-900 flex items-center gap-2">
          <ShieldAlert size={16} className="text-amber-700 shrink-0" />
          <span>{lang === "bn" ? "সর্বোত্তম স্পিচ অভিজ্ঞতার জন্য গুগল ক্রোম ব্রাউজার ব্যবহার করুন।" : "For best continuous live voice experience, use Google Chrome."}</span>
        </div>
      )}

      {/* MAIN GEMINI LIVE 3D STAGE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 min-h-0">
        
        {/* The Live Screen Orb Arena */}
        <div className={`${showDrawer ? "lg:col-span-7" : "lg:col-span-12"} bg-gradient-to-b from-[#050914] via-[#0b1324] to-[#02050e] rounded-3xl p-6 text-white flex flex-col items-center justify-between shadow-2xl border border-indigo-950/80 relative overflow-hidden transition-all duration-300`}>
          
          {/* Dynamic Cosmic Background Lighting */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className={`absolute top-1/4 left-1/4 w-80 h-80 rounded-full blur-[90px] transition-all duration-1000 ${
              isAiSpeaking 
                ? "bg-purple-600/40 opacity-100 scale-125" 
                : isListening 
                ? "bg-emerald-500/30 opacity-100 scale-110" 
                : isThinking 
                ? "bg-blue-600/35 opacity-100 scale-115" 
                : "bg-indigo-600/15 opacity-50 scale-100"
            }`} />
            
            <div className={`absolute bottom-1/4 right-1/4 w-88 h-88 rounded-full blur-[100px] transition-all duration-1000 ${
              isAiSpeaking 
                ? "bg-pink-600/35 opacity-100 scale-120" 
                : isListening 
                ? "bg-cyan-500/30 opacity-100 scale-110" 
                : isThinking 
                ? "bg-violet-600/30 opacity-100 scale-115" 
                : "bg-amber-600/10 opacity-40 scale-100"
            }`} />
          </div>

          {/* Top Live Bar inside Arena */}
          <div className="w-full flex items-center justify-between z-10">
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-xl px-4 py-1.5 rounded-full border border-white/15 shadow-sm">
              <span className={`w-2.5 h-2.5 rounded-full ${
                isAiSpeaking 
                  ? "bg-fuchsia-400 animate-ping" 
                  : isListening 
                  ? "bg-emerald-400 animate-ping" 
                  : isThinking 
                  ? "bg-cyan-400 animate-spin" 
                  : "bg-slate-500"
              }`} />
              <span className="text-xs font-black tracking-wide text-white">
                {isSessionActive 
                  ? (isAiSpeaking 
                      ? (lang === "bn" ? "জেমিনি মুখে উত্তর দিচ্ছে..." : "Gemini Speaking aloud...") 
                      : isThinking 
                      ? (lang === "bn" ? "চিন্তা করছে..." : "Processing...") 
                      : isListening 
                      ? (lang === "bn" ? "আপনার কথা শুনছি (বলুন)..." : "Listening continuously...") 
                      : (lang === "bn" ? "লাইভ কানেক্টেড" : "Connected"))
                  : (lang === "bn" ? "শুরু করতে নিচে অন বাটনে চাপুন" : "Click Start Voice below")}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Interruption Button when AI is speaking */}
              {isAiSpeaking && (
                <button
                  onClick={interruptAiSpeech}
                  className="px-3 py-1 bg-rose-500/80 hover:bg-rose-600 text-white rounded-full text-[10px] font-black uppercase tracking-wider backdrop-blur-md transition flex items-center gap-1 cursor-pointer border border-rose-300/40 animate-pulse"
                  title="Interrupt and speak now"
                >
                  <VolumeX size={11} />
                  <span>{lang === "bn" ? "থামিয়ে বলুন" : "Interrupt"}</span>
                </button>
              )}

              <div className="text-[11px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5 bg-black/50 backdrop-blur-md px-3.5 py-1 rounded-full border border-white/15">
                <Sparkles size={12} className="text-amber-400" />
                <span>{voiceProfiles.find(v => v.id === voiceMode)?.label}</span>
              </div>
            </div>
          </div>

          {/* ATTACHED IMAGE BANNER OVERVIEW (IF ANY) */}
          {attachedImage && (
            <div className="z-10 mt-3 bg-black/60 backdrop-blur-xl border border-amber-400/40 rounded-2xl p-2.5 flex items-center justify-between gap-3 w-full max-w-md shadow-2xl">
              <div className="flex items-center gap-3 overflow-hidden">
                <img src={attachedImage} alt="Attachment" className="w-14 h-14 object-cover rounded-xl border border-white/20 shrink-0" />
                <div className="text-left text-xs">
                  <p className="font-bold text-amber-300 flex items-center gap-1">
                    <Eye size={13} />
                    <span>{lang === "bn" ? "ছবি প্রস্তুত আছে" : "Vision Ready"}</span>
                  </p>
                  <p className="text-[11px] text-slate-300 line-clamp-1">
                    {lang === "bn" ? "মুখে বলুন 'ছবিটি দেখে বলো'..." : "Say 'describe this image'..."}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setAttachedImage(null)}
                className="p-1.5 hover:bg-rose-900/60 text-rose-400 rounded-lg transition cursor-pointer"
                title="Remove image"
              >
                <Trash2 size={15} />
              </button>
            </div>
          )}

          {/* THE 3D NEURAL HOLOGRAPHIC AUDIO CORE & VISUAL ORB */}
          <div className="relative flex flex-col items-center justify-center my-auto py-8 z-10 w-full max-w-md">
            
            {/* Outer Concentric Holographic Orbital Rings */}
            <div 
              className={`absolute rounded-full border border-dashed transition-all duration-700 pointer-events-none gemini-orbit-ring-1 ${
                isAiSpeaking 
                  ? "w-72 h-72 sm:w-96 sm:h-96 border-fuchsia-400/40 opacity-90" 
                  : isListening 
                  ? "w-64 h-64 sm:w-88 sm:h-88 border-emerald-400/40 opacity-85" 
                  : isThinking 
                  ? "w-68 h-68 sm:w-92 sm:h-92 border-cyan-400/40 opacity-80" 
                  : "w-56 h-56 sm:w-76 sm:h-76 border-white/10 opacity-30"
              }`}
            />

            <div 
              className={`absolute rounded-full border transition-all duration-700 pointer-events-none gemini-orbit-ring-2 ${
                isAiSpeaking 
                  ? "w-60 h-60 sm:w-80 sm:h-80 border-purple-400/50 opacity-80" 
                  : isListening 
                  ? "w-56 h-56 sm:w-76 sm:h-76 border-teal-400/50 opacity-75" 
                  : isThinking 
                  ? "w-58 h-58 sm:w-78 sm:h-78 border-blue-400/50 opacity-75" 
                  : "w-48 h-48 sm:w-64 sm:h-64 border-white/10 opacity-20"
              }`}
            />

            {/* Audio Reactive Sonic Pulse Ring */}
            {isListening && (
              <div 
                className="absolute rounded-full border-2 border-emerald-400/60 transition-all duration-75 pointer-events-none"
                style={{
                  width: `${210 + simulatedLevel * 140}px`,
                  height: `${210 + simulatedLevel * 140}px`,
                  opacity: 0.3 + simulatedLevel * 0.7
                }}
              />
            )}

            {isAiSpeaking && (
              <div 
                className="absolute rounded-full border-2 border-fuchsia-400/60 transition-all duration-75 pointer-events-none animate-ping"
                style={{
                  width: `${220 + simulatedLevel * 120}px`,
                  height: `${220 + simulatedLevel * 120}px`,
                  animationDuration: "2s"
                }}
              />
            )}

            {/* Main Fluid Holographic Sphere */}
            <div 
              className={`w-48 h-48 sm:w-60 sm:h-60 relative flex items-center justify-center rounded-full shadow-2xl cursor-pointer transition-all duration-500 ${
                isAiSpeaking 
                  ? "gemini-orb-speaking scale-110" 
                  : isListening 
                  ? "gemini-orb-listening scale-105" 
                  : isThinking 
                  ? "gemini-orb-morph scale-100" 
                  : "gemini-orb-morph hover:scale-105 opacity-90"
              }`}
              style={{
                background: isAiSpeaking 
                  ? "radial-gradient(circle at 30% 30%, #f43f5e, #c026d3, #7c3aed, #2563eb)"
                  : isListening
                  ? "radial-gradient(circle at 35% 35%, #10b981, #06b6d4, #3b82f6, #6366f1)"
                  : isThinking
                  ? "radial-gradient(circle at 40% 40%, #38bdf8, #818cf8, #c084fc, #3b82f6)"
                  : "radial-gradient(circle at 30% 30%, #d97706, #e11d48, #7c2d12, #1e293b)",
                boxShadow: isAiSpeaking
                  ? "0 0 80px rgba(192, 38, 211, 0.8), 0 0 140px rgba(244, 63, 94, 0.5), inset 0 0 40px rgba(255, 255, 255, 0.4)"
                  : isListening
                  ? `0 0 ${50 + simulatedLevel * 70}px rgba(16, 185, 129, 0.85), 0 0 120px rgba(6, 182, 212, 0.5), inset 0 0 35px rgba(255, 255, 255, 0.4)`
                  : isThinking
                  ? "0 0 70px rgba(56, 189, 248, 0.8), 0 0 110px rgba(129, 140, 248, 0.5), inset 0 0 35px rgba(255, 255, 255, 0.3)"
                  : "0 0 45px rgba(124, 45, 18, 0.5), inset 0 0 25px rgba(255, 255, 255, 0.2)"
              }}
              onClick={isSessionActive ? stopVoiceSession : startVoiceSession}
            >
              {/* Internal Neural Shimmer Layer */}
              <div className="absolute inset-2 rounded-full bg-gradient-to-tr from-white/10 via-transparent to-white/20 pointer-events-none backdrop-blur-xs" />

              {/* Central Reactive Equalizer Spectrum Bars */}
              <div className="flex items-center gap-1.5 z-20">
                {[0.3, 0.7, 1.1, 1.4, 1.6, 1.4, 1.1, 0.7, 0.3].map((factor, idx) => {
                  const barHeight = isAiSpeaking
                    ? Math.sin(Date.now() / 120 + idx) * 22 + 30
                    : isListening
                    ? Math.max(8, (simulatedLevel * 55 * factor) + 8)
                    : isThinking
                    ? Math.sin(Date.now() / 180 + idx) * 14 + 18
                    : 12;

                  return (
                    <div
                      key={idx}
                      className="gemini-wave-bar w-1.5 bg-white shadow-md rounded-full"
                      style={{
                        height: `${barHeight}px`,
                        opacity: isSessionActive ? 0.95 : 0.6,
                        boxShadow: "0 0 10px rgba(255,255,255,0.8)"
                      }}
                    />
                  );
                })}
              </div>
            </div>

            {/* Spoken Live Text & Subtitles */}
            <div className="min-h-[58px] mt-6 flex items-center justify-center w-full px-4">
              {liveTranscript ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-black/70 backdrop-blur-2xl border border-cyan-400/30 px-5 py-2.5 rounded-2xl text-center max-w-md shadow-2xl"
                >
                  <p className="text-xs sm:text-sm text-cyan-200 font-medium italic leading-snug">
                    "🎤 {liveTranscript}"
                  </p>
                </motion.div>
              ) : activeSpeechText ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-purple-950/80 backdrop-blur-2xl border border-fuchsia-400/40 px-5 py-2.5 rounded-2xl text-center max-w-md shadow-2xl"
                >
                  <p className="text-xs sm:text-sm text-fuchsia-100 font-medium leading-snug">
                    "{activeSpeechText}"
                  </p>
                </motion.div>
              ) : isSessionActive ? (
                <div className="flex items-center gap-2 bg-emerald-950/40 border border-emerald-500/30 px-4 py-2 rounded-full backdrop-blur-md">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <p className="text-xs text-emerald-200 font-medium">
                    {lang === "bn" ? "অটো শুনছি... স্বাভাবিকভাবে যেকোনো কথা বলুন..." : "Auto listening... speak naturally anytime..."}
                  </p>
                </div>
              ) : (
                <p className="text-xs text-slate-400 font-medium">
                  {lang === "bn" ? "শুরু করতে নিচের বাটনে চাপুন (একবার অন করলেই অটো চলবে)" : "Press below once to start continuous auto-dialogue"}
                </p>
              )}
            </div>

          </div>

          {/* Clean Master ON/OFF Toggle with High-Visibility Touch States */}
          <div className="w-full flex items-center justify-center z-20 pt-4 border-t border-white/10">
            <button
              onClick={isSessionActive ? stopVoiceSession : startVoiceSession}
              className={`w-full max-w-xs py-4 rounded-2xl flex items-center justify-center gap-3 font-black text-sm transition-all duration-300 cursor-pointer shadow-2xl ${
                isSessionActive
                  ? "bg-gradient-to-r from-rose-600 via-rose-500 to-amber-500 text-white shadow-rose-500/40 ring-4 ring-rose-500/30 hover:brightness-110"
                  : "bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-white shadow-emerald-500/40 ring-4 ring-emerald-500/30 hover:scale-102"
              }`}
            >
              {isSessionActive ? (
                <>
                  <MicOff size={22} />
                  <span>{lang === "bn" ? "ভয়েস বন্ধ করুন (OFF)" : "Turn Off Voice (OFF)"}</span>
                </>
              ) : (
                <>
                  <Mic size={22} className="animate-bounce" />
                  <span>{lang === "bn" ? "ভয়েস চালু করুন (ON)" : "Turn On Voice (ON)"}</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Right Drawer: Transcript History */}
        {showDrawer && (
          <div className="lg:col-span-5 bg-white border border-amber-200/90 rounded-3xl p-5 shadow-lg flex flex-col justify-between">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Radio size={14} className="text-[#7c2d12] animate-pulse" />
                <h3 className="text-xs font-black uppercase tracking-wider text-slate-800">
                  {lang === "bn" ? "ভয়েস হিস্ট্রি" : "Voice History"}
                </h3>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={clearHistory}
                  className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                  title="Clear History"
                >
                  <Trash2 size={14} />
                </button>
                <button
                  onClick={() => setShowDrawer(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg transition cursor-pointer"
                >
                  <X size={14} />
                </button>
              </div>
            </div>

            {/* Message log */}
            <div className="flex-1 overflow-y-auto my-3 space-y-3 pr-1 max-h-[400px]">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`p-3 rounded-2xl text-xs leading-relaxed ${
                    m.role === "user"
                      ? "bg-amber-50 text-amber-950 ml-6 border border-amber-200/70"
                      : "bg-slate-50 text-slate-900 mr-6 border border-slate-200/70"
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold mb-1">
                    <span>{m.role === "user" ? (lang === "bn" ? "আপনি" : "You") : "Gemini"}</span>
                    <span>{m.timestamp}</span>
                  </div>
                  {m.image && (
                    <img src={m.image} alt="User Upload" className="w-24 h-24 object-cover rounded-xl mb-2 border border-amber-300" />
                  )}
                  <p>{m.text}</p>
                </div>
              ))}
              <div ref={transcriptEndRef} />
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
