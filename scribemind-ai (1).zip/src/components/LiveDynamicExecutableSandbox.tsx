import React, { useEffect, useRef, useState } from "react";
import { Play, RefreshCw, AlertCircle, CheckCircle2, Code2, Terminal, ExternalLink } from "lucide-react";

interface LiveDynamicExecutableSandboxProps {
  htmlCode: string;
  customCss?: string;
  customJs?: string;
  className?: string;
  isolateIframe?: boolean;
  onExecutionSuccess?: () => void;
  onExecutionError?: (err: string) => void;
}

export const LiveDynamicExecutableSandbox: React.FC<LiveDynamicExecutableSandboxProps> = ({
  htmlCode,
  customCss = "",
  customJs = "",
  className = "",
  isolateIframe = false,
  onExecutionSuccess,
  onExecutionError
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const [hasError, setHasError] = useState<string | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);

  useEffect(() => {
    if (!htmlCode && !customCss && !customJs) return;

    setIsExecuting(true);
    setHasError(null);

    if (isolateIframe && iframeRef.current) {
      try {
        const doc = iframeRef.current.contentDocument || iframeRef.current.contentWindow?.document;
        if (doc) {
          doc.open();
          doc.write(`
            <!DOCTYPE html>
            <html>
              <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <script src="https://cdn.tailwindcss.com"></script>
                <style>
                  body { margin: 0; padding: 16px; font-family: system-ui, -apple-system, sans-serif; background: transparent; }
                  ${customCss || ""}
                </style>
              </head>
              <body>
                <div id="sandbox-root">${htmlCode}</div>
                <script>
                  try {
                    ${customJs || ""}
                  } catch (e) {
                    console.error("Custom JS error:", e);
                  }
                </script>
              </body>
            </html>
          `);
          doc.close();
          onExecutionSuccess?.();
        }
      } catch (err: any) {
        setHasError(err.message || "Failed to render in sandbox iframe");
        onExecutionError?.(err.message);
      } finally {
        setIsExecuting(false);
      }
      return;
    }

    // Direct DOM Mount with dynamic script tag execution
    if (containerRef.current) {
      try {
        const container = containerRef.current;
        container.innerHTML = htmlCode;

        // Extract and safely execute all embedded <script> tags
        const scripts = container.querySelectorAll("script");
        scripts.forEach((oldScript) => {
          const newScript = document.createElement("script");
          Array.from(oldScript.attributes).forEach(attr => newScript.setAttribute(attr.name, attr.value));
          newScript.textContent = oldScript.textContent;
          oldScript.parentNode?.replaceChild(newScript, oldScript);
        });

        // Run any custom JS
        if (customJs && customJs.trim()) {
          try {
            const runner = new Function("container", customJs);
            runner(container);
          } catch (jsErr: any) {
            console.warn("Dynamic JS execution notice:", jsErr);
          }
        }

        onExecutionSuccess?.();
      } catch (err: any) {
        console.error("DOM execution error:", err);
        setHasError(err.message || "Code execution failed");
        onExecutionError?.(err.message);
      } finally {
        setIsExecuting(false);
      }
    }
  }, [htmlCode, customCss, customJs, isolateIframe]);

  if (isolateIframe) {
    return (
      <div className={`relative w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 ${className}`}>
        <iframe
          ref={iframeRef}
          title="Live Component Execution Sandbox"
          className="w-full min-h-[320px] border-none"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        />
        {hasError && (
          <div className="p-3 bg-rose-950/80 border-t border-rose-800 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle size={14} className="shrink-0" />
            <span>{hasError}</span>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`w-full relative ${className}`}>
      {customCss && (
        <style dangerouslySetInnerHTML={{ __html: customCss }} />
      )}
      <div ref={containerRef} className="w-full" />
      {hasError && (
        <div className="mt-2 p-3 bg-rose-950/80 border border-rose-800 text-rose-300 rounded-xl text-xs flex items-center gap-2">
          <AlertCircle size={14} className="shrink-0" />
          <span>Error in live code execution: {hasError}</span>
        </div>
      )}
    </div>
  );
};
