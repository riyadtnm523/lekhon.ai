import React, { useEffect, useRef, useState } from "react";
import { Play, Pause, RotateCw, ZoomIn, ZoomOut, Box, Sparkles, Layers, Eye } from "lucide-react";

export type Model3DType = 
  | "earth" 
  | "solar_system" 
  | "galaxy" 
  | "cube" 
  | "dna" 
  | "matrix" 
  | "molecule" 
  | "book" 
  | "hologram";

interface Interactive3DViewerProps {
  type?: Model3DType | string;
  title?: string;
  lang?: "bn" | "en";
  autoRotateSpeed?: number;
  height?: number;
}

export const Interactive3DViewer: React.FC<Interactive3DViewerProps> = ({
  type = "earth",
  title,
  lang = "bn",
  autoRotateSpeed = 1,
  height = 320
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [isRotating, setIsRotating] = useState(true);
  const [wireframe, setWireframe] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [modelType, setModelType] = useState<Model3DType>(() => {
    const clean = (type || "").toLowerCase();
    if (clean.includes("solar") || clean.includes("planet")) return "solar_system";
    if (clean.includes("galaxy") || clean.includes("space") || clean.includes("star")) return "galaxy";
    if (clean.includes("dna") || clean.includes("helix") || clean.includes("gene")) return "dna";
    if (clean.includes("matrix") || clean.includes("code") || clean.includes("cyber")) return "matrix";
    if (clean.includes("molecule") || clean.includes("atom") || clean.includes("chem")) return "molecule";
    if (clean.includes("book") || clean.includes("cover")) return "book";
    if (clean.includes("hologram") || clean.includes("holo")) return "hologram";
    if (clean.includes("cube")) return "cube";
    return "earth";
  });

  // Rotation angles
  const rotRef = useRef({ x: 0.3, y: 0.5 });
  const isDraggingRef = useRef(false);
  const lastMouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let time = 0;

    const resize = () => {
      if (containerRef.current && canvas) {
        const rect = containerRef.current.getBoundingClientRect();
        canvas.width = rect.width * (window.devicePixelRatio || 1);
        canvas.height = height * (window.devicePixelRatio || 1);
        ctx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);
      }
    };

    resize();
    window.addEventListener("resize", resize);

    const render = () => {
      if (!containerRef.current || !canvas) return;
      const w = containerRef.current.clientWidth;
      const h = height;

      ctx.clearRect(0, 0, w, h);

      // Deep space / dark luxury background
      const bgGrad = ctx.createRadialGradient(w / 2, h / 2, 10, w / 2, h / 2, Math.max(w, h));
      bgGrad.addColorStop(0, "#0f172a");
      bgGrad.addColorStop(0.5, "#090d16");
      bgGrad.addColorStop(1, "#030712");
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // Background stars
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
      for (let i = 0; i < 40; i++) {
        const sx = ((Math.sin(i * 99 + time * 0.05) * 0.5 + 0.5) * w);
        const sy = ((Math.cos(i * 33 + time * 0.05) * 0.5 + 0.5) * h);
        const sSize = (Math.sin(i * 12 + time * 2) * 0.5 + 0.5) * 1.5 + 0.5;
        ctx.beginPath();
        ctx.arc(sx, sy, sSize, 0, Math.PI * 2);
        ctx.fill();
      }

      const cx = w / 2;
      const cy = h / 2;

      if (isRotating) {
        rotRef.current.y += 0.008 * autoRotateSpeed;
      }
      time += 0.02;

      const rx = rotRef.current.x;
      const ry = rotRef.current.y;
      const baseRadius = Math.min(w, h) * 0.28 * zoom;

      // 3D Projection helper
      const project = (x: number, y: number, z: number) => {
        // Rotate around Y
        const cosY = Math.cos(ry);
        const sinY = Math.sin(ry);
        const x1 = x * cosY - z * sinY;
        const z1 = x * sinY + z * cosY;

        // Rotate around X
        const cosX = Math.cos(rx);
        const sinX = Math.sin(rx);
        const y2 = y * cosX - z1 * sinX;
        const z2 = y * sinX + z1 * cosX;

        const distance = 400;
        const scale = distance / (distance + z2);
        return {
          x: cx + x1 * scale,
          y: cy + y2 * scale,
          z: z2,
          scale: scale
        };
      };

      // 1. EARTH 3D MODEL
      if (modelType === "earth") {
        // Glow atmosphere
        const glow = ctx.createRadialGradient(cx, cy, baseRadius * 0.8, cx, cy, baseRadius * 1.35);
        glow.addColorStop(0, "rgba(56, 189, 248, 0.4)");
        glow.addColorStop(0.6, "rgba(14, 165, 233, 0.15)");
        glow.addColorStop(1, "rgba(2, 132, 199, 0)");
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(cx, cy, baseRadius * 1.35, 0, Math.PI * 2);
        ctx.fill();

        // Sphere body
        const earthGrad = ctx.createRadialGradient(cx - baseRadius * 0.35, cy - baseRadius * 0.35, baseRadius * 0.1, cx, cy, baseRadius);
        earthGrad.addColorStop(0, "#38bdf8");
        earthGrad.addColorStop(0.4, "#0284c7");
        earthGrad.addColorStop(0.8, "#0369a1");
        earthGrad.addColorStop(1, "#082f49");
        ctx.fillStyle = earthGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, baseRadius, 0, Math.PI * 2);
        ctx.fill();

        // Continents and latitude/longitude lines in 3D
        ctx.strokeStyle = wireframe ? "rgba(255, 255, 255, 0.6)" : "rgba(186, 230, 253, 0.35)";
        ctx.lineWidth = wireframe ? 1.2 : 0.8;

        const latSteps = 8;
        const lonSteps = 16;

        for (let lat = 1; lat < latSteps; lat++) {
          const theta = (lat / latSteps) * Math.PI - Math.PI / 2;
          const r = baseRadius * Math.cos(theta);
          const y = baseRadius * Math.sin(theta);

          ctx.beginPath();
          let started = false;
          for (let lon = 0; lon <= lonSteps; lon++) {
            const phi = (lon / lonSteps) * Math.PI * 2;
            const x = r * Math.cos(phi);
            const z = r * Math.sin(phi);
            const p = project(x, y, z);
            if (p.z < 0 || wireframe) {
              if (!started) {
                ctx.moveTo(p.x, p.y);
                started = true;
              } else {
                ctx.lineTo(p.x, p.y);
              }
            } else {
              started = false;
            }
          }
          ctx.stroke();
        }

        // Continents / Green clusters on surface
        for (let i = 0; i < 45; i++) {
          const lat = (Math.sin(i * 1.7) * 0.75) * Math.PI;
          const lon = (i * 0.45) * Math.PI * 2;
          const r = baseRadius * Math.cos(lat);
          const x = r * Math.cos(lon);
          const y = baseRadius * Math.sin(lat);
          const z = r * Math.sin(lon);
          const p = project(x, y, z);

          if (p.z < 0) {
            ctx.fillStyle = "rgba(74, 222, 128, 0.75)";
            ctx.beginPath();
            ctx.arc(p.x, p.y, Math.max(1, 4 * p.scale), 0, Math.PI * 2);
            ctx.fill();
          }
        }
      }

      // 2. SOLAR SYSTEM 3D MODEL
      else if (modelType === "solar_system") {
        // Glowing Sun in Center
        const sunGlow = ctx.createRadialGradient(cx, cy, 5, cx, cy, 40);
        sunGlow.addColorStop(0, "#fbbf24");
        sunGlow.addColorStop(0.5, "#f97316");
        sunGlow.addColorStop(1, "rgba(239, 68, 68, 0)");
        ctx.fillStyle = sunGlow;
        ctx.beginPath();
        ctx.arc(cx, cy, 35, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#fef08a";
        ctx.beginPath();
        ctx.arc(cx, cy, 14, 0, Math.PI * 2);
        ctx.fill();

        // Orbiting Planets
        const planets = [
          { name: "Mercury", r: baseRadius * 0.45, speed: 2.5, size: 3, color: "#94a3b8" },
          { name: "Venus", r: baseRadius * 0.75, speed: 1.8, size: 4.5, color: "#fde047" },
          { name: "Earth", r: baseRadius * 1.1, speed: 1.2, size: 5.5, color: "#38bdf8" },
          { name: "Mars", r: baseRadius * 1.45, speed: 0.9, size: 4, color: "#ef4444" },
          { name: "Jupiter", r: baseRadius * 1.9, speed: 0.5, size: 9, color: "#fb923c" },
          { name: "Saturn", r: baseRadius * 2.3, speed: 0.35, size: 7.5, color: "#eab308", ring: true }
        ];

        planets.forEach((pl, idx) => {
          // Orbit line in 3D
          ctx.strokeStyle = "rgba(148, 163, 184, 0.25)";
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          for (let step = 0; step <= 32; step++) {
            const angle = (step / 32) * Math.PI * 2;
            const ox = pl.r * Math.cos(angle);
            const oz = pl.r * Math.sin(angle);
            const p = project(ox, 0, oz);
            if (step === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          }
          ctx.stroke();

          // Planet position
          const curAngle = time * pl.speed * 0.6 + idx * 1.2;
          const px = pl.r * Math.cos(curAngle);
          const pz = pl.r * Math.sin(curAngle);
          const p = project(px, 0, pz);

          // Render Saturn Ring
          if (pl.ring) {
            ctx.strokeStyle = "rgba(234, 179, 8, 0.6)";
            ctx.lineWidth = 2 * p.scale;
            ctx.beginPath();
            ctx.ellipse(p.x, p.y, pl.size * 2.5 * p.scale, pl.size * 0.8 * p.scale, 0.3, 0, Math.PI * 2);
            ctx.stroke();
          }

          // Planet body
          ctx.fillStyle = pl.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, pl.size * p.scale, 0, Math.PI * 2);
          ctx.fill();

          // Label
          ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
          ctx.font = "9px sans-serif";
          ctx.fillText(pl.name, p.x + 8, p.y + 3);
        });
      }

      // 3. COSMIC GALAXY 3D SPIRAL
      else if (modelType === "galaxy") {
        const arms = 3;
        const particlesPerArm = 80;

        for (let arm = 0; arm < arms; arm++) {
          const armAngleOffset = (arm / arms) * Math.PI * 2;
          for (let i = 0; i < particlesPerArm; i++) {
            const distance = (i / particlesPerArm) * baseRadius * 1.5;
            const spiralAngle = armAngleOffset + (i * 0.08) + time * 0.3;
            const x = distance * Math.cos(spiralAngle);
            const z = distance * Math.sin(spiralAngle);
            const y = (Math.sin(i * 0.3 + time) * 12) * (1 - i / particlesPerArm);

            const p = project(x, y, z);
            const alpha = Math.max(0.2, (1 - distance / (baseRadius * 1.6)));

            const colors = ["#a855f7", "#6366f1", "#38bdf8", "#ec4899", "#f43f5e"];
            ctx.fillStyle = colors[(arm + i) % colors.length];
            ctx.globalAlpha = alpha;
            ctx.beginPath();
            ctx.arc(p.x, p.y, Math.max(1, (3 - (distance / baseRadius)) * p.scale), 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
          }
        }

        // Galactic core
        const coreGlow = ctx.createRadialGradient(cx, cy, 2, cx, cy, 28);
        coreGlow.addColorStop(0, "#ffffff");
        coreGlow.addColorStop(0.3, "#c084fc");
        coreGlow.addColorStop(1, "rgba(99, 102, 241, 0)");
        ctx.fillStyle = coreGlow;
        ctx.beginPath();
        ctx.arc(cx, cy, 28, 0, Math.PI * 2);
        ctx.fill();
      }

      // 4. 3D CYBER CUBE / MATRIX BOX
      else if (modelType === "cube") {
        const s = baseRadius * 0.8;
        const vertices = [
          project(-s, -s, -s),
          project(s, -s, -s),
          project(s, s, -s),
          project(-s, s, -s),
          project(-s, -s, s),
          project(s, -s, s),
          project(s, s, s),
          project(-s, s, s)
        ];

        const edges = [
          [0, 1], [1, 2], [2, 3], [3, 0],
          [4, 5], [5, 6], [6, 7], [7, 4],
          [0, 4], [1, 5], [2, 6], [3, 7]
        ];

        // Draw glowing edges
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = wireframe ? 1.5 : 2.5;
        ctx.shadowColor = "#38bdf8";
        ctx.shadowBlur = 10;

        edges.forEach(([u, v]) => {
          ctx.beginPath();
          ctx.moveTo(vertices[u].x, vertices[u].y);
          ctx.lineTo(vertices[v].x, vertices[v].y);
          ctx.stroke();
        });
        ctx.shadowBlur = 0;

        // Draw neon nodes
        vertices.forEach((v) => {
          ctx.fillStyle = "#f43f5e";
          ctx.beginPath();
          ctx.arc(v.x, v.y, 4 * v.scale, 0, Math.PI * 2);
          ctx.fill();
        });
      }

      // 5. DNA DOUBLE HELIX
      else if (modelType === "dna") {
        const pairs = 24;
        const helixRadius = baseRadius * 0.6;
        const length = baseRadius * 1.8;

        for (let i = 0; i < pairs; i++) {
          const y = (i / pairs - 0.5) * length;
          const angle = (i * 0.45) + time * 0.8;

          const x1 = helixRadius * Math.cos(angle);
          const z1 = helixRadius * Math.sin(angle);
          const p1 = project(x1, y, z1);

          const x2 = helixRadius * Math.cos(angle + Math.PI);
          const z2 = helixRadius * Math.sin(angle + Math.PI);
          const p2 = project(x2, y, z2);

          // Connecting hydrogen bond rung
          ctx.strokeStyle = "rgba(148, 163, 184, 0.4)";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();

          // Strand 1 node (Adenine / Thymine)
          ctx.fillStyle = "#38bdf8";
          ctx.beginPath();
          ctx.arc(p1.x, p1.y, 4.5 * p1.scale, 0, Math.PI * 2);
          ctx.fill();

          // Strand 2 node (Cytosine / Guanine)
          ctx.fillStyle = "#f43f5e";
          ctx.beginPath();
          ctx.arc(p2.x, p2.y, 4.5 * p2.scale, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 6. 3D HOLOGRAM / MOLECULE
      else {
        // Molecule with central atom and orbiting electrons
        const centerGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, 20);
        centerGrad.addColorStop(0, "#fbbf24");
        centerGrad.addColorStop(1, "#d97706");
        ctx.fillStyle = centerGrad;
        ctx.beginPath();
        ctx.arc(cx, cy, 16, 0, Math.PI * 2);
        ctx.fill();

        for (let orbit = 0; orbit < 3; orbit++) {
          const tilt = (orbit * Math.PI) / 3;
          ctx.strokeStyle = "rgba(56, 189, 248, 0.5)";
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          for (let step = 0; step <= 32; step++) {
            const angle = (step / 32) * Math.PI * 2;
            const ox = baseRadius * 0.9 * Math.cos(angle);
            const oz = baseRadius * 0.9 * Math.sin(angle);
            // Tilt around Z
            const tx = ox * Math.cos(tilt) - oz * Math.sin(tilt);
            const tz = ox * Math.sin(tilt) + oz * Math.cos(tilt);
            const p = project(tx, 0, tz);
            if (step === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
          }
          ctx.stroke();

          // Electron
          const eAngle = time * (1.5 + orbit * 0.4);
          const ox = baseRadius * 0.9 * Math.cos(eAngle);
          const oz = baseRadius * 0.9 * Math.sin(eAngle);
          const tx = ox * Math.cos(tilt) - oz * Math.sin(tilt);
          const tz = ox * Math.sin(tilt) + oz * Math.cos(tilt);
          const ep = project(tx, 0, tz);

          ctx.fillStyle = "#38bdf8";
          ctx.shadowColor = "#38bdf8";
          ctx.shadowBlur = 8;
          ctx.beginPath();
          ctx.arc(ep.x, ep.y, 4, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animId);
    };
  }, [modelType, isRotating, wireframe, zoom, autoRotateSpeed, height]);

  // Touch and Mouse Handlers for 360 Rotation
  const handlePointerDown = (e: React.PointerEvent) => {
    isDraggingRef.current = true;
    lastMouseRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastMouseRef.current.x;
    const dy = e.clientY - lastMouseRef.current.y;

    rotRef.current.y += dx * 0.01;
    rotRef.current.x += dy * 0.01;

    lastMouseRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  return (
    <div 
      ref={containerRef}
      className="relative my-6 rounded-2xl overflow-hidden border border-slate-700/80 bg-slate-950 shadow-xl select-none group"
    >
      {/* 3D Canvas */}
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className="w-full cursor-grab active:cursor-grabbing block touch-none"
        style={{ height: `${height}px` }}
      />

      {/* Top Header Badge */}
      <div className="absolute top-3 left-3 flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700 text-xs font-semibold text-sky-400">
        <Sparkles className="w-3.5 h-3.5 animate-pulse text-amber-400" />
        <span>{title || (lang === "bn" ? "৩ডি ইন্টারেক্টিভ মডেল" : "3D Interactive Animation")}</span>
        <span className="text-[10px] text-slate-400 font-mono uppercase bg-slate-800 px-1.5 py-0.5 rounded">
          {modelType}
        </span>
      </div>

      {/* Top Right 3D Model Switcher */}
      <div className="absolute top-3 right-3 flex items-center gap-1 bg-slate-900/80 backdrop-blur-md p-1 rounded-xl border border-slate-700">
        {(["earth", "solar_system", "galaxy", "cube", "dna", "molecule"] as Model3DType[]).map((m) => (
          <button
            key={m}
            type="button"
            onClick={() => setModelType(m)}
            className={`px-2 py-1 text-[10px] rounded-lg font-medium transition-all ${
              modelType === m 
                ? "bg-sky-600 text-white shadow-xs" 
                : "text-slate-400 hover:text-white hover:bg-slate-800"
            }`}
          >
            {m === "earth" ? "🌍 Earth" : m === "solar_system" ? "🪐 Solar" : m === "galaxy" ? "🌌 Galaxy" : m === "cube" ? "🧊 Cube" : m === "dna" ? "🧬 DNA" : "⚛️ Atom"}
          </button>
        ))}
      </div>

      {/* Bottom Interactive Floating Control Bar */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700 shadow-lg text-slate-300">
        {/* Play/Pause Rotation */}
        <button
          type="button"
          onClick={() => setIsRotating(!isRotating)}
          title={isRotating ? "Pause Auto-Rotation" : "Start Auto-Rotation"}
          className="p-1.5 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
        >
          {isRotating ? <Pause className="w-3.5 h-3.5 text-amber-400" /> : <Play className="w-3.5 h-3.5 text-emerald-400" />}
        </button>

        {/* Reset Angle */}
        <button
          type="button"
          onClick={() => { rotRef.current = { x: 0.3, y: 0.5 }; }}
          title="Reset 3D Angle"
          className="p-1.5 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
        >
          <RotateCw className="w-3.5 h-3.5" />
        </button>

        {/* Wireframe Toggle */}
        <button
          type="button"
          onClick={() => setWireframe(!wireframe)}
          title="Toggle 3D Wireframe"
          className={`p-1.5 rounded-full transition-colors ${wireframe ? "text-sky-400 bg-sky-950/60" : "hover:text-white hover:bg-slate-800"}`}
        >
          <Layers className="w-3.5 h-3.5" />
        </button>

        {/* Zoom Controls */}
        <button
          type="button"
          onClick={() => setZoom(prev => Math.min(prev + 0.15, 1.8))}
          title="Zoom In"
          className="p-1.5 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>

        <button
          type="button"
          onClick={() => setZoom(prev => Math.max(prev - 0.15, 0.6))}
          title="Zoom Out"
          className="p-1.5 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Interaction Hint */}
      <div className="absolute bottom-3 left-3 text-[10px] text-slate-500 pointer-events-none hidden sm:block">
        👆 {lang === "bn" ? "৩৬০° ঘুরাতে স্পর্শ বা ড্র্যাগ করুন" : "Touch & drag to rotate in 360°"}
      </div>
    </div>
  );
};
