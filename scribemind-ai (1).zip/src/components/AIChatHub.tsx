import React, { useState, useRef, useEffect } from "react";
import { 
  Send, Bot, User, Sparkles, Trash2, Download, Copy, Check, 
  Volume2, VolumeX, Paperclip, RefreshCw, Feather, Code2, 
  BookOpen, Compass, HeartHandshake, Zap, MessageSquare,
  Image as ImageIcon, Sliders
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Markdown from "react-markdown";
import { AmbientChatAnimation, AmbientAnimationType } from "./AmbientChatAnimation";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  persona?: string;
}

interface AIChatHubProps {
  lang: "bn" | "en";
  currentUser: any;
  modelProvider?: string;
  customGeminiKey?: string;
  customDeepseekKey?: string;
}

export const AIChatHub: React.FC<AIChatHubProps> = ({
  lang,
  currentUser,
  modelProvider = "gemini",
  customGeminiKey,
  customDeepseekKey,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem("lekhok_ai_chat_hub_messages");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      {
        id: "init_1",
        role: "assistant",
        content: lang === "bn" 
          ? "নমস্কার! আমি ওমর ফারুক মাসউদের তৈরি লেখনী এআই আনলিমিটেড চ্যাট সহকারী। আপনি যেকোনো বিষয়ে উপন্যাস, গল্প, বিজ্ঞান, কোডিং, ইতিহাস বা ব্যক্তিগত বিষয়ে কথা বলতে পারেন।"
          : "Hello! I am Lekhok AI Unlimited Chat Assistant created by Omar Faruk Masud. You can chat about novels, stories, science, coding, history, or daily life.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        persona: "assistant"
      }
    ];
  });

  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activePersona, setActivePersona] = useState<"assistant" | "storyteller" | "coder" | "scholar" | "companion">("assistant");
  const [attachedFile, setAttachedFile] = useState<{ name: string; type: string; mimeType: string; dataBase64: string } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  // Background and Ambient Animation state
  const [ambientFx, setAmbientFx] = useState<AmbientAnimationType>(() => {
    return (localStorage.getItem("lekhok_hub_ambient_fx") as AmbientAnimationType) || "golden_sparkles";
  });
  const [chatWallpaper, setChatWallpaper] = useState<string>(() => {
    return localStorage.getItem("lekhok_hub_chat_wallpaper") || "";
  });
  const [showFxMenu, setShowFxMenu] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    localStorage.setItem("lekhok_ai_chat_hub_messages", JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem("lekhok_hub_ambient_fx", ambientFx);
  }, [ambientFx]);

  useEffect(() => {
    localStorage.setItem("lekhok_hub_chat_wallpaper", chatWallpaper);
  }, [chatWallpaper]);

  const personas = [
    { id: "assistant", name: lang === "bn" ? "মাস্টার সহকারী" : "Master Assistant", icon: Sparkles, desc: lang === "bn" ? "সব বিষয়ের পারদর্শী" : "General Purpose" },
    { id: "storyteller", name: lang === "bn" ? "ঔপন্যাসিক ও কবি" : "Storyteller", icon: Feather, desc: lang === "bn" ? "কল্পকাহিনী ও সাহিত্য" : "Novels & Fiction" },
    { id: "coder", name: lang === "bn" ? "সফটওয়্যার আর্কিটেক্ট" : "Code Engineer", icon: Code2, desc: lang === "bn" ? "প্রোগ্রামিং ও লজিক" : "Full-Stack Dev" },
    { id: "scholar", name: lang === "bn" ? "গবেষক ও বিজ্ঞানী" : "Research Scholar", icon: BookOpen, desc: lang === "bn" ? "তথ্যভিত্তিক বিশ্লেষণ" : "Academic Facts" },
    { id: "companion", name: lang === "bn" ? "বন্ধু ও সাথী" : "Friendly Buddy", icon: HeartHandshake, desc: lang === "bn" ? "খোলামেলা আড্ডা" : "Warm Conversation" },
  ];

  const starterPrompts = [
    lang === "bn" ? "একটি রহস্যময় টাইম ট্রাভেলের রোমাঞ্চকর গল্পের সূচনা লিখুন।" : "Write an opening chapter for a mysterious time-travel sci-fi thriller.",
    lang === "bn" ? "মহাবিশ্বের ব্ল্যাক হোলের ভেতরের রহস্য সহজভাবে বুঝিয়ে বলুন।" : "Explain what happens inside a black hole in vivid, simple terms.",
    lang === "bn" ? "একটি রেসপনসিভ ক্যালকুলেটর অ্যাপের পূর্ণাঙ্গ কোড লিখুন।" : "Write full clean JavaScript code for a modern calculator widget.",
    lang === "bn" ? "মানসিক চাপ কমাতে কিছু কার্যকরী মেডিটেশন কৌশল বলুন।" : "Suggest top mindfulness and calm breathing techniques for focus.",
  ];

  const handleSendMessage = async (customText?: string) => {
    const textToSend = (customText || inputMessage).trim();
    if (!textToSend && !attachedFile) return;

    const userMsg: ChatMessage = {
      id: "user_" + Date.now(),
      role: "user",
      content: textToSend || (lang === "bn" ? "[ফাইল যুক্ত করা হয়েছে]" : "[Attached File]"),
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      persona: activePersona
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage("");
    const currentAttachment = attachedFile;
    setAttachedFile(null);
    setIsLoading(true);

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (modelProvider) headers["x-model-provider"] = modelProvider;
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const res = await fetch("/api/ai-chat", {
        method: "POST",
        headers,
        body: JSON.stringify({
          messages: [...messages, userMsg],
          userMessage: textToSend,
          persona: activePersona,
          language: lang === "bn" ? "Bengali" : "English",
          attachment: currentAttachment
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned error ${res.status}`);
      }

      const data = await res.json();
      const botMsg: ChatMessage = {
        id: "ai_" + Date.now(),
        role: "assistant",
        content: data.reply || (lang === "bn" ? "কোনো উত্তর পাওয়া যায়নি।" : "No response content received."),
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        persona: activePersona
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (err: any) {
      console.error("AI Chat send error:", err);
      const errorMsg: ChatMessage = {
        id: "ai_err_" + Date.now(),
        role: "assistant",
        content: lang === "bn" 
          ? `⚠️ বার্তা প্রক্রিয়াকরণে সমস্যা হয়েছে: ${err.message || "দয়া করে আবার চেষ্টা করুন।"}`
          : `⚠️ Failed to generate chat response: ${err.message || "Please try again."}`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        persona: activePersona
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setAttachedFile({
        name: file.name,
        type: file.type.startsWith("image/") ? "image" : "document",
        mimeType: file.type || "application/octet-stream",
        dataBase64: event.target?.result as string
      });
    };
    reader.readAsDataURL(file);
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeakText = (id: string, text: string) => {
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[#*`_~\[\]]/g, "");
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    
    // detect Bengali vs English voice
    const voices = window.speechSynthesis.getVoices();
    const isBn = /[\u0980-\u09FF]/.test(cleanText);
    const matchedVoice = voices.find(v => isBn ? (v.lang.includes("bn") || v.lang.includes("BD") || v.lang.includes("IN")) : (v.lang.includes("en-US") || v.lang.includes("en-GB")));
    if (matchedVoice) utterance.voice = matchedVoice;

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: "init_new_" + Date.now(),
        role: "assistant",
        content: lang === "bn" ? "নতুন চ্যাট শুরু হয়েছে। আপনি কী জানতে বা লিখতে চান?" : "New chat conversation started. What would you like to discuss?",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        persona: activePersona
      }
    ]);
  };

  const handleExportChat = () => {
    const textContent = messages.map(m => `### ${m.role === "user" ? "User" : "Lekhok AI"} [${m.timestamp}]\n${m.content}\n`).join("\n---\n\n");
    const blob = new Blob([textContent], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Lekhok_AI_Chat_Transcript_${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 w-full max-w-6xl mx-auto flex flex-col h-[calc(100vh-4rem)] p-3 sm:p-5 font-sans text-left">
      
      {/* Top Header & Persona Bar */}
      <div className="bg-white border border-amber-200/80 rounded-3xl p-4 shadow-xs mb-3 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#7c2d12] to-amber-600 flex items-center justify-center text-white shadow-md">
              <MessageSquare size={20} />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-1.5">
                <span>{lang === "bn" ? "আনলিমিটেড এআই চ্যাট হাব" : "Unlimited AI Chat Hub"}</span>
                <span className="text-[10px] font-black uppercase tracking-wider bg-amber-100 text-amber-950 px-2 py-0.5 rounded-full border border-amber-300">
                  Unlimited
                </span>
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">
                {lang === "bn" ? "সীমাহীন বার্তা, গল্প লিখন, কোডিং সহায়তা ও প্রশ্নোত্তরের পূর্ণ স্বাধীনতা" : "Unrestricted conversational AI for novels, coding, research & daily chats"}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            {/* Ambient FX & Wallpaper toggle */}
            <div className="relative">
              <button
                onClick={() => setShowFxMenu(!showFxMenu)}
                className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300/80 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
                title={lang === "bn" ? "অ্যানিমেশন ও ব্যাকগ্রাউন্ড ইফেক্টস" : "Ambient Animation & Wallpaper"}
              >
                <Sparkles size={13} className="text-amber-600 animate-pulse" />
                <span className="hidden sm:inline">{lang === "bn" ? "অ্যানিমেশন" : "Visual FX"}</span>
              </button>

              <AnimatePresence>
                {showFxMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 top-full mt-2 w-64 bg-white border border-amber-300 rounded-2xl p-3 shadow-xl z-50 space-y-2.5 font-sans"
                  >
                    <div className="flex items-center justify-between border-b border-amber-100 pb-1.5">
                      <span className="text-[11px] font-black text-slate-800">
                        {lang === "bn" ? "লাইভ ক্যানভাস অ্যানিমেশন" : "Ambient Particle FX"}
                      </span>
                      <button
                        onClick={() => setShowFxMenu(false)}
                        className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                      >
                        ✕
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-1.5">
                      {[
                        { id: "golden_sparkles", label: "✨ Golden Dust" },
                        { id: "stars", label: "🌌 Starlight" },
                        { id: "matrix_cyber", label: "⚡ Cyber Matrix" },
                        { id: "zen_ripples", label: "🌊 Zen Waves" },
                        { id: "aurora_waves", label: "🌈 Aurora Glow" },
                        { id: "none", label: "🚫 None" },
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => setAmbientFx(item.id as AmbientAnimationType)}
                          className={`px-2 py-1.5 rounded-xl text-[10px] font-bold text-left transition border ${
                            ambientFx === item.id 
                              ? "bg-[#7c2d12] text-white border-[#7c2d12] shadow-xs"
                              : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200"
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>

                    <div className="border-t border-amber-100 pt-2 space-y-1">
                      <span className="text-[10px] font-bold text-slate-600 block">
                        {lang === "bn" ? "ব্যাকগ্রাউন্ড ইমেজ লিঙ্ক" : "Custom Wallpaper Image URL"}
                      </span>
                      <div className="flex gap-1">
                        <input
                          type="text"
                          value={chatWallpaper}
                          onChange={(e) => setChatWallpaper(e.target.value)}
                          placeholder="https://images.unsplash.com/..."
                          className="flex-1 text-[10px] px-2 py-1 border border-slate-200 rounded-lg focus:outline-none"
                        />
                        {chatWallpaper && (
                          <button
                            onClick={() => setChatWallpaper("")}
                            className="text-[10px] px-2 bg-slate-100 text-slate-500 rounded-lg hover:bg-slate-200"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <button
              onClick={handleExportChat}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
              title={lang === "bn" ? "চ্যাট এক্সপোর্ট করুন" : "Export Chat"}
            >
              <Download size={13} />
              <span className="hidden sm:inline">{lang === "bn" ? "এক্সপোর্ট" : "Export"}</span>
            </button>

            <button
              onClick={handleClearHistory}
              className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200/60 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
              title={lang === "bn" ? "চ্যাট ক্লিয়ার করুন" : "Clear Chat"}
            >
              <Trash2 size={13} />
              <span className="hidden sm:inline">{lang === "bn" ? "ক্লিয়ার" : "Clear"}</span>
            </button>
          </div>
        </div>

        {/* Persona Selectors */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none pt-1">
          {personas.map((p) => {
            const Icon = p.icon;
            const isSelected = activePersona === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setActivePersona(p.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-extrabold whitespace-nowrap transition cursor-pointer shrink-0 border ${
                  isSelected 
                    ? "bg-[#7c2d12] text-amber-50 border-[#7c2d12] shadow-md scale-102"
                    : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200/80"
                }`}
              >
                <Icon size={14} className={isSelected ? "text-amber-300" : "text-[#7c2d12]"} />
                <span>{p.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Messages Scroll Area with Dynamic Live Background and Ambient Particles */}
      <div 
        className="flex-1 bg-white/80 backdrop-blur-xs border border-amber-200/70 rounded-3xl p-4 sm:p-6 overflow-y-auto space-y-4 shadow-inner relative overflow-hidden"
        style={chatWallpaper && chatWallpaper.trim() !== "" ? {
          backgroundImage: `url(${chatWallpaper})`,
          backgroundSize: "cover",
          backgroundPosition: "center"
        } : undefined}
      >
        {/* Ambient Live Canvas Overlay */}
        <AmbientChatAnimation type={ambientFx} opacity={0.6} />

        {/* Backdrop tint layer if wallpaper is set to ensure 100% text readability */}
        {chatWallpaper && chatWallpaper.trim() !== "" && (
          <div className="absolute inset-0 bg-white/70 backdrop-blur-[2px] pointer-events-none z-0" />
        )}

        <div className="relative z-10 space-y-4">
        {messages.map((m) => {
          const isUser = m.role === "user";
          return (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${isUser ? "flex-row-reverse" : "flex-row"}`}
            >
              {/* Avatar Icon */}
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-sm ${
                isUser 
                  ? "bg-slate-900 text-white"
                  : "bg-gradient-to-tr from-[#7c2d12] to-amber-700 text-amber-100"
              }`}>
                {isUser ? <User size={15} /> : <Bot size={16} />}
              </div>

              {/* Message Bubble */}
              <div className={`max-w-[85%] sm:max-w-[78%] rounded-3xl px-5 py-4 space-y-2 shadow-xs ${
                isUser
                  ? "bg-gradient-to-br from-[#7c2d12] to-[#63220c] text-white rounded-tr-xs"
                  : "bg-white border border-amber-200/80 text-slate-900 rounded-tl-xs"
              }`}>
                {/* Meta info & actions */}
                <div className={`flex items-center justify-between text-[10px] pb-1 border-b ${
                  isUser ? "border-white/20 text-amber-200" : "border-slate-100 text-slate-400"
                }`}>
                  <span className="font-bold">
                    {isUser ? (currentUser?.displayName || "You") : "Lekhok AI"}
                  </span>
                  <div className="flex items-center gap-2">
                    <span>{m.timestamp}</span>
                    <button
                      onClick={() => handleCopyText(m.id, m.content)}
                      className="p-1 hover:opacity-100 opacity-70 transition cursor-pointer"
                      title="Copy text"
                    >
                      {copiedId === m.id ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
                    </button>
                    {!isUser && (
                      <button
                        onClick={() => handleSpeakText(m.id, m.content)}
                        className={`p-1 hover:opacity-100 transition cursor-pointer ${speakingId === m.id ? "text-amber-500 font-bold" : "opacity-70"}`}
                        title="Listen to voice audio"
                      >
                        {speakingId === m.id ? <VolumeX size={11} /> : <Volume2 size={11} />}
                      </button>
                    )}
                  </div>
                </div>

                {/* Markdown content */}
                <div className={`prose prose-sm max-w-none text-xs sm:text-sm leading-relaxed ${
                  isUser ? "text-white prose-invert" : "text-slate-800"
                }`}>
                  <Markdown>{m.content}</Markdown>
                </div>
              </div>
            </motion.div>
          );
        })}

        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex gap-3"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#7c2d12] to-amber-700 text-amber-100 flex items-center justify-center shrink-0">
              <Bot size={16} />
            </div>
            <div className="bg-white border border-amber-200/80 rounded-3xl rounded-tl-xs px-5 py-4 shadow-xs flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#7c2d12] animate-ping" />
              <span className="text-xs font-bold text-slate-500">
                {lang === "bn" ? "লেখক এআই চিন্তা করছে..." : "Lekhok AI is writing..."}
              </span>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Suggested Starters when conversation is short */}
      {messages.length <= 2 && (
        <div className="my-2 flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {starterPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p)}
              className="text-[11px] font-medium bg-amber-50/80 hover:bg-amber-100 border border-amber-200/60 text-[#7c2d12] px-3 py-1.5 rounded-xl whitespace-nowrap transition cursor-pointer shrink-0 shadow-2xs"
            >
              ✨ {p}
            </button>
          ))}
        </div>
      )}

      {/* Attachment Preview Chip */}
      {attachedFile && (
        <div className="bg-amber-100 border border-amber-300 px-3 py-1.5 rounded-xl text-xs flex items-center justify-between text-[#7c2d12] font-bold mt-2">
          <span className="truncate">📎 {attachedFile.name}</span>
          <button
            onClick={() => setAttachedFile(null)}
            className="text-rose-600 hover:text-rose-800 ml-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Input Box Bar */}
      <div className="bg-white border-2 border-amber-300 rounded-3xl p-2.5 shadow-md mt-2 flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,text/*,.pdf,.doc,.docx,.txt,.md,.json"
          onChange={handleFileUpload}
          className="hidden"
        />

        <button
          onClick={() => fileInputRef.current?.click()}
          className="p-2.5 bg-amber-50 hover:bg-amber-100 text-[#7c2d12] rounded-2xl transition cursor-pointer"
          title={lang === "bn" ? "ফাইল যুক্ত করুন" : "Attach File"}
        >
          <Paperclip size={18} />
        </button>

        <textarea
          rows={1}
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSendMessage();
            }
          }}
          placeholder={lang === "bn" ? "যেকোনো কিছু লিখুন বা প্রশ্ন করুন (সীমাহীন কথোপকথন)..." : "Ask anything or write stories (unlimited turns)..."}
          className="flex-1 resize-none bg-transparent text-xs sm:text-sm font-medium text-slate-900 focus:outline-none px-2 max-h-32"
        />

        <button
          onClick={() => handleSendMessage()}
          disabled={isLoading || (!inputMessage.trim() && !attachedFile)}
          className="p-3 bg-[#7c2d12] hover:bg-[#63220c] disabled:opacity-40 text-white rounded-2xl font-bold transition flex items-center justify-center shadow-md cursor-pointer"
        >
          <Send size={16} />
        </button>
      </div>

    </div>
  );
};
