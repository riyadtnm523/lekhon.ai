import React, { useState, useEffect, useRef } from "react";
import {
  Mic, MicOff, Volume2, VolumeX, Sparkles, Languages, RefreshCw,
  Copy, Check, Send, Play, Pause, BookOpen, Zap, AlertCircle,
  ChevronRight, Trash2, Radio, Globe, Layers, CornerDownLeft, Award,
  Cpu, Sliders, ShieldCheck, Headphones
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { globalAudioPlayer, unlockAudioAutoplay } from "../utils/audioPlayer";

interface ProVoiceAssistantProps {
  lang: "bn" | "en";
  currentUser?: any;
  currentBookTitle?: string;
  modelProvider?: "gemini" | "deepseek";
  customGeminiKey?: string;
  customDeepseekKey?: string;
  onInsertToBook?: (text: string) => void;
}

interface VoiceLog {
  id: string;
  speaker: "user" | "assistant";
  text: string;
  translatedText?: string;
  suggestions?: string[];
  persona?: string;
  language?: string;
  timestamp: string;
}

const SUPPORTED_LANGUAGES = [
  { code: "bn-BD", name: "বাংলা (Bengali)", flag: "🇧🇩", short: "Bengali" },
  { code: "en-US", name: "English (US)", flag: "🇺🇸", short: "English" },
  { code: "en-GB", name: "English (UK - JARVIS)", flag: "🇬🇧", short: "English UK" },
  { code: "ar-SA", name: "العربية (Arabic)", flag: "🇸🇦", short: "Arabic" },
  { code: "hi-IN", name: "हिन्दी (Hindi)", flag: "🇮🇳", short: "Hindi" },
  { code: "ur-PK", name: "اردو (Urdu)", flag: "🇵🇰", short: "Urdu" },
  { code: "es-ES", name: "Español (Spanish)", flag: "🇪🇸", short: "Spanish" },
  { code: "fr-FR", name: "Français (French)", flag: "🇫🇷", short: "French" },
  { code: "de-DE", name: "Deutsch (German)", flag: "🇩🇪", short: "German" },
  { code: "ja-JP", name: "日本語 (Japanese)", flag: "🇯🇵", short: "Japanese" },
  { code: "ko-KR", name: "한국어 (Korean)", flag: "🇰🇷", short: "Korean" },
  { code: "zh-CN", name: "中文 (Chinese)", flag: "🇨🇳", short: "Chinese" },
  { code: "tr-TR", name: "Türkçe (Turkish)", flag: "🇹🇷", short: "Turkish" }
];

const PERSONA_MODES = [
  {
    id: "jarvis",
    icon: "🤖",
    nameBn: "J.A.R.V.I.S. (Iron Man AI)",
    nameEn: "J.A.R.V.I.S. (Iron Man AI)",
    descBn: "টনি স্টার্কের সার্বক্ষণিক লাইভ ভয়েস সহকারী — স্বয়ংক্রিয় কথোপকথন ও দ্রুত বাস্তবসম্মত ভয়েস উত্তর",
    descEn: "Tony Stark's legendary AI — hands-free continuous real voice responses"
  },
  {
    id: "translator",
    icon: "🌐",
    nameBn: "দ্বি-ভাষিক অনুবাদক",
    nameEn: "Live Translator",
    descBn: "বাংলা এবং যেকোনো আন্তর্জাতিক ভাষার মধ্যে সরাসরি রিয়েল-টাইম অনুবাদ ও কণ্ঠস্বর রূপান্তর",
    descEn: "Seamless live speech translation between Bengali and 25+ global languages"
  },
  {
    id: "author_muse",
    icon: "✍️",
    nameBn: "লেখকের গল্পকার মিউজ",
    nameEn: "Storyteller Muse",
    descBn: "উপন্যাস ও গল্পের প্লট, রোমাঞ্চকর ক্লাইম্যাক্স ও জীবন্ত সংলাপ উদ্ভাবন",
    descEn: "Evocative plot arcs, dramatic dialogue generation & scene building"
  },
  {
    id: "critic",
    icon: "🧐",
    nameBn: "সাহিত্য সমালোচক ও এডিটর",
    nameEn: "Literary Critic",
    descBn: "পাণ্ডুলিপির ভাষা, চরিত্র বিশ্লেষণ এবং সাহিত্যের গভীর উৎকর্ষতা প্রদান",
    descEn: "Critical literary analysis, character motives & narrative polishing"
  }
];

const QUICK_STARTERS = [
  { bn: "হ্যালো জার্ভিস, আমার আজকের লেখার জন্য একটি শক্তিশালী আইডিয়া দাও।", en: "Hello JARVIS, give me a powerful concept for today's writing." },
  { bn: "আমার উপন্যাসের জন্য একটি অপ্রত্যাশিত প্লট টুইস্ট তৈরি করো।", en: "Create an unexpected, high-stakes plot twist for my novel." },
  { bn: "এই সংলাপটি আরও স্বাভাবিক ও তীক্ষ্ণ ভঙ্গিতে রূপান্তর করো।", en: "Make this dialogue sharper and more cinematic." },
  { bn: "একটি রহস্যময় ও সাসপেন্সপূর্ণ দৃশ্যের সূচনা কীভাবে লিখবো?", en: "How should I craft an opening for a suspenseful mystery scene?" }
];

export const ProVoiceAssistant: React.FC<ProVoiceAssistantProps> = ({
  lang,
  currentUser,
  currentBookTitle,
  modelProvider,
  customGeminiKey,
  customDeepseekKey,
  onInsertToBook
}) => {
  // Voice engine & Auto-detect States
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isHandsFreeMode, setIsHandsFreeMode] = useState<boolean>(true);
  const [silenceDelaySeconds, setSilenceDelaySeconds] = useState<number>(1.1);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [activePersona, setActivePersona] = useState<"jarvis" | "translator" | "author_muse" | "critic">("jarvis");
  const [inputLang, setInputLang] = useState<string>("bn-BD");
  const [targetTranslateLang, setTargetTranslateLang] = useState<string>("en-US");
  
  // Real-time live transcript display
  const [liveTranscript, setLiveTranscript] = useState("");
  const [typedInput, setTypedInput] = useState("");
  const [logs, setLogs] = useState<VoiceLog[]>([]);
  const [audioLevel, setAudioLevel] = useState<number>(0);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [insertedId, setInsertedId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successAudioTest, setSuccessAudioTest] = useState(false);

  // References
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const timerIntervalRef = useRef<any>(null);
  const recognitionRef = useRef<any>(null);
  const accumulatedSpeechRef = useRef<string>("");
  const isManuallyStoppedRef = useRef<boolean>(false);
  const silenceTimerRef = useRef<any>(null);
  const canvas3dRef = useRef<HTMLCanvasElement | null>(null);
  const isHandsFreeRef = useRef<boolean>(true);
  const isProcessingRef = useRef<boolean>(false);
  const isSpeakingRef = useRef<boolean>(false);
  const isRecordingRef = useRef<boolean>(false);
  const hasSpokenAudioRef = useRef<boolean>(false);
  const lastAudioSpokeTimeRef = useRef<number>(0);

  useEffect(() => {
    isHandsFreeRef.current = isHandsFreeMode;
  }, [isHandsFreeMode]);

  useEffect(() => {
    isProcessingRef.current = isProcessing;
  }, [isProcessing]);

  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  useEffect(() => {
    isHandsFreeRef.current = isHandsFreeMode;
  }, [isHandsFreeMode]);

  useEffect(() => {
    isProcessingRef.current = isProcessing;
  }, [isProcessing]);

  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isManuallyStoppedRef.current = true;
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      stopRecordingAndVisualizer();
      if (recognitionRef.current) {
        try { recognitionRef.current.abort(); } catch (e) {}
      }
      globalAudioPlayer.stop();
    };
  }, []);

  // 3D Arc Reactor Hologram Canvas Engine
  useEffect(() => {
    let animationId: number;
    const canvas = canvas3dRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let angle = 0;
    const particles: { x: number; y: number; z: number; size: number; speed: number; baseAngle: number; color: string }[] = [];
    const numParticles = 54;

    for (let i = 0; i < numParticles; i++) {
      particles.push({
        x: 0,
        y: 0,
        z: (Math.random() - 0.5) * 140,
        size: Math.random() * 2.8 + 1.2,
        speed: 0.018 + Math.random() * 0.02,
        baseAngle: (i / numParticles) * Math.PI * 2,
        color: i % 2 === 0 ? "#38bdf8" : (i % 3 === 0 ? "#f59e0b" : "#ec4899")
      });
    }

    const render3DArcReactor = () => {
      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;

      ctx.clearRect(0, 0, width, height);
      angle += 0.025;

      const dynamicRadius = isRecording 
        ? 52 + (audioLevel * 0.45) 
        : isSpeaking 
        ? 50 + Math.sin(angle * 5) * 9 
        : isProcessing
        ? 48 + Math.sin(angle * 8) * 6
        : 45 + Math.sin(angle) * 3;

      // 1. Background Arc Glow Aura
      const bgGlow = ctx.createRadialGradient(centerX, centerY, 12, centerX, centerY, dynamicRadius * 1.7);
      if (isRecording) {
        bgGlow.addColorStop(0, "rgba(244, 63, 94, 0.5)");
        bgGlow.addColorStop(0.5, "rgba(245, 158, 11, 0.25)");
        bgGlow.addColorStop(1, "rgba(0, 0, 0, 0)");
      } else if (isProcessing) {
        bgGlow.addColorStop(0, "rgba(245, 158, 11, 0.5)");
        bgGlow.addColorStop(0.5, "rgba(56, 189, 248, 0.3)");
        bgGlow.addColorStop(1, "rgba(0, 0, 0, 0)");
      } else if (isSpeaking) {
        bgGlow.addColorStop(0, "rgba(56, 189, 248, 0.5)");
        bgGlow.addColorStop(0.5, "rgba(129, 140, 248, 0.25)");
        bgGlow.addColorStop(1, "rgba(0, 0, 0, 0)");
      } else {
        bgGlow.addColorStop(0, "rgba(56, 189, 248, 0.22)");
        bgGlow.addColorStop(0.6, "rgba(30, 58, 138, 0.1)");
        bgGlow.addColorStop(1, "rgba(0, 0, 0, 0)");
      }
      ctx.fillStyle = bgGlow;
      ctx.beginPath();
      ctx.arc(centerX, centerY, dynamicRadius * 1.7, 0, Math.PI * 2);
      ctx.fill();

      // 2. 3D Orbiting Arc Reactor Rings
      const draw3DRing = (tiltX: number, tiltY: number, radiusScale: number, strokeColor: string) => {
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = isRecording || isSpeaking ? 2.5 : 1.6;
        ctx.beginPath();

        const steps = 48;
        for (let i = 0; i <= steps; i++) {
          const theta = (i / steps) * Math.PI * 2 + angle * tiltX;
          const r = dynamicRadius * radiusScale;
          const px = Math.cos(theta) * r;
          const py = Math.sin(theta) * r * Math.cos(tiltY);
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.stroke();
        ctx.restore();
      };

      if (isRecording) {
        draw3DRing(1.4, 0.7, 1.25, "rgba(244, 63, 94, 0.75)");
        draw3DRing(-1.2, 0.5, 1.45, "rgba(245, 158, 11, 0.75)");
      } else if (isProcessing) {
        draw3DRing(2.0, 0.6, 1.35, "rgba(245, 158, 11, 0.8)");
        draw3DRing(-2.0, 0.8, 1.5, "rgba(56, 189, 248, 0.8)");
      } else if (isSpeaking) {
        draw3DRing(1.2, 0.6, 1.3, "rgba(56, 189, 248, 0.75)");
        draw3DRing(-1.1, 0.8, 1.48, "rgba(129, 140, 248, 0.75)");
      } else {
        draw3DRing(0.6, 0.6, 1.22, "rgba(56, 189, 248, 0.45)");
        draw3DRing(-0.6, 0.7, 1.38, "rgba(245, 158, 11, 0.35)");
      }

      // 3. Orbiting HUD Particles
      particles.forEach((p) => {
        const curAngle = p.baseAngle + angle * (isRecording ? 1.8 : 0.9);
        const radius = dynamicRadius * 1.38;
        const px = centerX + Math.cos(curAngle) * radius;
        const py = centerY + Math.sin(curAngle) * radius * 0.48 + Math.sin(angle * 2.5 + p.z) * 14;

        ctx.fillStyle = isRecording ? "#fca5a5" : isProcessing ? "#fde047" : isSpeaking ? "#7dd3fc" : p.color;
        ctx.beginPath();
        ctx.arc(px, py, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      // 4. Core Arc Reactor Shaded Sphere (Iron Man Unibeam look)
      const sphereGrad = ctx.createRadialGradient(
        centerX - dynamicRadius * 0.3,
        centerY - dynamicRadius * 0.3,
        dynamicRadius * 0.08,
        centerX,
        centerY,
        dynamicRadius
      );

      if (isRecording) {
        sphereGrad.addColorStop(0, "#fff1f2");
        sphereGrad.addColorStop(0.3, "#f43f5e");
        sphereGrad.addColorStop(0.7, "#be123c");
        sphereGrad.addColorStop(1, "#4c0519");
      } else if (isProcessing) {
        sphereGrad.addColorStop(0, "#fef08a");
        sphereGrad.addColorStop(0.3, "#eab308");
        sphereGrad.addColorStop(0.7, "#ca8a04");
        sphereGrad.addColorStop(1, "#422006");
      } else if (isSpeaking) {
        sphereGrad.addColorStop(0, "#f0f9ff");
        sphereGrad.addColorStop(0.3, "#38bdf8");
        sphereGrad.addColorStop(0.7, "#2563eb");
        sphereGrad.addColorStop(1, "#0f172a");
      } else {
        sphereGrad.addColorStop(0, "#e0f2fe");
        sphereGrad.addColorStop(0.3, "#0284c7");
        sphereGrad.addColorStop(0.7, "#0369a1");
        sphereGrad.addColorStop(1, "#082f49");
      }

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, dynamicRadius, 0, Math.PI * 2);
      ctx.fill();

      // Inner Core Arc Highlight
      ctx.strokeStyle = "rgba(255, 255, 255, 0.6)";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.arc(centerX, centerY, dynamicRadius - 1.5, 0, Math.PI * 2);
      ctx.stroke();

      animationId = requestAnimationFrame(render3DArcReactor);
    };

    render3DArcReactor();
    return () => cancelAnimationFrame(animationId);
  }, [isRecording, isSpeaking, isProcessing, audioLevel]);

  // Audio Stream & Microphone Hook
  const initAudioStream = async () => {
    try {
      unlockAudioAutoplay();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      audioStreamRef.current = stream;

      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioCtx;
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 128;
      analyserRef.current = analyser;

      const source = audioCtx.createMediaStreamSource(stream);
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const checkLevel = () => {
        if (analyserRef.current) {
          analyserRef.current.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const avg = sum / dataArray.length;
          const level = Math.min(100, Math.round((avg / 128) * 100));
          setAudioLevel(level);

          const now = Date.now();
          if (level > 12) {
            hasSpokenAudioRef.current = true;
            lastAudioSpokeTimeRef.current = now;
          } else if (
            hasSpokenAudioRef.current &&
            now - lastAudioSpokeTimeRef.current > (silenceDelaySeconds * 1000 || 1100) &&
            !isProcessingRef.current &&
            !isSpeakingRef.current &&
            isRecordingRef.current
          ) {
            hasSpokenAudioRef.current = false;
            stopAndSubmitVoice();
          }

          animFrameRef.current = requestAnimationFrame(checkLevel);
        }
      };
      checkLevel();

      return stream;
    } catch (err: any) {
      console.warn("Microphone access error:", err);
      setErrorMessage(
        lang === "bn"
          ? "মাইক্রোফোন পারমিশন পাওয়া যায়নি। ব্রাউজারের অ্যাড্রেস বারের লক আইকনে ক্লিক করে মাইক্রোফোন এলাও করুন।"
          : "Microphone permission denied. Please allow microphone access in your browser."
      );
      throw err;
    }
  };

  const stopRecordingAndVisualizer = () => {
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((t) => t.stop());
      audioStreamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== "closed") {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setAudioLevel(0);
    setIsRecording(false);
  };

  // Trigger Automatic Submission on Voice Silence (Hands-Free VAD)
  const resetSilenceTimer = () => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }

    if (!isHandsFreeRef.current || isProcessingRef.current || isSpeakingRef.current) {
      return;
    }

    silenceTimerRef.current = setTimeout(() => {
      const speech = (accumulatedSpeechRef.current || "").trim();
      if (speech.length > 0 && !isProcessingRef.current && !isSpeakingRef.current) {
        console.log("VAD: Silence detected. Auto-submitting speech:", speech);
        stopAndSubmitVoice();
      }
    }, silenceDelaySeconds * 1000);
  };

  // Start Voice Recording with Hands-Free Continuous Speech Recognition
  const startRecording = async () => {
    if (isProcessingRef.current || isSpeakingRef.current) {
      return;
    }

    setErrorMessage(null);
    setLiveTranscript("");
    accumulatedSpeechRef.current = "";
    isManuallyStoppedRef.current = false;
    audioChunksRef.current = [];
    hasSpokenAudioRef.current = false;
    lastAudioSpokeTimeRef.current = Date.now();

    try {
      const stream = await initAudioStream();
      globalAudioPlayer.playChime("start_listening");

      let mimeType = "audio/webm;codecs=opus";
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = MediaRecorder.isTypeSupported("audio/webm")
          ? "audio/webm"
          : MediaRecorder.isTypeSupported("audio/mp4")
          ? "audio/mp4"
          : "";
      }

      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      recorder.start(250);
      setIsRecording(true);
      setRecordingSeconds(0);

      timerIntervalRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);

      // Continuous Speech Recognition
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        try {
          const rec = new SpeechRecognition();
          rec.continuous = true;
          rec.interimResults = true;
          rec.lang = inputLang;

          rec.onresult = (evt: any) => {
            let interim = "";
            for (let i = evt.resultIndex; i < evt.results.length; i++) {
              const chunk = evt.results[i][0].transcript;
              if (evt.results[i].isFinal) {
                accumulatedSpeechRef.current = (accumulatedSpeechRef.current + " " + chunk).trim();
              } else {
                interim += chunk;
              }
            }
            const fullTranscript = (accumulatedSpeechRef.current + " " + interim).trim();
            if (fullTranscript) {
              setLiveTranscript(fullTranscript);
              hasSpokenAudioRef.current = true;
              lastAudioSpokeTimeRef.current = Date.now();
              // Trigger VAD silence countdown on every new word
              resetSilenceTimer();
            }
          };

          rec.onspeechend = () => {
            if (isRecordingRef.current && (accumulatedSpeechRef.current || liveTranscript) && !isProcessingRef.current) {
              setTimeout(() => {
                if (isRecordingRef.current && !isProcessingRef.current) {
                  stopAndSubmitVoice();
                }
              }, 400);
            }
          };

          rec.onerror = (e: any) => {
            console.log("Speech recognition status:", e.error);
          };

          rec.onend = () => {
            if (!isManuallyStoppedRef.current && mediaRecorderRef.current?.state === "recording") {
              try {
                rec.start();
              } catch (e) {}
            }
          };

          rec.start();
          recognitionRef.current = rec;
        } catch (e) {
          console.warn("SpeechRecognition init exception:", e);
        }
      }
    } catch (err: any) {
      setIsRecording(false);
    }
  };

  // Stop Recording & Send for AI Generation
  const stopAndSubmitVoice = async () => {
    isManuallyStoppedRef.current = true;
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }

    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
      recognitionRef.current = null;
    }

    setIsRecording(false);
    setIsProcessing(true);

    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }

    const recordedMimeType = mediaRecorderRef.current?.mimeType || "audio/webm";

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }

    await new Promise((r) => setTimeout(r, 250));
    stopRecordingAndVisualizer();

    const audioBlob = new Blob(audioChunksRef.current, { type: recordedMimeType });

    let base64Audio = "";
    if (audioBlob.size > 200) {
      const reader = new FileReader();
      base64Audio = await new Promise((resolve) => {
        reader.onloadend = () => {
          const result = reader.result as string;
          const commaIdx = result.indexOf(",");
          resolve(commaIdx !== -1 ? result.substring(commaIdx + 1) : result);
        };
        reader.onerror = () => resolve("");
        reader.readAsDataURL(audioBlob);
      });
    }

    const finalCapturedText = (accumulatedSpeechRef.current || liveTranscript || "").trim();

    await executeVoiceQuery({
      text: finalCapturedText,
      audioBase64: base64Audio,
      audioMimeType: recordedMimeType
    });
  };

  // Submit Text Query
  const handleTextSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!typedInput.trim() || isProcessing) return;
    const textToSend = typedInput.trim();
    setTypedInput("");
    await executeVoiceQuery({ text: textToSend });
  };

  // AI Pipeline Execution with Auto-Resume Loop
  const executeVoiceQuery = async (payload: { text?: string; audioBase64?: string; audioMimeType?: string }) => {
    setIsProcessing(true);
    setErrorMessage(null);

    const inputLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === inputLang);
    const targetLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === targetTranslateLang);

    const userLogId = "usr-" + Date.now();
    const userPromptText = payload.text || (lang === "bn" ? "ভয়েস বার্তা (Voice Speech)" : "Voice Speech Message");

    setLogs((prev) => [
      {
        id: userLogId,
        speaker: "user",
        text: userPromptText,
        language: inputLangObj?.short || "Bengali",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      },
      ...prev
    ]);

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (modelProvider) headers["x-model-provider"] = modelProvider;
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12000);

      const response = await fetch("/api/voice-live-translate", {
        method: "POST",
        headers,
        signal: controller.signal,
        body: JSON.stringify({
          text: payload.text || "",
          audioBase64: payload.audioBase64 || "",
          audioMimeType: payload.audioMimeType || "audio/webm",
          sourceLanguage: inputLangObj?.short || "Bengali",
          targetLanguage: targetLangObj?.short || "English",
          persona: activePersona,
          bookContext: currentBookTitle || ""
        })
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      const data = await response.json();
      const actualTranscript = data.transcript || payload.text || "Voice Speech Processed";
      const translation = data.translation || "";
      const reply = data.response || data.translation || (activePersona === "jarvis" ? "Yes Boss, system operational." : "ভয়েস রেসপন্স প্রস্তুত হয়েছে।");
      const suggestions = Array.isArray(data.suggestions) ? data.suggestions : [];

      if (actualTranscript && actualTranscript !== userPromptText) {
        setLogs((prev) =>
          prev.map((l) => (l.id === userLogId ? { ...l, text: actualTranscript } : l))
        );
      }

      const aiLogId = "ai-" + Date.now();
      const aiLog: VoiceLog = {
        id: aiLogId,
        speaker: "assistant",
        text: reply,
        translatedText: translation,
        suggestions: suggestions,
        persona: activePersona,
        language: activePersona === "translator" ? targetLangObj?.short || "English" : inputLangObj?.short || "Bengali",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };
      setLogs((prev) => [aiLog, ...prev]);

      // Speak response out loud in Real Iron Man / JARVIS Voice
      if (autoSpeak && reply) {
        setIsSpeaking(true);
        const speakLang = activePersona === "translator" ? targetLangObj?.short || "English" : inputLangObj?.short || "Bengali";
        
        globalAudioPlayer.speakText(
          reply,
          speakLang,
          () => {
            setIsSpeaking(false);
            // Hands-free continuous loop: automatically start listening again after JARVIS finishes speaking!
            if (isHandsFreeRef.current) {
              setTimeout(() => {
                if (isHandsFreeRef.current && !isRecordingRef.current) {
                  startRecording();
                }
              }, 400);
            }
          }
        );
      } else if (isHandsFreeRef.current) {
        // If not auto-speaking, resume listening immediately
        setTimeout(() => {
          if (isHandsFreeRef.current && !isRecordingRef.current) {
            startRecording();
          }
        }, 400);
      }
    } catch (err: any) {
      console.error("Pro Voice Assistant error:", err);
      setErrorMessage(
        lang === "bn"
          ? "ভয়েস প্রসেস করতে সাময়িক বিলম্ব হচ্ছে। অনুগ্রহ করে পুনরায় বলুন অথবা নিচে লিখুন।"
          : "Voice query could not be completed. Please speak again or type below."
      );
      if (isHandsFreeRef.current) {
        setTimeout(() => {
          if (isHandsFreeRef.current && !isRecordingRef.current) startRecording();
        }, 1500);
      }
    } finally {
      setIsProcessing(false);
      setLiveTranscript("");
    }
  };

  const handleTestAudio = () => {
    setSuccessAudioTest(true);
    const testPhrase = lang === "bn" 
      ? "জি বস, জার্ভিস ভয়েস সিস্টেম সম্পূর্ণ প্রস্তুত ও লাইভ আছে।" 
      : "Systems online, Boss. J.A.R.V.I.S. is ready at your command.";

    globalAudioPlayer.speakText(
      testPhrase,
      lang === "bn" ? "Bengali" : "English",
      () => setTimeout(() => setSuccessAudioTest(false), 2000)
    );
  };

  const handleInterruptOrToggle = () => {
    if (isSpeaking) {
      globalAudioPlayer.stop();
      setIsSpeaking(false);
      if (isHandsFreeMode) {
        setTimeout(() => startRecording(), 200);
      }
    } else if (isRecording) {
      stopAndSubmitVoice();
    } else {
      startRecording();
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleInsertText = (id: string, text: string) => {
    if (onInsertToBook) {
      onInsertToBook(text);
      setInsertedId(id);
      setTimeout(() => setInsertedId(null), 2000);
    }
  };

  return (
    <div id="pro-voice-studio-root" className="w-full max-w-6xl mx-auto space-y-6 font-sans text-left pb-24">
      {/* 3D Holographic Master Banner (Iron Man Arc Reactor Style) */}
      <div className="relative rounded-3xl p-6 sm:p-8 text-white overflow-hidden shadow-2xl border border-cyan-500/30 bg-gradient-to-br from-[#060a12] via-[#0d1527] to-[#060a12]">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-500/20 backdrop-blur-md text-cyan-300 text-xs font-black border border-cyan-500/40">
              <Cpu size={14} className="animate-spin text-cyan-400" />
              <span>{lang === "bn" ? "J.A.R.V.I.S. লাইভ হ্যান্ডস-ফ্রি ভয়েস ইঞ্জিন" : "J.A.R.V.I.S. Hands-Free Live Real Voice Engine"}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black font-serif tracking-tight text-slate-100 flex items-center gap-3">
              <span>{lang === "bn" ? "টনি স্টার্কের মতো লাইভ ভয়েস অ্যাসিস্ট্যান্ট" : "Iron Man J.A.R.V.I.S. Live Voice Studio"}</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {lang === "bn" 
                ? "কোনো বাটন বন্ধ বা ক্লিক করা লাগবে না—আপনি স্বাভাবিকভাবে কথা বলবেন, সাথে সাথে এআই উত্তর বুঝে রিয়েল সিনেমাটিক ভয়েসে উত্তর দিয়ে স্বয়ংক্রিয়ভাবে পরবর্তী কথা শুনবে।" 
                : "No manual stopping needed—speak freely, and JARVIS auto-detects your speech, answers in real cinematic voice, and continuously listens hands-free."}
            </p>
          </div>

          {/* Quick Audio Test & Controls */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-2.5 shrink-0">
            <button
              onClick={handleTestAudio}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-slate-200 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition border border-white/15 cursor-pointer backdrop-blur-md"
            >
              <Headphones size={15} className="text-cyan-400" />
              <span>{successAudioTest ? (lang === "bn" ? "জার্ভিস কথা বলছে..." : "JARVIS Speaking...") : (lang === "bn" ? "জার্ভিস ভয়েস টেস্ট" : "Test Real Voice")}</span>
            </button>

            {isSpeaking && (
              <button
                onClick={() => {
                  globalAudioPlayer.stop();
                  setIsSpeaking(false);
                }}
                className="px-4 py-2.5 bg-rose-600/30 hover:bg-rose-600/50 text-rose-300 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition border border-rose-500/30 cursor-pointer animate-pulse"
              >
                <VolumeX size={15} />
                <span>{lang === "bn" ? "ভয়েস থামান / ইন্টারেপ্ট" : "Interrupt Voice"}</span>
              </button>
            )}
          </div>
        </div>

        {/* Persona Mode Tabs */}
        <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-6 mt-6 border-t border-slate-800/80">
          {PERSONA_MODES.map((mode) => (
            <button
              key={mode.id}
              onClick={() => setActivePersona(mode.id as any)}
              className={`p-3.5 rounded-2xl text-left transition flex items-start gap-3 cursor-pointer border ${
                activePersona === mode.id
                  ? "bg-cyan-500/20 border-cyan-400/60 shadow-lg shadow-cyan-500/10 text-white"
                  : "bg-white/5 border-white/10 hover:bg-white/10 text-slate-400"
              }`}
            >
              <span className="text-2xl p-1.5 bg-black/40 rounded-xl">{mode.icon}</span>
              <div className="space-y-0.5 min-w-0">
                <div className={`text-xs font-extrabold ${activePersona === mode.id ? "text-cyan-300" : "text-slate-200"}`}>
                  {lang === "bn" ? mode.nameBn : mode.nameEn}
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-snug">
                  {lang === "bn" ? mode.descBn : mode.descEn}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: 3D Arc Reactor Sphere & Live Voice Subtitle Box (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#0b101b] rounded-3xl border border-slate-800 p-6 shadow-2xl flex flex-col items-center justify-between text-center relative overflow-hidden">
            {/* Live State Header */}
            <div className="w-full flex items-center justify-between z-10 border-b border-slate-800/80 pb-3">
              <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Radio size={13} className={isRecording ? "text-rose-500 animate-pulse" : isSpeaking ? "text-cyan-400 animate-pulse" : "text-slate-500"} />
                <span>{lang === "bn" ? "JARVIS স্ট্যাটাস" : "J.A.R.V.I.S. Core"}</span>
              </span>

              <span
                className={`text-[10px] font-black px-2.5 py-1 rounded-full uppercase tracking-wider ${
                  isProcessing
                    ? "bg-amber-500/20 text-amber-300 animate-pulse border border-amber-500/30"
                    : isRecording
                    ? "bg-rose-500/20 text-rose-300 animate-pulse border border-rose-500/30"
                    : isSpeaking
                    ? "bg-cyan-500/20 text-cyan-300 animate-pulse border border-cyan-500/30"
                    : "bg-slate-800 text-slate-400"
                }`}
              >
                {isProcessing
                  ? (lang === "bn" ? "⚡ প্রসেসিং হচ্ছে..." : "⚡ Thinking...")
                  : isRecording
                  ? (lang === "bn" ? `🔴 শুনছি (বলুন): 00:${recordingSeconds < 10 ? "0" + recordingSeconds : recordingSeconds}` : `🔴 Listening: 00:${recordingSeconds < 10 ? "0" + recordingSeconds : recordingSeconds}`)
                  : isSpeaking
                  ? (lang === "bn" ? "🔊 জার্ভিস উত্তর বলছে..." : "🔊 J.A.R.V.I.S. Speaking...")
                  : (lang === "bn" ? "প্রস্তুত (Ready)" : "Online")}
              </span>
            </div>

            {/* 3D Holographic Arc Reactor Stage */}
            <div 
              onClick={handleInterruptOrToggle}
              className="relative py-4 z-10 flex flex-col items-center justify-center cursor-pointer group"
              title={isSpeaking ? (lang === "bn" ? "ইন্টারেপ্ট করতে ক্লিক করুন" : "Click to interrupt") : (lang === "bn" ? "কথা বলতে ক্লিক করুন" : "Click to speak")}
            >
              <canvas
                ref={canvas3dRef}
                width={260}
                height={220}
                className="w-64 h-52 transition-transform duration-300 group-hover:scale-105"
              />

              {/* Main Interactive Mic Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleInterruptOrToggle();
                }}
                disabled={isProcessing}
                className={`mt-2 px-6 py-3 rounded-2xl flex items-center justify-center gap-2.5 text-white shadow-2xl transition-all duration-300 cursor-pointer z-20 ${
                  isProcessing
                    ? "bg-slate-800 opacity-60 cursor-not-allowed"
                    : isSpeaking
                    ? "bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 ring-4 ring-cyan-500/30 scale-105 shadow-cyan-500/30"
                    : isRecording
                    ? "bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-700 hover:to-amber-700 ring-4 ring-rose-500/30 scale-105"
                    : "bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 hover:scale-105 ring-4 ring-cyan-500/20 shadow-cyan-600/30"
                }`}
              >
                {isProcessing ? (
                  <RefreshCw size={18} className="animate-spin text-amber-300" />
                ) : isSpeaking ? (
                  <Volume2 size={18} className="animate-pulse text-white" />
                ) : isRecording ? (
                  <MicOff size={18} className="animate-pulse text-white" />
                ) : (
                  <Mic size={18} className="text-white" />
                )}
                
                <span className="text-xs font-black uppercase tracking-wider">
                  {isProcessing
                    ? (lang === "bn" ? "প্রসেস হচ্ছে..." : "Processing...")
                    : isSpeaking
                    ? (lang === "bn" ? "⏹️ ভয়েস থামান (ইন্টারেপ্ট)" : "⏹️ Interrupt Voice")
                    : isRecording
                    ? (lang === "bn" ? "🎙️ শুনছি... (কথা শেষ করলেই উত্তর দেবে)" : "🎙️ Listening... (Auto-replies when finished)")
                    : isHandsFreeMode
                    ? (lang === "bn" ? "🤖 জার্ভিস চালু করুন" : "🤖 Start JARVIS Hands-Free")
                    : (lang === "bn" ? "🎙️ কথা বলতে চাপুন" : "🎙️ Tap to Speak")}
                </span>
              </button>
            </div>

            {/* Real-time Subtitle Stream (Live Transcription) */}
            <div className="w-full mt-4 p-4 rounded-2xl bg-black/70 border border-slate-800 text-xs text-slate-200 z-10 text-left space-y-1.5">
              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400">
                <span className="flex items-center gap-1.5 text-cyan-400">
                  <Mic size={12} className={isRecording ? "animate-pulse text-rose-400" : "text-cyan-400"} />
                  <span>{lang === "bn" ? "আপনার লাইভ কথা (Live Transcript):" : "Live Speech Subtitles:"}</span>
                </span>
                {isRecording && <span className="text-rose-400 animate-pulse text-[10px]">● VAD AUTO-DETECT ACTIVE</span>}
              </div>

              <div className="min-h-[44px] flex items-center">
                {liveTranscript ? (
                  <p className="text-cyan-300 font-bold leading-relaxed text-xs sm:text-sm animate-pulse">
                    "{liveTranscript}"
                  </p>
                ) : isRecording ? (
                  <p className="text-slate-400 italic">
                    {lang === "bn" ? "কথা বলুন—কথা শেষ হওয়া মাত্রই জার্ভিস স্বয়ংক্রিয়ভাবে উত্তর দেবে..." : "Speak now—JARVIS will auto-detect when you finish and reply..."}
                  </p>
                ) : (
                  <p className="text-slate-500">
                    {lang === "bn" ? "হ্যান্ডস-ফ্রি মোডে শুরু করতে উপরের বাটনে ট্যাপ করুন।" : "Tap the button above to begin hands-free conversation."}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Hands-Free VAD & Language Configuration Card */}
          <div className="bg-[#0b101b] rounded-3xl border border-slate-800 p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-extrabold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Sliders size={13} className="text-cyan-400" />
                <span>{lang === "bn" ? "হ্যান্ডস-ফ্রি ও অটো-ডিটেক্ট সেটিংস" : "Hands-Free & VAD Engine"}</span>
              </span>
              <span className="text-xs text-cyan-400 font-bold flex items-center gap-1">
                <ShieldCheck size={14} />
                <span>Auto-Speech Loop</span>
              </span>
            </div>

            {/* Hands-Free Continuous Loop Switch */}
            <div className="p-3.5 bg-slate-900/90 rounded-2xl border border-slate-800 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-xs font-black text-slate-200">
                  {lang === "bn" ? "🤖 স্বয়ংক্রিয় লাইভ কথোপকথন (Hands-Free Loop)" : "🤖 Continuous Hands-Free Conversation"}
                </div>
                <p className="text-[10px] text-slate-400">
                  {lang === "bn" 
                    ? "কোনো বাটন প্রেস ছাড়া একের পর এক স্বাভাবিক কথোপকথন" 
                    : "Auto-detects silence, replies instantly, and resumes listening"}
                </p>
              </div>

              <input
                type="checkbox"
                checked={isHandsFreeMode}
                onChange={(e) => {
                  setIsHandsFreeMode(e.target.checked);
                  if (e.target.checked && !isRecording && !isProcessing && !isSpeaking) {
                    startRecording();
                  }
                }}
                className="w-5 h-5 text-cyan-500 rounded cursor-pointer accent-cyan-500"
              />
            </div>

            {/* Silence Detection Threshold */}
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-xs font-bold text-slate-400">
                <span>{lang === "bn" ? "কথা শেষের বিরতি (Silence Delay):" : "Auto-Send Silence Delay:"}</span>
                <span className="text-cyan-400 font-mono">{silenceDelaySeconds}s</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="2.5"
                step="0.1"
                value={silenceDelaySeconds}
                onChange={(e) => setSilenceDelaySeconds(parseFloat(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>Fast (0.8s)</span>
                <span>Balanced (1.3s)</span>
                <span>Relaxed (2.5s)</span>
              </div>
            </div>

            {/* Language Selectors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80">
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-400">
                  {lang === "bn" ? "আপনার ভাষা (Input):" : "Input Language:"}
                </label>
                <select
                  value={inputLang}
                  onChange={(e) => setInputLang(e.target.value)}
                  className="w-full bg-[#060a12] border border-slate-700 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-200 outline-hidden cursor-pointer"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code} className="bg-slate-900 text-white">
                      {l.flag} {l.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-400">
                  {lang === "bn" ? "অনুবাদ ভাষা (Translate to):" : "Translate Language:"}
                </label>
                <select
                  value={targetTranslateLang}
                  onChange={(e) => setTargetTranslateLang(e.target.value)}
                  className="w-full bg-[#060a12] border border-slate-700 rounded-xl px-3 py-2.5 text-xs font-bold text-slate-200 outline-hidden cursor-pointer"
                >
                  {SUPPORTED_LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code} className="bg-slate-900 text-white">
                      {l.flag} {l.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Auto speak check */}
            <label className="flex items-center justify-between pt-2 text-xs font-bold text-slate-300 cursor-pointer">
              <span>{lang === "bn" ? "জার্ভিসের রিয়েল ভয়েস অটো শুনুন" : "Auto-Speak with Real Voice"}</span>
              <input
                type="checkbox"
                checked={autoSpeak}
                onChange={(e) => setAutoSpeak(e.target.checked)}
                className="w-4 h-4 text-cyan-600 rounded cursor-pointer accent-cyan-500"
              />
            </label>
          </div>
        </div>

        {/* Right Column: Voice Conversation Dialogue & Quick Starters (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Quick Voice Starters */}
          <div className="bg-[#0b101b] rounded-3xl border border-slate-800 p-5 shadow-xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-black text-cyan-400">
              <Zap size={14} />
              <span>{lang === "bn" ? "জার্ভিস কুইক ভয়েস কমান্ড (এক ক্লিকে জিজ্ঞাসা করুন):" : "J.A.R.V.I.S. Quick Voice Starters:"}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {QUICK_STARTERS.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => executeVoiceQuery({ text: lang === "bn" ? item.bn : item.en })}
                  disabled={isProcessing}
                  className="p-2.5 rounded-xl bg-slate-900/80 hover:bg-cyan-500/10 border border-slate-800 hover:border-cyan-500/30 text-left text-xs font-medium text-slate-300 hover:text-white transition flex items-center justify-between gap-2 cursor-pointer"
                >
                  <span className="truncate">{lang === "bn" ? item.bn : item.en}</span>
                  <ChevronRight size={13} className="text-cyan-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Conversation Transcript Logs */}
          <div className="bg-[#0b101b] rounded-3xl border border-slate-800 p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Award size={16} className="text-cyan-400" />
                <h3 className="text-sm font-black text-slate-100">
                  {lang === "bn" ? "জার্ভিস লাইভ কনভার্সেশন হিস্ট্রি" : "J.A.R.V.I.S. Live Dialogues & Logs"}
                </h3>
              </div>
              {logs.length > 0 && (
                <button
                  onClick={() => setLogs([])}
                  className="text-xs font-bold text-slate-400 hover:text-rose-400 flex items-center gap-1 transition cursor-pointer"
                >
                  <Trash2 size={13} />
                  <span>{lang === "bn" ? "ক্লিয়ার করুন" : "Clear"}</span>
                </button>
              )}
            </div>

            {errorMessage && (
              <div className="p-3.5 bg-rose-950/40 border border-rose-800/60 rounded-2xl text-xs font-bold text-rose-300 flex items-center gap-2.5">
                <AlertCircle size={16} className="shrink-0 text-rose-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {logs.length === 0 ? (
              <div className="py-14 text-center text-slate-500 space-y-3">
                <div className="w-14 h-14 mx-auto rounded-full bg-slate-900 flex items-center justify-center text-cyan-400 border border-cyan-500/30">
                  <Mic size={24} />
                </div>
                <p className="text-xs font-medium max-w-sm mx-auto">
                  {lang === "bn"
                    ? "মাইক্রোফোনে কথা বলুন। জার্ভিস সরাসরি আপনার বক্তব্য বুঝে রিয়েল সিনেমাটিক ভয়েসে উত্তর দেবে এবং স্বয়ংক্রিয়ভাবে পরবর্তী কথোপকথন চালিয়ে যাবে।"
                    : "Speak freely. JARVIS will auto-detect your speech and respond continuously with real cinematic voice."}
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1">
                {logs.map((item) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-4 rounded-2xl border transition ${
                      item.speaker === "user"
                        ? "bg-cyan-950/25 border-cyan-500/35 ml-6 text-cyan-100"
                        : "bg-slate-900/90 border-slate-800 mr-6 text-slate-200"
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] font-extrabold text-slate-400 mb-2">
                      <span className="flex items-center gap-1.5 text-slate-300 font-bold">
                        {item.speaker === "user" ? "🗣️ আপনি বলেছেন (User Voice)" : "⚡ J.A.R.V.I.S. (Iron Man AI)"}
                      </span>
                      <span>{item.timestamp}</span>
                    </div>

                    <p className="text-xs sm:text-sm font-medium leading-relaxed">
                      {item.text}
                    </p>

                    {item.translatedText && item.translatedText !== item.text && (
                      <div className="mt-3 pt-2.5 border-t border-slate-800/80 text-xs font-serif text-cyan-300">
                        <span className="font-sans font-bold text-[10px] uppercase text-slate-400 block mb-0.5">
                          {lang === "bn" ? "অনুবাদ / Translation:" : "Translation:"}
                        </span>
                        "{item.translatedText}"
                      </div>
                    )}

                    {/* Suggestions */}
                    {item.suggestions && item.suggestions.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {item.suggestions.map((sug, sIdx) => (
                          <button
                            key={sIdx}
                            onClick={() => executeVoiceQuery({ text: sug })}
                            className="text-[10px] bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-200 px-2 py-1 rounded-lg border border-slate-700 transition cursor-pointer"
                          >
                            + {sug}
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Actions Bar */}
                    <div className="mt-3 flex items-center justify-end gap-2 text-[11px] font-bold">
                      {/* Audio Playback */}
                      <button
                        onClick={() => globalAudioPlayer.speakText(item.text, item.language || "Bengali")}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 flex items-center gap-1 cursor-pointer transition"
                        title="Play Speech"
                      >
                        <Volume2 size={12} className="text-cyan-400" />
                        <span>{lang === "bn" ? "শুনুন" : "Play"}</span>
                      </button>

                      {/* Copy */}
                      <button
                        onClick={() => handleCopyText(item.id, item.text)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 flex items-center gap-1 cursor-pointer transition"
                      >
                        {copiedId === item.id ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        <span>{copiedId === item.id ? (lang === "bn" ? "কপি হয়েছে" : "Copied") : (lang === "bn" ? "কপি" : "Copy")}</span>
                      </button>

                      {/* Insert to Book */}
                      {onInsertToBook && (
                        <button
                          onClick={() => handleInsertText(item.id, item.translatedText ? `${item.text}\n\n*${item.translatedText}*` : item.text)}
                          className="px-3 py-1 bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 text-white rounded-lg flex items-center gap-1 cursor-pointer shadow-md transition"
                          title="Insert into active book chapter"
                        >
                          {insertedId === item.id ? <Check size={12} /> : <BookOpen size={12} />}
                          <span>{insertedId === item.id ? (lang === "bn" ? "বইয়ে যুক্ত হয়েছে!" : "Inserted!") : (lang === "bn" ? "বইয়ে যুক্ত করুন" : "Add to Book")}</span>
                        </button>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Fallback Text Input Bar */}
            <form onSubmit={handleTextSubmit} className="pt-2 flex items-center gap-2">
              <input
                type="text"
                value={typedInput}
                onChange={(e) => setTypedInput(e.target.value)}
                placeholder={lang === "bn" ? "অথবা এখানে টাইপ করে জার্ভিসকে জিজ্ঞাসা করুন..." : "Or type your voice query for J.A.R.V.I.S. here..."}
                disabled={isProcessing}
                className="flex-1 bg-[#060a12] border border-slate-700 focus:border-cyan-500 rounded-2xl px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 outline-hidden"
              />
              <button
                type="submit"
                disabled={!typedInput.trim() || isProcessing}
                className="px-4 py-2.5 bg-gradient-to-r from-cyan-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 disabled:opacity-50 text-white rounded-2xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-md"
              >
                <Send size={13} />
                <span>{lang === "bn" ? "পাঠান" : "Send"}</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
