import React, { useState, useEffect, useRef } from "react";
import {
  Folder, FolderOpen, FileCode, FileText, FileJson, File, Search,
  RefreshCw, Save, Copy, Check, Plus, Trash2, Sparkles, Play,
  Terminal, ShieldCheck, Zap, Code2, Cpu, Wrench, Eye, EyeOff,
  ChevronRight, ChevronDown, CheckCircle2, AlertTriangle, ArrowRight,
  Maximize2, Minimize2, Undo2, Layers, Download
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export interface FileNode {
  name: string;
  path: string;
  type: "file" | "directory";
  size?: number;
  extension?: string;
  updatedAt?: string;
  children?: FileNode[];
}

interface ProjectCodeStudioIDEProps {
  lang: "bn" | "en";
  modelProvider?: string;
  customGeminiKey?: string;
  customDeepseekKey?: string;
}

export const ProjectCodeStudioIDE: React.FC<ProjectCodeStudioIDEProps> = ({
  lang,
  modelProvider = "gemini",
  customGeminiKey = "",
  customDeepseekKey = ""
}) => {
  // Tree & Files State
  const [fileTree, setFileTree] = useState<FileNode[]>([]);
  const [isLoadingTree, setIsLoadingTree] = useState(false);
  const [openFolders, setOpenFolders] = useState<Record<string, boolean>>({
    "src": true,
    "src/components": true,
    "src/utils": true
  });
  const [fileSearchQuery, setFileSearchQuery] = useState("");

  // Active File State
  const [activeFilePath, setActiveFilePath] = useState<string>("src/App.tsx");
  const [fileContent, setFileContent] = useState<string>("");
  const [originalFileContent, setOriginalFileContent] = useState<string>("");
  const [fileMeta, setFileMeta] = useState<{ size: number; extension: string; updatedAt?: string } | null>(null);
  const [isLoadingFile, setIsLoadingFile] = useState(false);
  const [isSavingFile, setIsSavingFile] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);

  // New File Modal
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newFilePathInput, setNewFilePathInput] = useState("");

  // AI Autonomous Developer Assistant State
  const [aiPrompt, setAiPrompt] = useState("");
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiHistory, setAiHistory] = useState<Array<{
    prompt: string;
    summary: string;
    explanation: string;
    targetFilePath: string;
    updatedCode: string;
    diffSummary?: string;
    timestamp: string;
  }>>([]);
  const [selectedAiResult, setSelectedAiResult] = useState<any | null>(null);

  // Load Tree on Mount
  const fetchProjectTree = async () => {
    try {
      setIsLoadingTree(true);
      const res = await fetch("/api/admin/project-tree");
      if (!res.ok) throw new Error("Failed to fetch tree");
      const data = await res.json();
      if (data.tree) {
        setFileTree(data.tree);
      }
    } catch (err) {
      console.warn("Project tree fetch notice:", err);
    } finally {
      setIsLoadingTree(false);
    }
  };

  // Read File Content
  const loadFileContent = async (filePath: string) => {
    try {
      setIsLoadingFile(true);
      const res = await fetch("/api/admin/read-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath })
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to read file");
      }
      const data = await res.json();
      setActiveFilePath(data.filePath);
      setFileContent(data.content);
      setOriginalFileContent(data.content);
      setFileMeta({
        size: data.size,
        extension: data.extension,
        updatedAt: data.updatedAt
      });
    } catch (err: any) {
      alert(err.message || "Failed to load file content.");
    } finally {
      setIsLoadingFile(false);
    }
  };

  useEffect(() => {
    fetchProjectTree();
    loadFileContent("src/App.tsx");
  }, []);

  // Toggle Folder Open/Close
  const toggleFolder = (folderPath: string) => {
    setOpenFolders(prev => ({
      ...prev,
      [folderPath]: !prev[folderPath]
    }));
  };

  // Save File to Server
  const handleSaveCurrentFile = async () => {
    if (!activeFilePath) return;
    try {
      setIsSavingFile(true);
      const res = await fetch("/api/admin/save-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: activeFilePath,
          content: fileContent
        })
      });
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to save file");
      }
      setOriginalFileContent(fileContent);
      setSaveSuccessNotice(true);
      setTimeout(() => setSaveSuccessNotice(false), 3000);
      fetchProjectTree();
    } catch (err: any) {
      alert(err.message || "Failed to save file.");
    } finally {
      setIsSavingFile(false);
    }
  };

  // Create New File
  const handleCreateNewFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFilePathInput.trim()) return;

    try {
      const res = await fetch("/api/admin/create-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: newFilePathInput.trim(),
          content: `// ${newFilePathInput.trim()}\nimport React from 'react';\n\nexport const Component = () => {\n  return <div>New Component</div>;\n};\n`
        })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to create file");
      }
      setShowNewFileModal(false);
      const createdPath = newFilePathInput.trim();
      setNewFilePathInput("");
      await fetchProjectTree();
      await loadFileContent(createdPath);
      alert(lang === "bn" ? `✅ নতুন ফাইল "${createdPath}" তৈরি হয়েছে!` : `✅ New file "${createdPath}" created!`);
    } catch (err: any) {
      alert(err.message || "Error creating file");
    }
  };

  // Copy Code
  const handleCopyCode = () => {
    navigator.clipboard.writeText(fileContent);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // AI Code Engineer Assistant Execution
  const handleRunAiCodeEngineer = async (customPromptText?: string) => {
    const promptToUse = customPromptText || aiPrompt;
    if (!promptToUse.trim()) return;

    setIsAiGenerating(true);
    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        "x-model-provider": modelProvider
      };
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const res = await fetch("/api/admin/ai-code-engineer", {
        method: "POST",
        headers,
        body: JSON.stringify({
          prompt: promptToUse,
          activeFilePath,
          activeFileContent: fileContent,
          language: lang === "bn" ? "Bengali" : "English"
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "AI Coding Assistant encountered an error");
      }

      const result = await res.json();
      const newEntry = {
        prompt: promptToUse,
        summary: result.summary || "Code modification completed",
        explanation: result.explanation || "",
        targetFilePath: result.targetFilePath || activeFilePath,
        updatedCode: result.updatedCode || "",
        diffSummary: result.diffSummary || "",
        timestamp: new Date().toLocaleTimeString()
      };

      setAiHistory(prev => [newEntry, ...prev]);
      setSelectedAiResult(newEntry);
      setAiPrompt("");
    } catch (err: any) {
      alert(err.message || "AI Coding Assistant failed.");
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Apply AI Result Directly to Active File and Disk
  const handleApplyAiResult = async (result: any) => {
    if (!result.updatedCode) return;
    try {
      setIsSavingFile(true);
      const targetPath = result.targetFilePath || activeFilePath;
      const res = await fetch("/api/admin/save-file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: targetPath,
          content: result.updatedCode
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Failed to write file");
      }

      setFileContent(result.updatedCode);
      setOriginalFileContent(result.updatedCode);
      setActiveFilePath(targetPath);
      setSaveSuccessNotice(true);
      setTimeout(() => setSaveSuccessNotice(false), 3000);
      alert(lang === "bn" ? `⚡ সফলভাবে AI কোড "${targetPath}" ফাইলে প্রয়োগ ও সেভ করা হয়েছে!` : `⚡ Successfully applied AI code to "${targetPath}"!`);
    } catch (err: any) {
      alert(err.message || "Failed to apply code.");
    } finally {
      setIsSavingFile(false);
    }
  };

  // Helper for File Icons
  const getFileIcon = (ext?: string) => {
    switch (ext) {
      case ".tsx":
      case ".ts":
      case ".jsx":
      case ".js":
        return <FileCode size={14} className="text-cyan-400 shrink-0" />;
      case ".json":
        return <FileJson size={14} className="text-amber-400 shrink-0" />;
      case ".html":
      case ".css":
        return <FileText size={14} className="text-rose-400 shrink-0" />;
      default:
        return <File size={14} className="text-slate-400 shrink-0" />;
    }
  };

  // Recursive Tree Renderer
  const renderTree = (nodes: FileNode[], depth = 0) => {
    return (
      <div className="space-y-0.5">
        {nodes
          .filter(node => {
            if (!fileSearchQuery.trim()) return true;
            return node.path.toLowerCase().includes(fileSearchQuery.toLowerCase());
          })
          .map((node) => {
            if (node.type === "directory") {
              const isOpen = !!openFolders[node.path];
              return (
                <div key={node.path} className="select-none">
                  <div
                    onClick={() => toggleFolder(node.path)}
                    style={{ paddingLeft: `${depth * 12 + 6}px` }}
                    className="flex items-center gap-1.5 py-1 px-2 rounded-lg hover:bg-slate-800/80 cursor-pointer text-slate-300 hover:text-white transition text-xs font-semibold"
                  >
                    {isOpen ? <ChevronDown size={12} className="text-slate-400" /> : <ChevronRight size={12} className="text-slate-400" />}
                    {isOpen ? <FolderOpen size={14} className="text-amber-400 shrink-0" /> : <Folder size={14} className="text-amber-500 shrink-0" />}
                    <span className="truncate">{node.name}</span>
                  </div>

                  {isOpen && node.children && (
                    <div className="border-l border-slate-800/80 ml-3">
                      {renderTree(node.children, depth + 1)}
                    </div>
                  )}
                </div>
              );
            } else {
              const isActive = activeFilePath === node.path;
              return (
                <div
                  key={node.path}
                  onClick={() => loadFileContent(node.path)}
                  style={{ paddingLeft: `${depth * 12 + 6}px` }}
                  className={`flex items-center justify-between py-1 px-2 rounded-lg cursor-pointer transition text-xs select-none ${
                    isActive
                      ? "bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40"
                      : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200"
                  }`}
                >
                  <div className="flex items-center gap-1.5 truncate">
                    {getFileIcon(node.extension)}
                    <span className="truncate">{node.name}</span>
                  </div>
                  {node.size ? (
                    <span className="text-[9px] text-slate-500 font-mono shrink-0 ml-1">
                      {(node.size / 1024).toFixed(1)}k
                    </span>
                  ) : null}
                </div>
              );
            }
          })}
      </div>
    );
  };

  const isFileModified = fileContent !== originalFileContent;

  return (
    <div className="bg-slate-950 text-slate-100 rounded-3xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col font-sans">
      {/* Top Header Bar */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-cyan-500 to-blue-600 text-slate-950 rounded-2xl shadow-md font-black">
            <Terminal size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                {lang === "bn" ? "প্রোজেক্ট ফুল সোর্স কোড স্টুডিও ও এআই ডেভেলপার" : "Project Full Source Code Studio & AI Developer"}
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-cyan-400/20 text-cyan-300 border border-cyan-400/40 text-[9px] font-mono font-bold">
                ROOT IDE
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {lang === "bn"
                ? "ওয়েবসাইটের সকল সোর্স ফাইল ব্রাউজ করুন, কোড এডিট করুন এবং AI কে সরাসরি ফাইল পরিমার্জন বা নতুন ফিচার তৈরির নির্দেশ দিন।"
                : "Browse all project files (src, public, server, utils), edit code directly, or prompt the AI Developer to engineer changes."}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowNewFileModal(true)}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            <Plus size={13} />
            <span>{lang === "bn" ? "নতুন ফাইল" : "New File"}</span>
          </button>

          <button
            onClick={fetchProjectTree}
            disabled={isLoadingTree}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition cursor-pointer"
            title="Refresh Files"
          >
            <RefreshCw size={14} className={isLoadingTree ? "animate-spin" : ""} />
          </button>
        </div>
      </div>

      {/* Main IDE Layout: 3 Columns (File Tree | Code Editor | AI Developer) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[640px] max-h-[820px] overflow-hidden">
        
        {/* COLUMN 1: PROJECT FILE TREE (3 Cols) */}
        <div className="lg:col-span-3 bg-slate-900/90 border-r border-slate-800 flex flex-col h-full max-h-[820px] overflow-hidden">
          <div className="p-3 border-b border-slate-800 bg-slate-950/40 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <span>{lang === "bn" ? "প্রজেক্ট ফাইলস" : "Workspace Files"}</span>
              <span className="text-[9px] font-mono text-cyan-400 font-bold">● LIVE FS</span>
            </div>

            <div className="relative">
              <Search size={12} className="absolute left-2.5 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder={lang === "bn" ? "ফাইল খুঁজুন..." : "Filter files..."}
                value={fileSearchQuery}
                onChange={(e) => setFileSearchQuery(e.target.value)}
                className="w-full pl-7 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>
          </div>

          <div className="p-2 flex-1 overflow-y-auto space-y-1 custom-scrollbar">
            {isLoadingTree ? (
              <div className="p-4 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
                <RefreshCw size={14} className="animate-spin text-cyan-400" />
                <span>{lang === "bn" ? "ফাইল স্ক্যান হচ্ছে..." : "Loading file tree..."}</span>
              </div>
            ) : fileTree.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-500">
                {lang === "bn" ? "কোন ফাইল পাওয়া যায়নি।" : "No files found."}
              </div>
            ) : (
              renderTree(fileTree)
            )}
          </div>
        </div>

        {/* COLUMN 2: CODE EDITOR (6 Cols) */}
        <div className="lg:col-span-6 bg-slate-950 flex flex-col h-full max-h-[820px] overflow-hidden border-r border-slate-800">
          {/* File Top Bar */}
          <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 truncate">
              {getFileIcon(fileMeta?.extension)}
              <span className="text-xs font-mono font-bold text-white truncate">
                {activeFilePath}
              </span>
              {isFileModified && (
                <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded text-[9px] font-mono font-bold shrink-0">
                  ● Modified
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition flex items-center gap-1 cursor-pointer"
                title="Copy code"
              >
                {isCopied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                <span>{isCopied ? "Copied" : "Copy"}</span>
              </button>

              <button
                onClick={() => setFileContent(originalFileContent)}
                disabled={!isFileModified}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg text-xs transition cursor-pointer disabled:opacity-30"
                title="Revert modifications"
              >
                <Undo2 size={12} />
              </button>

              <button
                onClick={handleSaveCurrentFile}
                disabled={isSavingFile || !isFileModified}
                className="px-3.5 py-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black rounded-lg text-xs transition flex items-center gap-1.5 cursor-pointer shadow-md disabled:opacity-40"
              >
                {isSavingFile ? (
                  <>
                    <RefreshCw size={12} className="animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <>
                    <Save size={12} />
                    <span>{lang === "bn" ? "সেভ করুন" : "Save File"}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Toast Notification */}
          {saveSuccessNotice && (
            <div className="bg-emerald-950/80 border-b border-emerald-500/40 text-emerald-300 px-4 py-1.5 text-xs flex items-center gap-2 font-mono">
              <CheckCircle2 size={13} className="text-emerald-400" />
              <span>{lang === "bn" ? `ফাইল "${activeFilePath}" সফলভাবে ডিস্কে সেভ করা হয়েছে!` : `File "${activeFilePath}" saved successfully to disk!`}</span>
            </div>
          )}

          {/* Editor Textarea with Line Numbers */}
          <div className="flex-1 relative flex overflow-hidden bg-slate-950">
            {isLoadingFile ? (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80 z-10 text-xs text-slate-400 gap-2">
                <RefreshCw size={16} className="animate-spin text-cyan-400" />
                <span>{lang === "bn" ? "ফাইল লোড হচ্ছে..." : "Reading file content..."}</span>
              </div>
            ) : (
              <div className="flex w-full h-full">
                {/* Line Numbers */}
                <div className="w-12 bg-slate-900/50 py-3 pr-2 select-none border-r border-slate-800/80 text-right font-mono text-[11px] text-slate-600 leading-[20px] overflow-hidden">
                  {fileContent.split("\n").map((_, i) => (
                    <div key={i}>{i + 1}</div>
                  ))}
                </div>

                {/* Code Textarea */}
                <textarea
                  value={fileContent}
                  onChange={(e) => setFileContent(e.target.value)}
                  spellCheck={false}
                  className="flex-1 bg-transparent p-3 text-cyan-100 font-mono text-xs leading-[20px] resize-none focus:outline-none custom-scrollbar overflow-auto whitespace-pre"
                />
              </div>
            )}
          </div>

          {/* Editor Status Bar */}
          <div className="px-4 py-1.5 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-500 font-mono">
            <div className="flex items-center gap-3">
              <span>Lines: {fileContent.split("\n").length}</span>
              <span>Size: {fileMeta ? (fileMeta.size / 1024).toFixed(1) : 0} KB</span>
            </div>
            <span>UTF-8 | TypeScript / React</span>
          </div>
        </div>

        {/* COLUMN 3: AUTONOMOUS AI CODE DEVELOPER (3 Cols) */}
        <div className="lg:col-span-3 bg-slate-900/95 flex flex-col h-full max-h-[820px] overflow-hidden">
          {/* AI Header */}
          <div className="p-3.5 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles size={16} className="text-amber-400" />
              <h3 className="text-xs font-black text-white">
                {lang === "bn" ? "AI কোড ইঞ্জিনিয়ার" : "AI Code Architect"}
              </h3>
            </div>
            <span className="text-[9px] font-bold px-2 py-0.5 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-full font-mono">
              AUTONOMOUS
            </span>
          </div>

          {/* AI Conversation & Output History */}
          <div className="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
            {/* Quick Prompt Suggestions */}
            <div className="space-y-1.5">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
                {lang === "bn" ? "দ্রুত নির্দেশিকা (Quick Actions):" : "Quick AI Directives:"}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: "🔍 স্ক্যান ও ফিক্স", prompt: `Analyze and fix any syntax or logical errors in ${activeFilePath}. Ensure clean TypeScript types and imports.` },
                  { label: "👑 প্রো বাটন যোগ", prompt: `Add a visible PRO mode buy/upgrade button and modal trigger to this component.` },
                  { label: "🎨 প্রিমিয়াম স্টাইল", prompt: `Upgrade this component with modern Tailwind CSS glassmorphism, responsive styling and smooth animations.` },
                  { label: "⚡ পারফরম্যান্স", prompt: `Optimize this component for high performance and clean modular architecture.` }
                ].map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleRunAiCodeEngineer(item.prompt)}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold rounded-lg border border-slate-700 transition cursor-pointer"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Selected AI Result Preview & 1-Click Apply */}
            {selectedAiResult && (
              <div className="p-3 bg-slate-950 rounded-xl border border-amber-500/40 space-y-2.5 shadow-lg animate-fadeIn">
                <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                  <span className="text-[10px] font-bold text-amber-400 flex items-center gap-1 font-mono">
                    ✦ AI Plan ({selectedAiResult.timestamp})
                  </span>
                  <span className="text-[9px] text-slate-400 font-mono truncate max-w-[120px]">
                    {selectedAiResult.targetFilePath}
                  </span>
                </div>

                <p className="text-[11px] font-bold text-white">{selectedAiResult.summary}</p>
                
                {selectedAiResult.explanation && (
                  <p className="text-[10px] text-slate-400 leading-relaxed whitespace-pre-line">
                    {selectedAiResult.explanation}
                  </p>
                )}

                {selectedAiResult.diffSummary && (
                  <div className="p-2 bg-slate-900 rounded-lg text-[10px] text-cyan-300 font-mono border border-slate-800">
                    {selectedAiResult.diffSummary}
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => handleApplyAiResult(selectedAiResult)}
                  className="w-full py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-slate-950 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Zap size={13} />
                  <span>{lang === "bn" ? "⚡ ১-ক্লিকে কোড ফাইলে সেভ করুন" : "⚡ 1-Click Apply to File"}</span>
                </button>
              </div>
            )}

            {/* Generation Spinner */}
            {isAiGenerating && (
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-2">
                <RefreshCw size={18} className="animate-spin text-amber-400 mx-auto" />
                <p className="text-xs font-bold text-slate-300">
                  {lang === "bn" ? "AI ডেভেলপার কোড রচনা করছে..." : "AI Engineer is writing & testing code..."}
                </p>
              </div>
            )}
          </div>

          {/* AI Prompt Input Bar */}
          <div className="p-3 border-t border-slate-800 bg-slate-950/60 space-y-2">
            <textarea
              rows={3}
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              placeholder={lang === "bn" ? "AI কে নির্দেশ দিন (যেমন: 'এই ফাইলে একটি নতুন বাটন যোগ করো বা এরর ফিক্স করো')..." : "Instruct AI Developer (e.g. 'Add a new PRO purchase modal trigger to this file')..."}
              className="w-full p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-sans resize-none"
            />

            <button
              type="button"
              disabled={isAiGenerating || !aiPrompt.trim()}
              onClick={() => handleRunAiCodeEngineer()}
              className="w-full py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {isAiGenerating ? (
                <>
                  <RefreshCw size={13} className="animate-spin" />
                  <span>Generating Code...</span>
                </>
              ) : (
                <>
                  <Sparkles size={13} />
                  <span>{lang === "bn" ? "AI কে কোড লিখতে বলুন" : "Execute AI Code Engineer"}</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>

      {/* CREATE NEW FILE MODAL */}
      <AnimatePresence>
        {showNewFileModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-md w-full text-white shadow-2xl space-y-4"
            >
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Plus size={16} className="text-cyan-400" />
                <span>{lang === "bn" ? "নতুন ফাইল তৈরি করুন" : "Create New File"}</span>
              </h3>

              <form onSubmit={handleCreateNewFile} className="space-y-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">
                    {lang === "bn" ? "ফাইল পাথ (যেমন: src/components/NewWidget.tsx)" : "Relative File Path"}
                  </label>
                  <input
                    type="text"
                    required
                    value={newFilePathInput}
                    onChange={(e) => setNewFilePathInput(e.target.value)}
                    placeholder="src/components/MyNewFeature.tsx"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowNewFileModal(false)}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-xl text-xs font-black transition cursor-pointer"
                  >
                    Create File
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
