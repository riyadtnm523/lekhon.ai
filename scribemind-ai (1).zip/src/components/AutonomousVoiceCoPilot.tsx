import React, { useState, useRef, useEffect, useCallback } from "react";
import { 
  Mic, MicOff, Sparkles, X, Volume2, Search, 
  BookOpen, Compass, ChevronRight, Zap, CheckCircle2,
  Radio, Send, RefreshCw, AudioWaveform, Flame, Image as ImageIcon,
  Camera, Upload, Eye, Trash2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { unlockAudioAutoplay, stopAllSpokenAudio, playSpokenAudioAloud } from "../utils/audioPlayer";

interface AutonomousVoiceCoPilotProps {
  lang: "bn" | "en";
  currentUser: any;
  currentBook: any;
  onNavigateTab: (tab: "editor" | "ai_chat" | "voice_buddy" | "code_studio" | "social" | "mind_matrix" | "history" | "settings") => void;
  onExecuteBookCreation: (topic: string, genre?: string, prompt?: string, chapterCount?: number) => void;
  onDownloadPdf?: () => void;
  onPublishBook?: () => void;
  onTranslateBook?: (targetLang: string) => void;
  modelProvider?: string;
  customGeminiKey?: string;
  customDeepseekKey?: string;
}

export const AutonomousVoiceCoPilot: React.FC<AutonomousVoiceCoPilotProps> = ({
  lang,
  currentUser,
  currentBook,
  onNavigateTab,
  onExecuteBookCreation,
  onDownloadPdf,
  onPublishBook,
  onTranslateBook,
  modelProvider = "gemini",
  customGeminiKey,
  customDeepseekKey,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [lastAction, setLastAction] = useState<string | null>(null);
  const [spokenResponse, setSpokenResponse] = useState<string>("");
  const [simulatedLevel, setSimulatedLevel] = useState<number>(0);
  const [speechLanguage, setSpeechLanguage] = useState<"bn-BD" | "en-US">(lang === "bn" ? "bn-BD" : "en-US");
  
  // Multimodal Vision Image State
  const [attachedImage, setAttachedImage] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const isMountedRef = useRef(true);
  const isActiveRef = useRef(false);
  const isSpeakingRef = useRef(false);
  const isProcessingRef = useRef(false);
  const silenceTimerRef = useRef<any>(null);
  const currentTranscriptRef = useRef<string>("");
  const cancelAudioRef = useRef<(() => void) | null>(null);
  const waveAnimRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const speechCooldownUntilRef = useRef<number>(0);
  const lastAiSpokenTailRef = useRef<string>("");

  // Sync language with prop when changed
  useEffect(() => {
    setSpeechLanguage(lang === "bn" ? "bn-BD" : "en-US");
  }, [lang]);

  // Visual audio wave dynamic simulation
  useEffect(() => {
    let phase = 0;
    const animateWave = () => {
      if (!isMountedRef.current) return;
      phase += 0.12;

      if (isSpeakingRef.current) {
        setSimulatedLevel(0.65 + Math.sin(phase * 1.8) * 0.3);
      } else if (isActiveRef.current && currentTranscriptRef.current.length > 0) {
        setSimulatedLevel(0.48 + Math.sin(phase * 2.2) * 0.28);
      } else if (isActiveRef.current) {
        setSimulatedLevel(0.15 + Math.sin(phase * 0.7) * 0.08);
      } else {
        setSimulatedLevel(0);
      }

      waveAnimRef.current = requestAnimationFrame(animateWave);
    };

    waveAnimRef.current = requestAnimationFrame(animateWave);
    return () => {
      if (waveAnimRef.current) cancelAnimationFrame(waveAnimRef.current);
    };
  }, []);

  // Safe Recognition Spawner - Always creates a clean new instance
  const startFreshRecognition = useCallback(() => {
    if (!isMountedRef.current || !isActiveRef.current || isSpeakingRef.current || isProcessingRef.current) {
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
      recognitionRef.current = null;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = speechLanguage;

    recognition.onstart = () => {
      if (!isMountedRef.current || !isActiveRef.current || isSpeakingRef.current || isProcessingRef.current) return;
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      if (!isActiveRef.current || isSpeakingRef.current || isProcessingRef.current) return;
      if (Date.now() < speechCooldownUntilRef.current) return;

      let interim = "";
      let final = "";
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) final += event.results[i][0].transcript;
        else interim += event.results[i][0].transcript;
      }
      const text = (final || interim).trim();
      if (text && text.length >= 2) {
        // Acoustic echo check
        if (lastAiSpokenTailRef.current && lastAiSpokenTailRef.current.includes(text.toLowerCase())) {
          return;
        }

        setTranscript(text);
        currentTranscriptRef.current = text;

        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = setTimeout(() => {
          if (currentTranscriptRef.current.trim().length >= 2 && isActiveRef.current && !isSpeakingRef.current && !isProcessingRef.current) {
            const captured = currentTranscriptRef.current.trim();
            currentTranscriptRef.current = "";
            processVoiceCommand(captured);
          }
        }, 1100);
      }
    };

    recognition.onerror = (event: any) => {
      console.log("Boss voice recognition note:", event.error);
      if (event.error === "not-allowed") {
        setIsListening(false);
        setIsProcessing(false);
        return;
      }
    };

    recognition.onend = () => {
      if (!isMountedRef.current) return;
      setIsListening(false);

      // Auto-restart loop if session is ON and AI is not speaking/processing
      if (isActiveRef.current && !isSpeakingRef.current && !isProcessingRef.current) {
        setTimeout(() => {
          if (isActiveRef.current && !isSpeakingRef.current && !isProcessingRef.current) {
            startFreshRecognition();
          }
        }, 200);
      }
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
    } catch (err) {
      console.warn("Recognition start catch:", err);
    }
  }, [speechLanguage]);

  // Dual-Layer Vocal Speech Engine (Plays Google TTS Audio Aloud with Web Speech Fallback)
  const speakAloud = useCallback((text: string) => {
    if (!text || !isActiveRef.current) {
      setIsProcessing(false);
      isProcessingRef.current = false;
      setIsAiSpeaking(false);
      isSpeakingRef.current = false;
      return;
    }

    if (cancelAudioRef.current) {
      cancelAudioRef.current();
      cancelAudioRef.current = null;
    }

    // Stop microphone during AI speech
    isSpeakingRef.current = true;
    setIsAiSpeaking(true);
    setIsProcessing(false);
    isProcessingRef.current = false;
    setIsListening(false);

    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
    }

    lastAiSpokenTailRef.current = text.toLowerCase().slice(-100);

    cancelAudioRef.current = playSpokenAudioAloud(text, speechLanguage, {
      onStart: () => {
        if (!isMountedRef.current) return;
        setIsAiSpeaking(true);
        isSpeakingRef.current = true;
      },
      onEnd: () => {
        if (!isMountedRef.current) return;
        isSpeakingRef.current = false;
        setIsAiSpeaking(false);
        currentTranscriptRef.current = "";
        setTranscript("");
        speechCooldownUntilRef.current = Date.now() + 650;

        // CONTINUOUS RE-ENGAGE: Safely start fresh recognition session after speaker cools down!
        if (isActiveRef.current) {
          setTimeout(() => {
            if (isActiveRef.current && !isSpeakingRef.current && !isProcessingRef.current) {
              startFreshRecognition();
            }
          }, 650);
        }
      },
      onError: () => {
        if (!isMountedRef.current) return;
        isSpeakingRef.current = false;
        setIsAiSpeaking(false);
        speechCooldownUntilRef.current = Date.now() + 500;
        if (isActiveRef.current) {
          setTimeout(() => {
            if (isActiveRef.current && !isSpeakingRef.current && !isProcessingRef.current) {
              startFreshRecognition();
            }
          }, 500);
        }
      }
    });
  }, [speechLanguage, startFreshRecognition]);

  // Process Spoken User Command / Image input
  const processVoiceCommand = async (userText: string, imageOverride?: string | null) => {
    const textToProcess = userText.trim();
    const imageToUse = imageOverride !== undefined ? imageOverride : attachedImage;

    if (!textToProcess && !imageToUse) return;
    if (!isActiveRef.current) return;

    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
    }

    setIsListening(false);
    setIsProcessing(true);
    isProcessingRef.current = true;
    setTranscript(textToProcess || (speechLanguage.startsWith("bn") ? "ছবি বিশ্লেষণ করা হচ্ছে..." : "Analyzing attached image..."));
    currentTranscriptRef.current = "";

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (modelProvider) headers["x-model-provider"] = modelProvider;
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const res = await fetch("/api/voice-executive", {
        method: "POST",
        headers,
        body: JSON.stringify({
          userSpeech: textToProcess || "Please inspect this attached image and explain what you see.",
          language: speechLanguage.startsWith("bn") ? "Bengali" : "English",
          imageData: imageToUse,
          currentContext: {
            bookTitle: currentBook?.title || "",
            genre: currentBook?.genre || "",
            developer: "Omar Faruk Masud"
          }
        })
      });

      if (!res.ok) throw new Error(`Status ${res.status}`);
      const data = await res.json();
      const action = data.action || "CHAT";
      const reply = data.spokenReply || (speechLanguage.startsWith("bn") ? "জী বস, কাজ সম্পন্ন হয়েছে।" : "Yes Boss, executed.");

      setLastAction(action);
      setSpokenResponse(reply);

      // Play vocal response aloud
      if (isActiveRef.current) {
        speakAloud(reply);
      }

      // Execute Action on the application
      if (action === "CREATE_BOOK") {
        const topic = data.bookParams?.topic || textToProcess;
        const genre = data.bookParams?.genre || "Fiction";
        const prompt = data.bookParams?.prompt || textToProcess;
        const count = data.bookParams?.chapterCount || 5;
        onNavigateTab("editor");
        onExecuteBookCreation(topic, genre, prompt, count);
      } else if (action === "NAVIGATE") {
        const targetTab = data.navigationParams?.targetTab || "editor";
        onNavigateTab(targetTab as any);
      } else if (action === "DOWNLOAD_PDF") {
        if (onDownloadPdf) onDownloadPdf();
      } else if (action === "PUBLISH_BOOK") {
        if (onPublishBook) onPublishBook();
      } else if (action === "TRANSLATE_BOOK") {
        const targetLang = data.translationParams?.targetLanguage || "English";
        if (onTranslateBook) onTranslateBook(targetLang);
      }
    } catch (err: any) {
      console.warn("Voice executive error:", err);
      const fallbackReply = speechLanguage.startsWith("bn")
        ? "জী বস, আমি শুনতে পেয়েছি। দয়া করে বলুন কীভাবে সাহায্য করব।" 
        : "Yes Boss, I hear you. Please tell me how I can help.";
      setSpokenResponse(fallbackReply);
      if (isActiveRef.current) {
        speakAloud(fallbackReply);
      }
    } finally {
      setIsProcessing(false);
      isProcessingRef.current = false;
    }
  };

  // Image Upload Handler
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64Url = reader.result as string;
      setAttachedImage(base64Url);
      if (speechLanguage.startsWith("bn")) {
        setSpokenResponse("ছবি যুক্ত হয়েছে বস! এবার মুখে বলুন ছবি নিয়ে কী জানতে চান বা 'ছবিটি ব্যাখ্যা করো' বলুন।");
        speakAloud("ছবি যুক্ত হয়েছে বস! বলুন ছবি নিয়ে কী সাহায্য করব।");
      } else {
        setSpokenResponse("Image attached Boss! Speak your question about this image.");
        speakAloud("Image attached Boss! Ask me anything about this image.");
      }
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  // Toggle Assistant On/Off
  const toggleAssistant = () => {
    if (isOpen) {
      // Turn OFF
      setIsOpen(false);
      setIsListening(false);
      setIsAiSpeaking(false);
      isActiveRef.current = false;
      isSpeakingRef.current = false;
      isProcessingRef.current = false;
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (recognitionRef.current) {
        try { recognitionRef.current.abort(); } catch (e) {}
        recognitionRef.current = null;
      }
      if (cancelAudioRef.current) {
        cancelAudioRef.current();
        cancelAudioRef.current = null;
      }
      stopAllSpokenAudio();
    } else {
      // Unlock Audio Permissions immediately on touch/click gesture
      unlockAudioAutoplay();

      setIsOpen(true);
      isActiveRef.current = true;
      isSpeakingRef.current = false;
      isProcessingRef.current = false;
      setTranscript("");
      setSpokenResponse(
        speechLanguage.startsWith("bn")
          ? "বস, আমি শুনছি... আপনার আদেশ বলুন..."
          : "Listening Boss... give your command..."
      );
      startFreshRecognition();
    }
  };

  // Switch voice language
  const handleToggleLanguage = () => {
    const nextLang = speechLanguage === "bn-BD" ? "en-US" : "bn-BD";
    setSpeechLanguage(nextLang);
    if (recognitionRef.current) {
      try { recognitionRef.current.abort(); } catch (e) {}
    }
    setTimeout(() => {
      if (isActiveRef.current) {
        startFreshRecognition();
      }
    }, 200);
  };

  // Manual Instant Submit
  const handleManualSubmit = () => {
    if (transcript.trim() || attachedImage) {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      processVoiceCommand(transcript.trim());
    }
  };

  // Heartbeat Watchdog: Prevents microphone dropouts
  useEffect(() => {
    const heartbeat = setInterval(() => {
      if (isActiveRef.current && !isSpeakingRef.current && !isProcessingRef.current && !isListening) {
        startFreshRecognition();
      }
    }, 1500);
    return () => clearInterval(heartbeat);
  }, [isListening, startFreshRecognition]);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
      isActiveRef.current = false;
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (cancelAudioRef.current) {
        cancelAudioRef.current();
      }
      stopAllSpokenAudio();
    };
  }, []);

  return (
    <>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleImageFileChange}
      />

      {/* Persistent Floating AI Orb on bottom right */}
      <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 print:hidden">
        {/* Floating Command Hub when Active */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.92 }}
              transition={{ type: "spring", stiffness: 350, damping: 25 }}
              className="bg-gradient-to-b from-slate-950/98 via-slate-900/95 to-slate-950/98 backdrop-blur-2xl border-2 border-amber-500/40 text-white rounded-3xl p-4 shadow-[0_20px_50px_rgba(0,0,0,0.6)] w-80 sm:w-[420px] flex flex-col space-y-3 font-sans relative overflow-hidden"
            >
              {/* Background ambient glow */}
              <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-rose-500/15 rounded-full blur-3xl pointer-events-none" />

              {/* Header */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5 relative z-10">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-amber-400 flex items-center justify-center text-slate-950 shadow-[0_0_15px_rgba(245,158,11,0.5)]">
                    <Radio size={16} className={isListening ? "animate-pulse text-black" : "text-black"} />
                  </div>
                  <div>
                    <h3 className="text-xs font-black text-amber-400 flex items-center gap-1.5 tracking-tight">
                      <span>{speechLanguage.startsWith("bn") ? "ভয়েস এক্সিকিউটিভ (Boss Mode)" : "Voice Executive (Boss Mode)"}</span>
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded-md border border-emerald-500/40 font-black animate-pulse">
                        LIVE
                      </span>
                    </h3>
                    <p className="text-[9px] text-slate-400 font-bold flex items-center gap-1">
                      <span>Dev: Omar Faruk Masud</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Image Attachment Upload Button */}
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className={`p-1.5 rounded-lg border text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                      attachedImage 
                        ? "bg-amber-500 text-slate-950 border-amber-400" 
                        : "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
                    }`}
                    title={speechLanguage.startsWith("bn") ? "ছবি আপলোড করুন" : "Upload image for AI vision"}
                  >
                    <ImageIcon size={13} />
                    <span className="text-[10px]">{attachedImage ? "1" : "+"}</span>
                  </button>

                  {/* Language Switch Button */}
                  <button
                    onClick={handleToggleLanguage}
                    className="text-[10px] font-black bg-slate-800 hover:bg-slate-700 text-amber-300 px-2 py-1 rounded-lg border border-slate-700 transition cursor-pointer"
                    title="Switch Speech Language"
                  >
                    {speechLanguage === "bn-BD" ? "বাংলা" : "EN"}
                  </button>

                  <button
                    onClick={toggleAssistant}
                    className="p-1 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
                    title="Close Voice Assistant"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>

              {/* ATTACHED IMAGE PREVIEW (IF ANY) */}
              {attachedImage && (
                <div className="relative bg-slate-900 border border-amber-500/30 rounded-xl p-2 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 overflow-hidden">
                    <img src={attachedImage} alt="Attachment" className="w-12 h-12 object-cover rounded-lg border border-slate-700 shrink-0" />
                    <div className="text-[11px] text-amber-200 truncate">
                      <p className="font-bold">{speechLanguage.startsWith("bn") ? "📷 ছবি যুক্ত আছে" : "📷 Image Ready"}</p>
                      <p className="text-[9px] text-slate-400">{speechLanguage.startsWith("bn") ? "ছবি দেখে উত্তর দিতে প্রস্তুত" : "AI Vision active"}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setAttachedImage(null)}
                    className="p-1.5 hover:bg-rose-900/50 text-rose-400 rounded-lg transition cursor-pointer"
                    title="Remove image"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              )}

              {/* Spoken Status & Sound Waveform Display */}
              <div className="bg-slate-900/90 rounded-2xl p-3 border border-slate-800/80 space-y-2.5 relative z-10 shadow-inner">
                {/* Visual Audio Soundwave Canvas */}
                <div className="flex items-center justify-center gap-1.5 h-10 px-2 bg-black/40 rounded-xl border border-slate-800">
                  {Array.from({ length: 20 }).map((_, idx) => {
                    const waveHeight = isAiSpeaking
                      ? Math.max(6, Math.sin(idx * 0.4 + Date.now() * 0.02) * 26 + 14)
                      : isListening
                      ? Math.max(4, Math.sin(idx * 0.5) * 22 * (simulatedLevel + 0.4) + 6)
                      : 6;

                    return (
                      <motion.div
                        key={idx}
                        className={`w-1.5 rounded-full transition-all duration-75 ${
                          isAiSpeaking 
                            ? "bg-gradient-to-t from-purple-500 to-pink-400" 
                            : isListening 
                            ? "bg-gradient-to-t from-emerald-500 to-amber-400" 
                            : "bg-slate-700"
                        }`}
                        style={{ height: `${waveHeight}px` }}
                      />
                    );
                  })}
                </div>

                {/* AI Spoken Voice Response Message */}
                <div className="min-h-[44px] flex items-center justify-center text-center p-2 rounded-xl bg-slate-950/60 border border-slate-800/80">
                  {isProcessing ? (
                    <p className="text-xs text-amber-400 animate-pulse font-medium">
                      {speechLanguage === "bn-BD" ? "প্রসেস হচ্ছে ও উত্তর তৈরি হচ্ছে..." : "Processing response..."}
                    </p>
                  ) : (
                    <p className="text-xs text-slate-200 font-medium leading-relaxed">
                      "{spokenResponse || (speechLanguage === "bn-BD" ? "বস, আপনার যে কোনো আদেশ বলুন..." : "Give any voice command...")}"
                    </p>
                  )}
                </div>

                {/* User Real-Time Transcribed Speech Display */}
                {transcript && (
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-2 flex items-center justify-between gap-2">
                    <p className="text-xs text-amber-200 italic line-clamp-2">
                      🎤 "{transcript}"
                    </p>
                    <button
                      onClick={handleManualSubmit}
                      disabled={isProcessing}
                      className="p-1.5 bg-amber-500 text-slate-950 rounded-lg hover:bg-amber-400 transition cursor-pointer shrink-0"
                      title="Execute"
                    >
                      <Send size={12} />
                    </button>
                  </div>
                )}
              </div>

              {/* Action Trigger Badge */}
              {lastAction && (
                <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-amber-300 bg-amber-950/40 border border-amber-500/30 px-3 py-1.5 rounded-xl relative z-10">
                  <div className="flex items-center gap-1.5">
                    <Zap size={12} className="text-amber-400 animate-bounce" />
                    <span>Action: {lastAction}</span>
                  </div>
                  <span className="text-[9px] text-emerald-400 lowercase font-mono">executed</span>
                </div>
              )}

              {/* Status Hint Footer */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5 relative z-10">
                <span className="flex items-center gap-1">
                  <span className={`w-2 h-2 rounded-full ${isListening ? "bg-emerald-400 animate-ping" : isAiSpeaking ? "bg-purple-400 animate-pulse" : "bg-amber-400"}`} />
                  <span>{isListening ? (speechLanguage === "bn-BD" ? "মাইক্রোফোন শুনছে..." : "Microphone listening...") : isAiSpeaking ? (speechLanguage === "bn-BD" ? "কথা বলছে..." : "Speaking back...") : (speechLanguage === "bn-BD" ? "প্রসেস হচ্ছে..." : "Processing...")}</span>
                </span>
                <span className="text-slate-500 text-[9px]">
                  {speechLanguage === "bn-BD" ? "অটোমেটিক হ্যান্ডস-ফ্রি" : "Continuous Hands-Free"}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* The Holographic Glowing Voice Trigger Orb */}
        <motion.button
          whileHover={{ scale: 1.08 }}
          whileTap={{ scale: 0.92 }}
          onClick={toggleAssistant}
          className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-2xl transition-all duration-300 cursor-pointer relative overflow-hidden border-2 z-50 ${
            isOpen 
              ? "bg-gradient-to-tr from-rose-600 via-rose-500 to-amber-500 border-rose-300 shadow-[0_0_25px_rgba(225,29,72,0.6)] ring-4 ring-rose-500/30" 
              : "bg-gradient-to-tr from-[#7c2d12] via-amber-600 to-amber-500 border-amber-300 shadow-[0_0_25px_rgba(245,158,11,0.5)] hover:shadow-[0_0_35px_rgba(245,158,11,0.8)] ring-2 ring-amber-400/30"
          }`}
          title={lang === "bn" ? "বস ভয়েস অ্যাসিস্ট্যান্ট চালু/বন্ধ করুন" : "Toggle Boss Voice Assistant"}
        >
          {/* Animated Glow Rings */}
          <div className="absolute inset-0 bg-white/20 rounded-2xl animate-ping opacity-25 pointer-events-none" />
          
          {isOpen ? (
            <MicOff size={22} className="text-white drop-shadow" />
          ) : (
            <div className="relative flex items-center justify-center">
              <Mic size={22} className="text-amber-100 drop-shadow" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
            </div>
          )}
        </motion.button>
      </div>
    </>
  );
};
