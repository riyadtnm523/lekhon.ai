import React, { useState, useRef } from "react";
import { Award, Feather, BookOpen, Sparkles, Star, Zap, Shield, Crown, Share2, Download, Check, Edit2, Camera, Image, Upload, User } from "lucide-react";
import { motion } from "motion/react";

export const PRESET_AVATARS = [
  { id: "writer_1", name: "Classic Scribe", url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80" },
  { id: "writer_2", name: "Cosmic Poet", url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80" },
  { id: "writer_3", name: "Tech Novelist", url: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80" },
  { id: "writer_4", name: "Vintage Author", url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80" },
  { id: "writer_5", name: "Fantasy Storyteller", url: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80" },
  { id: "writer_6", name: "Cyberpunk Bard", url: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80" },
];

interface Animated3DProfileCardProps {
  displayName: string;
  loginId?: string;
  email?: string;
  role?: string;
  photoURL?: string;
  booksCount: number;
  totalChapters: number;
  totalWordsEstimated: number;
  lang: "bn" | "en";
  onEditName?: () => void;
  onUpdatePhoto?: (newPhotoUrl: string) => void;
  isReadOnly?: boolean;
}

export const Animated3DProfileCard: React.FC<Animated3DProfileCardProps> = ({
  displayName,
  loginId,
  email,
  role = "Author",
  photoURL,
  booksCount,
  totalChapters,
  totalWordsEstimated,
  lang,
  onEditName,
  onUpdatePhoto,
  isReadOnly = false
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glarePosition, setGlarePosition] = useState({ x: 50, y: 50 });
  const [avatarTheme, setAvatarTheme] = useState<"gold" | "crimson" | "cosmic" | "emerald">("gold");
  const [copiedId, setCopiedId] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  const [customPhotoInput, setCustomPhotoInput] = useState("");

  // Real-time dynamic author progression system
  const wordsCount = totalWordsEstimated || (booksCount * 3500);
  const activityScore = (booksCount * 180) + (totalChapters * 40) + Math.floor(wordsCount / 60);
  const currentLevel = Math.max(1, Math.floor(Math.sqrt(activityScore / 20)) + 1);
  const currentLevelMinScore = (currentLevel - 1) * (currentLevel - 1) * 20;
  const nextLevelMinScore = currentLevel * currentLevel * 20;
  const scoreInCurrentLevel = Math.max(0, activityScore - currentLevelMinScore);
  const scoreNeededForNextLevel = Math.max(1, nextLevelMinScore - currentLevelMinScore);
  const xpPercent = Math.min(100, Math.max(8, Math.round((scoreInCurrentLevel / scoreNeededForNextLevel) * 100)));

  const getAuthorRank = (lvl: number, langKey: "bn" | "en") => {
    if (lvl >= 16) return langKey === "bn" ? "মহাজ্ঞানী কালজয়ী লেখক (Grandmaster)" : "Grandmaster Polymath";
    if (lvl >= 10) return langKey === "bn" ? "মাস্টার সাহিত্যিক (Master Author)" : "Master Novelist";
    if (lvl >= 6) return langKey === "bn" ? "খ্যাতনামা কথাসাহিত্যিক (Prolific)" : "Prolific Author";
    if (lvl >= 3) return langKey === "bn" ? "দক্ষ গ্রন্থকার (Creative Writer)" : "Creative Scribe";
    return langKey === "bn" ? "শিক্ষানবিস লেখক (Novice Author)" : "Novice Scribe";
  };

  const authorRank = getAuthorRank(currentLevel, lang);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rX = ((y - centerY) / centerY) * -12; // tilt max 12deg
    const rY = ((x - centerX) / centerX) * 12;

    setRotateX(rX);
    setRotateY(rY);
    setGlarePosition({
      x: (x / rect.width) * 100,
      y: (y / rect.height) * 100
    });
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
  };

  const copyLoginProof = () => {
    if (loginId) {
      navigator.clipboard.writeText(loginId);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onUpdatePhoto) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        onUpdatePhoto(dataUrl);
        setShowAvatarPicker(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleApplyCustomUrl = () => {
    if (customPhotoInput.trim() && onUpdatePhoto) {
      onUpdatePhoto(customPhotoInput.trim());
      setCustomPhotoInput("");
      setShowAvatarPicker(false);
    }
  };

  // Avatar themes styling
  const themes = {
    gold: {
      gradient: "from-amber-600 via-[#7c2d12] to-amber-950",
      accent: "text-amber-300",
      border: "border-amber-500/40",
      glow: "rgba(245, 158, 11, 0.25)"
    },
    crimson: {
      gradient: "from-rose-700 via-purple-900 to-slate-950",
      accent: "text-rose-300",
      border: "border-rose-500/40",
      glow: "rgba(225, 29, 72, 0.25)"
    },
    cosmic: {
      gradient: "from-indigo-700 via-purple-900 to-slate-950",
      accent: "text-indigo-300",
      border: "border-indigo-500/40",
      glow: "rgba(99, 102, 241, 0.25)"
    },
    emerald: {
      gradient: "from-emerald-700 via-teal-900 to-slate-950",
      accent: "text-emerald-300",
      border: "border-emerald-500/40",
      glow: "rgba(16, 185, 129, 0.25)"
    }
  };

  const currentTheme = themes[avatarTheme];

  return (
    <div className="space-y-4 font-sans">
      {/* 3D Interactive Card Container */}
      <div style={{ perspective: 1000 }} className="w-full">
        <motion.div
          ref={cardRef}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          animate={{
            rotateX: rotateX,
            rotateY: rotateY
          }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          style={{ transformStyle: "preserve-3d" }}
          className={`w-full rounded-3xl p-6 sm:p-7 text-white shadow-2xl relative overflow-hidden select-none border ${currentTheme.border} bg-gradient-to-br ${currentTheme.gradient}`}
        >
          {/* Dynamic 3D Glare Lighting Effect */}
          <div
            className="absolute inset-0 pointer-events-none transition-opacity duration-200"
            style={{
              background: `radial-gradient(circle at ${glarePosition.x}% ${glarePosition.y}%, rgba(255,255,255,0.2) 0%, transparent 60%)`
            }}
          />

          {/* Micro Geometric Lines / Watermark */}
          <div className="absolute -right-8 -bottom-8 opacity-10 pointer-events-none">
            <Crown size={200} />
          </div>

          <div className="relative z-10 space-y-6">
            
            {/* Top Bar: Insignia & Badge */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-white/10 backdrop-blur-md rounded-xl border border-white/20">
                  <Feather size={18} className={currentTheme.accent} />
                </div>
                <div>
                  <span className="text-[10px] font-black tracking-widest uppercase opacity-80 block">
                    {lang === "bn" ? "লেখক পরিচয়পত্র" : "Author Identity Card"}
                  </span>
                  <span className="text-xs font-extrabold text-amber-200">
                    Lekhok AI Official
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/30 border border-white/20 backdrop-blur-md">
                <Crown size={12} className="text-amber-300" />
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-200">
                  {authorRank}
                </span>
              </div>
            </div>

            {/* Middle Section: 3D Glowing Avatar with Photo Upload & Author Info */}
            <div className="flex items-center gap-4">
              <div className="relative group shrink-0">
                {photoURL && photoURL.trim() !== "" ? (
                  <img
                    src={photoURL}
                    alt={displayName || "Author"}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-white/40 shadow-xl"
                    style={{ boxShadow: `0 10px 30px ${currentTheme.glow}` }}
                  />
                ) : (
                  <div 
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-white/20 to-white/5 border-2 border-white/40 backdrop-blur-lg flex items-center justify-center text-2xl sm:text-3xl font-black text-white shadow-xl"
                    style={{ boxShadow: `0 10px 30px ${currentTheme.glow}` }}
                  >
                    {(displayName || email || "A")[0].toUpperCase()}
                  </div>
                )}

                {/* Change Avatar Button */}
                {!isReadOnly && onUpdatePhoto && (
                  <button
                    onClick={() => setShowAvatarPicker(!showAvatarPicker)}
                    className="absolute -bottom-1 -right-1 bg-amber-400 hover:bg-amber-300 text-amber-950 p-1.5 rounded-full border-2 border-slate-900 shadow-md transition cursor-pointer"
                    title={lang === "bn" ? "ছবি পরিবর্তন করুন" : "Change Profile Photo"}
                  >
                    <Camera size={11} className="fill-current" />
                  </button>
                )}
              </div>

              <div className="flex-1 min-w-0 text-left space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg sm:text-xl font-black tracking-tight text-white truncate">
                    {displayName || (email ? email.split("@")[0] : "Author")}
                  </h3>
                  {!isReadOnly && onEditName && (
                    <button
                      onClick={onEditName}
                      className="p-1 hover:bg-white/10 rounded-lg text-amber-200 transition cursor-pointer"
                      title={lang === "bn" ? "নাম পরিবর্তন করুন" : "Edit Name"}
                    >
                      <Edit2 size={12} />
                    </button>
                  )}
                </div>

                {loginId && (
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono font-bold bg-black/40 px-2 py-0.5 rounded-md border border-white/10 text-amber-200">
                      ID: {loginId}
                    </span>
                    <button
                      onClick={copyLoginProof}
                      className="p-1 hover:bg-white/10 rounded text-[10px] font-bold text-amber-300 flex items-center gap-1 cursor-pointer transition"
                    >
                      {copiedId ? <Check size={10} className="text-emerald-400" /> : <Share2 size={10} />}
                      <span>{copiedId ? (lang === "bn" ? "কপি হয়েছে!" : "Copied!") : (lang === "bn" ? "কপি আইডি" : "Copy")}</span>
                    </button>
                  </div>
                )}

                {email && (
                  <p className="text-[11px] text-white/70 truncate font-mono">
                    {email}
                  </p>
                )}
              </div>
            </div>

            {/* Author XP Progress */}
            <div className="space-y-1.5 bg-black/25 p-3 rounded-2xl border border-white/10 backdrop-blur-xs">
              <div className="flex justify-between items-center text-[10px] font-bold">
                <span className="text-amber-200 uppercase tracking-wider flex items-center gap-1">
                  <Star size={11} className="fill-amber-300 text-amber-300" />
                  {lang === "bn" ? "রিয়েল-টাইম লেখক লেভেল ও এক্সপি" : "Real-Time Author Level & XP"}
                </span>
                <span className="font-mono text-white font-black">{xpPercent}% • Level {currentLevel}</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${xpPercent}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                  className="bg-gradient-to-r from-amber-400 via-amber-300 to-amber-100 h-full rounded-full shadow-md"
                />
              </div>
            </div>

            {/* 3D Bento Mini Stats */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3 text-center">
              <div className="bg-black/30 backdrop-blur-md p-2.5 rounded-xl border border-white/10 space-y-0.5">
                <span className="text-base sm:text-lg font-black text-white block">
                  {booksCount}
                </span>
                <span className="text-[9px] font-extrabold uppercase tracking-wider text-amber-200">
                  {lang === "bn" ? "বই রচিত" : "Books"}
                </span>
              </div>

              <div className="bg-black/30 backdrop-blur-md p-2.5 rounded-xl border border-white/10 space-y-0.5">
                <span className="text-base sm:text-lg font-black text-white block">
                  {totalChapters}
                </span>
                <span className="text-[9px] font-extrabold uppercase tracking-wider text-amber-200">
                  {lang === "bn" ? "অধ্যায়" : "Chapters"}
                </span>
              </div>

              <div className="bg-black/30 backdrop-blur-md p-2.5 rounded-xl border border-white/10 space-y-0.5">
                <span className="text-base sm:text-lg font-black text-white block">
                  {(totalWordsEstimated || booksCount * 4500).toLocaleString()}
                </span>
                <span className="text-[9px] font-extrabold uppercase tracking-wider text-amber-200">
                  {lang === "bn" ? "শব্দ সংখ্যা" : "Words"}
                </span>
              </div>
            </div>

          </div>
        </motion.div>
      </div>

      {/* Avatar Picker Modal / Drawer */}
      {showAvatarPicker && !isReadOnly && (
        <div className="bg-white border-2 border-amber-300 rounded-2xl p-4 shadow-lg space-y-3 animate-fadeIn text-left text-slate-800">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <Camera size={14} className="text-[#7c2d12]" />
              <span>{lang === "bn" ? "প্রোফাইল ছবি সেট করুন" : "Set Author Profile Picture"}</span>
            </h4>
            <button
              onClick={() => setShowAvatarPicker(false)}
              className="text-xs text-slate-400 hover:text-slate-700 font-bold"
            >
              ✕
            </button>
          </div>

          {/* Preset Avatars */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
              {lang === "bn" ? "পছন্দের প্রিসেট অবতার চয়ন করুন:" : "Choose from preset avatars:"}
            </label>
            <div className="grid grid-cols-6 gap-2">
              {PRESET_AVATARS.map((av) => (
                <button
                  key={av.id}
                  onClick={() => {
                    onUpdatePhoto?.(av.url);
                    setShowAvatarPicker(false);
                  }}
                  className={`relative rounded-xl overflow-hidden border-2 transition cursor-pointer hover:scale-105 ${
                    photoURL === av.url ? "border-amber-500 ring-2 ring-amber-400" : "border-slate-200"
                  }`}
                  title={av.name}
                >
                  <img src={av.url} alt={av.name} className="w-full h-12 object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Upload Custom File */}
          <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 py-2 bg-amber-50 hover:bg-amber-100 text-[#7c2d12] border border-amber-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <Upload size={13} />
              <span>{lang === "bn" ? "ডিভাইস থেকে ফটো আপলোড" : "Upload from Device"}</span>
            </button>

            {photoURL && (
              <button
                onClick={() => {
                  onUpdatePhoto?.("");
                  setShowAvatarPicker(false);
                }}
                className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-xl text-xs font-bold transition cursor-pointer"
                title={lang === "bn" ? "ছবি মুছে দিন" : "Remove Photo"}
              >
                ✕
              </button>
            )}
          </div>

          {/* Or enter Image URL */}
          <div className="flex gap-2">
            <input
              type="url"
              value={customPhotoInput}
              onChange={(e) => setCustomPhotoInput(e.target.value)}
              placeholder="https://example.com/photo.jpg"
              className="flex-1 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl text-[11px] font-medium focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
            <button
              onClick={handleApplyCustomUrl}
              disabled={!customPhotoInput.trim()}
              className="px-3 py-1.5 bg-[#7c2d12] text-amber-50 rounded-xl text-[11px] font-bold disabled:opacity-50 cursor-pointer"
            >
              {lang === "bn" ? "সেট" : "Set"}
            </button>
          </div>
        </div>
      )}

      {/* 3D Card Theme Switcher */}
      <div className="flex items-center justify-between bg-white border border-amber-200/80 p-2.5 rounded-2xl shadow-xs">
        <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 pl-1">
          {lang === "bn" ? "কার্ড থিম ও আলো" : "3D Card Hologram"}
        </span>
        <div className="flex gap-1.5">
          {(["gold", "crimson", "cosmic", "emerald"] as const).map((th) => (
            <button
              key={th}
              onClick={() => setAvatarTheme(th)}
              className={`w-6 h-6 rounded-full border-2 transition cursor-pointer ${
                avatarTheme === th ? "border-slate-900 scale-110 shadow-sm" : "border-transparent opacity-60 hover:opacity-100"
              }`}
              style={{
                background:
                  th === "gold"
                    ? "linear-gradient(135deg, #d97706, #78350f)"
                    : th === "crimson"
                    ? "linear-gradient(135deg, #e11d48, #881337)"
                    : th === "cosmic"
                    ? "linear-gradient(135deg, #6366f1, #312e81)"
                    : "linear-gradient(135deg, #10b981, #064e3b)"
              }}
              title={th}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
