import React, { useState, useRef } from "react";
import {
  GitFork, Printer, Sparkles, Image, FileUp, Download, Copy, Check,
  ChevronDown, ChevronRight, HelpCircle, BookOpen, Layers, RefreshCw,
  Search, Eye, ZoomIn, ZoomOut, Maximize2, Minimize2, Lightbulb,
  CheckCircle2, ArrowRight, Share2, Compass, Cpu, Mic, MicOff,
  Instagram, Linkedin, Twitter, Sparkle, Sliders, Smartphone, Monitor,
  LayoutGrid, ChevronLeft, DownloadCloud, ExternalLink, Zap
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import html2canvas from "html2canvas";

export interface ChartExample {
  text: string;
  translation?: string;
  highlight?: string;
}

export interface ChartNode {
  id: string;
  title: string;
  subtitle?: string;
  description: string;
  level: number; // 0 = Root, 1 = Branch, 2 = Sub-branch, 3 = Detail
  badge?: string;
  formula?: string;
  rules?: string[];
  examples?: ChartExample[];
  tips?: string[];
  color?: string;
  icon?: string;
  subNodes?: ChartNode[];
}

export interface ComparativeTableRow {
  branch: string;
  subBranch: string;
  structure: string;
  example: string;
  keyIdentifier: string;
}

export interface PracticeQuestion {
  question: string;
  options?: string[];
  answer: string;
  explanation: string;
}

export interface LearningChartData {
  id: string;
  title: string;
  conceptCategory: string;
  language: string;
  summary: string;
  rootNode: ChartNode;
  keyTakeaways: string[];
  comparativeSummaryTable: ComparativeTableRow[];
  practiceQuestions: PracticeQuestion[];
  createdAt: string;
}

interface LearningChartStudioProps {
  lang: "bn" | "en";
  currentUser?: any;
  customGeminiKey?: string;
  customDeepseekKey?: string;
  onSendToBookEditor?: (content: string) => void;
}

// Built-in Starter Templates for Instant Visual Learning (including exact match to user's infographic tree)
const STARTER_TEMPLATES: {
  id: string;
  titleBn: string;
  titleEn: string;
  category: string;
  icon: string;
  topic: string;
  data: LearningChartData;
}[] = [
  {
    id: "web_dev_tree",
    titleBn: "ওয়েব ডেভেলপমেন্ট সম্পূর্ণ রোডম্যাপ ও টেকনোলজি স্ট্যাক ট্রি",
    titleEn: "Web Development Architecture & Technology Stack Tree",
    category: "Software Engineering",
    icon: "💻",
    topic: "Web Development Full Stack (Front End vs Back End, APIs, Databases, Frameworks, Languages, Libraries)",
    data: {
      id: "web-dev-tree",
      title: "Web Development Complete Architecture & Tech Tree (ওয়েব ডেভেলপমেন্ট হায়ারার্কি)",
      conceptCategory: "Software Engineering & Web Architecture",
      language: "Bilingual (English & Bengali)",
      summary: "ওয়েব ডেভেলপমেন্ট মূলত দুটি প্রধান স্তম্ভের ওপর দাঁড়িয়ে আছে: Front End (ক্লায়েন্ট সাইড যা ব্যবহারকারী সরাসরি দেখে ও ইন্টারঅ্যাক্ট করে) এবং Back End (সার্ভার সাইড যা ডেটাবেজ, ব্যবসায়িক যুক্তি ও এপিআই প্রক্রিয়াকরণ করে)।",
      keyTakeaways: [
        "Front End মূল ভিত্তি: HTML (কাঠামো), CSS (নকশা ও স্টাইলিং), JavaScript (ইন্টারঅ্যাকশন ও লজিক)।",
        "Front End ফ্রেমওয়ার্ক ও লাইব্রেরি: React, Vue, Angular, Tailwind CSS, Bootstrap ইত্যাদি দ্রুত UI তৈরিতে সহায়তা করে।",
        "Back End আর্কিটেকচার: Server Languages (Node.js/JS, Python, PHP, Java, Ruby), API (REST, GraphQL), এবং Databases।",
        "Databases: Relational (PostgreSQL, MySQL) এবং NoSQL (MongoDB, Redis)।",
        "ফুল-স্ট্যাক ডেভেলপার হতে ফ্রন্টএন্ড, ব্যাকএন্ড, ডেটাবেজ ও এপিআই ইন্টিগ্রেশন আয়ত্ত করতে হয়।"
      ],
      rootNode: {
        id: "root-webdev",
        title: "</> Web Development",
        subtitle: "Full Stack Software Engineering Architecture",
        description: "ওয়েবসাইট ও আধুনিক ওয়েব অ্যাপ্লিকেশন তৈরির পূর্ণাঙ্গ প্রযুক্তিগত কাঠামো।",
        level: 0,
        badge: "মাস্টার আর্কিটেকচার",
        color: "#0284c7",
        icon: "💻",
        subNodes: [
          {
            id: "branch-backend",
            title: "১. Back End (সার্ভার ও ডেটা আর্কিটেকচার)",
            subtitle: "Server-side logic, Data processing & APIs",
            description: "অ্যাপ্লিকেশনের পেছনের ইঞ্জিন যা ডেটা সংরক্ষণ, সিকিউরিটি, ইউজার ভ্যালিডেশন ও সার্ভার প্রসেসিং পরিচালনা করে।",
            level: 1,
            badge: "Server Side",
            color: "#059669",
            icon: "🖥️",
            subNodes: [
              {
                id: "sub-be-api",
                title: "1.1 API (Application Programming Interface)",
                subtitle: "যোগাযোগ ও ডেটা ট্রান্সফার মাধ্যম",
                description: "ক্লায়েন্ট ও সার্ভারের মধ্যে ডেটা আদান-প্রদানের আর্কিটেকচারাল প্রোটোকল।",
                level: 2,
                badge: "Data Gateway",
                formula: "Client (Request) ⇄ API Gateway / Endpoints ⇄ Backend Service ⇄ Database",
                rules: [
                  "REST API: HTTP Methods (GET, POST, PUT, DELETE) এবং JSON পে-লোড ব্যবহার করে।",
                  "GraphQL: ক্লায়েন্ট যা চাইবে ঠিক সেই নির্দিষ্ট ডেটাই রিটার্ন করে (Over-fetching বন্ধ করে)।"
                ],
                examples: [
                  { text: "REST API Endpoint: GET /api/v1/users", translation: "ব্যবহারকারীদের তালিকা পেতে ব্যবহৃত হয়।", highlight: "REST API" },
                  { text: "GraphQL Query: query { user(id: 1) { name, email } }", translation: "শুধুমাত্র নাম ও ইমেইল ফেচ করে।", highlight: "GraphQL" }
                ],
                tips: ["সহজ প্রজেক্টে REST এবং জটিল ইন্টারকানেক্টেড মোবাইল/ওয়েব অ্যাপে GraphQL বেছে নিন।"],
                color: "#10b981",
                subNodes: [
                  { id: "leaf-graphql", title: "GraphQL", subtitle: "Declarative Data Fetching", description: "Facebook উদ্ভাবিত আধুনিক কোয়েরি ল্যাঙ্গুয়েজ।", level: 3, badge: "Modern", color: "#e11d48" },
                  { id: "leaf-rest", title: "REST API", subtitle: "Standard HTTP Endpoints", description: "ইন্ডাস্ট্রি স্ট্যান্ডার্ড স্টেটলেস আর্কিটেকচার।", level: 3, badge: "Standard", color: "#0284c7" }
                ]
              },
              {
                id: "sub-be-db",
                title: "1.2 Database (ডেটাবেজ স্টোরেজ)",
                subtitle: "Persistent Data Storage & Management",
                description: "ব্যবহারকারীর তথ্য, কন্টেন্ট ও সিস্টেম স্টেট দীর্ঘমেয়াদে সংরক্ষণ ও কোয়েরি করার ইঞ্জিন।",
                level: 2,
                badge: "Data Persistence",
                formula: "ACID (SQL Transactions) vs BASE (NoSQL Flexible Scaling)",
                rules: [
                  "Relational SQL: নির্দিষ্ট টেবিল স্কিমা ও ফরেন কী রিলেশনশিপ (PostgreSQL, MySQL)।",
                  "NoSQL Document: ফ্লেক্সিবল JSON-লাইক ডকুমেন্ট স্টোরেজ (MongoDB)।"
                ],
                examples: [
                  { text: "PostgreSQL: SELECT * FROM orders WHERE status = 'paid';", translation: "পেইড অর্ডার তালিকা কোয়েরি।", highlight: "PostgreSQL" },
                  { text: "MongoDB: db.users.find({ age: { $gte: 18 } })", translation: "প্রাপ্তবয়স্ক ইউজার খোঁজা।", highlight: "MongoDB" }
                ],
                tips: ["ব্যাংকিং ও ই-কমার্সে PostgreSQL/MySQL এবং সোশ্যাল ফিড ও চ্যাটে MongoDB/Redis জনপ্রিয়।"],
                color: "#f59e0b",
                subNodes: [
                  { id: "leaf-postgres", title: "PostgreSQL", subtitle: "Advanced Open Source Relational SQL", description: "শক্তিশালী রিলেশনাল ডেটাবেজ।", level: 3, badge: "SQL", color: "#336791" },
                  { id: "leaf-mysql", title: "MySQL", subtitle: "Classic Enterprise Relational SQL", description: "বহুল ব্যবহৃত ক্লাসিক এসকিউএল।", level: 3, badge: "SQL", color: "#f29111" },
                  { id: "leaf-mongo", title: "MongoDB", subtitle: "NoSQL Document Store (JSON/BSON)", description: "দ্রুত ও ফ্লেক্সিবল ডকুমেন্ট ডেটাবেজ।", level: 3, badge: "NoSQL", color: "#13aa52" }
                ]
              },
              {
                id: "sub-be-lang",
                title: "1.3 Language (ব্যাকএন্ড প্রোগ্রামিং ভাষা)",
                subtitle: "Backend Programming Languages & Runtimes",
                description: "সার্ভারের ব্যবসায়িক যুক্তি, সিকিউরিটি ও অ্যালগরিদম লেখার প্রোগ্রামিং ভাষা।",
                level: 2,
                badge: "Core Logic",
                formula: "Source Code ➔ Runtime/VM (V8 / JVM / CPython) ➔ Machine Execution",
                rules: [
                  "JavaScript (Node.js): নন-ব্লকিং ইভেন্ট-ড্রিভেন I/O, ফ্রন্টএন্ড ও ব্যাকএন্ডে একই ভাষা।",
                  "Python: ডেটা সায়েন্স, এআই ও দ্রুত ডেভেলপমেন্টের জন্য সেরা (Django, FastAPI)।",
                  "Java: এন্টারপ্রাইজ স্কেলিং ও হাই-সিকিউরিটি ব্যাংকিং সিস্টেমে নির্ভরযোগ্য।"
                ],
                examples: [
                  { text: "Node.js: app.listen(3000, () => console.log('Ready'))", translation: "এক্সপ্রেস সার্ভার চালু করার কোড।", highlight: "Node.js" },
                  { text: "Python: @app.get('/items') def read_items(): return items", translation: "ফাস্টএপিআই রাউট ডিক্লারেশন।", highlight: "Python" }
                ],
                tips: ["ফুল-স্ট্যাকের দ্রুততম পথ Node.js/TypeScript; এআই প্রজেক্টে Python সেরা।"],
                color: "#6366f1",
                subNodes: [
                  { id: "leaf-node", title: "JavaScript (Node.js)", subtitle: "Event-Driven Asynchronous Runtime", description: "রিয়েল-টাইম অ্যাপের জন্য দ্রুততম।", level: 3, badge: "Runtime", color: "#84ba64" },
                  { id: "leaf-python", title: "Python", subtitle: "AI, ML & Rapid APIs (FastAPI/Django)", description: "সহজ সিনট্যাক্স ও শক্তিশালী লাইব্রেরি।", level: 3, badge: "AI Ready", color: "#3776ab" },
                  { id: "leaf-java", title: "Java", subtitle: "Enterprise Spring Boot Ecosystem", description: "ভারী এন্টারপ্রাইজ সিস্টেমে বহুল ব্যবহৃত।", level: 3, badge: "Enterprise", color: "#ea2d2e" },
                  { id: "leaf-php", title: "PHP", subtitle: "Powering Web & Laravel Framework", description: "ওয়েবের ৮০% ব্যাকএন্ড ইঞ্জিন।", level: 3, badge: "Web Engine", color: "#777bb4" },
                  { id: "leaf-ruby", title: "Ruby", subtitle: "Developer Happiness with Rails", description: "স্টার্টআপদের দ্রুত প্রোটোটাইপিংয়ের জন্য।", level: 3, badge: "Rails", color: "#cc342d" }
                ]
              }
            ]
          },
          {
            id: "branch-frontend",
            title: "২. Front End (ইউজার ইন্টারফেস ও ক্লায়েন্ট সাইড)",
            subtitle: "User Interface, Interactivity & Web Experience",
            description: "ওয়েবসাইটের ভিজ্যুয়াল অংশ যা ব্রাউজারে প্রদর্শিত হয় এবং ইউজার ইন্টারঅ্যাকশন গ্রহণ করে।",
            level: 1,
            badge: "Client Side",
            color: "#0284c7",
            icon: "🖥️",
            subNodes: [
              {
                id: "sub-fe-lang",
                title: "2.1 Core Languages (ফ্রন্টএন্ডের মূল ত্রয়ী)",
                subtitle: "The Three Pillars of the Web",
                description: "ব্রাউজারে যেকোনো পেজ রেন্ডার করার তিনটি মৌলিক বিল্ডিং ব্লক।",
                level: 2,
                badge: "Web Foundations",
                formula: "HTML (Skeleton) + CSS (Skin & Clothes) + JavaScript (Muscles & Brain)",
                rules: [
                  "HTML: পেজের সব কন্টেন্ট ও কাঠামোগত ট্যাগ সংজ্ঞায়িত করে।",
                  "CSS: রঙ, ফন্ট, গ্রিড, ফ্লেক্সবক্স ও রেসপন্সিভ ডিজাইন তৈরি করে।",
                  "JavaScript: ইউজার ক্লিক, এনিমেশন ও ডায়নামিক স্টেট হ্যান্ডেল করে।"
                ],
                examples: [
                  { text: "<button class='btn'>Click</button>", translation: "এইচটিএমএল বাটন ট্যাগ।", highlight: "HTML" },
                  { text: ".btn { background: #0284c7; color: #fff; }", translation: "সিএসএস কালার স্টাইলিং।", highlight: "CSS" },
                  { text: "btn.addEventListener('click', () => alert('Hello'))", translation: "জাভাস্ক্রিপ্ট ইভেন্ট লিসেনার।", highlight: "JavaScript" }
                ],
                tips: ["ফ্রেমওয়ার্ক শেখার আগে ভ্যানিলা জাভাস্ক্রিপ্ট DOM ও ইভেন্ট লুপ ভালোভাবে আয়ত্ত করুন।"],
                color: "#ec4899",
                subNodes: [
                  { id: "leaf-html", title: "HTML5", subtitle: "Semantic Markup & Web Structure", description: "কাঠামোগত উপাদান।", level: 3, badge: "Structure", color: "#e34f26" },
                  { id: "leaf-css", title: "CSS3", subtitle: "Responsive Flexbox, Grid & Animations", description: "ভিজ্যুয়াল স্টাইলিং।", level: 3, badge: "Styling", color: "#1572b6" },
                  { id: "leaf-js", title: "JavaScript", subtitle: "Dynamic Scripting & Web Interactivity", description: "ইন্টারেক্টিভ লজিক।", level: 3, badge: "Engine", color: "#f7df1e" }
                ]
              },
              {
                id: "sub-fe-frameworks",
                title: "2.2 Frameworks (কম্পোনেন্ট ভিত্তিক ফ্রেমওয়ার্ক)",
                subtitle: "Single Page Application (SPA) Engines",
                description: "বড় আকারের স্কেলযোগ্য ওয়েব অ্যাপ্লিকেশন দ্রুত ও সুসংগঠিতভাবে তৈরির ইঞ্জিন।",
                level: 2,
                badge: "UI Architecture",
                formula: "UI = f(State) ➔ Reactive Virtual DOM Rendering",
                rules: [
                  "React: মেটা উদ্ভাবিত কম্পোনেন্ট আর্কিটেকচার ও হুকস ভিত্তিক ইকোসিস্টেম।",
                  "Vue.js: প্রোগ্রেসিভ, সহজে শেখা যায় এমন টু-ওয়ে ডেটা বাইন্ডিং।",
                  "Angular: গুগলের ফুল-ফিচার্ড এন্টারপ্রাইজ টাইপস্ক্রিপ্ট ফ্রেমওয়ার্ক।"
                ],
                examples: [
                  { text: "const [count, setCount] = useState(0);", translation: "রিঅ্যাক্ট স্টেট হুক।", highlight: "React" },
                  { text: "<template><p>{{ message }}</p></template>", translation: "ভিউ টেমপ্লেট সিনট্যাক্স।", highlight: "Vue" }
                ],
                tips: ["চাকরির বাজারে রিঅ্যাক্ট সবচেয়ে এগিয়ে, সহজে শুরু করতে ভিউ চমৎকার।"],
                color: "#8b5cf6",
                subNodes: [
                  { id: "leaf-react", title: "React", subtitle: "Component-Based UI & Virtual DOM (Meta)", description: "গ্লোবালি সবচেয়ে বেশি ব্যবহৃত লাইব্রেরি।", level: 3, badge: "Most Popular", color: "#61dafb" },
                  { id: "leaf-vue", title: "Vue.js", subtitle: "Progressive & Intuitive Web Framework", description: "সহজ ও আনন্দদায়ক কোডিং।", level: 3, badge: "Intuitive", color: "#4fc08d" },
                  { id: "leaf-angular", title: "Angular", subtitle: "Complete Enterprise TypeScript Framework (Google)", description: "বড় এন্টারপ্রাইজ সিস্টেমের জন্য।", level: 3, badge: "Enterprise", color: "#dd0031" }
                ]
              },
              {
                id: "sub-fe-libs",
                title: "2.3 Libraries & UI Toolkits (ডিজাইন সিস্টেম)",
                subtitle: "Modern CSS Utility & Component Toolkits",
                description: "দ্রুততম সময়ে আধুনিক, পলিশড ও রেসপন্সিভ ইউজার ইন্টারফেস তৈরির টুলকিট।",
                level: 2,
                badge: "Design Acceleration",
                formula: "Prebuilt Utilities (Tailwind) / Components (Bootstrap)",
                rules: [
                  "Tailwind CSS: ইউটিলিটি-ফার্স্ট সিএসএস ক্লাস দিয়ে কাস্টম ডিজাইন তৈরি।",
                  "Bootstrap: পূর্বে তৈরি করা বাটন, কার্ড, গ্রিড ও মডেলের ক্লাসিক লাইব্রেরি।",
                  "jQuery: লিগ্যাসি ওয়েবের DOM ম্যানিপুলেশন লাইব্রেরি।"
                ],
                examples: [
                  { text: "className='flex items-center justify-between p-4 bg-slate-900'", translation: "টেইলউইন্ড ইউটিলিটি ক্লাস।", highlight: "Tailwind" },
                  { text: "class='container-fluid row col-md-6'", translation: "বুটস্ট্র্যাপ গ্রিড ক্লাস।", highlight: "Bootstrap" }
                ],
                tips: ["আধুনিক ওয়েবে Tailwind CSS সবচেয়ে দ্রুত ও হালকা ইন্টারফেস নিশ্চিত করে।"],
                color: "#06b6d4",
                subNodes: [
                  { id: "leaf-tailwind", title: "Tailwind CSS", subtitle: "Utility-First CSS Framework for Rapid UI", description: "মর্ডান ওয়েবের এক নম্বর চয়েস।", level: 3, badge: "Modern UI", color: "#38bdf8" },
                  { id: "leaf-bootstrap", title: "Bootstrap", subtitle: "Responsive Prebuilt Component Framework", description: "ক্লাসিক রেসপন্সিভ লাইব্রেরি।", level: 3, badge: "Classic", color: "#7952b3" },
                  { id: "leaf-jquery", title: "jQuery", subtitle: "Legacy DOM Manipulation Utility", description: "লিগ্যাসি স্ক্রিপ্ট লাইব্রেরি।", level: 3, badge: "Legacy", color: "#0769ad" }
                ]
              }
            ]
          }
        ]
      },
      comparativeSummaryTable: [
        { branch: "Frontend", subBranch: "HTML / CSS / JS", structure: "Structure + Style + Logic", example: "<button onClick={fn}>Save</button>", keyIdentifier: "Web Essentials" },
        { branch: "Frontend", subBranch: "React / Vue / Angular", structure: "Component-based Virtual DOM", example: "const [data, setData] = useState()", keyIdentifier: "Modern SPA" },
        { branch: "Frontend", subBranch: "Tailwind / Bootstrap", structure: "Utility classes & Components", example: "class='p-4 bg-blue-600 rounded-xl'", keyIdentifier: "Speed & Style" },
        { branch: "Backend", subBranch: "Node.js / Python / Java", structure: "Event-loop / Microservices", example: "app.get('/api/data', handler)", keyIdentifier: "Server Engine" },
        { branch: "Backend", subBranch: "REST / GraphQL", structure: "HTTP JSON / Graph Query", example: "GET /api/v1/users", keyIdentifier: "API Gateway" },
        { branch: "Backend", subBranch: "PostgreSQL / MongoDB", structure: "Relational SQL / Document NoSQL", example: "SELECT * FROM orders", keyIdentifier: "Persistent Data" }
      ],
      practiceQuestions: [
        {
          question: "Which Frontend tool allows rapid UI styling directly inside HTML using utility classes?",
          options: ["Tailwind CSS", "GraphQL", "PostgreSQL", "Node.js"],
          answer: "Tailwind CSS",
          explanation: "Tailwind CSS is a utility-first CSS framework that lets you build modern designs directly in your markup without writing separate custom CSS files."
        },
        {
          question: "What is the key advantage of GraphQL over traditional REST APIs?",
          options: ["Prevents over-fetching by letting clients query exact fields needed", "Runs only on MySQL", "Doesn't require HTTP", "Compiles code to C++"],
          answer: "Prevents over-fetching by letting clients query exact fields needed",
          explanation: "GraphQL allows client applications to request precisely the data fields they require in a single query, eliminating unnecessary bandwidth usage."
        },
        {
          question: "Which database type should be chosen when strict ACID transactions and relational tables are required?",
          options: ["Relational SQL (e.g. PostgreSQL, MySQL)", "Document NoSQL (e.g. MongoDB)", "CSS Grid", "REST Gateway"],
          answer: "Relational SQL (e.g. PostgreSQL, MySQL)",
          explanation: "Relational databases enforce structured schemas, foreign keys, and strict ACID transaction compliance, making them essential for financial and enterprise systems."
        }
      ],
      createdAt: new Date().toLocaleDateString()
    }
  },
  {
    id: "ai_ml_tree",
    titleBn: "আর্টিফিশিয়াল ইন্টেলিজেন্স ও ডিপ লার্নিং হায়ারার্কি ট্রি",
    titleEn: "Artificial Intelligence & Modern Generative AI Taxonomy",
    category: "Artificial Intelligence",
    icon: "🧠",
    topic: "Artificial Intelligence (Machine Learning, Deep Learning, Generative AI, Transformers, LLMs, Computer Vision)",
    data: {
      id: "ai-ml-tree",
      title: "Artificial Intelligence & Modern LLM Architecture (এআই হায়ারার্কি)",
      conceptCategory: "Artificial Intelligence & Neural Networks",
      language: "Bilingual (English & Bengali)",
      summary: "আর্টিফিশিয়াল ইন্টেলিজেন্স (AI) হলো কম্পিউটারের মাধ্যমে মানুষের মতো বুদ্ধিমত্তা ও সিদ্ধান্ত গ্রহণের বিজ্ঞান। এর মূল শাখা Machine Learning এবং এর গভীরে রয়েছে Deep Learning ও আধুনিক Generative AI।",
      keyTakeaways: [
        "AI: সার্বিক কৃত্রিম বুদ্ধিমত্তা।",
        "Machine Learning: ডেটা থেকে প্যাটার্ন শিখে নিজে নিজে প্রেডিক্ট করা (Supervised, Unsupervised, Reinforcement)।",
        "Deep Learning: মানুষের মস্তিষ্কের নিউরনের আদলে মাল্টি-লেয়ার নিউরাল নেটওয়ার্ক (CNN, RNN, Transformers)।",
        "Generative AI & LLMs: ট্রান্সফরমার আর্কিটেকচার ও সেলফ-অ্যাটেনশন মেকানিজমে নতুন টেক্সট, ছবি ও অডিও তৈরি।"
      ],
      rootNode: {
        id: "root-ai",
        title: "🧠 Artificial Intelligence (AI)",
        subtitle: "The Science of Machine Intelligence",
        description: "কম্পিউটার সিস্টেমের মাধ্যমে মানুষের বুদ্ধিভিত্তিক কাজ স্বয়ংক্রিয়ভাবে সম্পাদন করার বিজ্ঞান।",
        level: 0,
        badge: "Core Domain",
        color: "#8b5cf6",
        icon: "🧠",
        subNodes: [
          {
            id: "branch-ml",
            title: "১. Machine Learning (ML)",
            subtitle: "Learning from Data & Patterns",
            description: "সুনির্দিষ্ট কোডিং ছাড়াই অ্যালগরিদম যখন অতীতের ডেটা থেকে শিক্ষা নিয়ে ভবিষ্যৎ অনুমান করে।",
            level: 1,
            badge: "Algorithms",
            color: "#3b82f6",
            icon: "📊",
            subNodes: [
              {
                id: "sub-supervised",
                title: "1.1 Supervised Learning (তত্ত্বাবধানে শিক্ষা)",
                subtitle: "Labeled Dataset Training",
                description: "ইনপুট ও সঠিক আউটপুট লেবেল দেওয়া ডেটা থেকে মডেলকে প্রশিক্ষণ দেওয়া।",
                level: 2,
                badge: "Classification & Regression",
                formula: "y = f(X) + ε (Given Features X and Target Labels Y)",
                rules: ["Classification (Discrete output যেমন Spam/Not Spam)", "Regression (Continuous value যেমন House Price)"],
                examples: [
                  { text: "Spam Detection: Filter emails based on labeled past spam", translation: "স্প্যাম ইমেইল ফিল্টার।", highlight: "Spam Filter" }
                ],
                tips: ["লেবেলযুক্ত ডেটার মান যত ভালো হবে, মডেলের নির্ভুলতা তত বাড়বে।"],
                color: "#0284c7"
              },
              {
                id: "sub-unsupervised",
                title: "1.2 Unsupervised Learning (স্বয়ংক্রিয় প্যাটার্ন)",
                subtitle: "Clustering & Anomaly Detection",
                description: "কোনো পূর্বনির্ধারিত লেবেল ছাড়াই ডেটার মধ্য থেকে অভ্যন্তরীণ প্যাটার্ন ও গ্রুপ খুঁজে বের করা।",
                level: 2,
                badge: "Clustering",
                formula: "Group data points minimizing intra-cluster distance: min Σ ||x - μ_k||²",
                rules: ["K-Means Clustering", "Principal Component Analysis (PCA)"],
                examples: [
                  { text: "Customer Segmentation: Grouping users by purchasing behavior", translation: "গ্রাহকদের কেনাকাটার ধরন অনুযায়ী দলবদ্ধ করা।", highlight: "Clustering" }
                ],
                tips: ["গ্রাহক বিভাগ ও ফ্রড ডিটেকশনে কার্যকর।"],
                color: "#10b981"
              }
            ]
          },
          {
            id: "branch-genai",
            title: "২. Deep Learning & Generative AI",
            subtitle: "Neural Networks & Foundation Models",
            description: "মাল্টি-লেয়ার নিউরাল নেটওয়ার্ক ও ট্রান্সফরমার ভিত্তিক আধুনিক জেনারেটিভ এআই।",
            level: 1,
            badge: "Transformers & LLMs",
            color: "#ec4899",
            icon: "✨",
            subNodes: [
              {
                id: "sub-transformers",
                title: "2.1 Transformers & Self-Attention",
                subtitle: "The Engine of Modern LLMs",
                description: "গুগলের উদ্ভাবিত 'Attention is All You Need' আর্কিটেকচার যা কনটেক্সট নির্ভুলভাবে বুঝতে পারে।",
                level: 2,
                badge: "Core Architecture",
                formula: "Attention(Q, K, V) = softmax((Q K^T) / √d_k) * V",
                rules: ["Query, Key, Value ম্যাট্রিক্স ক্যালকুলেশন", "প্যারালাল প্রসেসিং ও লং-কনটেক্সট উইন্ডো"],
                examples: [
                  { text: "Gemini 2.5/3.7: Massive Multimodal Reasoning & Code Generation", translation: "মাল্টিমোডাল যুক্তি ও কোড জেনারেশন।", highlight: "Gemini" }
                ],
                tips: ["টোকেনাইজেশন ও অ্যাটেনশন মেকানিজম এলএলএমের প্রাণ।"],
                color: "#f43f5e"
              }
            ]
          }
        ]
      },
      comparativeSummaryTable: [
        { branch: "AI", subBranch: "Symbolic & Rule-Based", structure: "IF-THEN Expert Rules", example: "Chess Engine Alpha-Beta", keyIdentifier: "Rule Engine" },
        { branch: "ML", subBranch: "Supervised Learning", structure: "Feature X ➔ Target Label Y", example: "House Price Predictor", keyIdentifier: "Labeled Data" },
        { branch: "Deep Learning", subBranch: "Transformers & LLMs", structure: "Self-Attention Q,K,V Softmax", example: "Gemini 3.7 Reasoning", keyIdentifier: "Generative AI" }
      ],
      practiceQuestions: [
        {
          question: "Which breakthrough mechanism allows Transformer models to process tokens in parallel while retaining long-range context?",
          options: ["Self-Attention Mechanism", "Decision Trees", "Linear Regression", "Bubble Sort"],
          answer: "Self-Attention Mechanism",
          explanation: "Self-attention computes weights between all pairs of tokens in a sequence simultaneously, allowing deep contextual understanding without recurrent sequential bottlenecks."
        }
      ],
      createdAt: new Date().toLocaleDateString()
    }
  },
  {
    id: "tense_tree",
    titleBn: "ইংরেজি Tense সম্পূর্ণ বংশবৃক্ষ ও ১২ প্রকার রূপভেদ",
    titleEn: "Complete English Tense Hierarchy (3 Types & 12 Subtypes)",
    category: "English Grammar",
    icon: "📘",
    topic: "English Grammar Tenses (Present, Past, Future and their 12 sub-types with formulas and examples)",
    data: {
      id: "demo-tense-tree",
      title: "English Grammar Tense Master Hierarchy (টেন্সের সম্পূর্ণ নিয়ম ও ১২টি শাখা)",
      conceptCategory: "English Grammar & Linguistics",
      language: "Bilingual (English & Bengali)",
      summary: "Tense (কাল) নির্দেশ করে কোনো কাজ কোন সময়ে নিষ্পন্ন হচ্ছে বা হয়েছিল বা হবে। প্রধানত Tense ৩ প্রকার (Present, Past, Future) এবং এই প্রতিটি Tense আবার ৪ ভাগে বিভক্ত, অর্থাৎ মোট ১২টি রূপভেদ বিদ্যমান।",
      keyTakeaways: [
        "ক্রিয়া সম্পাদনের সুনির্দিষ্ট সময়কে Tense বলে।",
        "Present Tense (বর্তমান কাল), Past Tense (অতীত কাল), Future Tense (ভবিষ্যত কাল)।",
        "প্রতিটি কালের ৪টি উপবিভাগ: Indefinite/Simple, Continuous/Progressive, Perfect, এবং Perfect Continuous।"
      ],
      rootNode: {
        id: "root-tense",
        title: "TENSE (ক্রিয়ার কাল)",
        subtitle: "The Time of an Action",
        description: "যে সময় কোনো কার্য সম্পন্ন হয়, তাকে Tense বলে। এটি ব্যাকরণের মেরুদণ্ড।",
        level: 0,
        badge: "মাস্টার কনসেপ্ট",
        color: "#7c2d12",
        icon: "⏳",
        subNodes: [
          {
            id: "branch-present",
            title: "১. Present Tense (বর্তমান কাল)",
            subtitle: "Action happening now or habitual facts",
            description: "যে কাজ বর্তমান সময়ে ঘটে বা সচরাচর হয়ে থাকে বা চিরন্তন সত্য প্রকাশ করে।",
            level: 1,
            badge: "৩টি প্রধান ভাগের ১ম ভাগ",
            color: "#0284c7",
            icon: "☀️",
            subNodes: [
              {
                id: "sub-pres-indef",
                title: "1.1 Present Indefinite / Simple",
                subtitle: "সাধারণ বর্তমান",
                description: "অভ্যাসগত কাজ, চিরন্তন সত্য বা সাধারণ বর্তমান সময়ের কোনো কাজ।",
                level: 2,
                badge: "Simple",
                formula: "Subject + Base Verb (v1) (+ s/es for 3rd Person Singular) + Object",
                rules: [
                  "Subject 3rd person singular হলে verb-এর শেষে s/es বসে।"
                ],
                examples: [
                  { text: "The sun rises in the east.", translation: "সূর্য পূর্ব দিকে ওঠে। (চিরন্তন সত্য)", highlight: "rises" }
                ],
                tips: ["Always, daily, usually থাকলে Present Indefinite হয়।"],
                color: "#0369a1"
              },
              {
                id: "sub-pres-cont",
                title: "1.2 Present Continuous / Progressive",
                subtitle: "ঘটমান বর্তমান",
                description: "কোনো কাজ বর্তমান সময়ে চলমান বা ঘটছে বোঝালে।",
                level: 2,
                badge: "Continuous",
                formula: "Subject + am/is/are + [Base Verb + ing] + Object",
                rules: ["I-তে am, Singular-এ is, Plural-এ are বসে।"],
                examples: [
                  { text: "I am writing a story.", translation: "আমি একটি গল্প লিখছি।", highlight: "am writing" }
                ],
                tips: ["Now, at this moment থাকলে Present Continuous হয়।"],
                color: "#0284c7"
              }
            ]
          }
        ]
      },
      comparativeSummaryTable: [
        { branch: "Present", subBranch: "Simple Present", structure: "Subject + V1 (+s/es) + Obj", example: "He plays football.", keyIdentifier: "Habitual, Daily facts" },
        { branch: "Present", subBranch: "Present Continuous", structure: "Sub + am/is/are + V(ing) + Obj", example: "He is playing football.", keyIdentifier: "Happening right now" }
      ],
      practiceQuestions: [
        {
          question: "Which tense is used for universal truths like 'Water boils at 100°C'?",
          options: ["Present Continuous", "Present Indefinite (Simple Present)", "Past Indefinite", "Present Perfect"],
          answer: "Present Indefinite (Simple Present)",
          explanation: "Scientific and universal truths are always expressed in the Present Indefinite Tense."
        }
      ],
      createdAt: new Date().toLocaleDateString()
    }
  }
];

export const LearningChartStudio: React.FC<LearningChartStudioProps> = ({
  lang,
  currentUser,
  customGeminiKey,
  customDeepseekKey,
  onSendToBookEditor
}) => {
  // Input State
  const [topicInput, setTopicInput] = useState("");
  const [depthTier, setDepthTier] = useState<"beginner" | "intermediate" | "advanced">("intermediate");
  const [chartLanguage, setChartLanguage] = useState<string>("Bengali");
  const [additionalNotes, setAdditionalNotes] = useState("");
  const [attachment, setAttachment] = useState<{ name: string; type: string; mimeType: string; dataBase64: string } | null>(null);
  
  // Voice Dictation
  const [isDictating, setIsDictating] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Active Chart & Views
  const [currentChart, setCurrentChart] = useState<LearningChartData>(STARTER_TEMPLATES[0].data);
  const [isGenerating, setIsGenerating] = useState(false);
  const [viewMode, setViewMode] = useState<"tree" | "matrix" | "pages" | "quiz">("tree");
  const [searchFilter, setSearchFilter] = useState("");
  const [activePageIndex, setActivePageIndex] = useState<number>(0);
  const [canvasTheme, setCanvasTheme] = useState<"neon_dark" | "clean_white" | "blueprint" | "parchment">("neon_dark");
  const [zoomScale, setZoomScale] = useState<number>(100);

  // Social Share & Export Modal
  const [isSocialModalOpen, setIsSocialModalOpen] = useState(false);
  const [socialFormat, setSocialFormat] = useState<"square_1_1" | "story_9_16" | "banner_16_9" | "carousel">("square_1_1");
  const [socialCardTheme, setSocialCardTheme] = useState<"cyber_dark" | "gradient_purple" | "clean_minimal" | "royal_gold">("cyber_dark");
  const [isExportingImage, setIsExportingImage] = useState(false);
  const [exportedImageUri, setExportedImageUri] = useState<string | null>(null);

  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    "root-webdev": true,
    "branch-backend": true,
    "branch-frontend": true,
    "sub-be-api": true,
    "sub-be-db": true,
    "sub-be-lang": true,
    "sub-fe-lang": true,
    "sub-fe-frameworks": true,
    "sub-fe-libs": true
  });
  
  // Feedback
  const [copiedNotification, setCopiedNotification] = useState(false);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
  
  const chartCanvasRef = useRef<HTMLDivElement>(null);
  const socialCardPreviewRef = useRef<HTMLDivElement>(null);

  // Toggle Node Expand/Collapse
  const toggleNode = (nodeId: string) => {
    setExpandedNodes(prev => ({
      ...prev,
      [nodeId]: !prev[nodeId]
    }));
  };

  const expandAll = () => {
    if (!currentChart) return;
    const newExpanded: Record<string, boolean> = {};
    const traverse = (node: ChartNode) => {
      newExpanded[node.id] = true;
      if (node.subNodes) node.subNodes.forEach(traverse);
    };
    traverse(currentChart.rootNode);
    setExpandedNodes(newExpanded);
  };

  const collapseAll = () => {
    if (!currentChart) return;
    const newExpanded: Record<string, boolean> = { [currentChart.rootNode.id]: true };
    setExpandedNodes(newExpanded);
  };

  // Voice Input Handlers
  const toggleVoiceInput = () => {
    if (isDictating) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsDictating(false);
      return;
    }

    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert(lang === "bn" ? "আপনার ব্রাউজারে স্পিচ রিকগনিশন সাপোর্ট করে না।" : "Speech recognition is not supported in this browser.");
      return;
    }

    const rec = new SpeechRec();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = chartLanguage === "Bengali" ? "bn-BD" : "en-US";

    rec.onresult = (e: any) => {
      let transcript = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        transcript += e.results[i][0].transcript;
      }
      setTopicInput(transcript);
    };

    rec.onerror = () => setIsDictating(false);
    rec.onend = () => setIsDictating(false);

    recognitionRef.current = rec;
    rec.start();
    setIsDictating(true);
  };

  // Handle File/Photo Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = (reader.result as string).split(",")[1];
      setAttachment({
        name: file.name,
        type: file.type.startsWith("image") ? "image" : "pdf",
        mimeType: file.type || (file.name.endsWith(".pdf") ? "application/pdf" : "image/jpeg"),
        dataBase64: base64
      });
    };
    reader.readAsDataURL(file);
  };

  // Generate AI Learning Chart
  const handleGenerateChart = async (customTopic?: string) => {
    const targetTopic = customTopic || topicInput;
    if (!targetTopic && !attachment) {
      alert(lang === "bn" ? "অনুগ্রহ করে একটি বিষয় লিখুন অথবা একটি নোটের ছবি আপলোড করুন।" : "Please enter a topic or upload a photo/note.");
      return;
    }

    setIsGenerating(true);
    try {
      const res = await fetch("/api/generate-learning-chart", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(customGeminiKey ? { "x-api-key-gemini": customGeminiKey } : {}),
          ...(customDeepseekKey ? { "x-api-key-deepseek": customDeepseekKey } : {})
        },
        body: JSON.stringify({
          topic: targetTopic,
          attachment,
          depth: depthTier,
          language: chartLanguage,
          additionalNotes
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const data: LearningChartData = await res.json();
      data.createdAt = new Date().toLocaleDateString();
      setCurrentChart(data);

      // Auto-expand all top-level branches
      const newExpanded: Record<string, boolean> = { [data.rootNode.id]: true };
      if (data.rootNode.subNodes) {
        data.rootNode.subNodes.forEach(b => {
          newExpanded[b.id] = true;
          if (b.subNodes) b.subNodes.forEach(sb => { newExpanded[sb.id] = true; });
        });
      }
      setExpandedNodes(newExpanded);
      setActivePageIndex(0);
    } catch (e: any) {
      console.error("Failed to generate chart:", e);
      alert(lang === "bn" ? "চার্ট তৈরি করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।" : `Failed to generate chart: ${e.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Export to High-Res Image using html2canvas
  const handleDownloadSocialCard = async () => {
    if (!socialCardPreviewRef.current) return;
    setIsExportingImage(true);
    try {
      const canvas = await html2canvas(socialCardPreviewRef.current, {
        scale: 2.5,
        useCORS: true,
        backgroundColor: null
      });
      const dataUrl = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.download = `${currentChart.title.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase()}_${socialFormat}.png`;
      link.href = dataUrl;
      link.click();
    } catch (e) {
      console.error("Canvas export error:", e);
    } finally {
      setIsExportingImage(false);
    }
  };

  // Native Web Share API
  const handleWebShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: currentChart.title,
          text: `Check out this visual learning tree on "${currentChart.title}": ${currentChart.summary}`,
          url: window.location.href
        });
      } catch (err) {
        console.log("Share canceled", err);
      }
    } else {
      handleCopyMarkdown();
    }
  };

  // Copy Markdown
  const handleCopyMarkdown = () => {
    let md = `# ${currentChart.title}\n\n`;
    md += `**Category:** ${currentChart.conceptCategory} | **Date:** ${currentChart.createdAt}\n\n`;
    md += `## Overview\n${currentChart.summary}\n\n`;
    md += `### Key Takeaways\n` + currentChart.keyTakeaways.map(t => `- ${t}`).join("\n") + "\n\n";

    const formatNode = (node: ChartNode, indent: number) => {
      const pad = "  ".repeat(indent);
      let res = `${pad}- **${node.title}**${node.subtitle ? ` (${node.subtitle})` : ""}\n`;
      if (node.description) res += `${pad}  *Description:* ${node.description}\n`;
      if (node.formula) res += `${pad}  *Formula/Structure:* \`${node.formula}\`\n`;
      if (node.rules && node.rules.length > 0) {
        res += `${pad}  *Rules:*\n` + node.rules.map(r => `${pad}    - ${r}`).join("\n") + "\n";
      }
      if (node.examples && node.examples.length > 0) {
        res += `${pad}  *Examples:*\n` + node.examples.map(ex => `${pad}    - "${ex.text}" ${ex.translation ? `(${ex.translation})` : ""}`).join("\n") + "\n";
      }
      if (node.subNodes) {
        node.subNodes.forEach(child => {
          res += formatNode(child, indent + 1);
        });
      }
      return res;
    };

    md += `## Structural Hierarchy\n\n` + formatNode(currentChart.rootNode, 0);

    navigator.clipboard.writeText(md);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2500);
  };

  // Split Large Charts into Multi-Page Segments
  const getChartPages = () => {
    const branches = currentChart.rootNode.subNodes || [];
    const pages: { title: string; subtitle: string; node: ChartNode | null; type: "overview" | "branch" | "matrix" | "quiz" }[] = [
      {
        title: lang === "bn" ? "পৃষ্ঠা ১: সার্বিক আর্কিটেকচার ও মূল স্তম্ভ" : "Page 1: Architecture Overview & Pillars",
        subtitle: currentChart.title,
        node: currentChart.rootNode,
        type: "overview"
      }
    ];

    branches.forEach((b, idx) => {
      pages.push({
        title: lang === "bn" ? `পৃষ্ঠা ${idx + 2}: ${b.title}` : `Page ${idx + 2}: ${b.title}`,
        subtitle: b.subtitle || b.description,
        node: b,
        type: "branch"
      });
    });

    if (currentChart.comparativeSummaryTable && currentChart.comparativeSummaryTable.length > 0) {
      pages.push({
        title: lang === "bn" ? `পৃষ্ঠা ${pages.length + 1}: তুলনামূলক সারসংক্ষেপ ম্যাট্রিক্স` : `Page ${pages.length + 1}: Comparative Summary Matrix`,
        subtitle: lang === "bn" ? "সকল শাখার সরাসরি তুলনা ও সনাক্তকারী লক্ষণ" : "Direct Branch Comparison & Rule Matrix",
        node: null,
        type: "matrix"
      });
    }

    if (currentChart.practiceQuestions && currentChart.practiceQuestions.length > 0) {
      pages.push({
        title: lang === "bn" ? `পৃষ্ঠা ${pages.length + 1}: স্ব-মূল্যায়ন কুইজ ও অনুশীলন` : `Page ${pages.length + 1}: Self-Assessment Quiz`,
        subtitle: lang === "bn" ? "জ্ঞান যাচাই ও পরীক্ষার প্রস্তুতি" : "Exam Preparation & Knowledge Check",
        node: null,
        type: "quiz"
      });
    }

    return pages;
  };

  const chartPages = getChartPages();

  // Print High-Res
  const handlePrint = () => {
    window.print();
  };

  // Recursive Tree Node Renderer (Infographic Flowchart Style)
  const renderTreeNode = (node: ChartNode, depth: number = 0) => {
    const isExpanded = expandedNodes[node.id] !== false;
    const hasChildren = node.subNodes && node.subNodes.length > 0;
    
    // Search Filter
    const matchesSearch = !searchFilter || 
      node.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
      (node.description && node.description.toLowerCase().includes(searchFilter.toLowerCase())) ||
      (node.formula && node.formula.toLowerCase().includes(searchFilter.toLowerCase()));

    if (!matchesSearch && !hasChildren) return null;

    const isDark = canvasTheme === "neon_dark";

    return (
      <div 
        key={node.id} 
        className={`relative transition-all ${
          depth > 0 
            ? isDark
              ? "pl-4 sm:pl-8 border-l-2 border-dashed border-cyan-500/40 my-3"
              : "pl-4 sm:pl-8 border-l-2 border-dashed border-amber-300 my-3"
            : "my-2"
        }`}
      >
        {/* Node Box */}
        <div 
          className={`rounded-2xl transition-all border shadow-xs hover:shadow-lg ${
            node.level === 0 
              ? isDark
                ? "bg-gradient-to-r from-[#030712] via-[#0f172a] to-[#1e1b4b] text-white border-cyan-500/80 p-5 shadow-[0_0_25px_rgba(6,182,212,0.25)]"
                : "bg-gradient-to-r from-[#7c2d12] to-[#9a3412] text-amber-50 border-amber-900 p-5 shadow-lg"
              : node.level === 1
              ? isDark
                ? "bg-[#0b1120] text-slate-100 border-cyan-700/60 p-4 hover:border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                : "bg-white text-slate-800 border-slate-300 p-4 hover:border-amber-500"
              : node.level === 2
              ? isDark
                ? "bg-[#030712]/90 text-slate-200 border-slate-700/80 p-3.5 hover:border-cyan-500/60"
                : "bg-[#faf9f6] text-slate-800 border-[#e4dcc9] p-3.5"
              : isDark
                ? "bg-[#0f172a]/80 text-slate-300 border-slate-800 p-3"
                : "bg-white text-slate-700 border-slate-200 p-3"
          }`}
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5 flex-1 min-w-0">
              {hasChildren && (
                <button
                  onClick={() => toggleNode(node.id)}
                  className={`p-1.5 rounded-lg transition shrink-0 cursor-pointer mt-0.5 ${
                    node.level === 0 
                      ? isDark ? "bg-cyan-950 text-cyan-300 hover:bg-cyan-900" : "bg-amber-800 text-amber-200"
                      : isDark ? "bg-slate-800 text-slate-300 hover:bg-slate-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                  title={isExpanded ? "Collapse" : "Expand"}
                >
                  {isExpanded ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
                </button>
              )}

              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  {node.icon && <span className="text-base">{node.icon}</span>}
                  <h3 className={`font-black tracking-tight ${
                    node.level === 0 
                      ? "text-xl sm:text-2xl text-white" 
                      : node.level === 1 
                      ? isDark ? "text-base sm:text-lg text-cyan-300" : "text-base sm:text-lg text-[#7c2d12]"
                      : isDark ? "text-sm sm:text-base text-slate-100" : "text-sm sm:text-base text-slate-900"
                  }`}>
                    {node.title}
                  </h3>
                  {node.badge && (
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider ${
                      node.level === 0 
                        ? isDark ? "bg-cyan-400 text-cyan-950" : "bg-amber-400 text-amber-950"
                        : isDark ? "bg-cyan-950 text-cyan-300 border border-cyan-800" : "bg-amber-100 text-amber-900 border border-amber-300"
                    }`}>
                      {node.badge}
                    </span>
                  )}
                  {node.subtitle && (
                    <span className={`text-xs font-semibold ${node.level === 0 ? "text-cyan-200" : isDark ? "text-slate-400" : "text-slate-500"}`}>
                      • {node.subtitle}
                    </span>
                  )}
                </div>

                {node.description && (
                  <p className={`text-xs sm:text-sm leading-relaxed mb-2.5 ${node.level === 0 ? (isDark ? "text-slate-300" : "text-amber-100") : isDark ? "text-slate-300" : "text-slate-600"}`}>
                    {node.description}
                  </p>
                )}

                {/* FORMULA / CODE / STRUCTURE HIGHLIGHT BOX */}
                {node.formula && (
                  <div className={`my-2.5 p-2.5 rounded-xl flex items-start gap-2 border ${
                    isDark 
                      ? "bg-cyan-950/40 border-cyan-800/80 text-cyan-200" 
                      : "bg-amber-50/90 border-amber-300 text-[#7c2d12]"
                  }`}>
                    <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md shrink-0 ${
                      isDark ? "bg-cyan-500 text-cyan-950" : "bg-amber-200 text-amber-950"
                    }`}>
                      {lang === "bn" ? "গঠন / সূত্র:" : "Structure / Formula:"}
                    </span>
                    <code className="text-xs font-black font-mono select-all break-all">
                      {node.formula}
                    </code>
                  </div>
                )}

                {/* RULES LIST */}
                {node.rules && node.rules.length > 0 && (
                  <div className="my-2 space-y-1">
                    <span className={`text-[10px] font-black uppercase tracking-wider block ${isDark ? "text-slate-400" : "text-slate-400"}`}>
                      {lang === "bn" ? "মূল নিয়মাবলী ও বিবরণ:" : "Rules & Mechanics:"}
                    </span>
                    <ul className="space-y-1">
                      {node.rules.map((rule, idx) => (
                        <li key={idx} className={`text-xs flex items-start gap-1.5 ${isDark ? "text-slate-300" : "text-slate-700"}`}>
                          <span className={isDark ? "text-cyan-400 font-black" : "text-amber-600 font-black"}>•</span>
                          <span>{rule}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* EXAMPLES WITH TRANSLATION */}
                {node.examples && node.examples.length > 0 && (
                  <div className={`my-2.5 border rounded-xl p-3 space-y-2 ${isDark ? "bg-[#0f172a] border-slate-800" : "bg-white border-slate-200"}`}>
                    <span className={`text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${isDark ? "text-cyan-300" : "text-[#7c2d12]"}`}>
                      <Lightbulb size={12} className={isDark ? "text-cyan-400" : "text-amber-500"} />
                      {lang === "bn" ? "বাস্তব উদাহরণ ও ব্যবহার:" : "Real Examples & Translation:"}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {node.examples.map((ex, exIdx) => (
                        <div key={exIdx} className={`border rounded-lg p-2 text-xs ${isDark ? "bg-[#030712] border-slate-700/80 text-slate-200" : "bg-slate-50 border-slate-200/80 text-slate-900"}`}>
                          <div className="font-bold mb-0.5">
                            {ex.text}
                          </div>
                          {ex.translation && (
                            <div className={`text-[11px] font-medium ${isDark ? "text-cyan-400" : "text-[#7c2d12]"}`}>
                              ↳ {ex.translation}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* TIPS & PRO ADVICE */}
                {node.tips && node.tips.length > 0 && (
                  <div className={`mt-2 text-[11px] p-2 rounded-lg flex items-start gap-1.5 border ${
                    isDark ? "bg-emerald-950/60 text-emerald-300 border-emerald-800/80" : "bg-emerald-50 text-emerald-900 border-emerald-200"
                  }`}>
                    <CheckCircle2 size={13} className="text-emerald-500 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold mr-1">{lang === "bn" ? "মনে রাখার টিপস:" : "Pro Tip:"}</span>
                      {node.tips.join(" ")}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* RECURSIVE SUB-BRANCHES */}
        {hasChildren && isExpanded && (
          <div className="space-y-3 mt-2">
            {node.subNodes!.map(child => renderTreeNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* ========================================================================= */}
      {/* 🌟 1. PROMINENTLY HIGHLIGHTED SOCIAL MEDIA POST & EXPORT HUB (Requested)  */}
      {/* ========================================================================= */}
      <div className="relative overflow-hidden bg-gradient-to-r from-[#1e1b4b] via-[#312e81] to-[#0f172a] text-white rounded-3xl p-5 sm:p-6 border-2 border-indigo-500/80 shadow-[0_0_30px_rgba(99,102,241,0.35)] print:hidden">
        {/* Glowing Ambient Badge */}
        <div className="absolute top-0 right-0 transform translate-x-4 -translate-y-4 w-44 h-44 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 relative z-10">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 bg-gradient-to-r from-pink-500 to-rose-500 text-white font-black text-[11px] rounded-full uppercase tracking-wider flex items-center gap-1.5 shadow-md animate-pulse">
                <Sparkle size={13} />
                {lang === "bn" ? "সোশ্যাল মিডিয়া ইনফোগ্রাফিক এক্সপোর্ট হাব" : "Social Media Infographic Hub"}
              </span>
              <span className="text-xs bg-indigo-900/80 border border-indigo-400/50 text-indigo-200 px-2.5 py-0.5 rounded-full font-bold">
                HD Export & Multi-Page Ready
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {lang === "bn" 
                ? "সোশ্যাল মিডিয়া ও স্টোরিতে চার্ট আপলোড ও শেয়ার করুন" 
                : "Export & Share Ready-Made Infographics to Social Media"}
            </h2>
            <p className="text-xs sm:text-sm text-indigo-200 max-w-2xl leading-relaxed">
              {lang === "bn"
                ? "যেকোনো টপিকের পুরো চার্টটি ইনস্টাগ্রাম (1:1), ফেসবুক পোস্ট, লিঙ্কডইন ব্যানার (16:9), কিংবা স্টোরি/রিলস (9:16) সাইজে এক ক্লিকে হাই-রেজ্যুলুশন ইমেজে ডাউনলোড করে আপলোড করুন।"
                : "Instantly export high-resolution infographic posters, square cards (1:1), vertical stories (9:16), or landscape slides (16:9) ready for Instagram, LinkedIn, Facebook, and Twitter!"}
            </p>
          </div>

          {/* Direct Social Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => {
                setSocialFormat("square_1_1");
                setIsSocialModalOpen(true);
              }}
              className="px-4 py-2.5 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-black rounded-xl text-xs flex items-center gap-2 shadow-lg transition transform hover:-translate-y-0.5 cursor-pointer"
            >
              <Instagram size={16} />
              <span>{lang === "bn" ? "ইনস্টাগ্রাম (1:1)" : "Instagram (1:1)"}</span>
            </button>

            <button
              onClick={() => {
                setSocialFormat("banner_16_9");
                setIsSocialModalOpen(true);
              }}
              className="px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-black rounded-xl text-xs flex items-center gap-2 shadow-lg transition transform hover:-translate-y-0.5 cursor-pointer"
            >
              <Linkedin size={16} />
              <span>{lang === "bn" ? "লিঙ্কডইন / ব্যানার (16:9)" : "LinkedIn / Post (16:9)"}</span>
            </button>

            <button
              onClick={() => {
                setSocialFormat("story_9_16");
                setIsSocialModalOpen(true);
              }}
              className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black rounded-xl text-xs flex items-center gap-2 shadow-lg transition transform hover:-translate-y-0.5 cursor-pointer"
            >
              <Smartphone size={16} />
              <span>{lang === "bn" ? "স্টোরি / রিলস (9:16)" : "Story / Reel (9:16)"}</span>
            </button>

            <button
              onClick={handleWebShare}
              className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 border border-white/20 transition cursor-pointer"
              title="Share"
            >
              <Share2 size={15} />
              <span>{lang === "bn" ? "শেয়ার" : "Share"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. TOPIC INPUT & AI GENERATOR BAR (Print Hidden)                           */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-r from-[#2a170e] via-[#431407] to-[#1e130c] text-amber-50 rounded-2xl p-5 sm:p-6 border border-amber-900/60 shadow-xl print:hidden space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-amber-500/20 text-amber-400 border border-amber-500/40 rounded-xl shadow-inner">
                <GitFork size={20} className="rotate-90" />
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {lang === "bn" ? "যেকোনো বিষয় দিন — এআই ভিজ্যুয়াল চার্ট বানাবে" : "Dynamic Visual Concept Tree Generator"}
              </h1>
            </div>
            <p className="text-xs sm:text-sm text-amber-200/90 max-w-2xl font-medium">
              {lang === "bn"
                ? "ওয়েব ডেভেলপমেন্ট, ব্যাকরণ, বায়োলজি, এআই, বিজনেস বা যেকোনো কঠিন বিষয় লিখুন — নিমিষেই সুন্দর ডায়াগ্রাম তৈরি হবে।"
                : "Type any topic or upload photo notes to generate deep hierarchical knowledge trees."}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-amber-950 font-black rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Printer size={15} />
              <span>{lang === "bn" ? "প্রিন্ট করুন (A4)" : "Print A4"}</span>
            </button>
            <button
              onClick={handleCopyMarkdown}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-amber-100 font-bold rounded-xl text-xs flex items-center gap-1.5 border border-white/20 transition cursor-pointer"
            >
              {copiedNotification ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              <span>{copiedNotification ? (lang === "bn" ? "কপি হয়েছে!" : "Copied!") : (lang === "bn" ? "আউটলাইন কপি" : "Copy Outline")}</span>
            </button>
          </div>
        </div>

        {/* Input Bar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 pt-2 border-t border-amber-800/60">
          <div className="lg:col-span-6 relative">
            <div className="flex items-center gap-1.5 bg-black/40 border border-amber-700/60 rounded-xl px-3 py-2.5 focus-within:border-amber-400 transition">
              <input
                type="text"
                value={topicInput}
                onChange={(e) => setTopicInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleGenerateChart()}
                placeholder={lang === "bn" ? "বিষয় লিখুন (যেমন: Web Development, Machine Learning, Tense, Photosynthesis...)" : "Enter topic (e.g. Web Development Architecture, ML Transformers, English Tenses...)"}
                className="w-full bg-transparent text-sm text-white placeholder-amber-200/50 outline-none font-medium"
              />
              <button
                onClick={toggleVoiceInput}
                className={`p-2 rounded-lg transition cursor-pointer ${
                  isDictating ? "bg-rose-500 text-white animate-pulse" : "bg-white/10 hover:bg-white/20 text-amber-300"
                }`}
                title="Voice Dictation"
              >
                {isDictating ? <MicOff size={14} /> : <Mic size={14} />}
              </button>
            </div>

            {attachment && (
              <div className="mt-1.5 flex items-center justify-between text-[11px] bg-amber-950/70 border border-amber-700/80 px-2.5 py-1 rounded-lg text-amber-200">
                <span className="truncate">📎 {attachment.name}</span>
                <button onClick={() => setAttachment(null)} className="text-rose-400 hover:underline ml-2 cursor-pointer font-bold">Remove</button>
              </div>
            )}
          </div>

          <div className="lg:col-span-4 flex items-center gap-2">
            <select
              value={depthTier}
              onChange={(e: any) => setDepthTier(e.target.value)}
              className="w-1/2 bg-black/40 border border-amber-700/60 text-xs font-bold text-amber-100 rounded-xl px-3 py-2.5 outline-none cursor-pointer"
            >
              <option value="beginner">{lang === "bn" ? "প্রাথমিক লেভেল" : "Beginner Level"}</option>
              <option value="intermediate">{lang === "bn" ? "বিস্তারিত / পূর্ণাঙ্গ" : "Intermediate / Detailed"}</option>
              <option value="advanced">{lang === "bn" ? "মাস্টার / গভীর বিশ্লেষণ" : "Advanced / In-Depth"}</option>
            </select>

            <select
              value={chartLanguage}
              onChange={(e) => setChartLanguage(e.target.value)}
              className="w-1/2 bg-black/40 border border-amber-700/60 text-xs font-bold text-amber-100 rounded-xl px-3 py-2.5 outline-none cursor-pointer"
            >
              <option value="Bengali">বাংলা (Bengali)</option>
              <option value="English">English</option>
              <option value="Bilingual">Bilingual (দ্বিভাষিক)</option>
            </select>
          </div>

          <div className="lg:col-span-2 flex items-center gap-2">
            <label className="p-2.5 bg-white/10 hover:bg-white/20 border border-white/20 text-amber-200 rounded-xl cursor-pointer transition flex items-center justify-center shrink-0" title="Upload Note / Image">
              <FileUp size={16} />
              <input type="file" accept="image/*,application/pdf" onChange={handleFileUpload} className="hidden" />
            </label>

            <button
              onClick={() => handleGenerateChart()}
              disabled={isGenerating}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 disabled:opacity-50 text-amber-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg transition cursor-pointer"
            >
              <Sparkles size={14} className={isGenerating ? "animate-spin" : ""} />
              <span>{isGenerating ? (lang === "bn" ? "চার্ট তৈরি হচ্ছে..." : "Generating...") : (lang === "bn" ? "চার্ট তৈরি করুন" : "Generate Chart")}</span>
            </button>
          </div>
        </div>

        {/* Instant Topic Presets */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-amber-900/40">
          <span className="text-[10px] font-black uppercase tracking-wider text-amber-300/80 mr-1 flex items-center gap-1">
            <Compass size={12} />
            {lang === "bn" ? "রেডি টেমপ্লেট নির্বাচন:" : "Instant Presets:"}
          </span>
          {STARTER_TEMPLATES.map(tmpl => (
            <button
              key={tmpl.id}
              onClick={() => {
                setCurrentChart(tmpl.data);
                setTopicInput(tmpl.titleBn);
                setActivePageIndex(0);
              }}
              className="px-2.5 py-1 bg-amber-950/60 hover:bg-amber-900 border border-amber-700/60 text-amber-200 text-xs font-bold rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <span>{tmpl.icon}</span>
              <span>{lang === "bn" ? tmpl.titleBn : tmpl.titleEn}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. VIEW CONTROLS & MULTI-PAGE TAB BAR (Print Hidden)                       */}
      {/* ========================================================================= */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-[#e4dcc9] p-3 rounded-2xl shadow-xs print:hidden">
        {/* View Modes */}
        <div className="flex flex-wrap items-center gap-1 bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setViewMode("tree")}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === "tree" ? "bg-white text-[#7c2d12] shadow-xs" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <GitFork size={13} className="rotate-90" />
            <span>{lang === "bn" ? "বংশবৃক্ষ / হায়ারার্কি ট্রি (বড় বক্স)" : "Interactive Concept Tree"}</span>
          </button>

          <button
            onClick={() => setViewMode("pages")}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === "pages" ? "bg-white text-indigo-700 shadow-xs" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <BookOpen size={13} />
            <span>{lang === "bn" ? "📄 মাল্টি-পেজ বিভাজন (পৃষ্ঠাভিত্তিক)" : "📄 Multi-Page Breakdown"}</span>
          </button>

          <button
            onClick={() => setViewMode("matrix")}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === "matrix" ? "bg-white text-[#7c2d12] shadow-xs" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Layers size={13} />
            <span>{lang === "bn" ? "তুলনামূলক ম্যাট্রিক্স টেবিল" : "Summary Matrix"}</span>
          </button>

          <button
            onClick={() => setViewMode("quiz")}
            className={`px-3 py-1.5 rounded-lg text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
              viewMode === "quiz" ? "bg-white text-[#7c2d12] shadow-xs" : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <HelpCircle size={13} />
            <span>{lang === "bn" ? "স্ব-মূল্যায়ন কুইজ" : "Self Quiz"}</span>
          </button>
        </div>

        {/* Theme & Search */}
        <div className="flex items-center gap-2">
          {/* Theme Selector */}
          <select
            value={canvasTheme}
            onChange={(e: any) => setCanvasTheme(e.target.value)}
            className="bg-slate-100 border border-slate-300 text-xs font-bold text-slate-800 rounded-lg px-2.5 py-1 outline-none cursor-pointer"
          >
            <option value="neon_dark">🌌 সাইবার নিয়ন ডার্ক (Cyber Dark)</option>
            <option value="clean_white">☀️ ক্লিন ক্লাসিক হোয়াইট (Clean White)</option>
            <option value="blueprint">📐 ব্লুপ্রিন্ট (Blueprint Blue)</option>
          </select>

          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder={lang === "bn" ? "চার্টে খুঁজুন..." : "Filter chart..."}
              className="pl-7 pr-3 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium outline-none w-32 sm:w-44 focus:border-indigo-500"
            />
          </div>

          <button onClick={expandAll} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer">
            {lang === "bn" ? "উন্মুক্ত" : "Expand"}
          </button>
          <button onClick={collapseAll} className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer">
            {lang === "bn" ? "সংকুচিত" : "Collapse"}
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. MULTI-PAGE BREAKDOWN CONTROLS (When in 'pages' viewMode)                */}
      {/* ========================================================================= */}
      {viewMode === "pages" && (
        <div className="bg-indigo-950/20 border border-indigo-500/30 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-black uppercase tracking-wider text-indigo-700 bg-indigo-100 px-2.5 py-1 rounded-md">
              {lang === "bn" ? `পৃষ্ঠা ${activePageIndex + 1} / ${chartPages.length}` : `Page ${activePageIndex + 1} of ${chartPages.length}`}
            </span>
            <span className="text-xs font-bold text-slate-700 truncate max-w-xs sm:max-w-md">
              {chartPages[activePageIndex]?.title}
            </span>
          </div>

          {/* Page Carousel Tabs */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActivePageIndex(p => Math.max(0, p - 1))}
              disabled={activePageIndex === 0}
              className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 disabled:opacity-40 hover:bg-slate-50 cursor-pointer"
            >
              <ChevronLeft size={16} />
            </button>

            <div className="flex items-center gap-1 overflow-x-auto max-w-xs sm:max-w-md p-1">
              {chartPages.map((page, idx) => (
                <button
                  key={idx}
                  onClick={() => setActivePageIndex(idx)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                    activePageIndex === idx 
                      ? "bg-indigo-600 text-white shadow-xs" 
                      : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-100"
                  }`}
                >
                  {idx + 1}
                </button>
              ))}
            </div>

            <button
              onClick={() => setActivePageIndex(p => Math.min(chartPages.length - 1, p + 1))}
              disabled={activePageIndex === chartPages.length - 1}
              className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 disabled:opacity-40 hover:bg-slate-50 cursor-pointer"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. MASTER EXPANSIVE VISUAL CANVAS BOX ("boro box ar modde")                */}
      {/* ========================================================================= */}
      <div 
        ref={chartCanvasRef}
        id="printable-learning-chart"
        className={`rounded-3xl p-6 sm:p-8 transition-all border shadow-lg space-y-6 print:border-none print:shadow-none print:p-0 print:m-0 ${
          canvasTheme === "neon_dark"
            ? "bg-[#030712] border-cyan-500/40 text-slate-100 shadow-[0_0_40px_rgba(6,182,212,0.15)]"
            : canvasTheme === "blueprint"
            ? "bg-[#022c43] border-blue-400 text-blue-50"
            : "bg-white border-[#e4dcc9] text-slate-900"
        }`}
      >
        {/* CHART HEADER (Visible on Screen & Print) */}
        <div className={`border-b pb-5 space-y-3 ${canvasTheme === "neon_dark" ? "border-slate-800" : "border-[#e4dcc9]"}`}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <span className={`text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md ${
                canvasTheme === "neon_dark" ? "bg-cyan-950 text-cyan-300 border border-cyan-800" : "bg-amber-100 text-[#7c2d12]"
              }`}>
                {currentChart.conceptCategory}
              </span>
              <h2 className={`text-2xl sm:text-3xl font-black tracking-tight mt-1.5 ${canvasTheme === "neon_dark" ? "text-white" : "text-slate-900"}`}>
                {currentChart.title}
              </h2>
            </div>
            <div className={`text-right text-xs font-semibold ${canvasTheme === "neon_dark" ? "text-slate-400" : "text-slate-400"} print:text-black`}>
              <span>Date: {currentChart.createdAt}</span>
              <span className={`block text-[10px] font-bold ${canvasTheme === "neon_dark" ? "text-cyan-400" : "text-amber-800"}`}>Lekhok AI Learning Studio</span>
            </div>
          </div>

          {/* Pedagogy Summary */}
          <div className={`rounded-2xl p-4 text-xs sm:text-sm leading-relaxed border ${
            canvasTheme === "neon_dark" 
              ? "bg-[#0f172a]/90 border-slate-800 text-slate-300" 
              : "bg-[#fcfaf7] border-[#e8dfce] text-slate-700"
          }`}>
            <span className={`font-black mr-1 block sm:inline ${canvasTheme === "neon_dark" ? "text-cyan-400" : "text-[#7c2d12]"}`}>
              {lang === "bn" ? "সারসংক্ষেপ ও মূল ধারণা:" : "Core Concept Overview:"}
            </span>
            {currentChart.summary}
          </div>

          {/* Key Takeaways */}
          {currentChart.keyTakeaways && currentChart.keyTakeaways.length > 0 && (
            <div className="space-y-1.5 pt-2">
              <span className={`text-[10px] font-black uppercase tracking-wider block ${canvasTheme === "neon_dark" ? "text-slate-400" : "text-slate-400"}`}>
                {lang === "bn" ? "গুরুত্বপূর্ণ মূল পয়েন্টসমূহ (High-Yield Takeaways):" : "High-Yield Key Takeaways:"}
              </span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {currentChart.keyTakeaways.map((point, pIdx) => (
                  <div 
                    key={pIdx} 
                    className={`rounded-xl p-2.5 text-xs flex items-start gap-2 border ${
                      canvasTheme === "neon_dark"
                        ? "bg-[#0b1120] border-slate-800 text-slate-200"
                        : "bg-amber-50/70 border-amber-200/80 text-slate-800"
                    }`}
                  >
                    <span className={`w-4 h-4 rounded-full text-[10px] font-black flex items-center justify-center shrink-0 mt-0.5 ${
                      canvasTheme === "neon_dark" ? "bg-cyan-500 text-cyan-950" : "bg-amber-600 text-amber-50"
                    }`}>
                      {pIdx + 1}
                    </span>
                    <span>{point}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 1. HIERARCHICAL TREE VIEW (All In One Big Box) */}
        {viewMode === "tree" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className={`text-xs font-black uppercase tracking-wider flex items-center gap-1.5 ${canvasTheme === "neon_dark" ? "text-cyan-400" : "text-slate-400"}`}>
                <GitFork size={13} className="rotate-90" />
                <span>{lang === "bn" ? "সম্পূর্ণ বংশবৃক্ষ ডায়াগ্রাম (Hierarchical Flowchart)" : "Hierarchical Concept Tree"}</span>
              </h4>
            </div>

            {renderTreeNode(currentChart.rootNode)}
          </div>
        )}

        {/* 2. MULTI-PAGE VIEW (Page-by-Page Breakdown) */}
        {viewMode === "pages" && (
          <div className="space-y-4">
            {chartPages[activePageIndex]?.type === "overview" && (
              <div className="space-y-4">
                <div className={`p-4 rounded-2xl border ${canvasTheme === "neon_dark" ? "bg-cyan-950/30 border-cyan-800 text-cyan-200" : "bg-indigo-50 border-indigo-200 text-indigo-950"}`}>
                  <h3 className="font-black text-lg mb-1">{chartPages[activePageIndex].title}</h3>
                  <p className="text-xs leading-relaxed">{currentChart.summary}</p>
                </div>
                {/* Render only Level 1 Branches */}
                {renderTreeNode(currentChart.rootNode)}
              </div>
            )}

            {chartPages[activePageIndex]?.type === "branch" && chartPages[activePageIndex].node && (
              <div className="space-y-4">
                <div className={`p-4 rounded-2xl border ${canvasTheme === "neon_dark" ? "bg-slate-900 border-slate-700 text-slate-200" : "bg-slate-50 border-slate-200 text-slate-900"}`}>
                  <h3 className="font-black text-lg mb-1">{chartPages[activePageIndex].title}</h3>
                  <p className="text-xs leading-relaxed">{chartPages[activePageIndex].subtitle}</p>
                </div>
                {renderTreeNode(chartPages[activePageIndex].node!)}
              </div>
            )}

            {chartPages[activePageIndex]?.type === "matrix" && (
              <div className="space-y-4">
                <h3 className={`text-base font-black uppercase ${canvasTheme === "neon_dark" ? "text-cyan-300" : "text-[#7c2d12]"}`}>
                  {lang === "bn" ? "তুলনামূলক সারসংক্ষেপ টেবিল" : "Comparative Summary Matrix"}
                </h3>
                {/* Table rendered below */}
              </div>
            )}

            {chartPages[activePageIndex]?.type === "quiz" && (
              <div className="space-y-4">
                <h3 className={`text-base font-black uppercase ${canvasTheme === "neon_dark" ? "text-cyan-300" : "text-[#7c2d12]"}`}>
                  {lang === "bn" ? "স্ব-মূল্যায়ন কুইজ" : "Self-Assessment Quiz"}
                </h3>
              </div>
            )}
          </div>
        )}

        {/* 3. COMPARATIVE SUMMARY MATRIX TABLE */}
        {(viewMode === "matrix" || (viewMode === "pages" && chartPages[activePageIndex]?.type === "matrix") || viewMode === "tree") && currentChart.comparativeSummaryTable && currentChart.comparativeSummaryTable.length > 0 && (
          <div className={`pt-6 border-t space-y-3 ${canvasTheme === "neon_dark" ? "border-slate-800" : "border-[#e4dcc9]"}`}>
            <h4 className={`text-sm font-black uppercase tracking-wider flex items-center gap-2 ${canvasTheme === "neon_dark" ? "text-cyan-300" : "text-[#7c2d12]"}`}>
              <Layers size={15} />
              <span>{lang === "bn" ? "তুলনামূলক সারসংক্ষেপ টেবিল (Comparative Summary Matrix)" : "Comparative Summary Matrix"}</span>
            </h4>

            <div className={`overflow-x-auto rounded-2xl border ${canvasTheme === "neon_dark" ? "border-slate-800" : "border-slate-200"}`}>
              <table className="w-full text-left text-xs">
                <thead className={`uppercase text-[10px] font-black tracking-wider ${
                  canvasTheme === "neon_dark" ? "bg-cyan-950 text-cyan-200" : "bg-[#7c2d12] text-amber-50"
                }`}>
                  <tr>
                    <th className="p-3">প্রধান শাখা (Branch)</th>
                    <th className="p-3">উপ-শাখা (Sub-branch)</th>
                    <th className="p-3">গঠন / সূত্র (Formula)</th>
                    <th className="p-3">উদাহরণ (Example)</th>
                    <th className="p-3">শনাক্তকারী লক্ষণ (Identifier)</th>
                  </tr>
                </thead>
                <tbody className={`divide-y ${canvasTheme === "neon_dark" ? "divide-slate-800" : "divide-slate-200"}`}>
                  {currentChart.comparativeSummaryTable.map((row, rIdx) => (
                    <tr key={rIdx} className={canvasTheme === "neon_dark" ? (rIdx % 2 === 0 ? "bg-[#0b1120]" : "bg-[#030712]") : (rIdx % 2 === 0 ? "bg-white" : "bg-[#faf9f6]")}>
                      <td className="p-3 font-bold">{row.branch}</td>
                      <td className={`p-3 font-bold ${canvasTheme === "neon_dark" ? "text-cyan-400" : "text-[#7c2d12]"}`}>{row.subBranch}</td>
                      <td className={`p-3 font-mono font-bold ${canvasTheme === "neon_dark" ? "text-slate-200 bg-cyan-950/20" : "text-slate-800 bg-amber-50/50"}`}>{row.structure}</td>
                      <td className="p-3 italic">{row.example}</td>
                      <td className={`p-3 font-semibold ${canvasTheme === "neon_dark" ? "text-emerald-400" : "text-emerald-800"}`}>{row.keyIdentifier}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 4. INTERACTIVE SELF-TEST QUIZ */}
        {(viewMode === "quiz" || (viewMode === "pages" && chartPages[activePageIndex]?.type === "quiz")) && currentChart.practiceQuestions && currentChart.practiceQuestions.length > 0 && (
          <div className="space-y-4">
            <h4 className={`text-sm font-black uppercase tracking-wider flex items-center gap-2 ${canvasTheme === "neon_dark" ? "text-cyan-300" : "text-[#7c2d12]"}`}>
              <HelpCircle size={15} />
              <span>{lang === "bn" ? "অনুশীলন ও স্ব-মূল্যায়ন কুইজ (Self-Test Knowledge Check)" : "Self-Assessment Quiz"}</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentChart.practiceQuestions.map((q, qIdx) => {
                const userSelected = selectedAnswers[qIdx];
                const isAnswered = userSelected !== undefined;
                const isCorrect = userSelected === q.answer;

                return (
                  <div 
                    key={qIdx} 
                    className={`rounded-2xl p-4 space-y-3 shadow-xs border ${
                      canvasTheme === "neon_dark" ? "bg-[#0b1120] border-slate-800 text-slate-200" : "bg-[#faf9f6] border-[#e4dcc9] text-slate-900"
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <span className={`w-5 h-5 rounded-full text-xs font-black flex items-center justify-center shrink-0 ${
                        canvasTheme === "neon_dark" ? "bg-cyan-500 text-cyan-950" : "bg-[#7c2d12] text-amber-50"
                      }`}>
                        {qIdx + 1}
                      </span>
                      <h5 className="text-sm font-bold leading-snug">
                        {q.question}
                      </h5>
                    </div>

                    {q.options && q.options.length > 0 && (
                      <div className="space-y-1.5 pt-1">
                        {q.options.map((opt, optIdx) => {
                          const isOptionSelected = userSelected === opt;
                          const isTargetAnswer = opt === q.answer;

                          let btnStyle = canvasTheme === "neon_dark" 
                            ? "bg-[#030712] border-slate-700 text-slate-300 hover:border-cyan-500"
                            : "bg-white border-slate-200 text-slate-700 hover:border-amber-400";

                          if (isAnswered) {
                            if (isTargetAnswer) {
                              btnStyle = "bg-emerald-500/20 border-emerald-500 text-emerald-300 font-black";
                            } else if (isOptionSelected && !isCorrect) {
                              btnStyle = "bg-rose-500/20 border-rose-500 text-rose-300 line-through";
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => setSelectedAnswers(prev => ({ ...prev, [qIdx]: opt }))}
                              disabled={isAnswered}
                              className={`w-full text-left p-2.5 rounded-xl border text-xs font-medium transition flex items-center justify-between cursor-pointer ${btnStyle}`}
                            >
                              <span>{opt}</span>
                              {isAnswered && isTargetAnswer && <Check size={14} className="text-emerald-400" />}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {isAnswered && (
                      <div className={`p-2.5 rounded-xl text-xs border ${
                        isCorrect 
                          ? "bg-emerald-950/60 text-emerald-300 border-emerald-800" 
                          : "bg-rose-950/60 text-rose-300 border-rose-800"
                      }`}>
                        <div className="font-bold mb-1">
                          {isCorrect ? "✓ সঠিক উত্তর!" : "✕ ভুল উত্তর! সঠিক উত্তর: " + q.answer}
                        </div>
                        <div className="text-[11px] leading-relaxed">
                          {q.explanation}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 6. SOCIAL MEDIA EXPORT MODAL (Square, Story, Banner with html2canvas)      */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {isSocialModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0f172a] border border-slate-700 text-white rounded-3xl w-full max-w-4xl p-6 shadow-2xl space-y-5"
            >
              {/* Modal Header */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-pink-500/20 text-pink-400 border border-pink-500/40 rounded-xl">
                    <Instagram size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-white">
                      {lang === "bn" ? "সোশ্যাল মিডিয়া পোস্ট ও স্টোরি কার্ড এক্সপোর্ট" : "Export Social Media Infographic Card"}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {lang === "bn" ? "হাই-রেজ্যুলুশন ইমেজ তৈরি করে সোশ্যাল প্ল্যাটফর্মে পোস্ট করুন" : "Generate crisp HD cards tailored for Instagram, LinkedIn & Stories"}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setIsSocialModalOpen(false)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 rounded-full text-slate-400 hover:text-white cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Format & Theme Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    {lang === "bn" ? "পোস্ট সাইজ / ফরম্যাট:" : "Select Aspect Ratio / Format:"}
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setSocialFormat("square_1_1")}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1 cursor-pointer ${
                        socialFormat === "square_1_1" ? "bg-pink-600 border-pink-400 text-white" : "bg-slate-800 border-slate-700 text-slate-300"
                      }`}
                    >
                      <LayoutGrid size={16} />
                      <span>1:1 Square</span>
                    </button>

                    <button
                      onClick={() => setSocialFormat("story_9_16")}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1 cursor-pointer ${
                        socialFormat === "story_9_16" ? "bg-emerald-600 border-emerald-400 text-white" : "bg-slate-800 border-slate-700 text-slate-300"
                      }`}
                    >
                      <Smartphone size={16} />
                      <span>9:16 Story</span>
                    </button>

                    <button
                      onClick={() => setSocialFormat("banner_16_9")}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1 cursor-pointer ${
                        socialFormat === "banner_16_9" ? "bg-blue-600 border-blue-400 text-white" : "bg-slate-800 border-slate-700 text-slate-300"
                      }`}
                    >
                      <Monitor size={16} />
                      <span>16:9 Banner</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 block mb-1.5">
                    {lang === "bn" ? "ভিজ্যুয়াল থিম:" : "Card Theme Style:"}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setSocialCardTheme("cyber_dark")}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                        socialCardTheme === "cyber_dark" ? "bg-cyan-600 border-cyan-400 text-white" : "bg-slate-800 border-slate-700 text-slate-300"
                      }`}
                    >
                      🌌 Cyber Neon Dark
                    </button>
                    <button
                      onClick={() => setSocialCardTheme("gradient_purple")}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                        socialCardTheme === "gradient_purple" ? "bg-purple-600 border-purple-400 text-white" : "bg-slate-800 border-slate-700 text-slate-300"
                      }`}
                    >
                      🔮 Royal Gradient
                    </button>
                  </div>
                </div>
              </div>

              {/* CARD PREVIEW CONTAINER (Target for html2canvas) */}
              <div className="flex justify-center bg-[#030712] p-4 rounded-2xl border border-slate-800 overflow-hidden max-h-[420px] overflow-y-auto">
                <div
                  ref={socialCardPreviewRef}
                  className={`p-6 rounded-3xl shadow-2xl transition-all relative ${
                    socialFormat === "square_1_1"
                      ? "w-[480px] min-h-[480px]"
                      : socialFormat === "story_9_16"
                      ? "w-[360px] min-h-[580px]"
                      : "w-[640px] min-h-[360px]"
                  } ${
                    socialCardTheme === "cyber_dark"
                      ? "bg-gradient-to-b from-[#030712] via-[#0f172a] to-[#1e1b4b] text-white border-2 border-cyan-500/80 shadow-[0_0_40px_rgba(6,182,212,0.3)]"
                      : "bg-gradient-to-br from-[#2e026d] via-[#150050] to-[#000000] text-white border-2 border-purple-500 shadow-[0_0_40px_rgba(168,85,247,0.3)]"
                  }`}
                >
                  {/* Watermark / Brand Header */}
                  <div className="flex items-center justify-between border-b border-white/20 pb-3 mb-4">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-cyan-400 text-black rounded-lg font-black text-xs">
                        Lekhok AI
                      </div>
                      <span className="text-[11px] font-bold text-cyan-300 tracking-wider uppercase">
                        {currentChart.conceptCategory}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      @visual.pedagogy
                    </span>
                  </div>

                  {/* Title & Concept */}
                  <div className="space-y-1 mb-4">
                    <h2 className="text-xl font-black text-white leading-tight">
                      {currentChart.title}
                    </h2>
                    <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                      {currentChart.summary}
                    </p>
                  </div>

                  {/* Branches Highlights */}
                  <div className="space-y-2.5">
                    {currentChart.rootNode.subNodes?.slice(0, 3).map((branch, bIdx) => (
                      <div key={bIdx} className="bg-white/10 backdrop-blur-md border border-white/15 p-2.5 rounded-xl space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black text-cyan-300">{branch.title}</span>
                          {branch.badge && <span className="text-[9px] bg-cyan-400 text-black font-black px-1.5 py-0.5 rounded">{branch.badge}</span>}
                        </div>
                        {branch.subNodes && branch.subNodes.length > 0 && (
                          <div className="flex flex-wrap gap-1 pt-1">
                            {branch.subNodes.map((s, sIdx) => (
                              <span key={sIdx} className="text-[10px] bg-black/40 border border-white/10 px-2 py-0.5 rounded-md text-slate-200 font-medium">
                                {s.title}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Footer Tag */}
                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400">
                    <span>💡 Learn & Master Faster with Visual Trees</span>
                    <span className="text-cyan-300 font-bold">Lekhok AI Studio</span>
                  </div>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-between border-t border-slate-800 pt-4">
                <span className="text-xs text-slate-400">
                  {lang === "bn" ? "রেজ্যুলুশন: Ultra HD 2.5x PNG" : "Format: Ultra HD 2.5x PNG"}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsSocialModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    {lang === "bn" ? "বাতিল" : "Cancel"}
                  </button>

                  <button
                    onClick={handleDownloadSocialCard}
                    disabled={isExportingImage}
                    className="px-5 py-2 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 disabled:opacity-50 text-white font-black rounded-xl text-xs flex items-center gap-2 shadow-lg cursor-pointer"
                  >
                    <DownloadCloud size={15} />
                    <span>{isExportingImage ? (lang === "bn" ? "ডাউনলোড হচ্ছে..." : "Exporting...") : (lang === "bn" ? "HD ইমেজ ডাউনলোড করুন" : "Download HD Image")}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
