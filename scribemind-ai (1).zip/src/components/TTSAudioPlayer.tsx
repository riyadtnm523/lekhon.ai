import React, { useState, useEffect, useRef } from "react";
import { Volume2, VolumeX, Play, Pause, RotateCcw, FastForward, Rewind, Settings2, Sparkles, Sliders, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface TTSAudioPlayerProps {
  text: string;
  title: string;
  chapterNumber: number;
  language?: string;
  lang: "bn" | "en";
}

export const TTSAudioPlayer: React.FC<TTSAudioPlayerProps> = ({
  text,
  title,
  chapterNumber,
  language = "Bengali",
  lang
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [rate, setRate] = useState<number>(1.0);
  const [pitch, setPitch] = useState<number>(1.0);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceURI, setSelectedVoiceURI] = useState<string>("");
  const [progress, setProgress] = useState<number>(0);
  const [showSettings, setShowSettings] = useState(false);
  const [currentSentence, setCurrentSentence] = useState<string>("");

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const chunksRef = useRef<string[]>([]);
  const currentChunkIndexRef = useRef<number>(0);
  const isPlayingRef = useRef<boolean>(false);

  // Clean Markdown markup for clean speech audio
  const cleanMarkdownForSpeech = (raw: string): string => {
    return raw
      .replace(/!\[.*?\]\(.*?\)/g, "") // remove images
      .replace(/\[.*?\]\(.*?\)/g, "$1") // link text only
      .replace(/```[\s\S]*?```/g, " [Code snippet] ") // skip code fences
      .replace(/`([^`]+)`/g, "$1")
      .replace(/#{1,6}\s+/g, "")
      .replace(/[*_~>]/g, "")
      .replace(/\[3d:[a-zA-Z0-9_-]+\]/g, "")
      .replace(/\[youtube:[a-zA-Z0-9_-]+\]/g, "")
      .replace(/\[video:.*?\]/g, "")
      .replace(/\n+/g, " ")
      .trim();
  };

  // Load available system voices
  useEffect(() => {
    const updateVoices = () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        const availableVoices = window.speechSynthesis.getVoices();
        setVoices(availableVoices);

        // Auto select preferred voice for Bengali or English
        const isBn = language.toLowerCase().includes("bengali") || language.toLowerCase().includes("bangla") || lang === "bn";
        const matchingVoice = availableVoices.find(v => 
          isBn ? (v.lang.includes("bn") || v.lang.includes("BD") || v.lang.includes("IN")) : (v.lang.includes("en-US") || v.lang.includes("en-GB"))
        );
        if (matchingVoice && !selectedVoiceURI) {
          setSelectedVoiceURI(matchingVoice.voiceURI);
        } else if (availableVoices.length > 0 && !selectedVoiceURI) {
          setSelectedVoiceURI(availableVoices[0].voiceURI);
        }
      }
    };

    updateVoices();
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }

    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [language, lang]);

  // Split text into natural conversational sentences for reliable long-form reading
  const prepareChunks = (fullText: string) => {
    const cleaned = cleanMarkdownForSpeech(fullText);
    if (!cleaned) return [];
    // Split by sentence terminators (., ।, ?, !)
    const sentences = cleaned.match(/[^.!?|।\n]+[.!?|।\n]+/g) || [cleaned];
    return sentences.map(s => s.trim()).filter(Boolean);
  };

  const playChunk = (index: number) => {
    if (!("speechSynthesis" in window)) return;
    const chunks = chunksRef.current;
    if (index >= chunks.length || !isPlayingRef.current) {
      setIsPlaying(false);
      setIsPaused(false);
      isPlayingRef.current = false;
      setProgress(100);
      return;
    }

    currentChunkIndexRef.current = index;
    const chunkText = chunks[index];
    setCurrentSentence(chunkText);
    setProgress(Math.round((index / chunks.length) * 100));

    window.speechSynthesis.cancel(); // cancel any active utterance

    const utter = new SpeechSynthesisUtterance(chunkText);
    utter.rate = rate;
    utter.pitch = pitch;

    if (selectedVoiceURI) {
      const selected = voices.find(v => v.voiceURI === selectedVoiceURI);
      if (selected) utter.voice = selected;
    }

    // Auto-detect language if Bengali
    if (language.toLowerCase().includes("bengali") || lang === "bn") {
      utter.lang = "bn-BD";
    }

    utter.onend = () => {
      if (isPlayingRef.current) {
        playChunk(index + 1);
      }
    };

    utter.onerror = (e) => {
      console.warn("TTS chunk speech notice:", e);
      if (isPlayingRef.current && index + 1 < chunks.length) {
        setTimeout(() => playChunk(index + 1), 200);
      } else {
        setIsPlaying(false);
        setIsPaused(false);
        isPlayingRef.current = false;
      }
    };

    utteranceRef.current = utter;
    window.speechSynthesis.speak(utter);
  };

  const handleTogglePlay = () => {
    if (!("speechSynthesis" in window)) {
      alert(lang === "bn" ? "আপনার ব্রাউজারে টেক্সট-টু-স্পিচ সমর্থিত নয়।" : "Speech synthesis is not supported on this browser.");
      return;
    }

    if (isPlaying && !isPaused) {
      // Pause
      window.speechSynthesis.pause();
      setIsPaused(true);
    } else if (isPlaying && isPaused) {
      // Resume
      window.speechSynthesis.resume();
      setIsPaused(false);
    } else {
      // Start fresh
      const chunks = prepareChunks(text);
      if (chunks.length === 0) return;
      chunksRef.current = chunks;
      isPlayingRef.current = true;
      setIsPlaying(true);
      setIsPaused(false);
      playChunk(0);
    }
  };

  const handleStop = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    isPlayingRef.current = false;
    setIsPlaying(false);
    setIsPaused(false);
    setProgress(0);
    setCurrentSentence("");
    currentChunkIndexRef.current = 0;
  };

  const handleNextSentence = () => {
    if (isPlaying) {
      playChunk(currentChunkIndexRef.current + 1);
    }
  };

  const handlePrevSentence = () => {
    if (isPlaying && currentChunkIndexRef.current > 0) {
      playChunk(currentChunkIndexRef.current - 1);
    }
  };

  const handleRateChange = (newRate: number) => {
    setRate(newRate);
    if (isPlaying && !isPaused) {
      // Re-trigger current chunk with new speed
      playChunk(currentChunkIndexRef.current);
    }
  };

  if (!text || text.trim().length === 0) return null;

  return (
    <div className="bg-gradient-to-r from-amber-900 via-[#7c2d12] to-amber-950 text-white rounded-2xl p-4 sm:p-5 shadow-lg border border-amber-800/60 font-sans print:hidden relative overflow-hidden">
      {/* Background Animated Sound Wave Effect when Playing */}
      <div className="absolute inset-0 bg-radial-gradient from-transparent to-black/30 pointer-events-none" />
      
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Left info: Chapter Audio Title & Waveform Visualizer */}
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 shrink-0 shadow-inner">
            <Volume2 size={20} className={isPlaying && !isPaused ? "animate-pulse" : ""} />
          </div>
          <div className="text-left space-y-0.5 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-black tracking-widest text-amber-300 bg-black/30 px-2 py-0.5 rounded">
                {lang === "bn" ? `অডিওবুক • অধ্যায় ${chapterNumber}` : `Audiobook • Chapter ${chapterNumber}`}
              </span>
              {isPlaying && !isPaused && (
                <div className="flex items-center gap-0.5 h-3">
                  {[40, 90, 60, 100, 50, 80].map((h, i) => (
                    <motion.div
                      key={i}
                      animate={{ height: ["20%", `${h}%`, "30%"] }}
                      transition={{ repeat: Infinity, duration: 0.6 + i * 0.1, ease: "easeInOut" }}
                      className="w-0.5 bg-amber-400 rounded-full"
                    />
                  ))}
                </div>
              )}
            </div>
            <h4 className="text-xs sm:text-sm font-bold text-white truncate max-w-xs sm:max-w-md">
              {title}
            </h4>
            {currentSentence && isPlaying && (
              <p className="text-[11px] text-amber-200/90 italic truncate max-w-xs sm:max-w-md font-serif">
                "{currentSentence}"
              </p>
            )}
          </div>
        </div>

        {/* Center & Right: Playback Controls + Speed Selection */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 self-end md:self-auto">
          
          {/* Sentence Skip Buttons */}
          <div className="flex items-center gap-1 bg-black/20 p-1 rounded-xl border border-white/10">
            <button
              onClick={handlePrevSentence}
              disabled={!isPlaying || currentChunkIndexRef.current === 0}
              className="p-1.5 hover:bg-white/10 disabled:opacity-30 rounded-lg transition text-amber-200 cursor-pointer"
              title={lang === "bn" ? "পূর্ববর্তী বাক্য" : "Previous Sentence"}
            >
              <Rewind size={14} />
            </button>
            <button
              onClick={handleTogglePlay}
              className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-amber-950 font-black rounded-lg text-xs transition flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              {isPlaying && !isPaused ? (
                <>
                  <Pause size={14} className="fill-current" />
                  <span>{lang === "bn" ? "পজ" : "Pause"}</span>
                </>
              ) : (
                <>
                  <Play size={14} className="fill-current" />
                  <span>{isPaused ? (lang === "bn" ? "চালান" : "Resume") : (lang === "bn" ? "শুনুন" : "Play Audio")}</span>
                </>
              )}
            </button>
            <button
              onClick={handleNextSentence}
              disabled={!isPlaying}
              className="p-1.5 hover:bg-white/10 disabled:opacity-30 rounded-lg transition text-amber-200 cursor-pointer"
              title={lang === "bn" ? "পরবর্তী বাক্য" : "Next Sentence"}
            >
              <FastForward size={14} />
            </button>
            <button
              onClick={handleStop}
              disabled={!isPlaying && !isPaused}
              className="p-1.5 hover:bg-white/10 disabled:opacity-30 rounded-lg transition text-rose-300 cursor-pointer"
              title={lang === "bn" ? "থামান" : "Stop"}
            >
              <RotateCcw size={14} />
            </button>
          </div>

          {/* Speed Selector Buttons */}
          <div className="flex items-center bg-black/25 p-1 rounded-xl border border-white/10">
            {[0.75, 1.0, 1.25, 1.5, 2.0].map((s) => (
              <button
                key={s}
                onClick={() => handleRateChange(s)}
                className={`px-2 py-1 rounded-md text-[10px] font-extrabold transition cursor-pointer ${
                  rate === s
                    ? "bg-amber-400 text-amber-950 shadow-xs"
                    : "text-amber-200/80 hover:text-white hover:bg-white/10"
                }`}
              >
                {s}x
              </button>
            ))}
          </div>

          {/* Voice Settings Dropdown Toggle */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-2 rounded-xl border transition cursor-pointer ${
              showSettings
                ? "bg-amber-400 text-amber-950 border-amber-300"
                : "bg-black/20 text-amber-200 border-white/10 hover:bg-white/10"
            }`}
            title={lang === "bn" ? "ভয়েস ও উচ্চারণ সেটিংস" : "Voice Settings"}
          >
            <Sliders size={14} />
          </button>

        </div>
      </div>

      {/* Progress Bar */}
      {isPlaying && (
        <div className="mt-3 w-full bg-black/30 rounded-full h-1.5 overflow-hidden">
          <motion.div
            className="bg-gradient-to-r from-amber-400 to-amber-200 h-full rounded-full"
            style={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      )}

      {/* Voice Selection Drawer */}
      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 pt-4 border-t border-amber-700/60 grid grid-cols-1 sm:grid-cols-2 gap-3 text-left"
          >
            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-wider text-amber-300">
                {lang === "bn" ? "কণ্ঠস্বর (Voice)" : "Voice Model"}
              </label>
              <select
                value={selectedVoiceURI}
                onChange={(e) => setSelectedVoiceURI(e.target.value)}
                className="w-full bg-black/40 border border-amber-600/40 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-amber-400"
              >
                {voices.map((v, i) => (
                  <option key={i} value={v.voiceURI} className="bg-slate-900 text-white">
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-bold uppercase tracking-wider text-amber-300">
                <span>{lang === "bn" ? "ভয়েস পিচ (Tone)" : "Pitch"}</span>
                <span>{pitch.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="0.7"
                max="1.3"
                step="0.1"
                value={pitch}
                onChange={(e) => setPitch(parseFloat(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
