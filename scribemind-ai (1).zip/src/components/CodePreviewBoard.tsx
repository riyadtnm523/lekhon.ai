import React, { useState, useEffect, useRef } from "react";
import {
  Code2, Play, RefreshCw, Copy, Check, Download, Sparkles,
  Monitor, Tablet, Smartphone, Maximize2, Layers, Zap,
  FileCode, CheckCircle2, ArrowRight, BookOpen, Plus, Trash2
} from "lucide-react";
import { motion } from "motion/react";

interface CodePreviewBoardProps {
  lang: "bn" | "en";
  currentUser?: any;
  onInsertToBook?: (codeSnippet: string) => void;
  onInsertCodeToBook?: (codeSnippet: string) => void;
  activeBookTitle?: string;
}

interface ProjectFiles {
  "index.html": string;
  "style.css": string;
  "metadata.json": string;
  "components/App.jsx": string;
}

const DEFAULT_PROJECT_FILES: ProjectFiles = {
  "index.html": `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Interactive Preview Board</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-900 text-slate-100 min-h-screen flex flex-col items-center justify-center p-6 font-sans">
  <div id="root" class="w-full max-w-lg"></div>
  
  <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <script type="text/babel" src="components/App.jsx"></script>
</body>
</html>`,

  "style.css": `/* Modern Glassmorphism & UI Accents */
body {
  margin: 0;
  font-family: system-ui, -apple-system, sans-serif;
  background: radial-gradient(circle at top, #1e293b, #0f172a);
}

.glass-panel {
  background: rgba(30, 41, 59, 0.7);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
}

.glow-btn {
  background: linear-gradient(135deg, #f59e0b, #d97706);
  transition: all 0.3s ease;
}

.glow-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(245, 158, 11, 0.4);
}`,

  "metadata.json": `{
  "name": "Live Web Preview Project",
  "version": "2.4.0",
  "author": "Lekhok AI Author Studio",
  "framework": "React 18 + Tailwind CSS",
  "responsive": true,
  "theme": "Midnight Glass"
}`,

  "components/App.jsx": `function App() {
  const [count, setCount] = React.useState(0);
  const [isLiked, setIsLiked] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState("overview");

  return (
    <div className="glass-panel rounded-3xl p-8 text-center space-y-6 text-white border border-slate-700">
      <div className="inline-flex p-3 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-500/30">
        <i className="fa-solid fa-code text-2xl"></i>
      </div>
      
      <div className="space-y-2">
        <h1 className="text-2xl font-black tracking-tight">Interactive Preview Board</h1>
        <p className="text-xs text-slate-300">Edit HTML, CSS, Metadata & JSX simultaneously on the left and see instant live reload!</p>
      </div>

      <div className="flex justify-center gap-3">
        <button 
          onClick={() => setCount(c => c + 1)}
          className="glow-btn px-5 py-2.5 rounded-xl font-bold text-xs text-white flex items-center gap-2 cursor-pointer"
        >
          <i className="fa-solid fa-plus"></i> Count: {count}
        </button>

        <button 
          onClick={() => setIsLiked(!isLiked)}
          className={"px-4 py-2.5 rounded-xl font-bold text-xs border transition flex items-center gap-2 cursor-pointer " + (isLiked ? "bg-rose-600 border-rose-500 text-white" : "bg-slate-800 border-slate-700 text-slate-300")}
        >
          <i className={"fa-solid fa-heart " + (isLiked ? "text-white" : "text-rose-400")}></i>
          {isLiked ? "Favorited!" : "Like"}
        </button>
      </div>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));`
};

export const QUICK_SNIPPETS = [
  {
    title: "⚡ Interactive Counter",
    file: "components/App.jsx",
    desc: "React state counter with increment, reset & visual badge",
    code: `const [count, setCount] = React.useState(0);\n// Increment Handler: setCount(c => c + 1);`
  },
  {
    title: "🎨 Glassmorphism Card",
    file: "style.css",
    desc: "Frosted glass container with backdrop filter & glowing borders",
    code: `.glass-container {\n  background: rgba(255, 255, 255, 0.08);\n  backdrop-filter: blur(12px);\n  border: 1px solid rgba(255, 255, 255, 0.15);\n  border-radius: 1.25rem;\n}`
  },
  {
    title: "📱 Responsive Nav Drawer",
    file: "index.html",
    desc: "Mobile burger navigation with animated slide-in drawer",
    code: `<nav class="flex items-center justify-between p-4 bg-slate-900 text-white">\n  <span class="font-bold">Brand</span>\n  <button class="md:hidden p-2"><i class="fa-solid fa-bars"></i></button>\n</nav>`
  },
  {
    title: "🌟 Dark Mode Toggle",
    file: "components/App.jsx",
    desc: "Dark & light theme switcher with persistent local storage",
    code: `const [isDark, setIsDark] = React.useState(true);\n// Toggle theme: setIsDark(!isDark);`
  }
];

export const CodePreviewBoard: React.FC<CodePreviewBoardProps> = ({
  lang,
  currentUser,
  onInsertToBook,
  onInsertCodeToBook,
  activeBookTitle
}) => {
  const [files, setFiles] = useState<ProjectFiles>(DEFAULT_PROJECT_FILES);
  const [activeFile, setActiveFile] = useState<keyof ProjectFiles>("components/App.jsx");
  const [deviceMode, setDeviceMode] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [insertedNotice, setInsertedNotice] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  // Compile files into single bundle for iframe execution
  const compilePreview = () => {
    let html = files["index.html"];
    const css = files["style.css"];
    const jsx = files["components/App.jsx"];

    // Inject CSS
    if (html.includes("</head>")) {
      html = html.replace("</head>", `<style>${css}</style></head>`);
    }

    // Inject JSX
    if (html.includes('src="components/App.jsx"')) {
      html = html.replace('<script type="text/babel" src="components/App.jsx"></script>', `<script type="text/babel">${jsx}</script>`);
    }

    return html;
  };

  const [previewDoc, setPreviewDoc] = useState(compilePreview());

  useEffect(() => {
    const timer = setTimeout(() => {
      setPreviewDoc(compilePreview());
    }, 300);
    return () => clearTimeout(timer);
  }, [files]);

  const handleCopyCode = (filename: string) => {
    navigator.clipboard.writeText(files[filename as keyof ProjectFiles]);
    setCopiedFile(filename);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const handleInsertSnippet = (snippetCode: string) => {
    setFiles(prev => ({
      ...prev,
      [activeFile]: prev[activeFile] + "\n\n" + snippetCode
    }));
  };

  const insertCallback = onInsertCodeToBook || onInsertToBook;

  const handleInsertToBookChapter = () => {
    if (!insertCallback) return;
    const markdownCode = `\`\`\`html\n<!-- Multi-File Web Project: ${activeFile} -->\n${files[activeFile]}\n\`\`\``;
    insertCallback(markdownCode);
    setInsertedNotice(true);
    setTimeout(() => setInsertedNotice(false), 2200);
  };

  return (
    <div id="code-preview-board-container" className="w-full max-w-7xl mx-auto space-y-6 font-sans text-left pb-16">
      {/* Header Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border border-amber-900/40">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-black border border-amber-500/30">
            <Code2 size={13} />
            <span>{lang === "bn" ? "প্রিভিউ বোর্ড ও মাল্টি-ফাইল ওয়েব স্টুডিও" : "Preview Board & Multi-File Web Studio"}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black font-serif tracking-tight">
            {lang === "bn" ? "লাইভ মাল্টি-ফাইল কোড প্রিভিউ বোর্ড" : "Live Multi-File Code Preview Board"}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            {lang === "bn" 
              ? "এক সাথে index.html, style.css, metadata.json এবং components ফাইল কোড লিখুন, লাইভ টেস্ট করুন এবং এক ক্লিকে বইয়ের অধ্যায়ে কোড ইনসার্ট করুন।" 
              : "Simultaneously view & test index.html, style.css, metadata.json and components with live multi-device preview."}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {insertCallback && (
            <button
              onClick={handleInsertToBookChapter}
              className="px-4 py-2.5 bg-gradient-to-r from-amber-600 to-[#7c2d12] hover:from-amber-700 hover:to-[#63220c] text-white rounded-xl text-xs font-extrabold flex items-center gap-2 cursor-pointer shadow-md transition"
              title="Insert current file code into active book chapter"
            >
              {insertedNotice ? <Check size={14} /> : <BookOpen size={14} />}
              <span>{insertedNotice ? (lang === "bn" ? "অধ্যায়ে যুক্ত হয়েছে!" : "Inserted to Chapter!") : (lang === "bn" ? "বইয়ের অধ্যায়ে কোড ইনসার্ট" : "Insert Code into Book")}</span>
            </button>
          )}

          <button
            onClick={() => setFiles(DEFAULT_PROJECT_FILES)}
            className="px-3 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer border border-white/10"
          >
            <RefreshCw size={13} />
            <span>{lang === "bn" ? "রিসেট" : "Reset"}</span>
          </button>
        </div>
      </div>

      {/* Quick Snippet Insert Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-[#eae3d2] dark:border-slate-800 shadow-sm flex items-center gap-3 overflow-x-auto">
        <div className="flex items-center gap-1.5 text-xs font-black text-[#7c2d12] dark:text-amber-400 shrink-0">
          <Sparkles size={14} />
          <span>{lang === "bn" ? "কুইক কোড ইনসার্ট:" : "Quick Insert:"}</span>
        </div>
        {QUICK_SNIPPETS.map((snip, idx) => (
          <button
            key={idx}
            onClick={() => handleInsertSnippet(snip.code)}
            className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 shrink-0 transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
            title={snip.desc}
          >
            <Plus size={12} className="text-amber-600" />
            <span>{snip.title}</span>
          </button>
        ))}
      </div>

      {/* Main Studio Grid: Editor on Left, Live Preview on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[600px]">
        {/* Editor Area (5 Columns) */}
        <div className="lg:col-span-6 flex flex-col bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden shadow-xl">
          {/* File Tabs */}
          <div className="flex items-center bg-slate-900 border-b border-slate-800 px-3 overflow-x-auto">
            {(Object.keys(files) as Array<keyof ProjectFiles>).map((fileName) => (
              <button
                key={fileName}
                onClick={() => setActiveFile(fileName)}
                className={`px-4 py-3 text-xs font-bold flex items-center gap-2 border-b-2 transition shrink-0 cursor-pointer ${
                  activeFile === fileName
                    ? "border-amber-500 text-amber-400 bg-slate-950"
                    : "border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
                }`}
              >
                <FileCode size={13} />
                <span>{fileName}</span>
              </button>
            ))}

            <div className="ml-auto flex items-center gap-2 pr-2">
              <button
                onClick={() => handleCopyCode(activeFile)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
                title="Copy File Code"
              >
                {copiedFile === activeFile ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
              </button>
            </div>
          </div>

          {/* Active Code Textarea */}
          <div className="flex-1 p-4 bg-slate-950 text-slate-100 font-mono text-xs relative flex flex-col">
            <textarea
              value={files[activeFile]}
              onChange={(e) => {
                const val = e.target.value;
                setFiles(prev => ({ ...prev, [activeFile]: val }));
              }}
              spellCheck={false}
              className="w-full flex-1 bg-transparent text-amber-100/90 font-mono text-xs leading-relaxed outline-hidden resize-none selection:bg-amber-600/40"
              rows={24}
            />
          </div>
        </div>

        {/* Live Preview Area (6 Columns) */}
        <div className="lg:col-span-6 flex flex-col bg-slate-100 dark:bg-slate-900 rounded-3xl border border-[#eae3d2] dark:border-slate-800 overflow-hidden shadow-xl">
          {/* Top Preview Controls */}
          <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-rose-500" />
              <span className="w-3 h-3 rounded-full bg-amber-500" />
              <span className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="text-[11px] font-bold text-slate-500 ml-2 font-mono">Live Preview Stage</span>
            </div>

            {/* Device Modes */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl text-xs">
              <button
                onClick={() => setDeviceMode("desktop")}
                className={`p-1.5 rounded-lg transition ${deviceMode === "desktop" ? "bg-white dark:bg-slate-700 text-[#7c2d12] dark:text-amber-300 shadow-xs font-bold" : "text-slate-500"}`}
                title="Desktop View (100%)"
              >
                <Monitor size={14} />
              </button>
              <button
                onClick={() => setDeviceMode("tablet")}
                className={`p-1.5 rounded-lg transition ${deviceMode === "tablet" ? "bg-white dark:bg-slate-700 text-[#7c2d12] dark:text-amber-300 shadow-xs font-bold" : "text-slate-500"}`}
                title="Tablet View (768px)"
              >
                <Tablet size={14} />
              </button>
              <button
                onClick={() => setDeviceMode("mobile")}
                className={`p-1.5 rounded-lg transition ${deviceMode === "mobile" ? "bg-white dark:bg-slate-700 text-[#7c2d12] dark:text-amber-300 shadow-xs font-bold" : "text-slate-500"}`}
                title="Mobile View (375px)"
              >
                <Smartphone size={14} />
              </button>
            </div>
          </div>

          {/* Iframe Preview Canvas */}
          <div className="flex-1 p-4 bg-slate-800/40 flex items-center justify-center overflow-auto min-h-[500px]">
            <div
              className={`bg-white rounded-2xl overflow-hidden shadow-2xl transition-all duration-300 h-full border border-slate-700/60 ${
                deviceMode === "desktop" ? "w-full" : deviceMode === "tablet" ? "w-[768px] max-w-full" : "w-[375px] max-w-full"
              }`}
              style={{ minHeight: "480px" }}
            >
              <iframe
                ref={iframeRef}
                srcDoc={previewDoc}
                title="Code Preview Frame"
                sandbox="allow-scripts allow-modals allow-same-origin allow-forms"
                className="w-full h-full min-h-[480px] border-none"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
