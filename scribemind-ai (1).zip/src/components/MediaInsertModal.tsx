import React, { useState } from "react";
import { X, Image as ImageIcon, Video, Box, Music, Link, Sparkles, Check, Upload, Play } from "lucide-react";

interface MediaInsertModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInsert: (markdownSnippet: string) => void;
  lang?: "bn" | "en";
}

export const MediaInsertModal: React.FC<MediaInsertModalProps> = ({
  isOpen,
  onClose,
  onInsert,
  lang = "bn"
}) => {
  const [activeTab, setActiveTab] = useState<"image" | "video" | "3d" | "callout" | "audio">("image");

  // Image states
  const [imageUrl, setImageUrl] = useState("");
  const [imageCaption, setImageCaption] = useState("");
  const [imagePreset, setImagePreset] = useState("technology");

  // Video states
  const [videoUrl, setVideoUrl] = useState("");
  const [videoTitle, setVideoTitle] = useState("");

  // 3D states
  const [selected3D, setSelected3D] = useState("earth");
  const [threeTitle, setThreeTitle] = useState("");

  // Callout states
  const [calloutType, setCalloutType] = useState<"tip" | "warn" | "info" | "success">("tip");
  const [calloutText, setCalloutText] = useState("");

  if (!isOpen) return null;

  const sampleImages = {
    technology: [
      { url: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97", title: "Coding Laptop Workspace" },
      { url: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5", title: "Cyber Code Matrix" },
      { url: "https://images.unsplash.com/photo-1555066931-4365d14bab8c", title: "Developer Screen" }
    ],
    nature: [
      { url: "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d", title: "Enchanted Forest" },
      { url: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05", title: "Misty Mountains" },
      { url: "https://images.unsplash.com/photo-1472214222541-d510753a8707", title: "Green Valley River" }
    ],
    scifi: [
      { url: "https://images.unsplash.com/photo-1451187580459-43490279c0fa", title: "Digital Earth from Space" },
      { url: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564", title: "Cosmic Nebula" },
      { url: "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0", title: "Deep Space Stars" }
    ]
  };

  const handleInsertImage = () => {
    if (!imageUrl.trim()) return;
    const snippet = `\n\n![${imageCaption.trim() || 'Book Illustration'}](${imageUrl.trim()})\n\n`;
    onInsert(snippet);
    onClose();
  };

  const handleInsertVideo = () => {
    if (!videoUrl.trim()) return;
    const snippet = `\n\n[video:${videoUrl.trim()}]\n*${videoTitle.trim() || 'ভিডিও প্লেয়ার'}*\n\n`;
    onInsert(snippet);
    onClose();
  };

  const handleInsert3D = () => {
    const snippet = `\n\n[3d:${selected3D}]\n*${threeTitle.trim() || (lang === "bn" ? 'ইন্টারেক্টিভ ৩ডি মডেল' : '3D Interactive Model')}*\n\n`;
    onInsert(snippet);
    onClose();
  };

  const handleInsertCallout = () => {
    if (!calloutText.trim()) return;
    let prefix = "💡";
    if (calloutType === "warn") prefix = "⚠️";
    if (calloutType === "info") prefix = "📘";
    if (calloutType === "success") prefix = "🟢";

    const snippet = `\n\n> ${prefix} ${calloutText.trim()}\n\n`;
    onInsert(snippet);
    onClose();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (!result) return;

      if (file.type.startsWith("image/")) {
        setImageUrl(result);
        setImageCaption(file.name.replace(/\.[^/.]+$/, ""));
      } else if (file.type.startsWith("video/")) {
        setVideoUrl(result);
        setVideoTitle(file.name.replace(/\.[^/.]+$/, ""));
        setActiveTab("video");
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              {lang === "bn" ? "পাণ্ডুলিপিতে ছবি, ভিডিও বা ৩ডি যোগ করুন" : "Insert Media or 3D Animation"}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-100 dark:border-slate-800 px-6 bg-slate-50 dark:bg-slate-950/40 gap-1 overflow-x-auto">
          {[
            { id: "image", label: lang === "bn" ? "🖼️ ছবি / ফটো" : "🖼️ Image", icon: ImageIcon },
            { id: "video", label: lang === "bn" ? "🎬 ভিডিও প্লেয়ার" : "🎬 Video", icon: Video },
            { id: "3d", label: lang === "bn" ? "🪐 ৩ডি অ্যানিমেশন" : "🪐 3D Models", icon: Box },
            { id: "callout", label: lang === "bn" ? "💡 রঙিন কলআউট" : "💡 Callout", icon: Sparkles }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 py-3 px-3 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? "border-amber-600 text-amber-600 dark:text-amber-400"
                    : "border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-300"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* TAB 1: IMAGE */}
          {activeTab === "image" && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === "bn" ? "ছবির লিংক (URL) বা ফাইল আপলোড:" : "Image URL or Upload File:"}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="flex-1 px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                  <label className="cursor-pointer flex items-center gap-1 px-3 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-300 transition-colors">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{lang === "bn" ? "আপলোড" : "Upload"}</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === "bn" ? "ছবির ক্যাপশন / বিবরণ:" : "Caption / Description:"}
                </label>
                <input
                  type="text"
                  value={imageCaption}
                  onChange={(e) => setImageCaption(e.target.value)}
                  placeholder={lang === "bn" ? "যেমন: সুন্দরবনের নৈসর্গিক দৃশ্য" : "e.g., Majestic landscape"}
                  className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              {/* Sample high quality image presets */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  {lang === "bn" ? "অথবা দ্রুত হাই-কোয়ালিটি ফটো পছন্দ করুন:" : "Or select a high-res stock photo:"}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[...sampleImages.technology, ...sampleImages.nature, ...sampleImages.scifi].slice(0, 6).map((img, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setImageUrl(img.url);
                        setImageCaption(img.title);
                      }}
                      className={`relative rounded-xl overflow-hidden aspect-video border-2 transition-all ${
                        imageUrl === img.url ? "border-amber-500 ring-2 ring-amber-500/30" : "border-transparent hover:opacity-90"
                      }`}
                    >
                      <img src={img.url} alt={img.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-1">
                        <span className="text-[9px] text-white font-medium truncate">{img.title}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: VIDEO */}
          {activeTab === "video" && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === "bn" ? "ইউটিউব (YouTube) বা ভিডিও লিংক (MP4/WebM):" : "YouTube or Video URL (MP4):"}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    placeholder="https://www.youtube.com/watch?v=..."
                    className="flex-1 px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                  <label className="cursor-pointer flex items-center gap-1 px-3 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-300 transition-colors">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{lang === "bn" ? "ভিডিও ফাইল" : "Upload MP4"}</span>
                    <input type="file" accept="video/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === "bn" ? "ভিডিওর শিরোনাম বা বিবরণ:" : "Video Title / Caption:"}
                </label>
                <input
                  type="text"
                  value={videoTitle}
                  onChange={(e) => setVideoTitle(e.target.value)}
                  placeholder={lang === "bn" ? "যেমন: এইচটিএমএল ও সিএসএস লাইভ ডেমো ভিডিও" : "e.g., Interactive Walkthrough"}
                  className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-xl text-[11px] text-amber-900 dark:text-amber-200">
                💡 {lang === "bn" ? "যেকোনো YouTube ভিডিও লিংক দিলে বইয়ের পৃষ্ঠার ভেতরে সরাসরি লাইভ ভিডিও প্লেয়ার এম্বেড হয়ে যাবে!" : "Enter any YouTube or video link to embed a responsive player directly inside the chapter!"}
              </div>
            </div>
          )}

          {/* TAB 3: 3D ANIMATION */}
          {activeTab === "3d" && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  {lang === "bn" ? "ইন্টারেক্টিভ ৩ডি মডেল পছন্দ করুন:" : "Select 3D Interactive Model:"}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "earth", name: "🌍 3D Earth", desc: "Atmosphere & Orbit" },
                    { id: "solar_system", name: "🪐 Solar System", desc: "Planetary Orbits" },
                    { id: "galaxy", name: "🌌 Cosmic Galaxy", desc: "Particle Spiral" },
                    { id: "cube", name: "🧊 Cyber 3D Cube", desc: "Wireframe Nodes" },
                    { id: "dna", name: "🧬 DNA Helix", desc: "Genetics Model" },
                    { id: "molecule", name: "⚛️ Atom Molecule", desc: "Electron Physics" }
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setSelected3D(m.id)}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        selected3D === m.id
                          ? "border-sky-500 bg-sky-50 dark:bg-sky-950/40 text-sky-900 dark:text-sky-200 ring-2 ring-sky-500/20"
                          : "border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100"
                      }`}
                    >
                      <p className="font-bold text-xs">{m.name}</p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{m.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === "bn" ? "৩ডি মডেলের শিরোনাম:" : "3D Model Title / Label:"}
                </label>
                <input
                  type="text"
                  value={threeTitle}
                  onChange={(e) => setThreeTitle(e.target.value)}
                  placeholder={lang === "bn" ? "যেমন: সৌরজগতের ত্রিমাত্রিক মডেল" : "e.g., 3D Solar System"}
                  className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          )}

          {/* TAB 4: CALLOUT */}
          {activeTab === "callout" && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  {lang === "bn" ? "কলআউট ধরণের প্রকারভেদ:" : "Callout Banner Type:"}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: "tip", name: "💡 Tips & Insight", bg: "bg-amber-50 border-amber-300 text-amber-900" },
                    { id: "warn", name: "⚠️ Warning & Notice", bg: "bg-rose-50 border-rose-300 text-rose-900" },
                    { id: "info", name: "📘 Important Note", bg: "bg-blue-50 border-blue-300 text-blue-900" },
                    { id: "success", name: "🟢 Key Takeaway", bg: "bg-emerald-50 border-emerald-300 text-emerald-900" }
                  ].map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setCalloutType(c.id as any)}
                      className={`p-2.5 rounded-xl border text-xs font-bold text-left transition-all ${
                        calloutType === c.id ? `${c.bg} ring-2 ring-amber-500/40` : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                      }`}
                    >
                      {c.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === "bn" ? "কলআউট বক্সের বার্তা:" : "Callout Message:"}
                </label>
                <textarea
                  rows={3}
                  value={calloutText}
                  onChange={(e) => setCalloutText(e.target.value)}
                  placeholder={lang === "bn" ? "এখানে বিশেষ পরামর্শ বা সতর্কতা বার্তাটি লিখুন..." : "Enter your highlight advice or note here..."}
                  className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white resize-none"
                />
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end gap-2 px-6 py-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-xl transition-colors"
          >
            {lang === "bn" ? "বাতিল" : "Cancel"}
          </button>
          <button
            type="button"
            onClick={() => {
              if (activeTab === "image") handleInsertImage();
              else if (activeTab === "video") handleInsertVideo();
              else if (activeTab === "3d") handleInsert3D();
              else if (activeTab === "callout") handleInsertCallout();
            }}
            className="flex items-center gap-1.5 px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs transition-colors"
          >
            <Check className="w-3.5 h-3.5" />
            <span>{lang === "bn" ? "পাণ্ডুলিপিতে যুক্ত করুন" : "Insert into Manuscript"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
