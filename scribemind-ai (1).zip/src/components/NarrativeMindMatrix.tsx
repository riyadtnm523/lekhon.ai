import React, { useState, useRef, useEffect } from "react";
import {
  Sparkles, Plus, Trash2, Link as LinkIcon, BookOpen,
  Layers, Download, RefreshCw, ZoomIn, ZoomOut, Zap, Edit2, Check,
  Share2, ArrowRight, Grid, Monitor, Cpu, Code2, Globe, Database,
  FileText, ChevronRight, ChevronLeft, Image as ImageIcon, Send, X, Copy,
  Play, Pause, Volume2, Maximize2, Minimize2, Compass, Move, Info, Eye
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { db, collection, addDoc } from "../firebase";

export interface MatrixBox {
  id: string;
  stepNumber?: number;
  level: number; // 1 = Foundation, 2 = Intermediate/Application, 3 = Advanced/Mastery
  title: string;
  subtitle?: string;
  description: string;
  tags?: string[];
  color: string;
  badge?: string;
  codeSnippet?: string;
  items?: string[];
  connectedTo?: string[]; // IDs of the next steps
  pageNumber?: number;
}

interface NarrativeMindMatrixProps {
  lang: "bn" | "en";
  currentBook?: any;
  onSendToOutline?: (topic: string, prompt: string) => void;
  onPublishToSocial?: (postData: { title: string; content: string; tags: string[]; category: string }) => void;
  modelProvider?: string;
  customGeminiKey?: string;
  customDeepseekKey?: string;
  currentUser?: any;
}

// Preset 1: Complete HTML5 Step-by-Step Mastery Guide
const PRESET_HTML_MASTERY: MatrixBox[] = [
  {
    id: "html_step_1",
    stepNumber: 1,
    level: 1,
    title: "ধাপ ১: HTML এর মূল পরিচিতি ও ফাইল সেটআপ",
    subtitle: "Web Structure Foundation & VS Code Setup",
    description: "HTML (HyperText Markup Language) হলো ওয়েব পেজের কঙ্কাল বা মূল কাঠামো। ব্রাউজার এই মার্কআপ পড়ে কনটেন্ট প্রদর্শন করে।",
    color: "#3b82f6",
    badge: "STEP 1: FOUNDATION",
    tags: ["HTML5", "VS Code", "index.html"],
    codeSnippet: `<!DOCTYPE html>\n<html lang="bn">\n<head>\n  <meta charset="UTF-8">\n  <title>আমার প্রথম ওয়েবসাইট</title>\n</head>\n<body>\n  <h1>হ্যালো বাংলাদেশ!</h1>\n</body>\n</html>`,
    items: [
      "<!DOCTYPE html>: ব্রাউজারকে HTML5 স্ট্যান্ডার্ড বোঝায়",
      "<html>: সমস্ত ওয়েব কনটেন্টের রুট কন্টেইনার",
      "<head>: মেটাডাটা, টাইটেল ও সিএসএস লিঙ্কিং",
      "<body>: ব্যবহারকারীর চোখে দৃশ্যমান সব কনটেন্ট"
    ],
    connectedTo: ["html_step_2"],
    pageNumber: 1
  },
  {
    id: "html_step_2",
    stepNumber: 2,
    level: 1,
    title: "ধাপ ২: হেডিং, প্যারাগ্রাফ ও টেক্সট ফরম্যাটিং",
    subtitle: "Typography & Content Structure",
    description: "কনটেন্ট সুন্দরভাবে সাজানোর জন্য h1 থেকে h6 হেডিং ট্যাগ এবং p, strong, em, mark ট্যাগ ব্যবহৃত হয়।",
    color: "#06b6d4",
    badge: "STEP 2: TYPOGRAPHY",
    tags: ["Heading", "Paragraph", "Formatting"],
    codeSnippet: `<h1>মূল শিরোনাম (H1)</h1>\n<p>এটি একটি অনুচ্ছেদ যেখানে <strong>বোল্ড</strong> এবং <em>ইটালিক</em> টেক্সট রয়েছে।</p>\n<hr>\n<p>হাইলাইট করা টেক্সট: <mark>HTML শেখা সহজ!</mark></p>`,
    items: [
      "<h1> - <h6>: ক্রমানুসারে গুরুত্ব অনুসারে শিরোনাম",
      "<p>: সাধারণ অনুচ্ছেদ বা প্যারাগ্রাফের জন্য",
      "<strong> ও <em>: গুরুত্বপূর্ণ ও বাঁকানো লেখার জন্য",
      "<br> ও <hr>: লাইন ব্রেক ও অনুভূমিক ডিভাইডার"
    ],
    connectedTo: ["html_step_3"],
    pageNumber: 1
  },
  {
    id: "html_step_3",
    stepNumber: 3,
    level: 2,
    title: "ধাপ ৩: লিঙ্ক, ইমেজ ও মাল্টিমিডিয়া যুক্ত করা",
    subtitle: "Hyperlinks, Images & Audio/Video",
    description: "ওয়েবপেজে অন্য পেজের লিঙ্ক (anchor tag) এবং ছবি, অডিও ও ভিডিও যুক্ত করার বাস্তব কৌশল।",
    color: "#10b981",
    badge: "STEP 3: MULTIMEDIA",
    tags: ["Hyperlinks", "img", "video", "audio"],
    codeSnippet: `<!-- লিঙ্ক তৈরি -->\n<a href="https://google.com" target="_blank">গুগলে যান</a>\n\n<!-- ইমেজ প্রদর্শন -->\n<img src="banner.jpg" alt="ওয়েবসাইট ব্যানার" width="400">\n\n<!-- ভিডিও এম্বেড -->\n<video controls width="320">\n  <source src="intro.mp4" type="video/mp4">\n</video>`,
    items: [
      "<a href='URL'>: যেকোনো ওয়েবপেজ বা সেকশনে নেভিগেশন লিঙ্ক",
      "target='_blank': নতুন ট্যাবে লিঙ্ক খোলার নির্দেশ",
      "<img src='' alt=''>: এসইও ও অ্যাক্সেসিবিলিটির জন্য alt আবশ্যক",
      "<video controls> ও <audio controls>: মিডিয়া প্লেয়ার"
    ],
    connectedTo: ["html_step_4"],
    pageNumber: 1
  },
  {
    id: "html_step_4",
    stepNumber: 4,
    level: 2,
    title: "ধাপ ৪: লিস্ট ও ডেটা টেবিল আর্কিটেকচার",
    subtitle: "Ordered, Unordered Lists & Complex Tables",
    description: "মেন্যু ও তালিকা তৈরি করতে ul/ol/li এবং সুশৃঙ্খল ডেটা ছক আকারে উপস্থাপন করতে table ট্যাগ ব্যবহৃত হয়।",
    color: "#f59e0b",
    badge: "STEP 4: LISTS & TABLES",
    tags: ["ul / ol / li", "table", "thead", "tbody"],
    codeSnippet: `<!-- আনঅর্ডারড লিস্ট -->\n<ul>\n  <li>হোম</li>\n  <li>আমাদের সম্পর্কে</li>\n</ul>\n\n<!-- ডেটা টেবিল -->\n<table border="1">\n  <tr><th>নাম</th><th>রোল</th></tr>\n  <tr><td>রাহিম</td><td>১০১</td></tr>\n</table>`,
    items: [
      "<ul> ও <li>: বুলেট পয়েন্টযুক্ত তালিকা (ন্যাভবার বানাতে আদর্শ)",
      "<ol> ও <li>: সংখ্যাযুক্ত ক্রমানুসারী তালিকা",
      "<table>, <tr>, <th>, <td>: টেবিল রো, হেডার সেল ও ডেটা সেল",
      "colspan ও rowspan: একাধিক কলাম বা রো একত্রিত করা"
    ],
    connectedTo: ["html_step_5"],
    pageNumber: 1
  },
  {
    id: "html_step_5",
    stepNumber: 5,
    level: 3,
    title: "ধাপ ৫: ফর্ম, ইনপুট ভ্যালিডেশন ও ইউজার ডেটা সংগ্রহ",
    subtitle: "Interactive Forms & Input Types",
    description: "ব্যবহারকারীর কাছ থেকে নাম, ইমেইল, পাসওয়ার্ড বা মেসেজ ইনপুট নেওয়ার জন্য ফর্ম তৈরি।",
    color: "#ec4899",
    badge: "STEP 5: FORMS & INPUTS",
    tags: ["form", "input", "validation", "button"],
    codeSnippet: `<form action="/submit" method="POST">\n  <label for="email">ইমেইল:</label>\n  <input type="email" id="email" required placeholder="name@example.com">\n  \n  <label for="msg">বার্তা:</label>\n  <textarea id="msg" rows="4"></textarea>\n  \n  <button type="submit">জমা দিন</button>\n</form>`,
    items: [
      "<form action='' method='POST'>: ডেটা পাঠানোর কন্টেইনার",
      "<input type='text|email|password|checkbox|radio'>: ইনপুট ফিল্ড",
      "required ও placeholder: ইউজার অভিজ্ঞতা ও বাধ্যতামূলক ভ্যালিডেশন",
      "<button type='submit'>: ফর্ম ডাটা সার্ভারে পাঠানো"
    ],
    connectedTo: ["html_step_6"],
    pageNumber: 1
  },
  {
    id: "html_step_6",
    stepNumber: 6,
    level: 3,
    title: "ধাপ ৬: সিম্যান্টিক HTML5, SEO ও ফাইনাল প্রজেক্ট",
    subtitle: "Modern Semantic Tags & Production Standards",
    description: "আধুনিক ওয়েব স্ট্যান্ডার্ডে div এর বদলে সিম্যান্টিক ট্যাগ ব্যবহার করে সম্পূর্ণ ওয়েবসাইট তৈরি ও এসইও অপ্টিমাইজেশন।",
    color: "#8b5cf6",
    badge: "STEP 6: SEMANTIC & SEO",
    tags: ["header", "nav", "main", "footer", "SEO"],
    codeSnippet: `<header>\n  <nav><!-- ন্যাভিগেশন মেন্যু --></nav>\n</header>\n<main>\n  <article>\n    <h2>আমার ব্লগ পোস্ট</h2>\n    <p>সিম্যান্টিক HTML এসইও র‍্যাঙ্কিং বহুগুণ বাড়ায়।</p>\n  </article>\n  <aside><!-- সাইডবার --></aside>\n</main>\n<footer>\n  <p>© ২০২৬ Lekhok AI. সর্বস্বত্ব সংরক্ষিত।</p>\n</footer>`,
    items: [
      "<header>, <nav>, <main>, <section>, <article>, <footer>",
      "সার্চ ইঞ্জিন অপ্টিমাইজেশন (SEO) এবং স্ক্রিন রিডারের জন্য পারফেক্ট",
      "ক্যাপস্টোন প্রজেক্ট: একটি সম্পূর্ণ রেসপনসিভ পোর্টফোলিও কাঠামো",
      "CSS ও JavaScript সংযোগের জন্য প্রস্তুত কাঠামো"
    ],
    connectedTo: [],
    pageNumber: 1
  }
];

// Preset 2: Full-Stack Web Development Architecture
const PRESET_WEB_DEV: MatrixBox[] = [
  {
    id: "web_fe_root",
    stepNumber: 1,
    level: 1,
    title: "ধাপ ১: ফ্রন্ট-এন্ড কোর ভিত্তি (HTML/CSS/JS)",
    subtitle: "Client-Side Engineering",
    description: "ব্যবহারকারীর ব্রাউজারে রেন্ডার হওয়া ভিজ্যুয়াল ইন্টারফেস ও ইউজার এক্সপেরিয়েন্স আর্কিটেকচার।",
    color: "#3b82f6",
    badge: "STEP 1: CORE FRONTEND",
    tags: ["HTML5", "CSS3", "JavaScript"],
    codeSnippet: `// Modern ES6+ Async Fetch\nasync function loadData() {\n  const res = await fetch('/api/data');\n  const json = await res.json();\n  console.log(json);\n}`,
    items: ["DOM Tree Architecture", "Responsive Layouts (Flexbox/Grid)", "Web APIs & Fetch", "ES6+ Async/Await"],
    connectedTo: ["web_fe_react"],
    pageNumber: 1
  },
  {
    id: "web_fe_react",
    stepNumber: 2,
    level: 2,
    title: "ধাপ ২: React ও মডার্ন কম্পোনেন্ট ফ্রেমওয়ার্ক",
    subtitle: "Modern Component Architecture",
    description: "স্টেট ম্যানেজমেন্ট, রিঅ্যাকটিভ ইউআই ও সার্ভার-সাইড রেন্ডারিং (SSR/SSG)।",
    color: "#06b6d4",
    badge: "STEP 2: REACT ECOSYSTEM",
    tags: ["React 19", "Next.js", "Tailwind CSS"],
    codeSnippet: `export default function Counter() {\n  const [count, setCount] = useState(0);\n  return <button onClick={() => setCount(c => c + 1)} className="btn">Click: {count}</button>;\n}`,
    items: ["Hooks & Custom State", "Zustand / Redux Toolkit", "Server Components", "Client Routing"],
    connectedTo: ["web_be_root"],
    pageNumber: 1
  },
  {
    id: "web_be_root",
    stepNumber: 3,
    level: 2,
    title: "ধাপ ৩: ব্যাক-এন্ড ও RESTful API সার্ভিসেস",
    subtitle: "Server-Side Infrastructure",
    description: "ডাটা প্রসেসিং, সিকিউরিটি, ইউজার অথেন্টিকেশন ও বিজনেস লজিক হ্যান্ডলিং।",
    color: "#10b981",
    badge: "STEP 3: BACKEND & APIS",
    tags: ["Node.js", "Express", "Python / FastAPI"],
    codeSnippet: `app.post('/api/auth/login', async (req, res) => {\n  const { email, password } = req.body;\n  const token = jwt.sign({ email }, process.env.JWT_SECRET);\n  res.json({ token, success: true });\n});`,
    items: ["RESTful APIs & WebSockets", "Middleware Pipeline", "JWT & OAuth 2.0 Auth", "Rate Limiting & Security"],
    connectedTo: ["web_be_db"],
    pageNumber: 1
  },
  {
    id: "web_be_db",
    stepNumber: 4,
    level: 3,
    title: "ধাপ ৪: ডেটাবেজ ও ক্লাউড পারসিস্টেন্স ইঞ্জিন",
    subtitle: "Relational & NoSQL Datastores",
    description: "উচ্চ পারফরম্যান্স কুয়েরি, ট্রানজাকশন ও রিয়েলটাইম সিনক্রোনাইজেশন।",
    color: "#f59e0b",
    badge: "STEP 4: DATABASES",
    tags: ["PostgreSQL", "Firestore", "Redis Cache"],
    codeSnippet: `SELECT users.id, users.name, COUNT(orders.id) AS total_orders\nFROM users\nJOIN orders ON users.id = orders.user_id\nGROUP BY users.id HAVING COUNT(orders.id) > 5;`,
    items: ["ACID Compliance & Schemas", "Realtime Snapshot Listeners", "In-Memory Caching (Redis)", "Data Indexing & Sharding"],
    connectedTo: ["web_be_cloud"],
    pageNumber: 1
  },
  {
    id: "web_be_cloud",
    stepNumber: 5,
    level: 3,
    title: "ধাপ ৫: DevOps, ডকার ও ক্লাউড ডিপ্লয়মেন্ট",
    subtitle: "Containerization & CI/CD",
    description: "সার্ভারলেস হোস্টিং, ডকার কন্টেইনার ও অটোমেটেড স্কেলিং।",
    color: "#ec4899",
    badge: "STEP 5: DEPLOYMENT",
    tags: ["Docker", "Cloud Run", "GitHub Actions"],
    codeSnippet: `FROM node:20-alpine\nWORKDIR /app\nCOPY package*.json ./\nRUN npm install --production\nCOPY . .\nCMD ["node", "dist/server.cjs"]`,
    items: ["Zero-Downtime Deployment", "Container Optimization", "Reverse Proxy (Nginx)", "Monitoring & Cloud Logging"],
    connectedTo: [],
    pageNumber: 1
  }
];

// Preset 3: English Grammar & Tense Matrix
const PRESET_TENSE_MATRIX: MatrixBox[] = [
  {
    id: "tense_present",
    stepNumber: 1,
    level: 1,
    title: "ধাপ ১: Present Tense (বর্তমান কাল)",
    subtitle: "Actions happening now or habitual facts",
    description: "বর্তমান সময়ে সংঘটিত কোনো কাজ বা চিরন্তন সত্য প্রকাশে ব্যবহৃত হয়।",
    color: "#10b981",
    badge: "STEP 1: PRESENT TENSE",
    tags: ["Habitual", "Fact", "Routine"],
    codeSnippet: `Formula: Subject + Verb(base/s/es) + Object\nExample: The sun rises in the east. / He reads books daily.`,
    items: [
      "Indefinite: Sub + V1(s/es) + Obj (e.g. He writes books)",
      "Continuous: Sub + am/is/are + V1-ing (e.g. He is writing)",
      "Perfect: Sub + have/has + V3 (e.g. He has written a chapter)",
      "Perfect Cont: Sub + have/has been + V1-ing + since/for"
    ],
    connectedTo: ["tense_past"],
    pageNumber: 1
  },
  {
    id: "tense_past",
    stepNumber: 2,
    level: 2,
    title: "ধাপ ২: Past Tense (অতীত কাল)",
    subtitle: "Actions completed in the past",
    description: "অতীতের কোনো ঘটনা, স্মৃতি বা সমাপ্ত কাজের বিবরণ নির্দেশ করে।",
    color: "#3b82f6",
    badge: "STEP 2: PAST TENSE",
    tags: ["Completed", "History", "Memory"],
    codeSnippet: `Formula: Subject + Verb(past form/V2) + Object\nExample: I completed my novel yesterday.`,
    items: [
      "Indefinite: Sub + V2 + Obj (e.g. He wrote a masterpiece)",
      "Continuous: Sub + was/were + V1-ing (e.g. They were reading)",
      "Perfect: Sub + had + V3 (e.g. The train had left before we arrived)",
      "Perfect Cont: Sub + had been + V1-ing + for 2 hours"
    ],
    connectedTo: ["tense_future"],
    pageNumber: 1
  },
  {
    id: "tense_future",
    stepNumber: 3,
    level: 3,
    title: "ধাপ ৩: Future Tense (ভবিষ্যৎ কাল)",
    subtitle: "Actions planned or expected to occur",
    description: "ভবিষ্যতে কোনো কাজ সংঘটিত হওয়ার প্রত্যাশা বা পরিকল্পনা।",
    color: "#8b5cf6",
    badge: "STEP 3: FUTURE TENSE",
    tags: ["Upcoming", "Prediction", "Goal"],
    codeSnippet: `Formula: Subject + will/shall + Verb(base) + Object\nExample: We will launch our application next month.`,
    items: [
      "Indefinite: Sub + shall/will + V1 + Obj (e.g. AI will write books)",
      "Continuous: Sub + will be + V1-ing (e.g. He will be coding)",
      "Perfect: Sub + will have + V3 (e.g. We will have finished by 5 PM)",
      "Perfect Cont: Sub + will have been + V1-ing + duration"
    ],
    connectedTo: [],
    pageNumber: 1
  }
];

export const NarrativeMindMatrix: React.FC<NarrativeMindMatrixProps> = ({
  lang,
  currentBook,
  onSendToOutline,
  onPublishToSocial,
  modelProvider = "gemini",
  customGeminiKey,
  customDeepseekKey,
  currentUser
}) => {
  const [boxes, setBoxes] = useState<MatrixBox[]>(() => {
    const saved = localStorage.getItem("lekhok_mind_matrix_boxes");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return PRESET_HTML_MASTERY;
  });

  const [activeTemplate, setActiveTemplate] = useState<"html_mastery" | "web_dev" | "tense" | "custom">("html_mastery");
  const [aiTopicPrompt, setAiTopicPrompt] = useState("");
  const [matrixTitle, setMatrixTitle] = useState("HTML5 Complete Step-by-Step Mastery Matrix");
  const [matrixOverview, setMatrixOverview] = useState("ধাপে ধাপে যুক্ত রেখার সাহায্যে সম্পূর্ণ বিষয়ের প্র্যাকটিকাল ভিজ্যুয়াল রোডম্যাপ।");
  const [isGenerating, setIsGenerating] = useState(false);
  const [editingBox, setEditingBox] = useState<MatrixBox | null>(null);
  const [selectedBoxDetail, setSelectedBoxDetail] = useState<MatrixBox | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [socialPublishing, setSocialPublishing] = useState(false);
  const [socialSuccessMsg, setSocialSuccessMsg] = useState(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);
  const [isWalkthroughPlaying, setIsWalkthroughPlaying] = useState<boolean>(false);
  const [isPlayingTts, setIsPlayingTts] = useState<boolean>(false);
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  const canvasRef = useRef<HTMLDivElement>(null);
  const nodeRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});
  const [connectorPaths, setConnectorPaths] = useState<{ fromId: string; toId: string; d: string; color: string }[]>([]);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem("lekhok_mind_matrix_boxes", JSON.stringify(boxes));
  }, [boxes]);

  // Recalculate dynamic SVG lines connecting the steps
  const updateConnectorLines = () => {
    if (!canvasRef.current) return;
    const canvasRect = canvasRef.current.getBoundingClientRect();
    const newPaths: { fromId: string; toId: string; d: string; color: string }[] = [];

    boxes.forEach((box, index) => {
      // Connect to explicit connectedTo array, or automatically to the next sequential step
      const targetIds = box.connectedTo && box.connectedTo.length > 0
        ? box.connectedTo
        : (index < boxes.length - 1 ? [boxes[index + 1].id] : []);

      const fromEl = nodeRefs.current[box.id];
      if (!fromEl) return;
      const fromRect = fromEl.getBoundingClientRect();

      targetIds.forEach(targetId => {
        const toEl = nodeRefs.current[targetId];
        if (!toEl) return;
        const toRect = toEl.getBoundingClientRect();

        // Calculate center points relative to canvas
        const fromX = (fromRect.left + fromRect.width / 2) - canvasRect.left;
        const fromY = (fromRect.bottom - 4) - canvasRect.top;
        const toX = (toRect.left + toRect.width / 2) - canvasRect.left;
        const toY = (toRect.top + 4) - canvasRect.top;

        // Create smooth curved Bezier connector path
        const deltaY = toY - fromY;
        const deltaX = toX - fromX;
        const cp1Y = fromY + Math.max(40, deltaY * 0.5);
        const cp2Y = toY - Math.max(40, deltaY * 0.5);
        const pathD = `M ${fromX} ${fromY} C ${fromX} ${cp1Y}, ${toX} ${cp2Y}, ${toX} ${toY}`;

        newPaths.push({
          fromId: box.id,
          toId: targetId,
          d: pathD,
          color: box.color || "#06b6d4"
        });
      });
    });

    setConnectorPaths(newPaths);
  };

  // Recompute lines on resize, box change, or zoom
  useEffect(() => {
    const timer = setTimeout(updateConnectorLines, 100);
    window.addEventListener("resize", updateConnectorLines);
    return () => {
      clearTimeout(timer);
      window.removeEventListener("resize", updateConnectorLines);
    };
  }, [boxes, zoomLevel]);

  // Walkthrough Auto-Play interval
  useEffect(() => {
    let interval: any = null;
    if (isWalkthroughPlaying) {
      interval = setInterval(() => {
        setActiveStepIndex(prev => {
          const next = (prev + 1) % boxes.length;
          // Scroll active box into view smoothly
          const activeBox = boxes[next];
          if (activeBox && nodeRefs.current[activeBox.id]) {
            nodeRefs.current[activeBox.id]?.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
          }
          return next;
        });
      }, 4000);
    }
    return () => clearInterval(interval);
  }, [isWalkthroughPlaying, boxes]);

  // Load Preset Roadmaps
  const handleLoadPreset = (type: "html_mastery" | "web_dev" | "tense") => {
    setIsWalkthroughPlaying(false);
    setActiveStepIndex(0);
    if (type === "html_mastery") {
      setBoxes(PRESET_HTML_MASTERY);
      setActiveTemplate("html_mastery");
      setMatrixTitle("HTML5 Complete Step-by-Step Mastery Matrix");
      setMatrixOverview("ডকুমেন্ট কাঠামো থেকে শুরু করে সিম্যান্টিক এসইও ও ফুল প্রজেক্ট পর্যন্ত ধাপে ধাপে সংযুক্ত ভিজ্যুয়াল রোডম্যাপ।");
    } else if (type === "web_dev") {
      setBoxes(PRESET_WEB_DEV);
      setActiveTemplate("web_dev");
      setMatrixTitle("Full-Stack Web Development Architecture");
      setMatrixOverview("ফ্রন্ট-এন্ড থেকে ক্লাউড ডিপ্লয়মেন্ট পর্যন্ত প্রতিটি লেয়ারের টেকনোলজি স্ট্যাক ও সংযোগ।");
    } else {
      setBoxes(PRESET_TENSE_MATRIX);
      setActiveTemplate("tense");
      setMatrixTitle("Complete English Grammar & Tense Matrix");
      setMatrixOverview("বর্তমান, অতীত ও ভবিষ্যৎ কালের সমস্ত নিয়ম, স্ট্রাকচার ও প্র্যাকটিকাল উদাহরণ।");
    }
    setTimeout(updateConnectorLines, 150);
  };

  // Generate AI Mind Matrix for any topic
  const handleGenerateAiMatrix = async () => {
    if (!aiTopicPrompt.trim() || isGenerating) return;
    setIsGenerating(true);
    setIsWalkthroughPlaying(false);

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (modelProvider) headers["x-model-provider"] = modelProvider;
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const response = await fetch("/api/generate-matrix", {
        method: "POST",
        headers,
        body: JSON.stringify({
          topic: aiTopicPrompt.trim(),
          language: lang === "bn" ? "Bengali" : "English"
        })
      });

      if (!response.ok) {
        throw new Error("Failed to generate mind matrix");
      }

      const data = await response.json();
      if (Array.isArray(data.boxes) && data.boxes.length > 0) {
        setBoxes(data.boxes);
        setActiveTemplate("custom");
        setMatrixTitle(data.title || `Mind Matrix: ${aiTopicPrompt.trim()}`);
        setMatrixOverview(data.overview || `ধাপে ধাপে সংযোগ রেখা দ্বারা সাজানো জ্ঞান কাঠামো: "${aiTopicPrompt.trim()}"`);
        setActiveStepIndex(0);
      }
    } catch (err: any) {
      console.warn("Falling back to rich local generated matrix:", err);
      const generatedBoxes: MatrixBox[] = [
        {
          id: "gen_1",
          stepNumber: 1,
          level: 1,
          title: `ধাপ ১: ${aiTopicPrompt.trim()} এর মূল ভিত্তি`,
          subtitle: "Core Foundation & Architecture",
          description: `এই প্রাথমিক ধাপে "${aiTopicPrompt.trim()}" এর মৌলিক ধারণা, ব্যাকগ্রাউন্ড ও প্রাথমিক প্রস্তুতি আলোচনা করা হয়েছে।`,
          color: "#3b82f6",
          badge: "STEP 1: FOUNDATION",
          tags: ["Core", "Basics", "Preparation"],
          codeSnippet: `// Step 1 Initializer\nconst topic = "${aiTopicPrompt.trim()}";\nconsole.log("Starting master roadmap for: " + topic);`,
          items: ["মৌলিক সংজ্ঞায়ন ও প্রাথমিক ধারণা", "প্রয়োজনীয় টুলস ও এনভায়রনমেন্ট সেটআপ", "প্রথম পর্যায়ের প্র্যাকটিস"],
          connectedTo: ["gen_2"],
          pageNumber: 1
        },
        {
          id: "gen_2",
          stepNumber: 2,
          level: 2,
          title: "ধাপ ২: মধ্যবর্তী অ্যাপ্লিকেশন ও কর্মপদ্ধতি",
          subtitle: "Practical Execution & Workflow",
          description: "বাস্তব ক্ষেত্রে ধারণাসমূহ কীভাবে প্রয়োগ করবেন এবং এর কার্যপদ্ধতি কী হবে তার পূর্ণাঙ্গ রূপরেখা।",
          color: "#10b981",
          badge: "STEP 2: EXECUTION",
          tags: ["Hands-on", "Workflow", "Methods"],
          codeSnippet: `// Step 2 Implementation Logic\nfunction executeWorkflow() {\n  return "Applying practical methods with high precision.";\n}`,
          items: ["ধাপ-১: প্রস্তুতি ও পরিকল্পনা", "ধাপ-২: কৌশলগত প্রয়োগ ও নিয়মাবলি", "ধাপ-৩: বাস্তব ত্রুটি ও সমাধান"],
          connectedTo: ["gen_3"],
          pageNumber: 1
        },
        {
          id: "gen_3",
          stepNumber: 3,
          level: 3,
          title: "ধাপ ৩: মাস্টার লেভেল অপ্টিমাইজেশন ও প্রজেক্ট",
          subtitle: "Deep Optimization & Mastery",
          description: "সর্বোচ্চ দক্ষতা অর্জন, পেশাদার মান বজায় রাখা এবং পূর্ণাঙ্গ প্রজেক্ট বাস্তবায়নের চূড়ান্ত ধাপ।",
          color: "#ec4899",
          badge: "STEP 3: MASTERY",
          tags: ["Deep Dive", "Scaling", "Production"],
          codeSnippet: `// Step 3 Production Ready Output\nexport const productionReady = true;`,
          items: ["সিস্টেম স্কেলিং ও দক্ষতা বৃদ্ধি", "আন্তর্জাতিক সেরা প্র্যাকটিস", "সম্পূর্ণ প্রজেক্ট ডেলিভারি"],
          connectedTo: [],
          pageNumber: 1
        }
      ];
      setBoxes(generatedBoxes);
      setActiveTemplate("custom");
      setMatrixTitle(`Mind Matrix: ${aiTopicPrompt.trim()}`);
      setMatrixOverview(`ধাপে ধাপে সংযোগ রেখা দ্বারা সাজানো জ্ঞান কাঠামো: "${aiTopicPrompt.trim()}"`);
    } finally {
      setIsGenerating(false);
      setTimeout(updateConnectorLines, 200);
    }
  };

  // Add a new Step Box
  const handleAddNewBox = () => {
    const newStepNum = boxes.length + 1;
    const newId = `box_${Date.now()}`;
    const newBox: MatrixBox = {
      id: newId,
      stepNumber: newStepNum,
      level: 2,
      title: `ধাপ ${newStepNum}: নতুন বিষয়`,
      subtitle: "Custom Category",
      description: "এই ধাপে প্রয়োজনীয় ধারণা ও কার্যপ্রণালী বিশদভাবে ব্যাখ্যা করুন।",
      color: "#06b6d4",
      badge: `STEP ${newStepNum}: CUSTOM`,
      tags: ["Custom", "Step"],
      items: ["প্রথম পয়েন্ট", "দ্বিতীয় পয়েন্ট", "তৃতীয় পয়েন্ট"],
      connectedTo: [],
      pageNumber: 1
    };

    // Auto-link previous box to this new box
    const updated = [...boxes];
    if (updated.length > 0) {
      const last = updated[updated.length - 1];
      if (!last.connectedTo || last.connectedTo.length === 0) {
        last.connectedTo = [newId];
      }
    }
    updated.push(newBox);
    setBoxes(updated);
    setEditingBox(newBox);
    setTimeout(updateConnectorLines, 150);
  };

  // Delete Box
  const handleDeleteBox = (id: string) => {
    setBoxes(boxes.filter(b => b.id !== id));
    setTimeout(updateConnectorLines, 150);
  };

  // Save Edited Box
  const handleSaveEditedBox = () => {
    if (!editingBox) return;
    setBoxes(boxes.map(b => (b.id === editingBox.id ? editingBox : b)));
    setEditingBox(null);
    setTimeout(updateConnectorLines, 150);
  };

  // 1-Click Copy Code
  const handleCopyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 2000);
  };

  // Read out loud with TTS
  const handlePlayAudio = (text: string) => {
    if (!text) return;
    if (isPlayingTts) {
      window.speechSynthesis.cancel();
      setIsPlayingTts(false);
      return;
    }

    try {
      const clean = text.replace(/[*#`_~\[\]()<>]/g, "");
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.lang = lang === "bn" ? "bn-BD" : "en-US";
      utterance.rate = 1.0;
      utterance.onend = () => setIsPlayingTts(false);
      utterance.onerror = () => setIsPlayingTts(false);
      setIsPlayingTts(true);
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("TTS speak error:", e);
      setIsPlayingTts(false);
    }
  };

  // Publish to Social Feed
  const handlePublishSocial = async () => {
    setSocialPublishing(true);
    try {
      const payload = {
        title: matrixTitle,
        content: `### 🧠 ${matrixTitle}\n\n${matrixOverview}\n\n**মোট সংযুক্ত ধাপ:** ${boxes.length} টি\n\n` +
          boxes.map((b, i) => `**ধাপ ${b.stepNumber || i + 1}: ${b.title}**\n${b.description}\n` + (b.codeSnippet ? `\`\`\`\n${b.codeSnippet}\n\`\`\`\n` : '')).join("\n"),
        tags: ["MindMatrix", "Roadmap", "VisualGuide", activeTemplate],
        category: "Learning Matrix"
      };

      if (onPublishToSocial) {
        await onPublishToSocial(payload);
      } else {
        await addDoc(collection(db, "posts"), {
          ...payload,
          authorName: currentUser?.displayName || "Lekhok Author",
          authorEmail: currentUser?.email || "author@lekhok.ai",
          createdAt: new Date().toISOString(),
          likes: 0,
          likedBy: []
        });
      }

      setSocialSuccessMsg(true);
      setTimeout(() => {
        setSocialSuccessMsg(false);
        setShowShareModal(false);
      }, 2000);
    } catch (err: any) {
      console.error("Social publish error:", err);
      alert("Failed to publish to social feed.");
    } finally {
      setSocialPublishing(false);
    }
  };

  return (
    <div className="w-full bg-[#030712] min-h-screen text-slate-100 font-sans pb-24 select-none">
      
      {/* 🌟 Top Navigation & Preset Selector Bar */}
      <div className="sticky top-0 z-30 bg-[#070b16]/90 backdrop-blur-md border-b border-slate-800/80 px-4 sm:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
            <Compass size={20} className="animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black text-white tracking-wide flex items-center gap-1.5">
                <span>{lang === "bn" ? "মাইন্ড ম্যাট্রিক্স: দাগ টেনে সংযুক্ত ভিজ্যুয়াল রোডম্যাপ" : "Mind Matrix: Step-by-Step Visual Roadmap"}</span>
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 text-[10px] font-mono font-black border border-cyan-500/30">
                LIVE CONNECTED FLOW
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              {lang === "bn" ? "আস্ত বড় পেজে প্রতিটি বিষয় দাগ টেনে ধাপে ধাপে বিশদ ব্যাখ্যা" : "Connected flowchart explaining every topic step-by-step"}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Preset Buttons */}
          <div className="flex items-center bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => handleLoadPreset("html_mastery")}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTemplate === "html_mastery"
                  ? "bg-cyan-500 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Code2 size={13} />
              <span>HTML5 কমপ্লিট গাইড</span>
            </button>

            <button
              onClick={() => handleLoadPreset("web_dev")}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTemplate === "web_dev"
                  ? "bg-cyan-500 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <Globe size={13} />
              <span>ফুলস্ট্যাক ওয়েব</span>
            </button>

            <button
              onClick={() => handleLoadPreset("tense")}
              className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTemplate === "tense"
                  ? "bg-cyan-500 text-slate-950 shadow-sm"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <FileText size={13} />
              <span>ইংরেজি Tense ম্যাট্রিক্স</span>
            </button>
          </div>

          {/* Zoom Controls */}
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setZoomLevel(z => Math.max(0.6, z - 0.1))}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
              title="Zoom Out"
            >
              <ZoomOut size={15} />
            </button>
            <span className="text-[10px] font-mono text-slate-300 font-bold px-1.5">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={() => setZoomLevel(z => Math.min(1.4, z + 0.1))}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
              title="Zoom In"
            >
              <ZoomIn size={15} />
            </button>
            <button
              onClick={() => setZoomLevel(1)}
              className="px-2 py-1 hover:bg-slate-800 text-[10px] text-slate-400 hover:text-white rounded-lg transition cursor-pointer font-mono"
            >
              100%
            </button>
          </div>

          {/* Add Step Button */}
          <button
            onClick={handleAddNewBox}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Plus size={14} className="text-cyan-400" />
            <span>{lang === "bn" ? "নতুন ধাপ যোগ" : "Add Step"}</span>
          </button>

          {/* Social Publish Button */}
          <button
            onClick={() => setShowShareModal(true)}
            className="px-4 py-2 bg-gradient-to-r from-amber-500 via-orange-500 to-pink-500 hover:from-amber-600 hover:via-orange-600 hover:to-pink-600 text-white font-black text-xs rounded-xl shadow-lg shadow-orange-500/25 border border-orange-400/40 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Share2 size={14} className="text-white" />
            <span>{lang === "bn" ? "🚀 সোশ্যালে পাবলিশ" : "Publish"}</span>
          </button>
        </div>
      </div>

      {/* 🧠 AI Mind Matrix Auto-Generator Prompt Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-5">
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 w-full md:w-auto">
            <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/20">
              <Sparkles size={18} />
            </div>
            <div className="text-left">
              <span className="text-xs font-black text-white block">
                {lang === "bn" ? "যেকোনো বিষয়ের সম্পূর্ণ ব্যাখ্যাসহ ধাপে ধাপে রোডম্যাপ বানান" : "Generate Step-by-Step Connected Roadmap for Any Subject"}
              </span>
              <span className="text-[10px] text-slate-400">
                {lang === "bn" ? "যেমন: 'CSS Flexbox ও Grid', 'জাভাস্ক্রিপ্ট DOM ম্যানিপুলেশন', 'উপন্যাসের প্লট আর্কিটেকচার'" : "e.g. 'React Hooks Deep Dive', 'Python Machine Learning Steps'"}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-1/2">
            <input
              type="text"
              placeholder={lang === "bn" ? "টপিক লিখুন... (যেমন: HTML5 Full Guide Step by Step)" : "Type topic to generate connected step-by-step matrix..."}
              value={aiTopicPrompt}
              onChange={(e) => setAiTopicPrompt(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleGenerateAiMatrix()}
              className="w-full bg-[#05070d] border border-slate-700/80 px-3.5 py-2.5 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
            />
            <button
              onClick={handleGenerateAiMatrix}
              disabled={isGenerating || !aiTopicPrompt.trim()}
              className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-black rounded-xl transition shrink-0 flex items-center gap-1.5 cursor-pointer disabled:opacity-50 shadow-md shadow-cyan-500/20"
            >
              {isGenerating ? (
                <>
                  <RefreshCw size={13} className="animate-spin" />
                  <span>{lang === "bn" ? "তৈরি হচ্ছে..." : "Building..."}</span>
                </>
              ) : (
                <>
                  <Zap size={13} />
                  <span>{lang === "bn" ? "রোডম্যাপ বানান" : "Generate"}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* 🚀 Header Summary Card */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-4">
        <div className="bg-gradient-to-r from-slate-900 via-[#0a0f1d] to-slate-900 border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="text-left">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <h1 className="text-base sm:text-lg font-black text-white">{matrixTitle}</h1>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-3xl leading-relaxed">{matrixOverview}</p>
          </div>

          {/* Step Walkthrough Controller */}
          <div className="flex items-center gap-2 bg-slate-950/80 p-2 rounded-xl border border-slate-800 shrink-0">
            <button
              onClick={() => {
                const prev = (activeStepIndex - 1 + boxes.length) % boxes.length;
                setActiveStepIndex(prev);
                const b = boxes[prev];
                if (b && nodeRefs.current[b.id]) {
                  nodeRefs.current[b.id]?.scrollIntoView({ behavior: "smooth", block: "center" });
                }
              }}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
              title="আগের ধাপ"
            >
              <ChevronLeft size={16} />
            </button>

            <button
              onClick={() => setIsWalkthroughPlaying(!isWalkthroughPlaying)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                isWalkthroughPlaying ? "bg-amber-500 text-slate-950" : "bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30"
              }`}
            >
              {isWalkthroughPlaying ? (
                <>
                  <Pause size={13} />
                  <span>পজ</span>
                </>
              ) : (
                <>
                  <Play size={13} />
                  <span>ইন্টারেক্টিভ ট্যুর</span>
                </>
              )}
            </button>

            <span className="text-[11px] font-mono text-cyan-400 font-bold px-1">
              ধাপ {activeStepIndex + 1}/{boxes.length}
            </span>

            <button
              onClick={() => {
                const next = (activeStepIndex + 1) % boxes.length;
                setActiveStepIndex(next);
                const b = boxes[next];
                if (b && nodeRefs.current[b.id]) {
                  nodeRefs.current[b.id]?.scrollIntoView({ behavior: "smooth", block: "center" });
                }
              }}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
              title="পরের ধাপ"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* ⬛⬛⬛ THE HUGE CONNECTED BLACKBOARD CANVAS WITH DRAWN LINES ⬛⬛⬛ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-5">
        <div
          ref={canvasRef}
          className="relative min-h-[850px] bg-[#02040a] border-2 border-slate-800/90 rounded-3xl p-6 sm:p-12 shadow-2xl overflow-x-auto text-left transition-transform duration-200"
          style={{ transform: `scale(${zoomLevel})`, transformOrigin: "top center" }}
        >
          {/* Cyber Neon Grid Pattern */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:32px_32px] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_50%,#000_80%,transparent_100%)] opacity-25 pointer-events-none" />

          {/* Ambient Glow Orbs */}
          <div className="absolute -top-32 -left-32 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* 🔗 DYNAMIC SVG CONNECTING LINES WITH ARROWS & LASER PULSES */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0 overflow-visible">
            <defs>
              <marker
                id="arrowhead-cyan"
                markerWidth="8"
                markerHeight="8"
                refX="5"
                refY="4"
                orient="auto"
              >
                <polygon points="0 0, 8 4, 0 8" fill="#06b6d4" />
              </marker>
              <marker
                id="arrowhead-emerald"
                markerWidth="8"
                markerHeight="8"
                refX="5"
                refY="4"
                orient="auto"
              >
                <polygon points="0 0, 8 4, 0 8" fill="#10b981" />
              </marker>
              <marker
                id="arrowhead-purple"
                markerWidth="8"
                markerHeight="8"
                refX="5"
                refY="4"
                orient="auto"
              >
                <polygon points="0 0, 8 4, 0 8" fill="#8b5cf6" />
              </marker>
            </defs>

            {connectorPaths.map((p, pIdx) => {
              return (
                <g key={pIdx}>
                  {/* Glowing base path */}
                  <path
                    d={p.d}
                    fill="none"
                    stroke={p.color}
                    strokeWidth="3"
                    strokeOpacity="0.4"
                    strokeLinecap="round"
                  />
                  {/* Animated laser energy pulse moving along the path */}
                  <path
                    d={p.d}
                    fill="none"
                    stroke={p.color}
                    strokeWidth="2.5"
                    strokeDasharray="8 12"
                    strokeLinecap="round"
                    className="animate-dash"
                    markerEnd={`url(#arrowhead-${p.color.includes("10b981") ? "emerald" : p.color.includes("8b5cf6") ? "purple" : "cyan"})`}
                  />
                </g>
              );
            })}
          </svg>

          {/* 📦 SEQUENTIAL STEP-BY-STEP BOXES FLOW (Single Expansive Connected Page) */}
          <div className="relative z-10 space-y-12">
            {boxes.map((box, index) => {
              const isActive = activeStepIndex === index;
              return (
                <div
                  key={box.id}
                  ref={(el) => {
                    nodeRefs.current[box.id] = el;
                  }}
                  className={`transition-all duration-300 ${
                    isActive ? "scale-[1.02] ring-2 ring-cyan-400 shadow-2xl shadow-cyan-500/20" : ""
                  }`}
                >
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="group relative bg-[#090d18] border-2 rounded-2xl p-6 sm:p-7 shadow-xl hover:shadow-cyan-500/10 flex flex-col justify-between"
                    style={{
                      borderColor: isActive ? box.color : `${box.color}50`,
                      boxShadow: `0 10px 35px -10px ${box.color}25`
                    }}
                  >
                    {/* Top Header Badge & Level Pointers */}
                    <div className="flex items-center justify-between gap-3 mb-4">
                      <div className="flex items-center gap-2">
                        <span
                          className="px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider font-mono shadow-sm flex items-center gap-1.5"
                          style={{
                            backgroundColor: `${box.color}25`,
                            color: box.color,
                            border: `1px solid ${box.color}60`
                          }}
                        >
                          <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: box.color }} />
                          <span>{box.badge || `STEP ${box.stepNumber || index + 1}`}</span>
                        </span>

                        {box.subtitle && (
                          <span className="text-[11px] text-slate-400 font-semibold hidden sm:inline">
                            • {box.subtitle}
                          </span>
                        )}
                      </div>

                      {/* Action Menu */}
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handlePlayAudio(`${box.title}. ${box.description}`)}
                          className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 rounded-lg transition cursor-pointer"
                          title="ভয়েসে শুনুন"
                        >
                          <Volume2 size={15} />
                        </button>
                        <button
                          onClick={() => setSelectedBoxDetail(box)}
                          className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 rounded-lg transition cursor-pointer"
                          title="সম্পূর্ণ বিস্তারিত দেখুন"
                        >
                          <Eye size={15} />
                        </button>
                        <button
                          onClick={() => setEditingBox(box)}
                          className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 rounded-lg transition cursor-pointer"
                          title="এডিট করুন"
                        >
                          <Edit2 size={15} />
                        </button>
                        <button
                          onClick={() => handleDeleteBox(box.id)}
                          className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-rose-400 rounded-lg transition cursor-pointer"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>

                    {/* Step Title */}
                    <h3 className="text-lg sm:text-xl font-black text-white group-hover:text-cyan-300 transition-colors">
                      {box.title}
                    </h3>

                    {/* Full In-Depth Description */}
                    <p className="text-xs sm:text-sm text-slate-300 mt-2.5 leading-relaxed font-sans">
                      {box.description}
                    </p>

                    {/* Two-Column Grid: Sub-Items & Working Code Snippet */}
                    <div className="mt-5 grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {/* Sub-steps / Checklist */}
                      {box.items && box.items.length > 0 && (
                        <div className="space-y-2 bg-[#04060c] p-4 rounded-xl border border-slate-800/90">
                          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center gap-1">
                            <span>📋 মূল পয়েন্ট ও কার্যপ্রণালী</span>
                          </div>
                          {box.items.map((it, iIdx) => (
                            <div key={iIdx} className="text-xs text-slate-200 flex items-start gap-2.5 leading-snug">
                              <span className="text-cyan-400 font-bold mt-0.5">›</span>
                              <span>{it}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Practical Working Code Block with Copy */}
                      {box.codeSnippet && (
                        <div className="bg-[#0c101a] rounded-xl border border-slate-800 overflow-hidden text-xs font-mono shadow-md flex flex-col justify-between">
                          <div className="flex items-center justify-between px-3.5 py-1.5 bg-[#070a12] border-b border-slate-800 text-[10px] text-slate-400">
                            <span className="font-bold uppercase tracking-wider text-slate-300">
                              💻 প্র্যাকটিকাল কোড / সিনট্যাক্স
                            </span>
                            <button
                              onClick={() => handleCopyCode(box.codeSnippet!, box.id)}
                              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-sans font-bold flex items-center gap-1 transition cursor-pointer"
                            >
                              {copiedCodeId === box.id ? (
                                <span className="text-emerald-400">✓ কপি হয়েছে</span>
                              ) : (
                                <>
                                  <Copy size={11} />
                                  <span>কপি</span>
                                </>
                              )}
                            </button>
                          </div>
                          <pre className="p-3.5 text-slate-200 overflow-x-auto whitespace-pre leading-relaxed text-[11px]">
                            {box.codeSnippet}
                          </pre>
                        </div>
                      )}
                    </div>

                    {/* Bottom Metadata & Connection Indicator */}
                    <div className="mt-5 pt-3.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                      {/* Tags */}
                      <div className="flex flex-wrap gap-1.5">
                        {box.tags?.map((t, tIdx) => (
                          <span
                            key={tIdx}
                            className="px-2 py-0.5 bg-slate-900 text-slate-400 rounded-md text-[10px] font-mono font-medium border border-slate-800"
                          >
                            #{t}
                          </span>
                        ))}
                      </div>

                      {/* Next Step Connection Pointer */}
                      {index < boxes.length - 1 && (
                        <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-bold font-mono">
                          <span>পরবর্তী ধাপের দিকে প্রবাহিত</span>
                          <ArrowRight size={13} className="animate-pulse" />
                        </div>
                      )}
                    </div>
                  </motion.div>
                </div>
              );
            })}
          </div>

          {/* Empty state */}
          {boxes.length === 0 && (
            <div className="py-24 text-center text-slate-500 space-y-4">
              <Layers size={40} className="mx-auto text-slate-600" />
              <p className="text-sm">{lang === "bn" ? "কোনো রোডম্যাপ ধাপ তৈরি করা হয়নি।" : "No steps in this roadmap yet."}</p>
              <button
                onClick={handleAddNewBox}
                className="px-5 py-2.5 bg-cyan-500 text-slate-950 font-bold text-xs rounded-xl shadow cursor-pointer"
              >
                {lang === "bn" ? "প্রথম ধাপ তৈরি করুন" : "Create first step"}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 🔍 MODAL: FULL IN-DEPTH STEP DETAILS DRAWER */}
      <AnimatePresence>
        {selectedBoxDetail && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border-2 border-slate-800 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl text-left space-y-5 text-slate-100 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <span
                    className="px-3 py-1 rounded-xl text-xs font-mono font-black"
                    style={{
                      backgroundColor: `${selectedBoxDetail.color}25`,
                      color: selectedBoxDetail.color,
                      border: `1px solid ${selectedBoxDetail.color}60`
                    }}
                  >
                    {selectedBoxDetail.badge || `STEP ${selectedBoxDetail.stepNumber}`}
                  </span>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    {selectedBoxDetail.title}
                  </h3>
                </div>

                <button
                  onClick={() => setSelectedBoxDetail(null)}
                  className="p-2 hover:bg-slate-800 text-slate-400 hover:text-white rounded-xl transition cursor-pointer"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
                  সম্পূর্ণ তাত্ত্বিক ও ব্যবহারিক ব্যাখ্যা
                </h4>
                <p className="text-sm text-slate-200 leading-relaxed bg-[#060912] p-4 rounded-xl border border-slate-800">
                  {selectedBoxDetail.description}
                </p>
              </div>

              {/* Items */}
              {selectedBoxDetail.items && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    বাস্তবায়ন নির্দেশিকা ও গুরুত্বপূর্ণ পয়েন্ট
                  </h4>
                  <div className="space-y-2 bg-[#060912] p-4 rounded-xl border border-slate-800">
                    {selectedBoxDetail.items.map((it, idx) => (
                      <div key={idx} className="text-xs text-slate-200 flex items-start gap-2">
                        <Check size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                        <span>{it}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Code Snippet */}
              {selectedBoxDetail.codeSnippet && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                      কোড স্নsnippet ও এক্সাম্পল
                    </h4>
                    <button
                      onClick={() => handleCopyCode(selectedBoxDetail.codeSnippet!, selectedBoxDetail.id)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-lg transition cursor-pointer"
                    >
                      {copiedCodeId === selectedBoxDetail.id ? "✓ কপি হয়েছে" : "কপি কোড"}
                    </button>
                  </div>
                  <pre className="p-4 bg-[#050810] border border-slate-800 rounded-xl text-xs font-mono text-cyan-300 overflow-x-auto whitespace-pre">
                    {selectedBoxDetail.codeSnippet}
                  </pre>
                </div>
              )}

              <div className="flex justify-end pt-3 border-t border-slate-800">
                <button
                  onClick={() => setSelectedBoxDetail(null)}
                  className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs rounded-xl transition cursor-pointer"
                >
                  বন্ধ করুন
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ✏️ MODAL: EDIT MATRIX BOX */}
      <AnimatePresence>
        {editingBox && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border-2 border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl text-left space-y-4 text-slate-100 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Edit2 size={16} className="text-cyan-400" />
                  <span>{lang === "bn" ? "ধাপ সম্পাদনা করুন" : "Edit Step"}</span>
                </h3>
                <button
                  onClick={() => setEditingBox(null)}
                  className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Title (শিরোনাম)</label>
                  <input
                    type="text"
                    value={editingBox.title}
                    onChange={(e) => setEditingBox({ ...editingBox, title: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-white text-xs font-semibold focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Badge (ব্যাজ/ধাপ নম্বর)</label>
                  <input
                    type="text"
                    value={editingBox.badge || ""}
                    onChange={(e) => setEditingBox({ ...editingBox, badge: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-white text-xs font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Description (সম্পূর্ণ ব্যাখ্যা)</label>
                  <textarea
                    rows={4}
                    value={editingBox.description}
                    onChange={(e) => setEditingBox({ ...editingBox, description: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-white text-xs leading-relaxed focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Sub-Items (প্রতি লাইনে একটি পয়েন্ট)</label>
                  <textarea
                    rows={3}
                    value={(editingBox.items || []).join("\n")}
                    onChange={(e) => setEditingBox({ ...editingBox, items: e.target.value.split("\n").filter(Boolean) })}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-white text-xs font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Code Snippet / Formula (কোড বা সূত্র)</label>
                  <textarea
                    rows={4}
                    value={editingBox.codeSnippet || ""}
                    onChange={(e) => setEditingBox({ ...editingBox, codeSnippet: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-white text-xs font-mono focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  onClick={() => setEditingBox(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  onClick={handleSaveEditedBox}
                  className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs rounded-xl shadow transition cursor-pointer"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 🚀 MODAL: 1-CLICK PUBLISH TO SOCIAL FEED */}
      <AnimatePresence>
        {showShareModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl text-left space-y-5 text-slate-100"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-gradient-to-tr from-amber-500 to-orange-500 text-white rounded-xl">
                    <Share2 size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">
                      {lang === "bn" ? "সোশ্যাল ফিডে প্রকাশ করুন" : "Publish to Social Feed"}
                    </h3>
                    <span className="text-[10px] text-slate-400 font-mono">Lekhok AI Author Network</span>
                  </div>
                </div>

                <button
                  onClick={() => setShowShareModal(false)}
                  className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition cursor-pointer"
                >
                  <X size={16} />
                </button>
              </div>

              {socialSuccessMsg ? (
                <div className="py-8 text-center space-y-3">
                  <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/40">
                    <Check size={24} />
                  </div>
                  <h4 className="text-base font-black text-white">
                    {lang === "bn" ? "🎉 সফলভাবে সোশ্যাল ফিডে পোস্ট হয়েছে!" : "🎉 Successfully Published to Social Feed!"}
                  </h4>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <span className="text-[10px] uppercase font-bold text-cyan-400 block tracking-wider">পোস্টের বিষয়বস্তু প্রিভিউ</span>
                    <h4 className="text-xs font-black text-white">{matrixTitle}</h4>
                    <p className="text-[11px] text-slate-400">
                      {boxes.length} টি সংযুক্ত ধাপের সম্পূর্ণ জ্ঞানচিত্র ও কোড সরাসরি কমিউনিটি ফিডে শেয়ার হবে।
                    </p>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => setShowShareModal(false)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
                    >
                      বাতিল
                    </button>
                    <button
                      onClick={handlePublishSocial}
                      disabled={socialPublishing}
                      className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-black text-xs rounded-xl shadow-lg transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      {socialPublishing ? (
                        <>
                          <RefreshCw size={13} className="animate-spin" />
                          <span>আপলোড হচ্ছে...</span>
                        </>
                      ) : (
                        <>
                          <Send size={13} />
                          <span>ফিডে পোস্ট করুন</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
