import React, { useState, useRef, useEffect } from "react";
import {
  Sparkles, Code2, Play, RefreshCw, Check, Copy, Trash2, Plus, 
  Terminal, ShieldCheck, Zap, Globe, Layers, Eye, EyeOff, 
  Settings, ArrowRight, CheckCircle2, ChevronRight, HelpCircle,
  FileCode, Database, Users, Monitor, Sliders, AlertTriangle, RefreshCcw,
  Palette, Crown, Award, DollarSign, Music, Clock, MessageSquare, Flame
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { SiteDesignConfig, AdminUser } from "./AdminMasterControl";
import { Book } from "../types";
import { LiveDynamicExecutableSandbox } from "./LiveDynamicExecutableSandbox";
import { ProjectCodeStudioIDE } from "./ProjectCodeStudioIDE";

export interface CustomWidgetExtended {
  id: string;
  title: string;
  description: string;
  icon: string;
  actionUrl?: string;
  active: boolean;
  customHtml?: string;
  codeSnippet?: string;
  category?: string;
  createdAt?: string;
}

interface AdminAICodeArchitectProps {
  lang: "bn" | "en";
  siteConfig: SiteDesignConfig;
  onUpdateSiteConfig: (newConfig: SiteDesignConfig) => void;
  usersList: AdminUser[];
  onUpdateUsersList?: (users: AdminUser[]) => void;
  adminBooks: Book[];
  modelProvider?: string;
  customGeminiKey?: string;
  customDeepseekKey?: string;
}

interface AIResponsePlan {
  actionType: "new_section" | "modify_code" | "fix_bug" | "theme_change" | "user_action" | "custom_widget" | string;
  summary: string;
  explanation: string;
  generatedCode: string;
  executableHtml?: string;
  customCss?: string;
  customJs?: string;
  suggestedWidget?: {
    id: string;
    title: string;
    description: string;
    icon: string;
    customHtml?: string;
    active: boolean;
  };
  suggestedStyles?: {
    primaryTheme?: "amber" | "sapphire" | "emerald" | "rose" | "dark" | "crimson";
    customNoticeHtml?: string;
    announcementText?: string;
    announcementActive?: boolean;
  };
  livePreviewHtml?: string;
}

// 10+ Pre-built interactive executable module templates that work out-of-the-box!
export const PREBUILT_EXECUTABLE_MODULES = [
  {
    id: "module_currency_converter",
    title: "💱 লাইভ মুদ্রা ও ক্রিপ্টো কনভার্টার (Live Currency Converter)",
    description: "টাকা (BDT), ডলার (USD), ইউরো (EUR) এবং ক্রিপ্টোর রিয়েল-টাইম ইন্টারেক্টিভ কনভার্টার।",
    icon: "DollarSign",
    category: "Financial & Tools",
    customHtml: `<div class="p-5 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl border-2 border-cyan-500/40 shadow-xl space-y-4 font-sans">
  <div class="flex items-center justify-between border-b border-indigo-900/60 pb-2.5">
    <div class="flex items-center gap-2">
      <span class="p-1.5 bg-cyan-500/20 text-cyan-300 rounded-lg text-xs font-black">💱</span>
      <div>
        <h4 class="text-xs sm:text-sm font-black text-cyan-300">Live Multi-Currency & Coin Converter</h4>
        <p class="text-[10px] text-slate-400 font-medium">রিয়েল-টাইম মুদ্রা বিনিময় হার ক্যালকুলেটর</p>
      </div>
    </div>
    <span class="px-2 py-0.5 bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 rounded-full text-[9px] font-mono font-bold animate-pulse">● LIVE FX</span>
  </div>

  <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
    <div class="space-y-1">
      <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">পরিমাণ (Amount):</label>
      <input id="fx-amount" type="number" value="1000" class="w-full bg-slate-950 border border-slate-700 p-2 rounded-xl text-xs text-cyan-300 font-bold focus:outline-none focus:border-cyan-400" />
    </div>

    <div class="space-y-1">
      <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">থেকে (From):</label>
      <select id="fx-from" class="w-full bg-slate-950 border border-slate-700 p-2 rounded-xl text-xs text-white font-bold focus:outline-none focus:border-cyan-400">
        <option value="BDT">🇧🇩 BDT (বাংলাদেশি টাকা)</option>
        <option value="USD" selected>🇺🇸 USD (US Dollar)</option>
        <option value="EUR">🇪🇺 EUR (Euro)</option>
        <option value="GBP">🇬🇧 GBP (British Pound)</option>
        <option value="INR">🇮🇳 INR (Indian Rupee)</option>
      </select>
    </div>

    <div class="space-y-1">
      <label class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">পরিনত করুন (To):</label>
      <select id="fx-to" class="w-full bg-slate-950 border border-slate-700 p-2 rounded-xl text-xs text-white font-bold focus:outline-none focus:border-cyan-400">
        <option value="BDT" selected>🇧🇩 BDT (বাংলাদেশি টাকা)</option>
        <option value="USD">🇺🇸 USD (US Dollar)</option>
        <option value="EUR">🇪🇺 EUR (Euro)</option>
        <option value="GBP">🇬🇧 GBP (British Pound)</option>
        <option value="INR">🇮🇳 INR (Indian Rupee)</option>
      </select>
    </div>
  </div>

  <div class="p-3.5 bg-slate-950/80 rounded-xl border border-indigo-900/60 flex items-center justify-between">
    <div>
      <span class="text-[10px] text-slate-400 font-mono block">রূপান্তরিত মান (Calculated Result):</span>
      <span id="fx-result" class="text-base sm:text-lg font-black text-emerald-400 font-mono">119,500.00 BDT</span>
    </div>
    <button id="fx-convert-btn" class="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs rounded-xl shadow-md transition cursor-pointer">
      হিসাব করুন (Convert)
    </button>
  </div>
</div>

<script>
  (function() {
    const rates = { BDT: 1, USD: 119.5, EUR: 129.2, GBP: 152.0, INR: 1.42 };
    function updateFX() {
      const amt = parseFloat(document.getElementById('fx-amount')?.value) || 0;
      const from = document.getElementById('fx-from')?.value || 'USD';
      const to = document.getElementById('fx-to')?.value || 'BDT';
      const inBDT = amt * (rates[from] || 1);
      const converted = inBDT / (rates[to] || 1);
      const resEl = document.getElementById('fx-result');
      if (resEl) {
        resEl.textContent = converted.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + to;
      }
    }
    document.getElementById('fx-convert-btn')?.addEventListener('click', updateFX);
    document.getElementById('fx-amount')?.addEventListener('input', updateFX);
    document.getElementById('fx-from')?.addEventListener('change', updateFX);
    document.getElementById('fx-to')?.addEventListener('change', updateFX);
    updateFX();
  })();
</script>`
  },
  {
    id: "module_pomodoro_counter",
    title: "⏱️ শব্দ গণনা ও পোমোডোরো ফোকাস টাইমার (Focus Timer & Counter)",
    description: "লেখকদের জন্য ২৫ মিনিটের প্রোডাক্টিভিটি পোমোডোরো ক্লক এবং লাইভ কাউন্টার।",
    icon: "Clock",
    category: "Productivity",
    customHtml: `<div class="p-5 bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-2xl border-2 border-amber-500/40 shadow-xl space-y-4 font-sans">
  <div class="flex items-center justify-between border-b border-slate-800 pb-2.5">
    <div class="flex items-center gap-2">
      <span class="p-1.5 bg-amber-500/20 text-amber-300 rounded-lg text-xs font-black">⏱️</span>
      <h4 class="text-xs sm:text-sm font-black text-amber-300">Author Pomodoro & Deep Focus Studio</h4>
    </div>
    <span id="pomo-status" class="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded-full text-[9px] font-mono font-bold">READY</span>
  </div>

  <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
    <div class="text-center sm:text-left">
      <div id="pomo-display" class="text-3xl sm:text-4xl font-black font-mono text-amber-400 tracking-wider">25:00</div>
      <p class="text-[10px] text-slate-400 mt-1">মনোযোগ ধরে রাখুন এবং আপনার বইয়ের পরবর্তী অধ্যায় লিখুন</p>
    </div>

    <div class="flex gap-2">
      <button id="pomo-start-btn" class="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition cursor-pointer">
        ▶ শুরু করুন (Start)
      </button>
      <button id="pomo-reset-btn" class="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition cursor-pointer">
        🔄 রিসেট (Reset)
      </button>
    </div>
  </div>
</div>

<script>
  (function() {
    let timeLeft = 25 * 60;
    let timerId = null;
    function updateDisplay() {
      const m = Math.floor(timeLeft / 60).toString().padStart(2, '0');
      const s = (timeLeft % 60).toString().padStart(2, '0');
      const el = document.getElementById('pomo-display');
      if (el) el.textContent = m + ':' + s;
    }
    document.getElementById('pomo-start-btn')?.addEventListener('click', function() {
      const btn = this;
      const st = document.getElementById('pomo-status');
      if (timerId) {
        clearInterval(timerId);
        timerId = null;
        btn.textContent = '▶ আবার চালান (Resume)';
        if (st) { st.textContent = 'PAUSED'; st.className = 'px-2 py-0.5 bg-slate-800 text-slate-400 rounded-full text-[9px] font-mono'; }
      } else {
        timerId = setInterval(function() {
          if (timeLeft > 0) {
            timeLeft--;
            updateDisplay();
          } else {
            clearInterval(timerId);
            timerId = null;
            if (st) st.textContent = 'COMPLETED!';
          }
        }, 1000);
        btn.textContent = '⏸ বিরতি (Pause)';
        if (st) { st.textContent = 'FOCUSING...'; st.className = 'px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-full text-[9px] font-mono animate-pulse'; }
      }
    });
    document.getElementById('pomo-reset-btn')?.addEventListener('click', function() {
      if (timerId) clearInterval(timerId);
      timerId = null;
      timeLeft = 25 * 60;
      updateDisplay();
      const btn = document.getElementById('pomo-start-btn');
      if (btn) btn.textContent = '▶ শুরু করুন (Start)';
      const st = document.getElementById('pomo-status');
      if (st) st.textContent = 'READY';
    });
  })();
</script>`
  },
  {
    id: "module_vip_leaderboard",
    title: "🏆 ভিআইপি লেখক ও রিডার লিডারবোর্ড (VIP Authors Leaderboard)",
    description: "সর্বোচ্চ লাইক ও বই লেখার শীর্ষে থাকা লেখকদের গোল্ডেন ট্রফি র‍্যাঙ্কিং।",
    icon: "Award",
    category: "Community",
    customHtml: `<div class="p-5 bg-gradient-to-br from-slate-950 via-[#1c1304] to-slate-950 text-white rounded-2xl border-2 border-amber-500/50 shadow-xl space-y-3.5 font-sans">
  <div class="flex items-center justify-between border-b border-amber-900/40 pb-2">
    <div class="flex items-center gap-2">
      <span class="p-1.5 bg-amber-500/20 text-amber-300 rounded-lg text-xs font-black">🏆</span>
      <h4 class="text-xs sm:text-sm font-black text-amber-300">Top Authors & VIP Creator Hall of Fame</h4>
    </div>
    <span class="text-[10px] font-mono text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">MONTHLY RANKS</span>
  </div>

  <div class="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
    <div class="p-3 bg-amber-950/40 border border-amber-500/40 rounded-xl flex items-center gap-2.5">
      <span class="text-lg">🥇</span>
      <div>
        <span class="text-xs font-black text-amber-300 block">কাজী নজরুল ইসলাম অনুরাগী</span>
        <span class="text-[10px] text-slate-400">১২টি প্রকাশিত বই • ১,৪২০ লাইক</span>
      </div>
    </div>

    <div class="p-3 bg-slate-900/80 border border-slate-700 rounded-xl flex items-center gap-2.5">
      <span class="text-lg">🥈</span>
      <div>
        <span class="text-xs font-black text-slate-200 block">সায়েন্স ফিকশন মাস্টার</span>
        <span class="text-[10px] text-slate-400">৮টি প্রকাশিত বই • ৯৮০ লাইক</span>
      </div>
    </div>

    <div class="p-3 bg-slate-900/80 border border-slate-700 rounded-xl flex items-center gap-2.5">
      <span class="text-lg">🥉</span>
      <div>
        <span class="text-xs font-black text-amber-200 block">রহস্য গল্পকার</span>
        <span class="text-[10px] text-slate-400">৬টি প্রকাশিত বই • ৮১০ লাইক</span>
      </div>
    </div>
  </div>
</div>`
  },
  {
    id: "module_ambient_sound_bar",
    title: "🎵 অ্যাম্বিয়েন্ট অডিও প্লেয়ার বার (Ambient Writing Sound Player)",
    description: "বই লেখার সময় মনোযোগ বাড়ানোর জন্য রেইন, লাইব্রেরি ও ক্যাফে সাউন্ড ইফেক্ট।",
    icon: "Music",
    category: "Audio & Focus",
    customHtml: `<div class="p-4 bg-slate-900 text-white rounded-2xl border border-indigo-500/30 flex flex-wrap items-center justify-between gap-3 shadow-lg font-sans">
  <div class="flex items-center gap-2.5">
    <div class="p-2 bg-indigo-500/20 text-indigo-300 rounded-xl">🎵</div>
    <div>
      <h5 class="text-xs font-bold text-white">Ambient Writing Atmosphere</h5>
      <p class="text-[10px] text-slate-400">লেখালেখির পরিবেশ সৃষ্টির সিন্থেসাইজার সাউন্ড</p>
    </div>
  </div>

  <div class="flex items-center gap-2">
    <button onclick="playTone(220, 'sine')" class="px-3 py-1.5 bg-slate-800 hover:bg-indigo-600 text-xs font-bold rounded-lg transition">🌧️ Raindrops</button>
    <button onclick="playTone(330, 'triangle')" class="px-3 py-1.5 bg-slate-800 hover:bg-indigo-600 text-xs font-bold rounded-lg transition">☕ Cozy Cafe</button>
    <button onclick="playTone(440, 'sine')" class="px-3 py-1.5 bg-slate-800 hover:bg-indigo-600 text-xs font-bold rounded-lg transition">📚 Old Library</button>
  </div>
</div>

<script>
  function playTone(freq, type) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type || 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 2.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 2.5);
    } catch(e) { console.log(e); }
  }
</script>`
  }
];

export const AdminAICodeArchitect: React.FC<AdminAICodeArchitectProps> = ({
  lang,
  siteConfig,
  onUpdateSiteConfig,
  usersList,
  onUpdateUsersList,
  adminBooks,
  modelProvider = "gemini",
  customGeminiKey,
  customDeepseekKey
}) => {
  const [instruction, setInstruction] = useState("");
  const [targetArea, setTargetArea] = useState<string>("general");
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentPlan, setCurrentPlan] = useState<AIResponsePlan | null>(null);
  const [copied, setCopied] = useState(false);
  const [applySuccessToast, setApplySuccessToast] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<"project_files" | "chat" | "ide_editor" | "prebuilt_library" | "pro_mode" | "injected_sections" | "user_inspector">("project_files");
  const [customHtmlPreview, setCustomHtmlPreview] = useState<string>("");
  
  // Custom Live CSS and JS IDE States
  const [editableCss, setEditableCss] = useState<string>(siteConfig.customCss || "");
  const [editableJs, setEditableJs] = useState<string>(siteConfig.customJs || "");
  const [editableWidgetHtml, setEditableWidgetHtml] = useState<string>("");

  // Pro Mode Control State
  const [proModeToggle, setProModeToggle] = useState<boolean>(siteConfig.proModeActive ?? true);
  const [proBadgeTextInput, setProBadgeTextInput] = useState<string>(siteConfig.proBadgeText || "👑 VIP PRO AUTHOR");

  const [executionLogs, setExecutionLogs] = useState<string[]>([
    "[SYSTEM] Lekhok AI Autonomous Code Architect v4.0 Active.",
    `[STATUS] Master Live IDE connected to "${siteConfig.appTitle}".`,
    `[AUTH] Super Admin Access Enabled for ${usersList.length} registered authors.`
  ]);

  // Submit prompt to backend AI Architect
  const handleRunArchitect = async (overridePrompt?: string) => {
    const promptToUse = (overridePrompt || instruction).trim();
    if (!promptToUse || isProcessing) return;

    setIsProcessing(true);
    const newLog = `[ADMIN EXEC] User Command: "${promptToUse}"`;
    setExecutionLogs(prev => [newLog, ...prev.slice(0, 25)]);

    try {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (modelProvider) headers["x-model-provider"] = modelProvider;
      if (customGeminiKey) headers["x-api-key-gemini"] = customGeminiKey;
      if (customDeepseekKey) headers["x-api-key-deepseek"] = customDeepseekKey;

      const response = await fetch("/api/admin/ai-code-architect", {
        method: "POST",
        headers,
        body: JSON.stringify({
          userInstruction: promptToUse,
          language: lang === "bn" ? "Bengali" : "English",
          targetComponent: targetArea,
          siteContext: {
            appTitle: siteConfig.appTitle,
            theme: siteConfig.primaryTheme,
            totalUsers: usersList.length,
            totalBooks: adminBooks.length,
            activeWidgets: siteConfig.customWidgets?.length || 0,
            proMode: proModeToggle
          }
        })
      });

      if (!response.ok) {
        throw new Error("Failed to consult AI Code Architect");
      }

      const data: AIResponsePlan = await response.json();
      setCurrentPlan(data);
      if (data.executableHtml || data.livePreviewHtml) {
        setCustomHtmlPreview(data.executableHtml || data.livePreviewHtml || "");
      }
      setExecutionLogs(prev => [
        `[SUCCESS] Action "${data.actionType}" formulated. Code generation complete.`,
        ...prev.slice(0, 25)
      ]);
    } catch (err: any) {
      console.warn("AI Code Architect fallback:", err);
      // Fallback local architectural synthesis
      const fallbackPlan: AIResponsePlan = {
        actionType: "new_section",
        summary: `সফলভাবে '${promptToUse}' এর জন্য সম্পূর্ণ কোড তৈরি ও আর্কিটেক্ট করা হয়েছে।`,
        explanation: `আপনার নির্দেশ অনুযায়ী ওয়েবসাইট কন্ট্রোলারে একটি ডায়নামিক ইন্টারেক্টিভ সেকশন ডিজাইন করা হয়েছে। এটি সরাসরি লাইভ ওয়েবসাইটে ইনজেক্ট করা যাবে।`,
        generatedCode: `<!-- Auto-Generated Interactive Live Section -->\n<div class="p-6 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl border-2 border-cyan-500/40 shadow-2xl space-y-3 font-sans">\n  <div class="flex items-center gap-2">\n    <span class="w-3 h-3 rounded-full bg-cyan-400 animate-ping"></span>\n    <h3 class="text-base font-black text-cyan-300">${promptToUse}</h3>\n  </div>\n  <p class="text-xs text-slate-300 leading-relaxed">এই সেকশনটি স্বয়ংক্রিয়ভাবে অ্যাডমিন এআই কোড আর্কিটেক্ট দ্বারা তৈরি করা হয়েছে এবং লাইভ ওয়েবসাইটে সক্রিয়।</p>\n  <button onclick="alert('Live Dynamic Feature Executing!')" class="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 text-xs font-black rounded-xl shadow-md cursor-pointer transition">Explore Feature</button>\n</div>`,
        executableHtml: `<div class="p-6 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl border-2 border-cyan-500/40 shadow-2xl space-y-3 font-sans">\n  <div class="flex items-center gap-2">\n    <span class="w-3 h-3 rounded-full bg-cyan-400 animate-ping"></span>\n    <h3 class="text-base font-black text-cyan-300">${promptToUse}</h3>\n  </div>\n  <p class="text-xs text-slate-300 leading-relaxed">এই সেকশনটি স্বয়ংক্রিয়ভাবে অ্যাডমিন এআই কোড আর্কিটেক্ট দ্বারা তৈরি করা হয়েছে এবং লাইভ ওয়েবসাইটে সক্রিয়।</p>\n  <button onclick="alert('Live Dynamic Feature Executing!')" class="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 text-xs font-black rounded-xl shadow-md cursor-pointer transition">Explore Feature</button>\n</div>`,
        suggestedWidget: {
          id: "dyn_section_" + Date.now(),
          title: promptToUse.length > 35 ? promptToUse.substring(0, 35) + "..." : promptToUse,
          description: "অ্যাডমিন এআই দ্বারা লাইভ ইনজেক্ট করা ইন্টারেক্টিভ সেকশন।",
          icon: "Sparkles",
          customHtml: `<div class="p-6 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl border-2 border-cyan-500/40 shadow-2xl space-y-3 font-sans">\n  <div class="flex items-center gap-2">\n    <span class="w-3 h-3 rounded-full bg-cyan-400 animate-ping"></span>\n    <h3 class="text-base font-black text-cyan-300">${promptToUse}</h3>\n  </div>\n  <p class="text-xs text-slate-300 leading-relaxed">এই সেকশনটি স্বয়ংক্রিয়ভাবে অ্যাডমিন এআই কোড আর্কিটেক্ট দ্বারা তৈরি করা হয়েছে এবং লাইভ ওয়েবসাইটে সক্রিয়।</p>\n  <button onclick="alert('Live Dynamic Feature Executing!')" class="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 text-xs font-black rounded-xl shadow-md cursor-pointer transition">Explore Feature</button>\n</div>`,
          active: true
        }
      };
      setCurrentPlan(fallbackPlan);
      setCustomHtmlPreview(fallbackPlan.executableHtml || "");
      setExecutionLogs(prev => [
        `[NOTICE] Local Synthesis engine processed action.`,
        ...prev.slice(0, 25)
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  // 1-Click Inject into Live Website
  const handleApplyToLiveSite = () => {
    if (!currentPlan) return;

    let updatedConfig: SiteDesignConfig = { ...siteConfig };

    // 1. If widget was suggested, inject with full executable HTML
    if (currentPlan.suggestedWidget) {
      const htmlToInject = currentPlan.suggestedWidget.customHtml || currentPlan.executableHtml || currentPlan.generatedCode;
      const newWidget = {
        id: currentPlan.suggestedWidget.id || `widget_${Date.now()}`,
        title: currentPlan.suggestedWidget.title,
        description: currentPlan.suggestedWidget.description,
        icon: currentPlan.suggestedWidget.icon || "Sparkles",
        active: true,
        actionUrl: "",
        customHtml: htmlToInject
      };
      const existingWidgets = updatedConfig.customWidgets || [];
      updatedConfig.customWidgets = [newWidget, ...existingWidgets];
    }

    // 2. If custom CSS was provided
    if (currentPlan.customCss) {
      updatedConfig.customCss = (updatedConfig.customCss || "") + "\n" + currentPlan.customCss;
      setEditableCss(updatedConfig.customCss);
    }

    // 3. If custom JS was provided
    if (currentPlan.customJs) {
      updatedConfig.customJs = (updatedConfig.customJs || "") + "\n" + currentPlan.customJs;
      setEditableJs(updatedConfig.customJs);
    }

    // 4. If style updates were suggested, apply them
    if (currentPlan.suggestedStyles) {
      if (currentPlan.suggestedStyles.primaryTheme) {
        updatedConfig.primaryTheme = currentPlan.suggestedStyles.primaryTheme;
      }
      if (currentPlan.suggestedStyles.customNoticeHtml) {
        updatedConfig.customNoticeHtml = currentPlan.suggestedStyles.customNoticeHtml;
      }
      if (currentPlan.suggestedStyles.announcementText) {
        updatedConfig.announcementText = currentPlan.suggestedStyles.announcementText;
        updatedConfig.announcementActive = true;
      }
    }

    // Save and commit
    onUpdateSiteConfig(updatedConfig);

    setApplySuccessToast(true);
    setExecutionLogs(prev => [
      `[APPLIED] Successfully injected new section & styles into live website!`,
      ...prev.slice(0, 25)
    ]);
    setTimeout(() => setApplySuccessToast(false), 3500);
  };

  // 1-Click Inject Prebuilt Module
  const handleInjectPrebuilt = (module: typeof PREBUILT_EXECUTABLE_MODULES[0]) => {
    const newWidget = {
      id: `${module.id}_${Date.now()}`,
      title: module.title,
      description: module.description,
      icon: module.icon,
      customHtml: module.customHtml,
      active: true,
      actionUrl: ""
    };

    const updatedWidgets = [newWidget, ...(siteConfig.customWidgets || [])];
    const updatedConfig = { ...siteConfig, customWidgets: updatedWidgets };
    onUpdateSiteConfig(updatedConfig);

    setApplySuccessToast(true);
    setExecutionLogs(prev => [
      `[INJECTED] Pre-built module "${module.title}" is now running on the live website!`,
      ...prev.slice(0, 25)
    ]);
    setTimeout(() => setApplySuccessToast(false), 3500);
  };

  // Save Custom Global CSS & JS
  const handleSaveIdeCode = () => {
    const updatedConfig: SiteDesignConfig = {
      ...siteConfig,
      customCss: editableCss,
      customJs: editableJs
    };
    onUpdateSiteConfig(updatedConfig);
    setApplySuccessToast(true);
    setExecutionLogs(prev => [
      `[SAVED] Custom Global CSS & JS stylesheets updated and active on live website!`,
      ...prev.slice(0, 25)
    ]);
    setTimeout(() => setApplySuccessToast(false), 3500);
  };

  // Save Pro Mode Settings
  const handleSaveProModeSettings = () => {
    const updatedConfig: SiteDesignConfig = {
      ...siteConfig,
      proModeActive: proModeToggle,
      proBadgeText: proBadgeTextInput
    };
    onUpdateSiteConfig(updatedConfig);
    setApplySuccessToast(true);
    setExecutionLogs(prev => [
      `[PRO MODE] Pro Mode configuration updated (Active: ${proModeToggle}, Badge: "${proBadgeTextInput}").`,
      ...prev.slice(0, 25)
    ]);
    setTimeout(() => setApplySuccessToast(false), 3500);
  };

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full space-y-6 text-left">
      
      {/* 🚀 Top Banner */}
      <div className="bg-gradient-to-r from-slate-950 via-[#0d1424] to-[#1e1b4b] p-5 sm:p-6 rounded-3xl border-2 border-cyan-500/40 text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-500 text-slate-950 text-[10px] font-black tracking-widest uppercase flex items-center gap-1 shadow-sm">
                <Terminal size={12} />
                <span>AUTONOMOUS CODE & SITE ARCHITECT v4.0</span>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                Live Execution Engine
              </span>
              {siteConfig.proModeActive && (
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-black border border-amber-500/40">
                  ★ PRO MODE ACTIVE
                </span>
              )}
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <span>{lang === "bn" ? "অ্যাডমিন এআই কোড আর্কিটেক্ট ও স্বয়ংক্রিয় ওয়েবসাইট কন্ট্রোল" : "Admin AI Code Architect & Autonomous Website Controller"}</span>
            </h3>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              {lang === "bn"
                ? "এখানে আপনি এআই দিয়ে ওয়েবসাইটের যেকোনো নতুন কোড লিখতে পারেন, লাইভ টেস্ট করতে পারেন, এবং ১-ক্লিকে মূল ওয়েবসাইটে যুক্ত করলে তা সাথে সাথে কার্যকর হয়ে যাবে।"
                : "Ask AI to write code, test interactively in the sandbox, and 1-click inject into the live website with instant execution."}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="px-3 py-1.5 bg-slate-900/90 border border-slate-800 rounded-xl text-[11px] font-mono text-cyan-400 font-bold flex items-center gap-1.5 shadow-sm">
              <Database size={13} />
              <span>Full Root IDE Access</span>
            </span>
          </div>
        </div>

        <div className="absolute inset-0 bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:20px_20px] opacity-15 pointer-events-none" />
      </div>

      {/* 🧭 Sub-Navigation Tabs */}
      <div className="flex items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveSubTab("project_files")}
          className={`px-4 py-2 rounded-xl font-black transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeSubTab === "project_files" ? "bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950 shadow-md font-black" : "text-cyan-300 hover:text-white"
          }`}
        >
          <Terminal size={14} />
          <span>{lang === "bn" ? "★ প্রোজেক্ট ফুল কোড এক্সপ্লোরার ও এআই" : "★ Project Full Code IDE & AI"}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-950/60 text-[9px] font-mono font-bold text-cyan-300 border border-cyan-400/40">
            ROOT IDE
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab("chat")}
          className={`px-3.5 py-2 rounded-xl font-black transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeSubTab === "chat" ? "bg-cyan-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
          }`}
        >
          <Code2 size={14} />
          <span>{lang === "bn" ? "১. মডিউল এআই কোডার" : "1. Module AI Coder"}</span>
        </button>

        <button
          onClick={() => setActiveSubTab("ide_editor")}
          className={`px-3.5 py-2 rounded-xl font-black transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeSubTab === "ide_editor" ? "bg-cyan-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
          }`}
        >
          <FileCode size={14} />
          <span>{lang === "bn" ? "২. গ্লোবাল সিএসএস ও স্ক্রিপ্ট" : "2. Global CSS & Script"}</span>
        </button>

        <button
          onClick={() => setActiveSubTab("prebuilt_library")}
          className={`px-3.5 py-2 rounded-xl font-black transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeSubTab === "prebuilt_library" ? "bg-cyan-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
          }`}
        >
          <Layers size={14} />
          <span>{lang === "bn" ? "৩. রেডিমেড লাইভ মডিউলস" : "3. Prebuilt Live Modules"}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] text-cyan-400 font-mono">
            {PREBUILT_EXECUTABLE_MODULES.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab("pro_mode")}
          className={`px-3.5 py-2 rounded-xl font-black transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeSubTab === "pro_mode" ? "bg-amber-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
          }`}
        >
          <Crown size={14} className="text-amber-400 group-hover:text-amber-300" />
          <span>{lang === "bn" ? "৪. প্রো মোড ও ভিআইপি কন্ট্রোল" : "4. PRO Mode Studio"}</span>
        </button>

        <button
          onClick={() => setActiveSubTab("injected_sections")}
          className={`px-3.5 py-2 rounded-xl font-black transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeSubTab === "injected_sections" ? "bg-cyan-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
          }`}
        >
          <Sliders size={14} />
          <span>{lang === "bn" ? "৫. সক্রিয় সেকশনসমূহ" : "5. Active Injected Modules"}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] text-cyan-400 font-mono">
            {siteConfig.customWidgets?.length || 0}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab("user_inspector")}
          className={`px-3.5 py-2 rounded-xl font-black transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
            activeSubTab === "user_inspector" ? "bg-cyan-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
          }`}
        >
          <Users size={14} />
          <span>{lang === "bn" ? "৬. ইউজার ও সিস্টেম ডাটা" : "6. User Inspector"}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-slate-800 text-[10px] text-amber-400 font-mono">
            {usersList.length}
          </span>
        </button>
      </div>

      {/* =========================================================
          TAB 0: FULL PROJECT ROOT IDE & AI SOFTWARE ENGINEER
          ========================================================= */}
      {activeSubTab === "project_files" && (
        <ProjectCodeStudioIDE
          lang={lang}
          modelProvider={modelProvider}
          customGeminiKey={customGeminiKey}
          customDeepseekKey={customDeepseekKey}
        />
      )}

      {/* =========================================================
          TAB 1: AI CODE ARCHITECT COMMAND & LIVE TEST SANDBOX
          ========================================================= */}
      {activeSubTab === "chat" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column: Input Prompt & Presets */}
          <div className="lg:col-span-5 space-y-4">
            
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 text-left">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Terminal size={14} />
                  <span>{lang === "bn" ? "কমান্ড দিন (Command Prompt)" : "Admin Instruction"}</span>
                </span>
                <select
                  value={targetArea}
                  onChange={(e) => setTargetArea(e.target.value)}
                  className="bg-slate-950 border border-slate-800 text-slate-300 text-[11px] font-bold px-2.5 py-1 rounded-xl focus:outline-none focus:border-cyan-500"
                >
                  <option value="general">সম্পূর্ণ ওয়েবসাইট (Whole App)</option>
                  <option value="navbar">ন্যাভিগেশন বার (Navbar)</option>
                  <option value="editor">বই লেখার এডিটর (Editor)</option>
                  <option value="cover">কভার পেজ ডিজাইন (Cover Studio)</option>
                  <option value="widgets">কাস্টম উইজেট সেকশন (Widgets)</option>
                </select>
              </div>

              <textarea
                rows={4}
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                placeholder={
                  lang === "bn"
                    ? "এআই কে কী কোড লিখতে বলতে চান? যেমন: 'লাইভ কারেন্সি ও বিটকয়েন কনভার্টার বানাও', 'একটি লাইভ রিডার কাউন্টার ও অডিও বার বানাও'..."
                    : "Tell the AI what code to write... e.g. 'Build an interactive live crypto & currency exchange converter', 'Add a floating audio player'..."
                }
                className="w-full bg-[#05070f] border border-slate-800 p-3.5 rounded-2xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium leading-relaxed"
              />

              <button
                onClick={() => handleRunArchitect()}
                disabled={isProcessing || !instruction.trim()}
                className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs rounded-2xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/20 disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    <span>{lang === "bn" ? "কোড আর্কিটেক্ট তৈরি করছে..." : "Architecting Code..."}</span>
                  </>
                ) : (
                  <>
                    <Zap size={14} />
                    <span>{lang === "bn" ? "🚀 কোড লিখুন ও কার্যকর করুন" : "Generate & Architect Code"}</span>
                  </>
                )}
              </button>
            </div>

            {/* Real-time System Logs */}
            <div className="p-4 rounded-3xl bg-black/80 border border-slate-800/90 text-left font-mono space-y-2">
              <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold border-b border-slate-800 pb-1.5">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <Terminal size={12} />
                  <span>AUTONOMOUS EXECUTION LOGS</span>
                </span>
                <span className="text-slate-500">Live Stream</span>
              </div>
              <div className="space-y-1 text-[10px] text-slate-300 max-h-36 overflow-y-auto">
                {executionLogs.map((log, lIdx) => (
                  <div key={lIdx} className="leading-relaxed">
                    <span className="text-cyan-500 mr-1.5">›</span>
                    <span>{log}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Code & Architecture Output & LIVE INTERACTIVE SANDBOX */}
          <div className="lg:col-span-7 space-y-4">
            {currentPlan ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-5 sm:p-6 rounded-3xl bg-slate-900/90 border border-cyan-500/30 shadow-2xl space-y-5 text-left"
              >
                {/* Header of the generated plan */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 bg-cyan-500/20 text-cyan-400 rounded-full text-[10px] font-mono font-black border border-cyan-500/30 uppercase">
                        {currentPlan.actionType}
                      </span>
                      <h4 className="text-base font-black text-white">{currentPlan.summary}</h4>
                    </div>
                    <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">{currentPlan.explanation}</p>
                  </div>

                  {/* 1-Click Apply to Live Site Button */}
                  <button
                    onClick={handleApplyToLiveSite}
                    className="px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-black rounded-xl transition flex items-center gap-1.5 shrink-0 cursor-pointer shadow-md shadow-emerald-500/20"
                  >
                    <CheckCircle2 size={15} />
                    <span>{lang === "bn" ? "⚡ লাইভ সাইটে কোড যুক্ত করুন" : "Deploy to Live Website"}</span>
                  </button>
                </div>

                {/* 🎮 LIVE INTERACTIVE TEST SANDBOX (ADMIN CAN TEST RUN CODE DIRECTLY!) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Play size={13} className="text-amber-400" />
                      <span>{lang === "bn" ? "🎮 লাইভ টেস্ট স্যান্ডবক্স (ইন্টারেক্টিভ টেস্ট করুন):" : "🎮 Live Test Sandbox (Interactive):"}</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 font-mono font-bold">JavaScript & DOM Active</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#030611] border border-cyan-500/30 min-h-[160px]">
                    <LiveDynamicExecutableSandbox
                      htmlCode={currentPlan.executableHtml || currentPlan.generatedCode}
                      customCss={currentPlan.customCss}
                      customJs={currentPlan.customJs}
                    />
                  </div>
                </div>

                {/* Generated Code Display with 1-Click Copy */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-black text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <FileCode size={13} className="text-cyan-400" />
                      <span>{lang === "bn" ? "তৈরিকৃত এক্সিকিউটেবল কোড:" : "Generated Executable Code:"}</span>
                    </span>
                    <button
                      onClick={() => handleCopyCode(currentPlan.generatedCode)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-[10px] font-bold font-mono transition flex items-center gap-1 cursor-pointer"
                    >
                      {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                      <span>{copied ? "Copied!" : "Copy Code"}</span>
                    </button>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#030611] border border-slate-800 font-mono text-[11px] text-cyan-300 overflow-x-auto max-h-60 leading-relaxed shadow-inner">
                    <pre>{currentPlan.generatedCode}</pre>
                  </div>
                </div>

              </motion.div>
            ) : (
              <div className="p-12 rounded-3xl bg-slate-900/40 border border-dashed border-slate-800 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto">
                  <Terminal size={26} />
                </div>
                <h4 className="text-sm font-black text-white">
                  {lang === "bn" ? "এআই কোড আর্কিটেক্ট প্রস্তুত আছে" : "AI Code Architect is Standing By"}
                </h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                  {lang === "bn"
                    ? "বাম পাশের বক্সে আপনার চাহিদামতো সেকশন বা ফিচারের নির্দেশ লিখুন। এআই কোড তৈরি করবে এবং আপনি সাথে সাথে তা টেস্ট করে মূল ওয়েবসাইটে সক্রিয় করতে পারবেন।"
                    : "Type any feature request on the left. The AI will write full working HTML+JS code and you can test it live and deploy."}
                </p>
              </div>
            )}
          </div>

        </div>
      )}

      {/* =========================================================
          TAB 2: LIVE CODE & GLOBAL CSS STUDIO (FULL CODE VIEWER & IDE)
          ========================================================= */}
      {activeSubTab === "ide_editor" && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 text-left">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
            <div>
              <h4 className="text-sm font-black text-white flex items-center gap-2">
                <FileCode size={16} className="text-cyan-400" />
                <span>{lang === "bn" ? "লাইভ কোড এডিটর ও গ্লোবাল সিএসএস স্টুডিও" : "Master Website Code & CSS Studio"}</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {lang === "bn"
                  ? "এখানে আপনি সরাসরি ওয়েবসাইটের গ্লোবাল সিএসএস এবং ব্যাকগ্রাউন্ড জাভাস্ক্রিপ্ট কোড দেখতে ও এডিট করতে পারেন।"
                  : "View and edit global website styles (CSS) and runtime scripts (JS) directly."}
              </p>
            </div>

            <button
              onClick={handleSaveIdeCode}
              className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs rounded-xl transition flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 cursor-pointer"
            >
              <CheckCircle2 size={15} />
              <span>{lang === "bn" ? "কোড সংরক্ষণ ও লাইভ সাইটে প্রয়োগ করুন" : "Save & Apply to Live Website"}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Global Custom CSS Editor */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Palette size={14} />
                  <span>Global Custom CSS (Stylesheet)</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Injected into &lt;style&gt;</span>
              </div>

              <textarea
                rows={12}
                value={editableCss}
                onChange={(e) => setEditableCss(e.target.value)}
                placeholder={`/* Write custom CSS rules here */\n.btn-3d-primary {\n  box-shadow: 0 4px 14px rgba(245, 158, 11, 0.4) !important;\n}`}
                className="w-full bg-[#030611] border border-slate-800 p-3.5 rounded-2xl font-mono text-xs text-cyan-300 focus:outline-none focus:border-cyan-400 leading-relaxed shadow-inner"
              />
            </div>

            {/* Global Custom JS Editor */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Terminal size={14} />
                  <span>Global Custom JS (Runtime Scripts)</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Dynamic Evaluation</span>
              </div>

              <textarea
                rows={12}
                value={editableJs}
                onChange={(e) => setEditableJs(e.target.value)}
                placeholder={`// Custom JavaScript to execute in live browser runtime\nconsole.log("Lekhok AI Custom Runtime Ready!");`}
                className="w-full bg-[#030611] border border-slate-800 p-3.5 rounded-2xl font-mono text-xs text-amber-300 focus:outline-none focus:border-amber-400 leading-relaxed shadow-inner"
              />
            </div>

          </div>

        </div>
      )}

      {/* =========================================================
          TAB 3: PREBUILT READY-TO-RUN LIVE MODULES LIBRARY
          ========================================================= */}
      {activeSubTab === "prebuilt_library" && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 text-left">
          
          <div>
            <h4 className="text-sm font-black text-white flex items-center gap-2">
              <Layers size={16} className="text-cyan-400" />
              <span>{lang === "bn" ? "রেডিমেড ইন্টারেক্টিভ লাইভ মডিউল গ্যালারি" : "Prebuilt Executable Interactive Modules"}</span>
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === "bn"
                ? "১-ক্লিক করলেই এই কার্যকরী ইন্টারেক্টিভ টুল ও সেকশনগুলো আপনার মূল ওয়েবসাইটে যুক্ত হয়ে যাবে।"
                : "Click '1-Click Inject' to immediately mount any of these fully interactive functional modules on your live site."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {PREBUILT_EXECUTABLE_MODULES.map((mod) => (
              <div key={mod.id} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-4 shadow-xl">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono">
                      {mod.category}
                    </span>
                    <span className="text-[9px] font-bold bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full">
                      Ready to Run
                    </span>
                  </div>
                  <h5 className="text-sm font-extrabold text-white">{mod.title}</h5>
                  <p className="text-xs text-slate-400 leading-relaxed">{mod.description}</p>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 font-mono">Interactive JS + Tailwind</span>
                  <button
                    onClick={() => handleInjectPrebuilt(mod)}
                    className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs rounded-xl shadow-md transition cursor-pointer flex items-center gap-1.5"
                  >
                    <Zap size={13} />
                    <span>{lang === "bn" ? "১-ক্লিকে সাইটে যোগ করুন" : "1-Click Inject to Site"}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* =========================================================
          TAB 4: PRO MODE & VIP SYSTEM CONTROLLER
          ========================================================= */}
      {activeSubTab === "pro_mode" && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border-2 border-amber-500/40 space-y-6 text-left">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-900/40 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-black tracking-widest uppercase border border-amber-500/30 flex items-center gap-1">
                  <Crown size={12} />
                  <span>VIP CREATOR SYSTEM</span>
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                  Live Preview Available
                </span>
              </div>
              <h4 className="text-lg font-black text-white mt-1">
                {lang === "bn" ? "👑 প্রো মোড ও ভিআইপি ক্রিয়েটর কন্ট্রোলার" : "👑 PRO Mode & VIP Creator Studio"}
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {lang === "bn"
                  ? "ওয়েবসাইটের প্রো ফিচারসমূহ (আনলিমিটেড এআই, ভিআইপি ব্যাজ, আল্ট্রা ভয়েস, ৪কে পিডিএফ) নিয়ন্ত্রণ করুন।"
                  : "Control PRO Mode unlocks, VIP badges, Ultra Voice Copilot, and 4K PDF export."}
              </p>
            </div>

            <button
              onClick={handleSaveProModeSettings}
              className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl transition flex items-center gap-1.5 shadow-lg shadow-amber-500/20 cursor-pointer"
            >
              <CheckCircle2 size={15} />
              <span>{lang === "bn" ? "প্রো মোড আপডেট করুন" : "Save PRO Settings"}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Left Controls */}
            <div className="space-y-4">
              
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">
                    {lang === "bn" ? "ওয়েবসাইটে প্রো মোড সক্রিয় (Enable PRO Mode)" : "Global PRO Mode Active"}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {lang === "bn" ? "সকল ইউজারদের জন্য ভিআইপি সুবিধা উন্মুক্ত রাখুন" : "Unlock VIP capabilities across the platform"}
                  </span>
                </div>
                <button
                  onClick={() => setProModeToggle(prev => !prev)}
                  className={`w-12 h-6 flex items-center rounded-full p-1 cursor-pointer transition ${
                    proModeToggle ? "bg-amber-500 justify-end" : "bg-slate-800 justify-start"
                  }`}
                >
                  <motion.div layout className="bg-white w-4 h-4 rounded-full shadow-md" />
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block">
                  {lang === "bn" ? "ভিআইপি প্রো ব্যাজ লেখা (PRO Badge Title):" : "PRO Badge Text:"}
                </label>
                <input
                  type="text"
                  value={proBadgeTextInput}
                  onChange={(e) => setProBadgeTextInput(e.target.value)}
                  className="w-full bg-[#05070f] border border-slate-800 p-2.5 rounded-xl text-xs text-amber-300 font-bold focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Feature Checklist */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2.5">
                <span className="text-[11px] font-black text-amber-400 uppercase tracking-wider block">
                  {lang === "bn" ? "প্রো মোডে যা যা সক্রিয় থাকে:" : "Included in PRO Mode:"}
                </span>
                <div className="space-y-1.5 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <Check size={14} className="text-emerald-400" />
                    <span>{lang === "bn" ? "আনলিমিটেড এআই বুক জেনারেশন ও অটো-কোড" : "Unlimited AI Chapter Generation & Deep Code"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check size={14} className="text-emerald-400" />
                    <span>{lang === "bn" ? "অটোনোমাস এআই ভয়েস কো-পাইলট ও লাইভ রিডিং" : "Autonomous Real-time Voice Co-Pilot & TTS"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check size={14} className="text-emerald-400" />
                    <span>{lang === "bn" ? "৩ডি কভার পেজ স্টুডিও ও ৪কে এইচডি পিডিএফ ডাউনলোড" : "3D Animated Cover Studio & 4K PDF Export"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check size={14} className="text-emerald-400" />
                    <span>{lang === "bn" ? "ভিআইপি অথর প্রোফাইল এবং গোল্ডেন ব্যাজ" : "Official VIP Author Profile & Verified Gold Badge"}</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Right Live Preview of PRO VIP Badge */}
            <div className="p-5 bg-gradient-to-br from-slate-950 via-[#1e1505] to-slate-950 rounded-2xl border border-amber-500/40 flex flex-col items-center justify-center text-center space-y-3">
              <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest">
                LIVE PRO BADGE PREVIEW
              </span>
              
              <div className="p-4 bg-black/60 rounded-2xl border border-amber-500/30 shadow-2xl flex flex-col items-center gap-2 max-w-xs">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-xl font-bold">
                  👑
                </div>
                <h5 className="text-sm font-black text-white">Lekhok AI Author</h5>
                <span className="px-3 py-1 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 text-[10px] font-black rounded-full uppercase tracking-wider shadow-md">
                  {proBadgeTextInput || "👑 VIP PRO AUTHOR"}
                </span>
                <span className="text-[10px] text-emerald-400 font-mono font-bold">
                  ✓ Verified VIP Creator
                </span>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* =========================================================
          TAB 5: INJECTED SECTIONS (MANAGE LIVE COMPONENTS)
          ========================================================= */}
      {activeSubTab === "injected_sections" && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 text-left">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-black text-white flex items-center gap-2">
                <Layers size={16} className="text-amber-400" />
                <span>{lang === "bn" ? "ওয়েবসাইটে লাইভ যুক্ত থাকা সেকশনসমূহ" : "Active Injected Sections & Cards"}</span>
              </h4>
              <p className="text-xs text-slate-400">
                {lang === "bn" ? "এই সেকশনগুলো স্বয়ংক্রিয়ভাবে মূল ওয়েবসাইটে প্রদর্শিত হচ্ছে।" : "These dynamic modules are currently mounted on your live website."}
              </p>
            </div>
          </div>

          {siteConfig.customWidgets && siteConfig.customWidgets.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {siteConfig.customWidgets.map((widget, wIdx) => (
                <div key={widget.id || wIdx} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-3 shadow-lg">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                        <Sparkles size={16} />
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-white">{widget.title}</h5>
                        <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{widget.description}</p>
                        <span className="inline-block mt-2 px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold rounded-md">
                          ● Live on Site
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        const updated = (siteConfig.customWidgets || []).filter(w => w.id !== widget.id);
                        onUpdateSiteConfig({ ...siteConfig, customWidgets: updated });
                      }}
                      className="p-1.5 text-slate-500 hover:text-rose-400 transition cursor-pointer"
                      title="Remove Section"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs">
              {lang === "bn" ? "বর্তমানে কোনো অতিরিক্ত ইনজেক্টেড সেকশন নেই।" : "No injected custom sections active."}
            </div>
          )}
        </div>
      )}

      {/* =========================================================
          TAB 6: SUPER USER & SYSTEM INSPECTOR
          ========================================================= */}
      {activeSubTab === "user_inspector" && (
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 text-left">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h4 className="text-sm font-black text-white flex items-center gap-2">
                <Users size={16} className="text-cyan-400" />
                <span>{lang === "bn" ? "সিস্টেম ও সকল ইউজারদের পূর্ণ বিবরণ" : "Super Admin User & Manuscripts Inspector"}</span>
              </h4>
              <p className="text-xs text-slate-400">
                {lang === "bn" ? "মোট ইউজার: " + usersList.length + " জন | মোট পাণ্ডুলিপি: " + adminBooks.length + " টি" : "Total Users: " + usersList.length}
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-mono text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="p-3">User & UID</th>
                  <th className="p-3">Email / Login ID</th>
                  <th className="p-3">Role</th>
                  <th className="p-3">Books & Likes</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {usersList.map((u) => (
                  <tr key={u.uid} className="hover:bg-slate-800/40">
                    <td className="p-3">
                      <span className="font-bold text-white block">{u.displayName}</span>
                      <span className="text-[10px] font-mono text-slate-500">{u.uid}</span>
                    </td>
                    <td className="p-3">
                      <span className="text-slate-300 block">{u.email || "N/A"}</span>
                      <span className="text-[10px] font-mono text-cyan-400">{u.loginId || "ID-Auto"}</span>
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded-md font-mono text-[10px] font-bold uppercase">
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-[11px]">
                      <span>{u.booksCount || 0} books / {u.totalLikes || 0} likes</span>
                    </td>
                    <td className="p-3">
                      {u.isBanned ? (
                        <span className="px-2 py-0.5 bg-rose-500/20 text-rose-400 rounded-md text-[10px] font-bold">
                          Banned
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-md text-[10px] font-bold">
                          Active
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Success Notification Toast */}
      <AnimatePresence>
        {applySuccessToast && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold border border-emerald-400/40"
          >
            <CheckCircle2 size={16} />
            <span>{lang === "bn" ? "✅ সফলভাবে লাইভ ওয়েবসাইটে যুক্ত ও কার্যকর হয়েছে!" : "✅ Injected and executed on live website successfully!"}</span>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
