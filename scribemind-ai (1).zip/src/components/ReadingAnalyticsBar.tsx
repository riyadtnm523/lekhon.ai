import React, { useState, useEffect } from "react";
import { Gauge, Clock, BookOpen, TrendingUp, Flame, Calendar, Award } from "lucide-react";

interface ReadingAnalyticsBarProps {
  currentChapterContent: string;
  chapterNumber: number;
  totalChapters: number;
  lang?: "bn" | "en";
  bookId?: string;
}

export const ReadingAnalyticsBarComponent: React.FC<ReadingAnalyticsBarProps> = ({
  currentChapterContent,
  chapterNumber,
  totalChapters,
  lang = "bn",
  bookId = "global"
}) => {
  const [readingSeconds, setReadingSeconds] = useState(0);
  const [streakDays, setStreakDays] = useState(1);
  const [totalCumulativeWords, setTotalCumulativeWords] = useState(0);

  // Load and calculate genuine reader streak & metrics from localStorage
  useEffect(() => {
    try {
      const todayStr = new Date().toISOString().split("T")[0];
      const savedStats = localStorage.getItem("lekhok_real_reader_stats");
      let stats = {
        lastActiveDate: todayStr,
        streak: 1,
        totalWordsRead: 0,
        readingHistory: [todayStr]
      };

      if (savedStats) {
        const parsed = JSON.parse(savedStats);
        stats.totalWordsRead = parsed.totalWordsRead || 0;
        
        if (parsed.lastActiveDate) {
          const lastDate = new Date(parsed.lastActiveDate);
          const today = new Date(todayStr);
          const diffDays = Math.round((today.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));

          if (diffDays === 0) {
            stats.streak = parsed.streak || 1;
          } else if (diffDays === 1) {
            stats.streak = (parsed.streak || 1) + 1;
            stats.lastActiveDate = todayStr;
          } else {
            stats.streak = 1; // Streak reset if missed more than 1 day
            stats.lastActiveDate = todayStr;
          }
        }
      }

      setStreakDays(stats.streak);
      setTotalCumulativeWords(stats.totalWordsRead);
      localStorage.setItem("lekhok_real_reader_stats", JSON.stringify(stats));
    } catch (e) {}
  }, []);

  // Real-time active reading timer
  useEffect(() => {
    const timer = setInterval(() => {
      setReadingSeconds(prev => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Update cumulative words read in local storage periodically
  useEffect(() => {
    if (readingSeconds > 0 && readingSeconds % 10 === 0) {
      const currentWords = (currentChapterContent || "").trim().split(/\s+/).filter(Boolean).length;
      try {
        const savedStats = localStorage.getItem("lekhok_real_reader_stats");
        if (savedStats) {
          const parsed = JSON.parse(savedStats);
          parsed.totalWordsRead = (parsed.totalWordsRead || 0) + Math.min(25, Math.ceil(currentWords / 15));
          localStorage.setItem("lekhok_real_reader_stats", JSON.stringify(parsed));
          setTotalCumulativeWords(parsed.totalWordsRead);
        }
      } catch (e) {}
    }
  }, [readingSeconds, currentChapterContent]);

  // Current Chapter Word Count
  const currentChapterWords = (currentChapterContent || "").trim().split(/\s+/).filter(Boolean).length;
  
  // Real reading speed (WPM) calculation:
  // If user has read for > 10 seconds, calculate active rate; otherwise default to calibrated 180-200 WPM
  const measuredWpm = readingSeconds > 8
    ? Math.min(450, Math.max(60, Math.round((currentChapterWords / Math.max(1, readingSeconds)) * 60)))
    : 185;

  const estimatedMinRead = Math.max(1, Math.ceil(currentChapterWords / Math.max(100, measuredWpm)));
  const progressPercent = Math.min(100, Math.round((chapterNumber / Math.max(1, totalChapters)) * 100));
  const remainingChapters = Math.max(0, totalChapters - chapterNumber);
  const estDaysToFinish = Math.max(1, Math.ceil(remainingChapters / 2));

  return (
    <div className="bg-gradient-to-r from-amber-950 via-[#3a1503] to-amber-950 text-amber-50 rounded-2xl p-3 sm:p-4 mb-4 shadow-md border border-amber-500/30 font-sans text-xs select-none">
      
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 border-b border-amber-800/60 pb-2.5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-amber-500/20 text-amber-300 rounded-lg border border-amber-500/30">
            <Gauge size={14} className="animate-pulse" />
          </div>
          <div>
            <h4 className="font-black text-amber-300 uppercase tracking-widest text-[10px] sm:text-[11px] flex items-center gap-1.5">
              <span>{lang === "bn" ? "রিয়েল-টাইম পড়ার গতি ও পাঠক এনালিটিক্স" : "Real-Time Reading Velocity & Tracker"}</span>
              <span className="text-[8px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 font-mono">
                REAL-TIME
              </span>
            </h4>
            <p className="text-[9px] text-amber-200/80 font-medium">
              {lang === "bn" ? "আপনার বাস্তব পড়ার গতি, মোট পঠিত শব্দ ও দৈনিক স্ট্রিক" : "Measured reading cadence, active words consumed & daily streak"}
            </p>
          </div>
        </div>

        {/* Real Daily Reading Streak Badge */}
        <div className="flex items-center gap-1.5 bg-amber-500/15 px-3 py-1 rounded-full border border-amber-500/30 text-[10px] text-amber-200 font-bold">
          <Flame size={12} className="text-amber-400 fill-amber-400 animate-bounce" />
          <span>
            {lang === "bn" ? `স্ট্রিক: ${streakDays} দিন নিয়মিত পড়া` : `${streakDays} Day Reading Streak`}
          </span>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3">
        
        {/* Metric 1: Reading Speed WPM */}
        <div className="bg-amber-900/40 p-2.5 rounded-xl border border-amber-800/50 flex flex-col justify-between">
          <span className="text-amber-300/80 text-[9px] font-bold uppercase tracking-wider flex items-center gap-1">
            <Clock size={11} />
            <span>{lang === "bn" ? "পড়ার গতি (WPM)" : "Reading Speed"}</span>
          </span>
          <span className="text-amber-100 font-black text-sm mt-1">
            ~{measuredWpm} <span className="text-[9px] font-normal text-amber-300/70">{lang === "bn" ? "শব্দ/মি." : "wpm"}</span>
          </span>
        </div>

        {/* Metric 2: Chapter Words & Est Time */}
        <div className="bg-amber-900/40 p-2.5 rounded-xl border border-amber-800/50 flex flex-col justify-between">
          <span className="text-amber-300/80 text-[9px] font-bold uppercase tracking-wider flex items-center gap-1">
            <BookOpen size={11} />
            <span>{lang === "bn" ? "অধ্যায়ের শব্দ" : "Chapter Words"}</span>
          </span>
          <span className="text-amber-100 font-black text-sm mt-1">
            {currentChapterWords} <span className="text-[9px] font-normal text-amber-300/70">({estimatedMinRead} {lang === "bn" ? "মি." : "min"})</span>
          </span>
        </div>

        {/* Metric 3: Total Words Read */}
        <div className="bg-amber-900/40 p-2.5 rounded-xl border border-amber-800/50 flex flex-col justify-between">
          <span className="text-amber-300/80 text-[9px] font-bold uppercase tracking-wider flex items-center gap-1">
            <Award size={11} />
            <span>{lang === "bn" ? "মোট পঠিত শব্দ" : "Total Read Words"}</span>
          </span>
          <span className="text-amber-100 font-black text-sm mt-1">
            {totalCumulativeWords + currentChapterWords} <span className="text-[9px] font-normal text-amber-300/70">{lang === "bn" ? "শব্দ" : "words"}</span>
          </span>
        </div>

        {/* Metric 4: Est Days to Finish */}
        <div className="bg-amber-900/40 p-2.5 rounded-xl border border-amber-800/50 flex flex-col justify-between">
          <span className="text-amber-300/80 text-[9px] font-bold uppercase tracking-wider flex items-center gap-1">
            <Calendar size={11} />
            <span>{lang === "bn" ? "বই শেষ হতে" : "Est. to Finish"}</span>
          </span>
          <span className="text-amber-200 font-black text-sm mt-1">
            ~{estDaysToFinish} {lang === "bn" ? "দিন" : "Days"}
          </span>
        </div>

      </div>

      {/* Chapter Progress */}
      <div className="mt-3 space-y-1">
        <div className="flex justify-between text-[9px] text-amber-300/80 font-bold">
          <span>{lang === "bn" ? "বইয়ের সামগ্রিক অগ্রগতি (Overall Book Progress):" : "Book Completion Track:"}</span>
          <span>{progressPercent}% ({chapterNumber}/{totalChapters} {lang === "bn" ? "অধ্যায়" : "Ch"})</span>
        </div>
        <div className="w-full h-1.5 bg-amber-950 rounded-full overflow-hidden border border-amber-800/60">
          <div 
            className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export const ReadingAnalyticsBar = React.memo(ReadingAnalyticsBarComponent);
