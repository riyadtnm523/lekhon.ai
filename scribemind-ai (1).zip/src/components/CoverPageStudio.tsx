import React, { useState, useRef } from "react";
import {
  Sparkles, Palette, Type, Layout, Image as ImageIcon,
  Download, Save, Check, RefreshCw, Undo, Eye, Sliders,
  Award, BookOpen, Layers, Star, Crown, Flame, Shield,
  ChevronRight, ZoomIn, Upload, Trash2
} from "lucide-react";
import { motion } from "motion/react";
import { Book } from "../types";

export interface CoverDesignState {
  title: string;
  subtitle: string;
  authorName: string;
  genre: string;
  tagline: string;
  publisherText: string;
  layoutTemplate: "classic_frame" | "modern_minimal" | "cyber_neon" | "magazine_bold" | "royal_gold" | "editorial_serif" | "abstract_art";
  colorPreset: string;
  customColor1: string;
  customColor2: string;
  fontFamily: "serif" | "sans" | "display" | "calligraphy";
  titleSize: "sm" | "md" | "lg" | "xl";
  borderStyle: "none" | "thin_gold" | "double_ornate" | "cyber_corners" | "minimal_white";
  badgeType: "none" | "bestseller" | "award_winner" | "collector_edition" | "original_work";
  imageUrl?: string;
  imageOpacity: number;
  imageBlur: number;
  overlayGradient: boolean;
  textureEffect: "none" | "grain" | "particles" | "gold_dust" | "geometric";
}

interface CoverPageStudioProps {
  book: Book;
  onSaveCover: (updatedBook: Book) => void;
  onClose?: () => void;
  lang: "bn" | "en";
}

export const COVER_COLOR_PRESETS = [
  { name: "Royal Midnight", c1: "#0f172a", c2: "#1e1b4b", gradient: "linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #311042 100%)" },
  { name: "Crimson Velvet", c1: "#450a0a", c2: "#7f1d1d", gradient: "linear-gradient(135deg, #450a0a 0%, #7f1d1d 50%, #1c0606 100%)" },
  { name: "Emerald Mystic", c1: "#022c22", c2: "#064e3b", gradient: "linear-gradient(135deg, #022c22 0%, #064e3b 50%, #0f172a 100%)" },
  { name: "Sapphire Ocean", c1: "#082f49", c2: "#0369a1", gradient: "linear-gradient(135deg, #082f49 0%, #0369a1 50%, #1e1b4b 100%)" },
  { name: "Golden Amber", c1: "#451a03", c2: "#78350f", gradient: "linear-gradient(135deg, #451a03 0%, #78350f 50%, #b45309 100%)" },
  { name: "Cyberpunk Violet", c1: "#2e1065", c2: "#701a75", gradient: "linear-gradient(135deg, #2e1065 0%, #701a75 50%, #030712 100%)" },
  { name: "Obsidian Slate", c1: "#090d16", c2: "#1e293b", gradient: "linear-gradient(135deg, #090d16 0%, #1e293b 100%)" },
  { name: "Vintage Parchment", c1: "#292524", c2: "#57534e", gradient: "linear-gradient(135deg, #1c1917 0%, #44403c 50%, #292524 100%)" },
];

export const CoverPageStudio: React.FC<CoverPageStudioProps> = ({
  book,
  onSaveCover,
  onClose,
  lang
}) => {
  const [design, setDesign] = useState<CoverDesignState>({
    title: book.title || "অমর কথা",
    subtitle: book.synopsis?.slice(0, 70) || "একটি রহস্যময় রূপকথা ও রোমাঞ্চকর অভিযাত্রা",
    authorName: book.creatorName || "লেখক এআই গ্রন্থকার",
    genre: book.genre || "কল্পবিজ্ঞান ও ফ্যান্টাসি",
    tagline: "জাতীয় বেস্টসেলার সংস্করণ",
    publisherText: "LEKHOK AI MASTERPIECE PUBLICATIONS",
    layoutTemplate: "royal_gold",
    colorPreset: "Royal Midnight",
    customColor1: "#0f172a",
    customColor2: "#1e1b4b",
    fontFamily: "serif",
    titleSize: "lg",
    borderStyle: "thin_gold",
    badgeType: "bestseller",
    imageUrl: book.coverImageUrl || "",
    imageOpacity: book.coverImageOpacity ?? 0.85,
    imageBlur: 0,
    overlayGradient: true,
    textureEffect: "gold_dust"
  });

  const [activeTab, setActiveTab] = useState<"text" | "layout" | "colors" | "graphics" | "badges">("layout");
  const [isSavedToast, setIsSavedToast] = useState(false);
  const coverPreviewRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const selectedPreset = COVER_COLOR_PRESETS.find(p => p.name === design.colorPreset) || COVER_COLOR_PRESETS[0];

  const handleSaveToBook = () => {
    const updatedBook: Book = {
      ...book,
      title: design.title,
      genre: design.genre,
      coverColor: selectedPreset.gradient,
      coverImageUrl: design.imageUrl,
      coverImageOpacity: design.imageOpacity,
      suggestedCoverStyle: `${design.layoutTemplate} • ${design.fontFamily} font • ${design.borderStyle} border • Badge: ${design.badgeType}`
    };

    onSaveCover(updatedBook);
    setIsSavedToast(true);
    setTimeout(() => setIsSavedToast(false), 3000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;
        const maxDim = 1000;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          setDesign(prev => ({ ...prev, imageUrl: canvas.toDataURL("image/jpeg", 0.85) }));
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };

  return (
    <div className="w-full bg-[#0b0f19] text-slate-100 rounded-3xl border border-amber-500/30 p-4 sm:p-6 shadow-2xl space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-black tracking-widest uppercase border border-amber-500/30 flex items-center gap-1">
              <Sparkles size={12} />
              <span>INTERACTIVE COVER DESIGN STUDIO</span>
            </span>
            <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-bold">
              Full Self-Edit Mode
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white mt-1">
            {lang === "bn" ? "🎨 বইয়ের কভার পেজ কাস্টমাইজেশন স্টুডিও" : "🎨 Book Cover Page Studio"}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {lang === "bn" 
              ? "বইয়ের টাইটেল, লেখক, ফ্রেম, ফন্ট, ব্যাকগ্রাউন্ড ও রয়্যাল ব্যাজ নিজের ইচ্ছেমতো সাজান।" 
              : "Customize title typography, layout templates, colors, badges, and background art."}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onClose && (
            <button
              onClick={onClose}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              {lang === "bn" ? "বন্ধ করুন" : "Close"}
            </button>
          )}
          <button
            onClick={handleSaveToBook}
            className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl transition flex items-center gap-1.5 shadow-lg shadow-amber-500/20 cursor-pointer"
          >
            <Save size={15} />
            <span>{lang === "bn" ? "বইয়ে কভার সংরক্ষণ করুন" : "Save Cover to Book"}</span>
          </button>
        </div>
      </div>

      {/* Main Studio Grid: Left Controls, Right Real-time 3D Cover Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: Controls & Styling Tabs */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Navigation Sub-Tabs */}
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-2xl border border-slate-800 overflow-x-auto text-xs">
            <button
              onClick={() => setActiveTab("layout")}
              className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === "layout" ? "bg-amber-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              <Layout size={14} />
              <span>{lang === "bn" ? "টেমপ্লেট ও লেআউট" : "Layouts"}</span>
            </button>

            <button
              onClick={() => setActiveTab("text")}
              className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === "text" ? "bg-amber-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              <Type size={14} />
              <span>{lang === "bn" ? "লেখা ও টাইপোগ্রাফি" : "Text & Fonts"}</span>
            </button>

            <button
              onClick={() => setActiveTab("colors")}
              className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === "colors" ? "bg-amber-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              <Palette size={14} />
              <span>{lang === "bn" ? "রং ও গ্রেডিয়েন্ট" : "Colors"}</span>
            </button>

            <button
              onClick={() => setActiveTab("graphics")}
              className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === "graphics" ? "bg-amber-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              <ImageIcon size={14} />
              <span>{lang === "bn" ? "ছবি ও আর্ট" : "Artwork"}</span>
            </button>

            <button
              onClick={() => setActiveTab("badges")}
              className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === "badges" ? "bg-amber-500 text-slate-950 shadow-md font-black" : "text-slate-400 hover:text-white"
              }`}
            >
              <Award size={14} />
              <span>{lang === "bn" ? "ব্যাজ ও ফ্রেম" : "Badges & Frames"}</span>
            </button>
          </div>

          {/* TAB 1: LAYOUT TEMPLATES */}
          {activeTab === "layout" && (
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <span className="text-xs font-black text-amber-400 uppercase tracking-wider block">
                {lang === "bn" ? "লেআউট টেমপ্লেট নির্বাচন করুন:" : "Choose Cover Layout Architecture:"}
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { id: "royal_gold", name: "Royal Gold & Ornate", desc: "ক্লাসিক স্বর্ণালী অলঙ্করণ ফ্রেম", icon: Crown },
                  { id: "classic_frame", name: "Classic Literature", desc: "মার্জিত মার্জিন ও বর্ডার", icon: BookOpen },
                  { id: "modern_minimal", name: "Modern Minimalist", desc: "পরিচ্ছন্ন ও আধুনিক ফোকাস", icon: Sparkles },
                  { id: "magazine_bold", name: "Magazine Impact", desc: "বোল্ড টাইপোগ্রাফি স্টাইল", icon: Flame },
                  { id: "cyber_neon", name: "Cyberpunk Matrix", desc: "ভবিষ্যতমুখী সাইবার গ্লো", icon: Star },
                  { id: "editorial_serif", name: "Editorial Prestige", desc: "উচ্চমানের সাহিত্যিক প্রকাশনা", icon: Shield }
                ].map((tmpl) => {
                  const Icon = tmpl.icon;
                  const isSelected = design.layoutTemplate === tmpl.id;
                  return (
                    <button
                      key={tmpl.id}
                      onClick={() => setDesign(prev => ({ ...prev, layoutTemplate: tmpl.id as any }))}
                      className={`p-3.5 rounded-2xl border text-left transition flex flex-col justify-between gap-2 cursor-pointer ${
                        isSelected 
                          ? "bg-amber-500/10 border-amber-500 text-white ring-2 ring-amber-500/20" 
                          : "bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <Icon size={18} className={isSelected ? "text-amber-400" : "text-slate-500"} />
                        {isSelected && <Check size={14} className="text-amber-400" />}
                      </div>
                      <div>
                        <span className="text-xs font-black block text-white">{tmpl.name}</span>
                        <span className="text-[10px] text-slate-400 mt-0.5 block">{tmpl.desc}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: TEXT & TYPOGRAPHY */}
          {activeTab === "text" && (
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block">
                    {lang === "bn" ? "বইয়ের মূল শিরোনাম (Book Title)" : "Book Title"}
                  </label>
                  <input
                    type="text"
                    value={design.title}
                    onChange={(e) => setDesign(prev => ({ ...prev, title: e.target.value }))}
                    className="w-full bg-[#05070f] border border-slate-800 p-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-bold"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-amber-300 uppercase tracking-wider block">
                    {lang === "bn" ? "লেখকের নাম (Author Name)" : "Author Name"}
                  </label>
                  <input
                    type="text"
                    value={design.authorName}
                    onChange={(e) => setDesign(prev => ({ ...prev, authorName: e.target.value }))}
                    className="w-full bg-[#05070f] border border-slate-800 p-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                    {lang === "bn" ? "উপশিরোনাম / সংক্ষিপ্ত ক্যাপশন (Subtitle)" : "Subtitle / Synopsis Line"}
                  </label>
                  <input
                    type="text"
                    value={design.subtitle}
                    onChange={(e) => setDesign(prev => ({ ...prev, subtitle: e.target.value }))}
                    className="w-full bg-[#05070f] border border-slate-800 p-2.5 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                    {lang === "bn" ? "জনরা / বিভাগ (Genre Tag)" : "Genre"}
                  </label>
                  <input
                    type="text"
                    value={design.genre}
                    onChange={(e) => setDesign(prev => ({ ...prev, genre: e.target.value }))}
                    className="w-full bg-[#05070f] border border-slate-800 p-2.5 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
                    {lang === "bn" ? "প্রকাশনা ট্যাগলাইন (Publisher Line)" : "Publisher"}
                  </label>
                  <input
                    type="text"
                    value={design.publisherText}
                    onChange={(e) => setDesign(prev => ({ ...prev, publisherText: e.target.value }))}
                    className="w-full bg-[#05070f] border border-slate-800 p-2.5 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Font Family Selection */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block">
                  {lang === "bn" ? "টাইপোগ্রাফি ফন্ট নির্বাচন:" : "Font Family Selection:"}
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: "serif", name: "Classic Serif", sample: "অমর কথা (সাহিত্যিক)" },
                    { id: "sans", name: "Clean Sans", sample: "Modern & Clean" },
                    { id: "display", name: "Bold Display", sample: "IMPACT BOLD" },
                    { id: "calligraphy", name: "Artistic Script", sample: "Graceful Poetry" }
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setDesign(prev => ({ ...prev, fontFamily: f.id as any }))}
                      className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                        design.fontFamily === f.id
                          ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold"
                          : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                      }`}
                    >
                      <span className="text-xs block font-bold">{f.name}</span>
                      <span className="text-[9px] text-slate-500 mt-0.5 block">{f.sample}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: COLORS & GRADIENTS */}
          {activeTab === "colors" && (
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <span className="text-xs font-black text-amber-400 uppercase tracking-wider block">
                {lang === "bn" ? "প্রিমিয়াম কালার প্যালেট নির্বাচন করুন:" : "Select Color Palette Preset:"}
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {COVER_COLOR_PRESETS.map((cp) => {
                  const isSelected = design.colorPreset === cp.name;
                  return (
                    <button
                      key={cp.name}
                      onClick={() => setDesign(prev => ({ ...prev, colorPreset: cp.name }))}
                      className={`p-2.5 rounded-xl border text-left transition flex items-center gap-2.5 cursor-pointer ${
                        isSelected ? "border-amber-400 ring-2 ring-amber-500/20" : "border-slate-800 hover:border-slate-700"
                      }`}
                      style={{ background: cp.gradient }}
                    >
                      <div className="w-5 h-5 rounded-full border border-white/40 shadow-sm shrink-0" style={{ background: cp.c2 }} />
                      <span className="text-xs font-bold text-white drop-shadow-md truncate">{cp.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: ARTWORK & IMAGES */}
          {activeTab === "graphics" && (
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-amber-400 uppercase tracking-wider">
                  {lang === "bn" ? "কভার ছবি ও ব্যাকগ্রাউন্ড আর্ট:" : "Cover Image & Art Overlay:"}
                </span>
                {design.imageUrl && (
                  <button
                    onClick={() => setDesign(prev => ({ ...prev, imageUrl: "" }))}
                    className="text-rose-400 hover:text-rose-300 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 size={13} />
                    <span>{lang === "bn" ? "ছবি মুছুন" : "Remove Image"}</span>
                  </button>
                )}
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="https://images.unsplash.com/photo-..."
                  value={design.imageUrl}
                  onChange={(e) => setDesign(prev => ({ ...prev, imageUrl: e.target.value }))}
                  className="flex-1 bg-[#05070f] border border-slate-800 p-2.5 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold rounded-xl transition flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Upload size={14} />
                  <span>{lang === "bn" ? "আপলোড" : "Upload"}</span>
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                />
              </div>

              {/* Opacity & Blur Sliders */}
              {design.imageUrl && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-300">
                      <span>{lang === "bn" ? "ছবির স্পষ্টতা (Opacity)" : "Cover Opacity"}</span>
                      <span className="text-amber-400">{Math.round(design.imageOpacity * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.1"
                      max="1"
                      step="0.05"
                      value={design.imageOpacity}
                      onChange={(e) => setDesign(prev => ({ ...prev, imageOpacity: parseFloat(e.target.value) }))}
                      className="w-full accent-amber-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-300">
                      <span>{lang === "bn" ? "ব্লার ইফেক্ট (Blur)" : "Backdrop Blur"}</span>
                      <span className="text-amber-400">{design.imageBlur}px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="8"
                      step="1"
                      value={design.imageBlur}
                      onChange={(e) => setDesign(prev => ({ ...prev, imageBlur: parseInt(e.target.value) }))}
                      className="w-full accent-amber-500"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: BADGES & EMBOSSED FRAMES */}
          {activeTab === "badges" && (
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <span className="text-xs font-black text-amber-400 uppercase tracking-wider block">
                {lang === "bn" ? "রয়্যাল ব্যাজ ও স্ট্যাম্প যুক্ত করুন:" : "Select Official Gold Badge:"}
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {[
                  { id: "none", name: "No Badge (None)" },
                  { id: "bestseller", name: "★ National Bestseller" },
                  { id: "award_winner", name: "🏆 Literary Award Winner" },
                  { id: "collector_edition", name: "👑 Collector's Edition" },
                  { id: "original_work", name: "✦ AI Masterpiece Original" }
                ].map((b) => (
                  <button
                    key={b.id}
                    onClick={() => setDesign(prev => ({ ...prev, badgeType: b.id as any }))}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      design.badgeType === b.id
                        ? "bg-amber-500/20 border-amber-500 text-amber-300 ring-2 ring-amber-500/20"
                        : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                    }`}
                  >
                    {b.name}
                  </button>
                ))}
              </div>

              {/* Borders */}
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <span className="text-xs font-black text-amber-400 uppercase tracking-wider block">
                  {lang === "bn" ? "ফ্রেম ও অলঙ্করণ বর্ডার:" : "Border Frame Style:"}
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: "none", name: "No Border" },
                    { id: "thin_gold", name: "Fine Gold Border" },
                    { id: "double_ornate", name: "Double Royal Frame" },
                    { id: "cyber_corners", name: "Cyber Corner Cuts" }
                  ].map((br) => (
                    <button
                      key={br.id}
                      onClick={() => setDesign(prev => ({ ...prev, borderStyle: br.id as any }))}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                        design.borderStyle === br.id
                          ? "bg-amber-500/20 border-amber-500 text-amber-300 ring-2 ring-amber-500/20"
                          : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"
                      }`}
                    >
                      {br.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Real-Time 3D/2D Book Cover Canvas Preview */}
        <div className="lg:col-span-5 flex flex-col items-center">
          
          <div className="text-center mb-2">
            <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest flex items-center justify-center gap-1">
              <Eye size={12} />
              <span>REAL-TIME BOOK COVER CANVAS</span>
            </span>
          </div>

          {/* Physical Book Cover Card */}
          <div
            ref={coverPreviewRef}
            className="w-full max-w-[340px] aspect-[1/1.5] rounded-2xl p-6 sm:p-7 relative overflow-hidden flex flex-col justify-between text-white shadow-2xl transition-all duration-300 select-none border border-amber-500/40"
            style={{ background: selectedPreset.gradient }}
          >
            {/* Background Cover Image */}
            {design.imageUrl && (
              <div 
                className="absolute inset-0 bg-cover bg-center transition-all duration-300 pointer-events-none"
                style={{
                  backgroundImage: `url(${design.imageUrl})`,
                  opacity: design.imageOpacity,
                  filter: `blur(${design.imageBlur}px)`
                }}
              />
            )}

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/20 pointer-events-none" />

            {/* Border Frames */}
            {design.borderStyle === "thin_gold" && (
              <div className="absolute inset-3.5 border border-amber-400/40 rounded-xl pointer-events-none" />
            )}
            {design.borderStyle === "double_ornate" && (
              <>
                <div className="absolute inset-3 border-2 border-amber-400/60 rounded-xl pointer-events-none" />
                <div className="absolute inset-4.5 border border-amber-300/30 rounded-lg pointer-events-none" />
              </>
            )}
            {design.borderStyle === "cyber_corners" && (
              <div className="absolute inset-3.5 border border-cyan-400/50 rounded-xl pointer-events-none">
                <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
                <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
                <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
                <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />
              </div>
            )}

            {/* TOP BAR: Genre & Royal Badge */}
            <div className="relative z-10 space-y-1.5 text-center">
              <span className="inline-block px-2.5 py-0.5 bg-black/50 backdrop-blur-md rounded-full text-[9px] font-mono font-bold tracking-widest text-amber-300 uppercase border border-amber-500/30 shadow-sm">
                ✦ {design.genre || "LITERATURE"} ✦
              </span>

              {design.badgeType !== "none" && (
                <div className="pt-1">
                  <span className="inline-flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 text-[10px] font-black uppercase rounded-full shadow-lg">
                    <Award size={12} />
                    <span>
                      {design.badgeType === "bestseller" && "National Bestseller"}
                      {design.badgeType === "award_winner" && "Literary Award Winner"}
                      {design.badgeType === "collector_edition" && "Collector's Edition"}
                      {design.badgeType === "original_work" && "AI Masterpiece"}
                    </span>
                  </span>
                </div>
              )}
            </div>

            {/* MIDDLE: Title, Subtitle, Ornaments */}
            <div className="relative z-10 text-center my-auto space-y-2 py-4">
              <div className="w-12 h-0.5 bg-amber-400/60 mx-auto rounded-full" />
              
              <h2
                className={`font-black text-white leading-tight drop-shadow-2xl px-2 ${
                  design.fontFamily === "serif" ? "font-serif" : design.fontFamily === "sans" ? "font-sans" : "font-mono"
                } ${
                  design.title.length > 25 ? "text-xl sm:text-2xl" : "text-2xl sm:text-3xl"
                }`}
              >
                {design.title}
              </h2>

              {design.subtitle && (
                <p className="text-[11px] text-amber-100/90 leading-relaxed font-serif italic max-w-[260px] mx-auto drop-shadow-md line-clamp-2">
                  "{design.subtitle}"
                </p>
              )}

              <div className="w-12 h-0.5 bg-amber-400/60 mx-auto rounded-full" />
            </div>

            {/* BOTTOM: Author & Publisher Line */}
            <div className="relative z-10 text-center space-y-1">
              <span className="text-[9px] text-amber-200/70 uppercase tracking-widest font-mono block">
                WRITTEN BY
              </span>
              <span className="text-sm font-black text-amber-300 drop-shadow-md block font-serif tracking-wide">
                {design.authorName}
              </span>
              <span className="text-[8px] text-slate-400 tracking-widest uppercase font-mono block pt-1">
                {design.publisherText}
              </span>
            </div>

          </div>

          {/* Quick Action Button below preview */}
          <div className="mt-4 flex gap-2">
            <button
              onClick={handleSaveToBook}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Check size={14} />
              <span>{lang === "bn" ? "এই কভারটি ব্যবহার করুন" : "Apply to Book"}</span>
            </button>
          </div>

        </div>

      </div>

      {/* Success Toast */}
      {isSavedToast && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 bg-emerald-600 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg"
        >
          <Check size={15} />
          <span>{lang === "bn" ? "✅ কভারটি সফলভাবে বইয়ে সংরক্ষণ করা হয়েছে!" : "✅ Cover applied and saved to your book!"}</span>
        </motion.div>
      )}

    </div>
  );
};
