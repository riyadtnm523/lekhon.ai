export interface BookPage {
  pageNumber: number;
  content: string;
  style?: {
    fontSize?: string; // e.g. "16px"
    textColor?: string; // e.g. "#ef4444"
    alignment?: "left" | "center" | "right" | "justify";
    animation?: "none" | "fade" | "glow" | "bounce" | "wave" | "wiggle" | "typing";
  };
}

export interface MediaAttachment {
  id: string;
  name: string;
  type: "image" | "video" | "document";
  url: string; // Base64 or standard asset link
  size?: string;
  uploadedAt: string;
}

export interface Chapter {
  chapterNumber: number;
  title: string;
  summary: string;
  estimatedPages: number;
  content?: string; // full markdown (legacy, or combined fallback)
  pages?: BookPage[]; // structured pages
  status: "idle" | "generating" | "completed" | "failed";
  aiNote?: string;
}

export interface Book {
  id: string;
  title: string;
  synopsis: string;
  genre: string;
  targetAudience: string;
  language: string;
  chapterCount: number;
  additionalInstructions?: string;
  customTone?: string;
  writingStyle?: string;
  suggestedCoverStyle?: string;
  coverColor?: string; // Gradient name or hex codes for cover rendering
  coverImageUrl?: string; // User custom uploaded image or link
  coverImageOpacity?: number; // Opacity of custom cover image (0.1 to 1.0)
  chapters: Chapter[];
  createdAt: string;
  updatedAt: string;
  
  // New social & storage features
  userId?: string;
  creatorEmail?: string;
  creatorName?: string;
  published?: boolean;
  publishedAt?: string;
  likes?: string[]; // array of user IDs who liked
  likesCount?: number;
  likedByNames?: { uid: string; name: string; email?: string; timestamp?: string }[];
  downloadsCount?: number;
  mediaAttachments?: MediaAttachment[];
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  photoURL?: string;
  bio?: string;
  isAdmin?: boolean;
  isDemo?: boolean;
  demoPassword?: string;
  followersCount?: number;
  followers?: string[]; // UIDs of users following this author
  following?: string[]; // UIDs of authors this user is following
  totalLikesReceived?: number;
  createdAt: string;
}
