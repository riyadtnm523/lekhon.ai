import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider,
  Auth
} from "firebase/auth";
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  addDoc,
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit,
  arrayUnion,
  arrayRemove,
  increment,
  Firestore
} from "firebase/firestore";

const firebaseConfig = {
  projectId: "plexiform-athlete-h07pf",
  appId: "1:715511437617:web:94dd4c2121895a9aeaf810",
  apiKey: "AIzaSyBmu3rKaC3wjNLe3fQR7JxAXDhqdK8102o",
  authDomain: "plexiform-athlete-h07pf.firebaseapp.com",
  storageBucket: "plexiform-athlete-h07pf.firebasestorage.app",
  messagingSenderId: "715511437617"
};

const app = initializeApp(firebaseConfig);

// Initialize Auth
export const auth: Auth = getAuth(app);

// Initialize Firestore with custom Database ID specified in firebase-applet-config.json
export const db: Firestore = getFirestore(app, "ai-studio-scribemindai-698510d7-c830-4ba9-bcbf-50138c6406de");

export {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  arrayUnion,
  arrayRemove,
  increment
};
