import React, { useState, useEffect, useRef } from "react";
import { 
  BookMarked,
  Languages, 
  Send,
  Sparkles,
  RefreshCw,
  Eye,
  EyeOff,
  Edit3,
  Printer,
  Download,
  FileText,
  BookOpen,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  FileDown,
  Trash2,
  HelpCircle,
  Sparkle,
  Sliders,
  Globe,
  User,
  Lock,
  Plus,
  PlusCircle,
  Search,
  Heart,
  Share2,
  LogOut,
  Cloud,
  FileUp,
  Video,
  Image,
  Check,
  CheckSquare,
  History,
  ShieldAlert,
  Zap,
  Database,
  Settings,
  Monitor,
  Smartphone,
  Copy,
  MessageSquare,
  Mic,
  Code2,
  Network,
  GitFork,
  Crown,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from "react-markdown";
import { Book, Chapter, BookPage, MediaAttachment } from "./types";
import { CodeSandboxBlock } from "./components/CodeSandboxBlock";
import { ReadingAnalyticsBar } from "./components/ReadingAnalyticsBar";
import { Interactive3DViewer } from "./components/Interactive3DViewer";
import { AnimatedCoverCanvas } from "./components/AnimatedCoverCanvas";
import { MediaInsertModal } from "./components/MediaInsertModal";
import { TTSAudioPlayer } from "./components/TTSAudioPlayer";
import { Animated3DProfileCard } from "./components/Animated3DProfileCard";
import { AIChatHub } from "./components/AIChatHub";
import { LiveVoiceBuddy } from "./components/LiveVoiceBuddy";
import { CodeStudioPlayground } from "./components/CodeStudioPlayground";
import { NarrativeMindMatrix } from "./components/NarrativeMindMatrix";
import { AutonomousVoiceCoPilot } from "./components/AutonomousVoiceCoPilot";
import { ProVoiceAssistant } from "./components/ProVoiceAssistant";
import { CodePreviewBoard } from "./components/CodePreviewBoard";
import { ChapterCodePreviewBoard } from "./components/ChapterCodePreviewBoard";
import { LearningChartStudio } from "./components/LearningChartStudio";
import { AdminMasterControl, SiteDesignConfig } from "./components/AdminMasterControl";
import { PublicAuthorProfileModal, AuthorProfileData } from "./components/PublicAuthorProfileModal";
import { LiveDynamicExecutableSandbox } from "./components/LiveDynamicExecutableSandbox";
import { CoverPageStudio } from "./components/CoverPageStudio";
import { PremiumStoreModal } from "./components/PremiumStoreModal";
import { downloadBookAsA4HTML } from "./utils/bookExporter";
import { 
  auth, 
  db, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  arrayUnion,
  arrayRemove,
  increment
} from "./firebase";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  attachment?: MediaAttachment;
}


const COVER_GRADIENTS = [
  { css: "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)", label: "Midnight Slate" },
  { css: "linear-gradient(135deg, #064e3b 0%, #022c22 100%)", label: "Emerald Deep" },
  { css: "linear-gradient(135deg, #1e1b4b 0%, #311042 100%)", label: "Royal Amethyst" },
  { css: "linear-gradient(135deg, #450a0a 0%, #1c0505 100%)", label: "Crimson Hearth" },
  { css: "linear-gradient(135deg, #7c2d12 0%, #2a0800 100%)", label: "Sienna Amber" },
  { css: "linear-gradient(135deg, #0f172a 0%, #172554 100%)", label: "Deep Cosmic" }
];

const loadingQuotes = [
  { text: "“বই হলো এমন এক মাধ্যম যা আমাদের অন্য জগতে নিয়ে যায়।”", author: "বাংলা প্রবাদ" },
  { text: "“A room without books is like a body without a soul.”", author: "Marcus Tullius Cicero" },
  { text: "“লেখার মূল রহস্য হলো শুরু করা।”", author: "মার্ক টোয়েন" },
  { text: "“There is no greater agony than bearing an untold story inside you.”", author: "Maya Angelou" },
  { text: "“কোডিং হলো কম্পিউটারের জন্য বই লেখার মতো, যেখানে প্রতিটি লাইন একটি গল্প।”", author: "Lekhok AI" }
];

// Split chapter content into virtual pages
export function paginateChapterContent(content: string = ""): string[] {
  if (!content) return [""];
  if (content.includes("<!-- PAGE_BREAK -->")) {
    return content.split("<!-- PAGE_BREAK -->").map(p => p.trim());
  }
  
  // Dynamic paginate based on characters (~2000 characters per page)
  const paragraphs = content.split("\n\n");
  const pages: string[] = [];
  let currentPage: string[] = [];
  let currentLen = 0;
  
  for (const para of paragraphs) {
    if (currentLen + para.length > 2000 && currentPage.length > 0) {
      pages.push(currentPage.join("\n\n"));
      currentPage = [para];
      currentLen = para.length;
    } else {
      currentPage.push(para);
      currentLen += para.length + 2; // account for newlines
    }
  }
  if (currentPage.length > 0) {
    pages.push(currentPage.join("\n\n"));
  }
  return pages.length > 0 ? pages : [""];
}

// Regex based parser for beautiful sentence customization, coloring and text effects
export function parseTextWithCustomTags(text: string): React.ReactNode {
  if (typeof text !== "string") return text;

  // Check for 3D tag: [3d:earth], [3d:solar_system], [3d:galaxy], [3d:cube], [3d:dna], [3d:molecule]
  const tag3dRegex = /\[3d:([a-zA-Z0-9_\-]+)\]|\{3d:([a-zA-Z0-9_\-]+)\}/gi;
  if (tag3dRegex.test(text)) {
    const segments = text.split(/(\[3d:[a-zA-Z0-9_\-]+\]|\{3d:[a-zA-Z0-9_\-]+\})/gi);
    return (
      <React.Fragment>
        {segments.map((seg, i) => {
          const m = /\[3d:([a-zA-Z0-9_\-]+)\]|\{3d:([a-zA-Z0-9_\-]+)\}/i.exec(seg);
          if (m) {
            const modelName = m[1] || m[2];
            return (
              <div key={`3d-${i}`} className="my-6">
                <Interactive3DViewer type={modelName} />
              </div>
            );
          }
          return <React.Fragment key={i}>{parseTextWithCustomTags(seg)}</React.Fragment>;
        })}
      </React.Fragment>
    );
  }

  // Check for Video tag: [video:URL] or {video:URL}
  const tagVideoRegex = /\[video:([^\]]+)\]|\{video:([^}]+)\}/gi;
  if (tagVideoRegex.test(text)) {
    const segments = text.split(/(\[video:[^\]]+\]|\{video:[^}]+\})/gi);
    return (
      <React.Fragment>
        {segments.map((seg, i) => {
          const m = /\[video:([^\]]+)\]|\{video:([^}]+)\}/i.exec(seg);
          if (m) {
            const vUrl = (m[1] || m[2]).trim();
            if (!vUrl) return null;
            const isYT = vUrl.includes("youtube.com") || vUrl.includes("youtu.be");
            let ytId = "";
            if (isYT) {
              const ytMatch = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/.exec(vUrl);
              ytId = ytMatch ? ytMatch[1] : "";
            }

            return (
              <div key={`video-${i}`} className="my-6 rounded-2xl overflow-hidden border-4 border-[#eae3d2] shadow-md bg-black">
                {isYT && ytId ? (
                  <iframe
                    src={`https://www.youtube.com/embed/${ytId}`}
                    title="Video Player"
                    className="w-full aspect-video border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : vUrl ? (
                  <video src={vUrl} controls className="w-full max-h-[380px] bg-black" />
                ) : null}
              </div>
            );
          }
          return <React.Fragment key={i}>{parseTextWithCustomTags(seg)}</React.Fragment>;
        })}
      </React.Fragment>
    );
  }
  
  if (!text.includes("{")) return text;
  
  // Regex to match: {color:red}text{/color}, {size:20px}text{/size}, {anim:bounce}text{/anim}, {bg:yellow}text{/bg}, {align:center}text{/align}, {badge:gold}text{/badge}, {box:glow}text{/box}
  const tagRegex = /\{(\w+):([^}]+)\}([\s\S]*?)\{\/\1\}/g;
  
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  let match;
  
  while ((match = tagRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.substring(lastIndex, match.index));
    }
    
    const [_, tagName, tagVal, content] = match;
    const key = `styled-${match.index}-${lastIndex}`;
    const parsedContent = parseTextWithCustomTags(content);
    
    if (tagName === "color") {
      parts.push(<span key={key} style={{ color: tagVal }}>{parsedContent}</span>);
    } else if (tagName === "size") {
      parts.push(<span key={key} style={{ fontSize: tagVal }}>{parsedContent}</span>);
    } else if (tagName === "bg") {
      const isHex = tagVal.startsWith("#");
      parts.push(
        <span 
          key={key} 
          className={isHex ? "" : `highlight-${tagVal}`} 
          style={isHex ? { backgroundColor: tagVal, padding: "2px 4px", borderRadius: "4px" } : {}}
        >
          {parsedContent}
        </span>
      );
    } else if (tagName === "anim") {
      if (tagVal === "rainbow") {
        parts.push(
          <span key={key} className="bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-500 bg-clip-text text-transparent font-extrabold animate-pulse">
            {parsedContent}
          </span>
        );
      } else {
        parts.push(<span key={key} className={`anim-${tagVal}`}>{parsedContent}</span>);
      }
    } else if (tagName === "badge") {
      parts.push(
        <span key={key} className="inline-flex items-center gap-1 px-2.5 py-0.5 my-0.5 rounded-full text-xs font-black bg-amber-100 text-[#7c2d12] border border-amber-300 shadow-xs font-sans">
          <span>{parsedContent}</span>
        </span>
      );
    } else if (tagName === "box") {
      parts.push(
        <div key={key} className="my-4 p-4 rounded-2xl bg-amber-50/80 border-2 border-amber-200/80 shadow-sm font-sans">
          {parsedContent}
        </div>
      );
    } else if (tagName === "align") {
      parts.push(<div key={key} className={`text-${tagVal}`} style={{ textAlign: tagVal as any }}>{parsedContent}</div>);
    } else if (tagName === "font") {
      parts.push(<span key={key} style={{ fontFamily: tagVal }}>{parsedContent}</span>);
    } else {
      parts.push(match[0]);
    }
    
    lastIndex = tagRegex.lastIndex;
  }
  
  if (lastIndex < text.length) {
    parts.push(text.substring(lastIndex));
  }
  
  return parts.length > 0 ? <React.Fragment>{parts}</React.Fragment> : text;
}

// Highlight Code keywords for colored syntax highlighting safely using React elements
function highlightCode(codeStr: string, language: string = ""): React.ReactNode {
  if (!codeStr) return null;
  const lang = (language || "").toLowerCase();

  // 1. HTML / XML / SVG Syntax Tokenizer
  if (lang === "html" || lang === "xml" || lang === "htm" || lang === "svg") {
    const tokens: React.ReactNode[] = [];
    let key = 0;
    const tagRegex = /(<!--[\s\S]*?-->)|(<!DOCTYPE[\s\S]*?>)|(<\/?[a-zA-Z0-9\-:]+)((?:[^>'"]|"[^"]*"|'[^']*')*)(\/?>)/gi;
    let lastIdx = 0;
    let match: RegExpExecArray | null;

    while ((match = tagRegex.exec(codeStr)) !== null) {
      if (match.index > lastIdx) {
        tokens.push(<span key={key++} className="text-slate-200">{codeStr.slice(lastIdx, match.index)}</span>);
      }

      if (match[1]) {
        // Comment
        tokens.push(<span key={key++} className="text-slate-500 italic">{match[1]}</span>);
      } else if (match[2]) {
        // DOCTYPE
        tokens.push(<span key={key++} className="text-amber-400 font-bold">{match[2]}</span>);
      } else if (match[3]) {
        // Opening / closing tag name
        const fullTagHead = match[3];
        const isClosing = fullTagHead.startsWith("</");
        const tagName = isClosing ? fullTagHead.slice(2) : fullTagHead.slice(1);

        tokens.push(<span key={key++} className="text-sky-400">&lt;{isClosing ? "/" : ""}</span>);
        tokens.push(<span key={key++} className="text-indigo-400 font-bold">{tagName}</span>);

        // Tag attributes
        const attrStr = match[4] || "";
        if (attrStr) {
          const attrRegex = /(\s+)([a-zA-Z0-9\-:]+)(?:(=)(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
          let attrMatch: RegExpExecArray | null;
          let lastAttrIdx = 0;
          while ((attrMatch = attrRegex.exec(attrStr)) !== null) {
            if (attrMatch.index > lastAttrIdx) {
              tokens.push(attrStr.slice(lastAttrIdx, attrMatch.index));
            }
            tokens.push(attrMatch[1]); // space
            tokens.push(<span key={key++} className="text-amber-300">{attrMatch[2]}</span>); // attribute name
            if (attrMatch[3]) {
              tokens.push(<span key={key++} className="text-slate-400">=</span>);
              const quote = attrMatch[4] !== undefined ? '"' : attrMatch[5] !== undefined ? "'" : "";
              const val = attrMatch[4] ?? attrMatch[5] ?? attrMatch[6] ?? "";
              tokens.push(<span key={key++} className="text-emerald-400">{quote}{val}{quote}</span>);
            }
            lastAttrIdx = attrRegex.lastIndex;
          }
          if (lastAttrIdx < attrStr.length) {
            tokens.push(attrStr.slice(lastAttrIdx));
          }
        }

        tokens.push(<span key={key++} className="text-sky-400">{match[5]}</span>);
      }
      lastIdx = tagRegex.lastIndex;
    }

    if (lastIdx < codeStr.length) {
      tokens.push(<span key={key++} className="text-slate-200">{codeStr.slice(lastIdx)}</span>);
    }

    return <>{tokens.length > 0 ? tokens : codeStr}</>;
  }

  // 2. JavaScript / TypeScript / Python / CSS / General Code Tokenizer
  const isJs = ["js", "javascript", "ts", "typescript", "json", "jsx", "tsx"].includes(lang);
  const isPy = ["python", "py"].includes(lang);
  const jsKeywords = new Set(["const", "let", "var", "function", "return", "import", "export", "from", "default", "class", "extends", "if", "else", "for", "while", "try", "catch", "async", "await", "new", "throw", "switch", "case", "break", "typeof", "instanceof", "yield", "null", "undefined", "true", "false"]);
  const pyKeywords = new Set(["def", "class", "return", "import", "from", "as", "if", "elif", "else", "for", "while", "in", "try", "except", "finally", "with", "lambda", "and", "or", "not", "is", "None", "True", "False", "pass", "break", "continue", "yield", "async", "await"]);

  const lines = codeStr.split("\n");
  let key = 0;

  return (
    <>
      {lines.map((line, lIdx) => {
        if (line.trim().startsWith("//") || line.trim().startsWith("#")) {
          return <div key={lIdx} className="text-slate-500 italic">{line}</div>;
        }

        const lineTokens: React.ReactNode[] = [];
        let cur = 0;
        const lineRegex = /(["'`])(?:\\.|[^\\])*?\1|(\/\/[^\n]*|#[^\n]*)|(\b\d+(?:\.\d+)?\b)|(\b[a-zA-Z_$][a-zA-Z0-9_$]*\b)/g;
        let match: RegExpExecArray | null;

        while ((match = lineRegex.exec(line)) !== null) {
          if (match.index > cur) {
            lineTokens.push(line.slice(cur, match.index));
          }
          const text = match[0];
          if (text.startsWith('"') || text.startsWith("'") || text.startsWith("`")) {
            lineTokens.push(<span key={key++} className="text-emerald-400">{text}</span>);
          } else if (text.startsWith("//") || text.startsWith("#")) {
            lineTokens.push(<span key={key++} className="text-slate-500 italic">{text}</span>);
          } else if (/^\d+/.test(text)) {
            lineTokens.push(<span key={key++} className="text-amber-400">{text}</span>);
          } else if (isJs && jsKeywords.has(text)) {
            lineTokens.push(<span key={key++} className="text-indigo-400 font-bold">{text}</span>);
          } else if (isPy && pyKeywords.has(text)) {
            lineTokens.push(<span key={key++} className="text-indigo-400 font-bold">{text}</span>);
          } else {
            lineTokens.push(text);
          }
          cur = lineRegex.lastIndex;
        }

        if (cur < line.length) {
          lineTokens.push(line.slice(cur));
        }

        return (
          <div key={lIdx} className="min-h-[1.25em]">
            {lineTokens.length > 0 ? lineTokens : (line || " ")}
          </div>
        );
      })}
    </>
  );
}

// Standard code snippet for books (clean syntax highlighting, copy)
const BookCodeSnippet: React.FC<{ code: string; language: string }> = ({ code, language }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-4 rounded-xl overflow-hidden border border-slate-700/60 bg-[#121824] shadow-md font-mono text-xs text-left not-italic">
      <div className="flex items-center justify-between px-3.5 py-2 bg-[#0c1017] border-b border-slate-800 text-[11px] text-slate-400 select-none">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
          </div>
          <span className="font-bold text-slate-300 uppercase tracking-wider text-[10px] ml-1">
            {language || "code"}
          </span>
        </div>
        <button
          onClick={handleCopy}
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-sans font-bold flex items-center gap-1 transition cursor-pointer"
        >
          {copied ? (
            <>
              <span className="text-emerald-400 font-bold">✓</span>
              <span>কপি হয়েছে</span>
            </>
          ) : (
            <>
              <span>📋</span>
              <span>কপি</span>
            </>
          )}
        </button>
      </div>
      <div className="p-4 overflow-x-auto text-slate-100 font-mono text-xs leading-relaxed">
        <pre className="whitespace-pre">{highlightCode(code, language)}</pre>
      </div>
    </div>
  );
};

// Markdown Custom Rendering components mapping
const markdownComponents: any = {
  blockquote: ({ children }: any) => {
    const textContent = React.Children.toArray(children)
      .map((c: any) => {
        if (typeof c === 'string') return c;
        if (c?.props?.children) {
          if (typeof c.props.children === 'string') return c.props.children;
          if (Array.isArray(c.props.children)) return c.props.children.join('');
        }
        return '';
      })
      .join('');

    const hasTip = textContent.includes("💡") || textContent.includes("tip");
    const hasWarn = textContent.includes("⚠️") || textContent.includes("warn");
    const hasInfo = textContent.includes("📘") || textContent.includes("info");
    const hasSuccess = textContent.includes("🟢") || textContent.includes("success") || textContent.includes("💚");

    if (hasTip) {
      return (
        <div className="my-5 p-4 rounded-xl border-l-4 border-amber-500 bg-amber-50/70 text-amber-950 text-[11px] shadow-xs font-sans">
          <div className="font-bold flex items-center gap-1.5 text-amber-800 mb-1">
            <span>💡</span> Tips & Insight / বিশেষ পরামর্শ
          </div>
          <div className="leading-relaxed text-slate-800 italic">{children}</div>
        </div>
      );
    }
    if (hasWarn) {
      return (
        <div className="my-5 p-4 rounded-xl border-l-4 border-rose-500 bg-rose-50/70 text-rose-950 text-[11px] shadow-xs font-sans">
          <div className="font-bold flex items-center gap-1.5 text-rose-800 mb-1">
            <span>⚠️</span> Warning & Alert / সতর্কতা
          </div>
          <div className="leading-relaxed text-slate-800 font-medium">{children}</div>
        </div>
      );
    }
    if (hasInfo) {
      return (
        <div className="my-5 p-4 rounded-xl border-l-4 border-blue-500 bg-blue-50/70 text-blue-950 text-[11px] shadow-xs font-sans">
          <div className="font-bold flex items-center gap-1.5 text-blue-800 mb-1">
            <span>📘</span> Information Note / গুরুত্বপূর্ণ তথ্য
          </div>
          <div className="leading-relaxed text-slate-800">{children}</div>
        </div>
      );
    }
    if (hasSuccess) {
      return (
        <div className="my-5 p-4 rounded-xl border-l-4 border-emerald-500 bg-emerald-50/70 text-emerald-950 text-[11px] shadow-xs font-sans">
          <div className="font-bold flex items-center gap-1.5 text-emerald-800 mb-1">
            <span>🟢</span> Key Takeaway / সিদ্ধান্ত
          </div>
          <div className="leading-relaxed text-slate-800">{children}</div>
        </div>
      );
    }

    return (
      <blockquote className="border-l-4 border-amber-800/40 pl-4 py-1 my-4 italic text-slate-600 bg-amber-50/10 rounded-r-md text-[11px]">
        {children}
      </blockquote>
    );
  },

  pre: ({ children }: any) => {
    return <div className="my-2">{children}</div>;
  },

  code: ({ inline, className, children, ...props }: any) => {
    const match = /language-(\w+)/.exec(className || "");
    const lang = (match ? match[1] : "").toLowerCase();
    
    // Safely extract text content without turning node objects into [object Object]
    const extractText = (node: any): string => {
      if (node === null || node === undefined) return "";
      if (typeof node === "string" || typeof node === "number") return String(node);
      if (Array.isArray(node)) return node.map(extractText).join("");
      if (typeof node === "object" && node.props?.children !== undefined) {
        return extractText(node.props.children);
      }
      return "";
    };

    const rawCode = extractText(children).replace(/\n$/, "");

    // 3D block support
    if (lang === "3d" || lang === "threejs" || lang === "three") {
      return (
        <div className="my-6">
          <Interactive3DViewer type={rawCode.trim() || "earth"} />
        </div>
      );
    }

    const isExplicitBlock = Boolean(match) || (rawCode && rawCode.includes("\n"));

    if (isExplicitBlock) {
      return (
        <BookCodeSnippet code={rawCode} language={lang || "code"} />
      );
    }

    return (
      <code className="text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-slate-800/80 px-1.5 py-0.5 rounded font-mono text-[12px] font-semibold inline mx-0.5 align-baseline" {...props}>
        {rawCode || children}
      </code>
    );
  },

  p: ({ children }: any) => {
    const parseParagraphContent = (node: any): any => {
      if (typeof node === "string") {
        return parseTextWithCustomTags(node);
      }
      if (Array.isArray(node)) {
        return node.map((n, i) => (
          <React.Fragment key={i}>
            {parseParagraphContent(n)}
          </React.Fragment>
        ));
      }
      return node;
    };
    return <div className="leading-relaxed mb-4 text-justify">{parseParagraphContent(children)}</div>;
  },

  img: ({ src, alt, ...props }: any) => {
    if (!src || typeof src !== "string" || src.trim() === "") {
      return null;
    }
    const isVideo = (src && src.startsWith("data:video/")) || (alt && alt.toLowerCase().startsWith("video:"));
    const isDoc = (src && src.startsWith("data:application/")) || (alt && alt.toLowerCase().startsWith("document:"));

    if (isVideo) {
      return (
        <span className="block my-6 text-center select-none font-sans">
          <span className="inline-block w-full max-w-lg rounded-2xl border-4 border-[#eae3d2] bg-white p-2.5 shadow-md">
            <span className="block text-xs font-bold text-slate-700 mb-2 flex items-center justify-center gap-1.5">
              📹 Video: {alt ? alt.replace(/^video:\s*/i, "") : "Attachment"}
            </span>
            <video src={src} controls className="w-full rounded-xl border border-slate-200 max-h-[300px]" />
          </span>
        </span>
      );
    }

    if (isDoc) {
      const fileName = alt ? alt.replace(/^document:\s*/i, "") : "Document.pdf";
      return (
        <span className="block my-6 select-none font-sans">
          <span className="flex items-center justify-between gap-4 w-full max-w-md mx-auto rounded-2xl border-2 border-dashed border-[#7c2d12]/30 bg-amber-50/40 p-4 shadow-xs">
            <span className="flex items-center gap-3">
              <span className="p-2.5 bg-[#7c2d12] text-amber-50 rounded-xl font-bold text-sm">📄</span>
              <span className="text-left">
                <span className="block text-xs font-extrabold text-slate-800 line-clamp-1">{fileName}</span>
                <span className="block text-[9px] text-slate-400 font-bold uppercase tracking-wider">Resource File</span>
              </span>
            </span>
            <a
              href={src}
              download={fileName}
              className="px-3.5 py-1.5 bg-[#7c2d12] hover:bg-[#63220c] text-amber-50 rounded-lg text-[10px] font-extrabold shadow-sm transition"
            >
              Download
            </a>
          </span>
        </span>
      );
    }

    return (
      <span className="block my-6 text-center select-none font-sans">
        <span className="inline-block max-w-full rounded-2xl border-4 border-[#eae3d2] bg-white p-2.5 shadow-md hover:shadow-lg transition duration-300">
          <img 
            src={src} 
            alt={alt || "Illustration"} 
            referrerPolicy="no-referrer"
            className="rounded-xl max-h-[380px] w-auto max-w-full object-cover" 
            {...props} 
          />
          {alt && (
            <span className="block text-[11px] text-slate-500 mt-2 font-medium italic">
              📸 {alt}
            </span>
          )}
        </span>
      </span>
    );
  }
};

export default function App() {
  const [lang, setLang] = useState<"bn" | "en">("bn");
  const [hasApiKey, setHasApiKey] = useState<boolean | null>(null);

  // Firebase Auth states
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [authError, setAuthError] = useState("");

  // Demo Account & Profile Proof States
  const [authTab, setAuthTab] = useState<"standard" | "demo_register" | "demo_login">("standard");
  const [demoName, setDemoName] = useState("");
  const [demoUsername, setDemoUsername] = useState("");
  const [demoPassword, setDemoPassword] = useState("");
  const [showDemoPassInModal, setShowDemoPassInModal] = useState(false);
  const [showProfilePassProof, setShowProfilePassProof] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Profile Bio and Display Name Editing
  const [userBio, setUserBio] = useState("");
  const [userDisplayNameInput, setUserDisplayNameInput] = useState("");
  const [isEditingProfileName, setIsEditingProfileName] = useState(false);

  // Social Filter & Likes
  const [socialFilter, setSocialFilter] = useState<"all" | "popular" | "latest">("all");

  // Navigation and Modes
  const [activeMainTab, setActiveMainTab] = useState<"editor" | "social" | "ai_chat" | "voice_buddy" | "pro_voice" | "code_board" | "code_studio" | "mind_matrix" | "learning_chart" | "admin" | "history" | "settings">("editor");
  const [isDesktopMode, setIsDesktopMode] = useState<boolean>(false);
  const [selectedAuthorProfile, setSelectedAuthorProfile] = useState<AuthorProfileData | null>(null);

  // Chat file attachments
  const [chatAttachment, setChatAttachment] = useState<MediaAttachment | null>(null);
  const chatFileInputRef = useRef<HTMLInputElement | null>(null);

  // User books history
  const [userBooks, setUserBooks] = useState<Book[]>([]);
  const [isFetchingHistory, setIsFetchingHistory] = useState(false);

  // Translation states
  const [isTranslating, setIsTranslating] = useState(false);
  const [showTranslateModal, setShowTranslateModal] = useState(false);
  const [selectedTranslateLanguage, setSelectedTranslateLanguage] = useState("English");

  // Admin section
  const [adminPasswordInput, setAdminPasswordInput] = useState("");
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [adminError, setAdminError] = useState("");
  const [adminBooks, setAdminBooks] = useState<Book[]>([]);

  // Master Site Design and Customizer Config State
  const [siteConfig, setSiteConfig] = useState<SiteDesignConfig>(() => {
    const saved = localStorage.getItem("lekhok_site_design_config");
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      appTitle: "লেখক AI",
      tagline: "আপনার ব্যক্তিগত বই লেখার এআই সহকারী",
      announcementText: "🎉 নতুন সুপার এআই ভয়েস ও ৩ডি বই কভার উন্মোচিত হয়েছে!",
      announcementActive: true,
      announcementBg: "from-amber-600 to-[#7c2d12]",
      primaryTheme: "amber",
      enabledTabs: {
        editor: true,
        ai_chat: true,
        voice_buddy: true,
        code_studio: true,
        mind_matrix: true,
        social: true,
        history: true
      },
      maintenanceMode: false,
      footerNote: "Lekhok AI Publications • Powered by Lekhok Neural Engine",
      customWidgets: []
    };
  });

  const [isCoverStudioOpen, setIsCoverStudioOpen] = useState(false);
  const [isPremiumStoreOpen, setIsPremiumStoreOpen] = useState(false);

  // Master Live Dynamic CSS & JS Injector (Managed by Admin AI Code Architect)
  useEffect(() => {
    if (siteConfig.customCss) {
      let styleTag = document.getElementById("lekhok-custom-live-css");
      if (!styleTag) {
        styleTag = document.createElement("style");
        styleTag.id = "lekhok-custom-live-css";
        document.head.appendChild(styleTag);
      }
      styleTag.textContent = siteConfig.customCss;
    }
  }, [siteConfig.customCss]);

  useEffect(() => {
    if (siteConfig.customJs) {
      try {
        const scriptFn = new Function(siteConfig.customJs);
        scriptFn();
      } catch (err) {
        console.warn("Custom runtime script warning:", err);
      }
    }
  }, [siteConfig.customJs]);

  const handleUpdateSiteConfig = (newConfig: SiteDesignConfig) => {
    setSiteConfig(newConfig);
    try {
      localStorage.setItem("lekhok_site_design_config", JSON.stringify(newConfig));
    } catch (e) {}
  };

  // API provider & keys states
  const [selectedProvider, setSelectedProvider] = useState<"gemini" | "deepseek">(() => {
    return (localStorage.getItem("lekhok_provider") as "gemini" | "deepseek") || "gemini";
  });
  const [geminiApiKey, setGeminiApiKey] = useState<string>(() => {
    return localStorage.getItem("lekhok_api_key_gemini") || "";
  });
  const [deepseekApiKey, setDeepseekApiKey] = useState<string>(() => {
    return localStorage.getItem("lekhok_api_key_deepseek") || "";
  });
  const [tempGeminiKey, setTempGeminiKey] = useState(() => {
    return localStorage.getItem("lekhok_api_key_gemini") || "";
  });
  const [tempDeepseekKey, setTempDeepseekKey] = useState(() => {
    return localStorage.getItem("lekhok_api_key_deepseek") || "";
  });
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [showDeepseekKey, setShowDeepseekKey] = useState(false);

  // Chat input voice dictation
  const [isChatDictating, setIsChatDictating] = useState(false);
  const chatDictationRef = useRef<any>(null);

  const toggleChatDictation = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert(lang === "bn" ? "ভয়েস ডিকটেশন ক্রোম ব্রাউজারে সাপোর্ট করে।" : "Voice dictation is supported in Chrome.");
      return;
    }

    if (isChatDictating) {
      if (chatDictationRef.current) {
        try { chatDictationRef.current.stop(); } catch (e) {}
      }
      setIsChatDictating(false);
    } else {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = lang === "bn" ? "bn-BD" : "en-US";

      recognition.onstart = () => setIsChatDictating(true);
      recognition.onresult = (event: any) => {
        let text = "";
        for (let i = 0; i < event.results.length; i++) {
          text += event.results[i][0].transcript;
        }
        if (text) {
          setUserChatPrompt(prev => (prev ? prev + " " + text : text));
        }
      };
      recognition.onerror = () => setIsChatDictating(false);
      recognition.onend = () => setIsChatDictating(false);

      chatDictationRef.current = recognition;
      try {
        recognition.start();
      } catch (e) {
        setIsChatDictating(false);
      }
    }
  };

  const getAIHeaders = () => {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      "x-model-provider": selectedProvider
    };
    if (geminiApiKey) {
      headers["x-api-key-gemini"] = geminiApiKey;
    }
    if (deepseekApiKey) {
      headers["x-api-key-deepseek"] = deepseekApiKey;
    }
    return headers;
  };

  // Social feed states
  const [publishedBooks, setPublishedBooks] = useState<Book[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSocialBook, setSelectedSocialBook] = useState<Book | null>(null);
  const [socialBookChapterIndex, setSocialBookChapterIndex] = useState<number>(0);
  const [socialBookPageIndex, setSocialBookPageIndex] = useState<number>(0);
  const [socialReaderTheme, setSocialReaderTheme] = useState<"light" | "warm" | "night">("warm");
  const [socialReaderFontSize, setSocialReaderFontSize] = useState<number>(17);
  const [socialSwipeNotice, setSocialSwipeNotice] = useState<string | null>(null);
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);

  // Auto-save indicator
  const [isSyncingWithDb, setIsSyncingWithDb] = useState(false);

  // Custom rich sentence styles
  const [selectedTextColor, setSelectedTextColor] = useState("#000000");
  const [selectedFontSize, setSelectedFontSize] = useState("16px");
  const [selectedTextAnimation, setSelectedTextAnimation] = useState("none");
  const [selectedTextHighlight, setSelectedTextHighlight] = useState("none");

  // Extensive/Deep Writing Speed Mode states
  const [writingSpeedMode, setWritingSpeedMode] = useState<"standard" | "extensive">("standard");
  const [extensiveProgress, setExtensiveProgress] = useState(0);
  const [extensiveStepText, setExtensiveStepText] = useState("");

  // Media vaults attachments
  const [mediaVault, setMediaVault] = useState<MediaAttachment[]>([]);
  const [isUploadingMedia, setIsUploadingMedia] = useState(false);

  // User Writing Preferences & Subject settings
  const [preferredTone, setPreferredTone] = useState<string>("Professional & Educational");
  const [preferredStyle, setPreferredStyle] = useState<string>("Detailed prose tailored precisely to book genre");
  const [preferredLength, setPreferredLength] = useState<"short" | "detailed" | "epic">("detailed");
  const [preferredLanguage, setPreferredLanguage] = useState<string>("Bengali");
  const [preferredSubject, setPreferredSubject] = useState<string>("All Genres / যেকোনো বিষয়");

  // Chapter generation states
  const [isGeneratingChapter, setIsGeneratingChapter] = useState<boolean>(false);
  const [generatingChapterNumber, setGeneratingChapterNumber] = useState<number | null>(null);
  const [autoWriteSequence, setAutoWriteSequence] = useState<boolean>(false);

  // Batch Auto-Writing States
  const [isBatchWriting, setIsBatchWriting] = useState(false);
  const [batchProgress, setBatchProgress] = useState(0);
  const [batchStatusText, setBatchStatusText] = useState("");
  const isBatchCancelledRef = useRef(false);

  // Chat Custom Background State (Image or Video)
  const [chatBgType, setChatBgType] = useState<"none" | "image" | "video">(() => {
    return (localStorage.getItem("scribemind_chat_bg_type") as any) || "none";
  });
  const [chatBgUrl, setChatBgUrl] = useState<string>(() => {
    return localStorage.getItem("scribemind_chat_bg_url") || "";
  });
  const [chatBgOpacity, setChatBgOpacity] = useState<number>(() => {
    const saved = localStorage.getItem("scribemind_chat_bg_opacity");
    return saved ? parseFloat(saved) : 0.25;
  });
  const [isChatBgModalOpen, setIsChatBgModalOpen] = useState(false);

  // Media Insert Modal State
  const [isMediaInsertModalOpen, setIsMediaInsertModalOpen] = useState(false);

  // Page tracking pagination inside active chapter
  const [activePageIndex, setActivePageIndex] = useState(0);
  
  // Conversational states
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [userChatPrompt, setUserChatPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [loadingQuoteIndex, setLoadingQuoteIndex] = useState(0);

  // Active book state
  const [currentBook, setCurrentBook] = useState<Book | null>(null);
  
  // UI Panel configurations
  const [activeChapterIndex, setActiveChapterIndex] = useState<number>(0);
  const [previewTab, setPreviewTab] = useState<"cover" | "synopsis" | "chapters">("cover");
  const [editorMode, setEditorMode] = useState<"read" | "edit">("read");

  // Advanced PDF Printing & Page Configurations
  const [pageSize, setPageSize] = useState<"A4" | "LETTER" | "A5">("A4");
  const [printMargin, setPrintMargin] = useState<"normal" | "narrow" | "wide">("normal");
  const [showPageNumbers, setShowPageNumbers] = useState(true);
  const [printFontSize, setPrintFontSize] = useState<"sm" | "md" | "lg">("md");
  const [isPrintSettingsOpen, setIsPrintSettingsOpen] = useState(false);

  const chatBottomRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Restore cached active book and user books on mount
  useEffect(() => {
    try {
      const savedActiveBook = localStorage.getItem("scribemind_active_book");
      if (savedActiveBook) {
        const parsed = JSON.parse(savedActiveBook);
        if (parsed && parsed.title) {
          setCurrentBook(parsed);
        }
      }
      const cachedBooks = localStorage.getItem("scribemind_all_cached_books");
      if (cachedBooks) {
        const parsed = JSON.parse(cachedBooks);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setUserBooks(parsed);
        }
      }
    } catch (err) {
      console.warn("Could not restore cached book on mount:", err);
    }
  }, []);

  // Merge guest books to Firestore when logging in with a real account
  const mergeGuestBooksToFirestore = async (realUser: any) => {
    const localBooks = localStorage.getItem("scribemind_guest_books");
    if (!localBooks) return;

    try {
      const booksArr = JSON.parse(localBooks);
      if (booksArr.length === 0) return;

      setIsSyncingWithDb(true);
      for (const book of booksArr) {
        const mergedBook = {
          ...book,
          userId: realUser.uid,
          creatorEmail: realUser.email || "",
          creatorName: realUser.displayName || realUser.email?.split("@")[0] || "Author",
          updatedAt: new Date().toLocaleDateString()
        };
        await setDoc(doc(db, "books", book.id), mergedBook);
      }
      
      // Clear guest session
      localStorage.removeItem("scribemind_guest_books");
      localStorage.removeItem("scribemind_guest_user");
      
      alert(lang === "bn" 
        ? `🎉 সফলভাবে আপনার ডেমো/গেস্ট অ্যাকাউন্টের ${booksArr.length}টি বই রিয়েল ক্লাউড অ্যাকাউন্টে মার্জ করা হয়েছে!` 
        : `🎉 Successfully merged ${booksArr.length} book(s) from your Demo Guest account to your secure Cloud profile!`
      );
    } catch (err) {
      console.error("Error merging guest books:", err);
    } finally {
      setIsSyncingWithDb(false);
    }
  };

  // Handle start guest mode
  const handleStartGuestMode = () => {
    try {
      const guestId = `guest-${Math.random().toString(36).substring(2, 11)}`;
      const guestObj = {
        uid: guestId,
        email: "guest@scribemind.local",
        displayName: lang === "bn" ? "গেস্ট লেখক (Demo)" : "Guest Author (Demo)",
        isGuest: true
      };
      localStorage.setItem("scribemind_guest_user", JSON.stringify(guestObj));
      setCurrentUser(guestObj);
      setShowAuthModal(false);
      alert(lang === "bn" 
        ? "🎉 সফলভাবে গেস্ট মোডে লগইন করা হয়েছে! আপনার সব বই ব্রাউজারে সুরক্ষিত থাকবে। পরবর্তীতে আপনি এটি ক্লাউড অ্যাকাউন্টে কনভার্ট করতে পারবেন।" 
        : "🎉 Successfully logged in to Guest Mode! Your books will be safely saved in this browser. You can convert to a full Cloud Account anytime!"
      );
    } catch (err) {
      console.error("Error starting guest mode:", err);
    }
  };

  // Handle logout
  const handleLogout = async () => {
    if (currentUser?.isGuest) {
      localStorage.removeItem("scribemind_guest_user");
      setCurrentUser(null);
      alert(lang === "bn" ? "🚪 গেস্ট সেশন শেষ করা হয়েছে।" : "🚪 Guest session closed.");
    } else {
      await signOut(auth);
    }
  };

  // Check API key configuration status on mount
  useEffect(() => {
    fetch("/api/config-status")
      .then((res) => res.json())
      .then((data) => {
        setHasApiKey(data.hasApiKey);
      })
      .catch((err) => {
        console.error("Failed to check config status:", err);
      });
  }, []);

  // Firebase auth listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        // Sync any guest books
        await mergeGuestBooksToFirestore(user);
        
        const userDocRef = doc(db, "users", user.uid);
        const userSnap = await getDoc(userDocRef);
        if (!userSnap.exists()) {
          const genId = `LKH-${Math.floor(100000 + Math.random() * 900000)}`;
          const newProfile = {
            uid: user.uid,
            loginId: genId,
            email: user.email,
            displayName: user.displayName || user.email?.split("@")[0] || "Author",
            isAdmin: false,
            createdAt: new Date().toISOString()
          };
          await setDoc(userDocRef, newProfile);
          await setDoc(doc(db, "users", `login-${genId}`), newProfile, { merge: true });
        }
      } else {
        // Fallback to local guest user if available
        const savedGuest = localStorage.getItem("scribemind_guest_user");
        if (savedGuest) {
          setCurrentUser(JSON.parse(savedGuest));
        } else {
          setCurrentUser(null);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  // Ensure active currentUser profile is auto-synced to Firestore for cross-device logins
  useEffect(() => {
    if (currentUser) {
      const syncActiveUserToFirestore = async () => {
        try {
          const loginId = currentUser.loginId || `LKH-${Math.floor(100000 + Math.random() * 900000)}`;
          const updatedUser = { ...currentUser, loginId };
          const upperLoginId = loginId.toUpperCase();
          const cleanUsername = (currentUser.username || currentUser.demoUsername || currentUser.email || "").toLowerCase().replace(/[^a-z0-9_]/g, "");

          await setDoc(doc(db, "users", `login-${upperLoginId}`), updatedUser, { merge: true });
          await setDoc(doc(db, "users", `login-${loginId}`), updatedUser, { merge: true });

          if (currentUser.uid) {
            await setDoc(doc(db, "users", currentUser.uid), updatedUser, { merge: true });
          }
          if (cleanUsername) {
            await setDoc(doc(db, "users", `demo-${cleanUsername}`), updatedUser, { merge: true });
          }

          // Update local map
          const existingAccountsRaw = localStorage.getItem("scribemind_demo_accounts");
          const accountsMap = existingAccountsRaw ? JSON.parse(existingAccountsRaw) : {};
          accountsMap[upperLoginId] = updatedUser;
          if (cleanUsername) accountsMap[cleanUsername] = updatedUser;
          localStorage.setItem("scribemind_demo_accounts", JSON.stringify(accountsMap));
        } catch (sErr) {
          console.warn("Auto-sync profile to Firestore warning:", sErr);
        }
      };
      syncActiveUserToFirestore();
    }
  }, [currentUser]);

  // Handle Google Sign In
  const handleGoogleSignIn = async () => {
    setAuthError("");
    try {
      setIsFetchingHistory(true);
      const provider = new GoogleAuthProvider();
      const userCredential = await signInWithPopup(auth, provider);
      const user = userCredential.user;
      
      // Save/Sync user record in Firestore
      await setDoc(doc(db, "users", user.uid), {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || "Author",
        isAdmin: false,
        createdAt: new Date().toISOString()
      }, { merge: true });
      
      alert(lang === "bn" ? "🎉 গুগল দিয়ে সফলভাবে লগইন করা হয়েছে!" : "🎉 Logged in with Google successfully!");
      setShowAuthModal(false);
    } catch (err: any) {
      console.error("Google Sign In error:", err);
      setAuthError(lang === "bn" 
        ? "গুগল লগইন ব্যর্থ হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।" 
        : `Google Sign In failed: ${err.message}`
      );
    } finally {
      setIsFetchingHistory(false);
    }
  };

  // Handle Login and Sign Up Auth Submit
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    const email = authEmail.trim();
    const password = authPassword.trim();
    const name = authName.trim();

    if (!email || !password) {
      setAuthError(lang === "bn" ? "দয়া করে ইমেইল এবং পাসওয়ার্ড দিন।" : "Please fill in email and password.");
      return;
    }

    if (password.length < 6) {
      setAuthError(lang === "bn" ? "পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।" : "Password must be at least 6 characters.");
      return;
    }

    try {
      setIsFetchingHistory(true);
      if (isSignUp) {
        if (!name) {
          setAuthError(lang === "bn" ? "দয়া করে আপনার নাম দিন।" : "Please enter your name.");
          setIsFetchingHistory(false);
          return;
        }
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        await updateProfile(user, { displayName: name });
        
        const generatedLoginId = `LKH-${Math.floor(100000 + Math.random() * 900000)}`;
        const userProfileObj = {
          uid: user.uid,
          loginId: generatedLoginId,
          email: user.email,
          displayName: name,
          password: password,
          demoPassword: password,
          isAdmin: false,
          createdAt: new Date().toISOString()
        };

        // Set user record in Firestore
        await setDoc(doc(db, "users", user.uid), userProfileObj, { merge: true });
        await setDoc(doc(db, "users", `login-${generatedLoginId}`), userProfileObj, { merge: true });
        
        alert(lang === "bn" 
          ? `🎉 রেজিস্ট্রেশন সফল হয়েছে!\n\n🔑 আপনার Login ID: ${generatedLoginId}\n📧 ইমেইল: ${user.email}\n\nআপনার প্রোফাইল সেকশনে এই Login ID দেখতে পাবেন!` 
          : `🎉 Account registered successfully!\n\n🔑 Login ID: ${generatedLoginId}\n📧 Email: ${user.email}`
        );
      } else {
        await signInWithEmailAndPassword(auth, email, password);
        alert(lang === "bn" ? "🎉 সফলভাবে লগইন করা হয়েছে!" : "🎉 Logged in successfully!");
      }
      
      // Reset inputs & close modal
      setAuthEmail("");
      setAuthPassword("");
      setAuthName("");
      setShowAuthModal(false);
    } catch (err: any) {
      console.error("Auth error:", err);
      let errMsg = err.message;
      if (err.code === "auth/email-already-in-use") {
        errMsg = lang === "bn" ? "এই ইমেইলটি ইতিপূর্বে ব্যবহার করা হয়েছে।" : "This email is already in use.";
      } else if (err.code === "auth/weak-password") {
        errMsg = lang === "bn" ? "পাসওয়ার্ড অত্যন্ত দুর্বল। কমপক্ষে ৬ অক্ষরের দিন।" : "Password is too weak. Min 6 chars.";
      } else if (err.code === "auth/invalid-credential" || err.code === "auth/wrong-password" || err.code === "auth/user-not-found") {
        errMsg = lang === "bn" ? "ভুল ইমেইল অথবা পাসওয়ার্ড।" : "Invalid email or password.";
      } else {
        errMsg = lang === "bn" ? "লগইন বা সাইন-আপ করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।" : "Authentication failed. Please try again.";
      }
      setAuthError(errMsg);
    } finally {
      setIsFetchingHistory(false);
    }
  };

  // Handle Demo Account Registration with Custom Name & Password
  const handleDemoRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    const name = demoName.trim();
    const username = demoUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
    const password = demoPassword.trim();

    if (!name || !username || !password) {
      setAuthError(lang === "bn" ? "দয়া করে আপনার নাম, ইউজারনেম এবং পাসওয়ার্ড দিন।" : "Please fill in name, username, and password.");
      return;
    }

    if (password.length < 4) {
      setAuthError(lang === "bn" ? "পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।" : "Password must be at least 4 characters.");
      return;
    }

    try {
      setIsFetchingHistory(true);
      const generatedLoginId = `LKH-${Math.floor(100000 + Math.random() * 900000)}`;
      const demoUid = `demo-${username}`;
      const demoEmail = `${username}@demo.lekhok.app`;

      const newDemoUser = {
        uid: demoUid,
        loginId: generatedLoginId,
        email: demoEmail,
        displayName: name,
        username: username,
        password: password,
        demoPassword: password,
        isGuest: true,
        isDemo: true,
        createdAt: new Date().toLocaleDateString(),
        bio: lang === "bn" ? "আমি লেখক এআই প্ল্যাটফর্মের একজন সম্মানিত লেখক।" : "Featured author profile on Lekhok AI Platform.",
        followersCount: 0,
        followers: [],
        following: [],
        totalLikesReceived: 0
      };

      // Save to localStorage map of demo accounts
      const existingAccountsRaw = localStorage.getItem("scribemind_demo_accounts");
      const accountsMap = existingAccountsRaw ? JSON.parse(existingAccountsRaw) : {};
      accountsMap[username] = newDemoUser;
      accountsMap[generatedLoginId] = newDemoUser;
      localStorage.setItem("scribemind_demo_accounts", JSON.stringify(accountsMap));

      // Set current session
      localStorage.setItem("scribemind_guest_user", JSON.stringify(newDemoUser));
      setCurrentUser(newDemoUser);

      // Save in Firestore for multi-device sync
      try {
        await setDoc(doc(db, "users", demoUid), newDemoUser, { merge: true });
        await setDoc(doc(db, "users", `login-${generatedLoginId}`), newDemoUser, { merge: true });
      } catch (fErr) {
        console.warn("Firestore sync warning for demo user:", fErr);
      }

      alert(lang === "bn"
        ? `🎉 সফলভাবে আপনার লেখক অ্যাকাউন্ট তৈরি হয়েছে!\n\n🔑 Login ID: ${generatedLoginId}\n👤 ইউজারনেম: ${username}\n🔒 পাসওয়ার্ড: ${password}\n\nআপনার প্রোফাইলে (Profile & Settings) এই তথ্য দেখতে পাবেন। অন্য যেকোনো মোবাইল বা কম্পিউটার থেকে এই Login ID/ইউজারনেম এবং পাসওয়ার্ড দিলে আপনার অ্যাকাউন্ট সাথে সাথে ওপেন হয়ে যাবে!`
        : `🎉 Author Account Created Successfully!\n\n🔑 Login ID: ${generatedLoginId}\n👤 Username: ${username}\n🔒 Password: ${password}\n\nCredentials saved to profile. Use this Login ID and Password on any mobile device to log in!`
      );

      setDemoName("");
      setDemoUsername("");
      setDemoPassword("");
      setShowAuthModal(false);
    } catch (err: any) {
      console.error("Demo registration error:", err);
      setAuthError(err.message || "Failed to create demo profile.");
    } finally {
      setIsFetchingHistory(false);
    }
  };

  // Handle Universal Account Login with Login ID, Username or Email & Password
  const handleDemoLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    const loginInput = demoUsername.trim();
    const cleanInput = loginInput.toLowerCase().replace(/[^a-z0-9_]/g, "");
    const uppercaseInput = loginInput.toUpperCase();
    const password = demoPassword.trim();

    if (!loginInput || !password) {
      setAuthError(lang === "bn" ? "দয়া করে Login ID, ইউজারনেম অথবা ইমেইল এবং পাসওয়ার্ড দিন।" : "Please enter Login ID, username, or email and password.");
      return;
    }

    try {
      setIsFetchingHistory(true);
      // 1. Check local storage map first
      const existingAccountsRaw = localStorage.getItem("scribemind_demo_accounts");
      const accountsMap = existingAccountsRaw ? JSON.parse(existingAccountsRaw) : {};
      let matchedUser = accountsMap[cleanInput] || accountsMap[uppercaseInput] || accountsMap[loginInput];

      // 2. Direct Firestore document lookups (doesn't require collection query permissions)
      if (!matchedUser) {
        const docIdsToTry = [
          `login-${uppercaseInput}`,
          `login-${loginInput}`,
          `login-${cleanInput}`,
          `demo-${cleanInput}`,
          cleanInput,
          uppercaseInput,
          loginInput
        ];

        for (const docId of docIdsToTry) {
          if (matchedUser) break;
          try {
            const uSnap = await getDoc(doc(db, "users", docId));
            if (uSnap.exists()) {
              matchedUser = uSnap.data();
            }
          } catch (dErr) {
            console.warn(`Doc lookup warning for ${docId}:`, dErr);
          }
        }
      }

      // 3. Collection query fallback wrapped safely
      if (!matchedUser) {
        try {
          const q1 = query(collection(db, "users"), where("loginId", "==", uppercaseInput));
          const snap1 = await getDocs(q1);
          if (!snap1.empty) {
            matchedUser = snap1.docs[0].data();
          } else {
            const q2 = query(collection(db, "users"), where("username", "==", cleanInput));
            const snap2 = await getDocs(q2);
            if (!snap2.empty) {
              matchedUser = snap2.docs[0].data();
            } else {
              const q3 = query(collection(db, "users"), where("email", "==", loginInput.toLowerCase()));
              const snap3 = await getDocs(q3);
              if (!snap3.empty) {
                matchedUser = snap3.docs[0].data();
              }
            }
          }
        } catch (qErr) {
          console.warn("Firestore collection query warning:", qErr);
        }
      }

      const isValidPass = matchedUser && (
        matchedUser.demoPassword?.trim() === password || 
        matchedUser.password?.trim() === password
      );

      if (matchedUser && isValidPass) {
        if (!matchedUser.loginId) {
          matchedUser.loginId = `LKH-${Math.floor(100000 + Math.random() * 900000)}`;
        }

        localStorage.setItem("scribemind_guest_user", JSON.stringify(matchedUser));
        setCurrentUser(matchedUser);

        // Save matched user in local accounts map
        accountsMap[uppercaseInput] = matchedUser;
        accountsMap[cleanInput] = matchedUser;
        localStorage.setItem("scribemind_demo_accounts", JSON.stringify(accountsMap));

        // Fetch user books from Firestore
        try {
          if (matchedUser.uid) {
            const qBooks = query(collection(db, "books"), where("userId", "==", matchedUser.uid));
            const bSnap = await getDocs(qBooks);
            if (!bSnap.empty) {
              const cloudBooks: Book[] = bSnap.docs.map(d => d.data() as Book);
              setUserBooks(cloudBooks);
            }
          }
        } catch (bErr) {
          console.warn("Failed to fetch user books from Firestore:", bErr);
        }

        alert(lang === "bn"
          ? `🎉 স্বাগতম ${matchedUser.displayName}! আপনার অ্যাকাউন্টে সফলভাবে প্রবেশ করা হয়েছে।\n🔑 Login ID: ${matchedUser.loginId}`
          : `🎉 Welcome back ${matchedUser.displayName}! Account logged in successfully.\n🔑 Login ID: ${matchedUser.loginId}`
        );

        setDemoUsername("");
        setDemoPassword("");
        setShowAuthModal(false);
      } else {
        setAuthError(lang === "bn" 
          ? "ভুল Login ID / ইউজারনেম অথবা পাসওয়ার্ড! অনুগ্রহ করে প্রোফাইলে থাকা সঠিক Login ID ও পাসওয়ার্ড দিয়ে চেষ্টা করুন।" 
          : "Invalid Login ID, Username, or Password. Please check your credentials."
        );
      }
    } catch (err: any) {
      console.error("Universal login error:", err);
      setAuthError(lang === "bn"
        ? "লগইন করতে সমস্যা হয়েছে। দয়া করে আপনার Login ID ও পাসওয়ার্ড সঠিক আছে কিনা তা পরীক্ষা করে আবার চেষ্টা করুন।"
        : "Login failed. Please verify your Login ID and Password."
      );
    } finally {
      setIsFetchingHistory(false);
    }
  };

  // Toggle Like on a Book
  const handleToggleLike = async (book: Book, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();

    if (!currentUser) {
      alert(lang === "bn" ? "বইটিতে লাইক দেওয়ার জন্য অনুগ্রহ করে আপনার অ্যাকাউন্টে বা ডেমো অ্যাকাউন্টে লগইন করুন।" : "Please log in or create a Demo account to like books!");
      setShowAuthModal(true);
      return;
    }

    try {
      const bookRef = doc(db, "books", book.id);
      const currentLikes: string[] = book.likes || [];
      const isAlreadyLiked = currentLikes.includes(currentUser.uid);

      const updatedLikes = isAlreadyLiked
        ? currentLikes.filter(id => id !== currentUser.uid)
        : [...currentLikes, currentUser.uid];

      const currentLikedByNames = book.likedByNames || [];
      const updatedLikedByNames = isAlreadyLiked
        ? currentLikedByNames.filter(item => item.uid !== currentUser.uid)
        : [
            ...currentLikedByNames,
            {
              uid: currentUser.uid,
              name: currentUser.displayName || currentUser.email?.split("@")[0] || "Reader",
              email: currentUser.email || "",
              timestamp: new Date().toLocaleDateString()
            }
          ];

      const newLikesCount = updatedLikes.length;

      const updatedBook: Book = {
        ...book,
        likes: updatedLikes,
        likesCount: newLikesCount,
        likedByNames: updatedLikedByNames
      };

      try {
        await setDoc(bookRef, updatedBook, { merge: true });
        if (book.userId) {
          await updateDoc(doc(db, "users", book.userId), {
            totalLikesReceived: increment(isAlreadyLiked ? -1 : 1)
          });
        }
      } catch (fErr) {
        console.warn("Liking sync notice:", fErr);
      }

      setPublishedBooks(prev => prev.map(b => b.id === book.id ? updatedBook : b));
      if (selectedSocialBook && selectedSocialBook.id === book.id) {
        setSelectedSocialBook(updatedBook);
      }
      if (currentBook && currentBook.id === book.id) {
        setCurrentBook(updatedBook);
      }

    } catch (err) {
      console.error("Error toggling like:", err);
    }
  };

  // Toggle Follow Author
  const handleToggleFollowAuthor = async (authorUid: string, authorName: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();

    if (!currentUser) {
      alert(lang === "bn" ? "লেখককে ফলো করার জন্য লগইন করুন।" : "Please log in to follow authors!");
      setShowAuthModal(true);
      return;
    }

    if (currentUser.uid === authorUid) {
      alert(lang === "bn" ? "আপনি নিজের প্রোফাইল ফলো করতে পারবেন না!" : "You cannot follow yourself!");
      return;
    }

    try {
      const currentFollowing: string[] = currentUser.following || [];
      const isFollowing = currentFollowing.includes(authorUid);

      const updatedFollowing = isFollowing
        ? currentFollowing.filter(id => id !== authorUid)
        : [...currentFollowing, authorUid];

      const updatedUser = { ...currentUser, following: updatedFollowing };
      setCurrentUser(updatedUser);

      if (currentUser.isGuest) {
        localStorage.setItem("scribemind_guest_user", JSON.stringify(updatedUser));
      } else {
        await setDoc(doc(db, "users", currentUser.uid), { following: updatedFollowing }, { merge: true });
      }

      // Update author follower count in Firestore
      try {
        const authorRef = doc(db, "users", authorUid);
        const authorSnap = await getDoc(authorRef);
        if (authorSnap.exists()) {
          const authorData = authorSnap.data();
          const authorFollowers: string[] = authorData.followers || [];
          const updatedAuthorFollowers = isFollowing
            ? authorFollowers.filter(id => id !== currentUser.uid)
            : [...authorFollowers, currentUser.uid];

          await updateDoc(authorRef, {
            followers: updatedAuthorFollowers,
            followersCount: updatedAuthorFollowers.length
          });
        }
      } catch (fErr) {
        console.warn("Follow count sync notice:", fErr);
      }

      alert(isFollowing 
        ? (lang === "bn" ? `আপনি ${authorName}-কে আনফলো করেছেন।` : `Unfollowed ${authorName}`)
        : (lang === "bn" ? `🎉 আপনি এখন ${authorName}-কে ফলো করছেন!` : `🎉 You are now following ${authorName}!`)
      );

    } catch (err) {
      console.error("Error toggling follow:", err);
    }
  };

  // Save Author Bio
  const handleSaveBio = async (newBio: string) => {
    if (!currentUser) return;
    try {
      const updatedUser = { ...currentUser, bio: newBio };
      setCurrentUser(updatedUser);
      if (currentUser.isGuest) {
        localStorage.setItem("scribemind_guest_user", JSON.stringify(updatedUser));
        const existingAccountsRaw = localStorage.getItem("scribemind_demo_accounts");
        if (existingAccountsRaw && currentUser.username) {
          const map = JSON.parse(existingAccountsRaw);
          map[currentUser.username] = updatedUser;
          localStorage.setItem("scribemind_demo_accounts", JSON.stringify(map));
        }
      } else {
        await setDoc(doc(db, "users", currentUser.uid), { bio: newBio }, { merge: true });
      }
      alert(lang === "bn" ? "🎉 বায়ো সফলভাবে সেভ করা হয়েছে!" : "🎉 Bio saved successfully!");
    } catch (err) {
      console.error("Error saving bio:", err);
    }
  };

  // Save Author Display Name
  const handleSaveDisplayName = async (newName: string) => {
    if (!currentUser || !newName.trim()) return;
    try {
      const trimmed = newName.trim();
      const updatedUser = { ...currentUser, displayName: trimmed };
      setCurrentUser(updatedUser);

      if (!currentUser.isGuest && auth.currentUser) {
        await updateProfile(auth.currentUser, { displayName: trimmed });
        await setDoc(doc(db, "users", currentUser.uid), { displayName: trimmed }, { merge: true });
      } else if (currentUser.isGuest) {
        localStorage.setItem("scribemind_guest_user", JSON.stringify(updatedUser));
        const existingAccountsRaw = localStorage.getItem("scribemind_demo_accounts");
        if (existingAccountsRaw && currentUser.username) {
          const map = JSON.parse(existingAccountsRaw);
          map[currentUser.username] = updatedUser;
          localStorage.setItem("scribemind_demo_accounts", JSON.stringify(map));
        }
      }
      setIsEditingProfileName(false);
      alert(lang === "bn" ? "🎉 লেখক নাম আপডেট করা হয়েছে!" : "🎉 Author name updated!");
    } catch (err) {
      console.error("Error updating author name:", err);
    }
  };

  // Sync books to Firestore (or local storage if guest)
  const saveBookToFirestore = async (book: Book) => {
    try {
      setIsSyncingWithDb(true);
      
      // 1. Always save to local active book cache immediately
      localStorage.setItem("scribemind_active_book", JSON.stringify(book));

      const uid = currentUser?.uid || auth.currentUser?.uid || "local-author";
      const updatedBookData: Book = {
        ...book,
        userId: uid,
        creatorEmail: currentUser?.email || auth.currentUser?.email || "guest@scribemind.local",
        creatorName: currentUser?.displayName || auth.currentUser?.displayName || "Author",
        updatedAt: new Date().toLocaleDateString()
      };

      // 2. Update all cached books in localStorage
      const cachedRaw = localStorage.getItem("scribemind_all_cached_books");
      let allCached: Book[] = cachedRaw ? JSON.parse(cachedRaw) : [];
      const existsInCache = allCached.some(b => b.id === book.id);
      if (existsInCache) {
        allCached = allCached.map(b => b.id === book.id ? updatedBookData : b);
      } else {
        allCached = [updatedBookData, ...allCached];
      }
      localStorage.setItem("scribemind_all_cached_books", JSON.stringify(allCached));
      setUserBooks(allCached);

      if (currentUser?.isGuest) {
        localStorage.setItem("scribemind_guest_books", JSON.stringify(allCached));
        return;
      }

      // 3. Sync to Firestore if authenticated
      if (auth.currentUser || (currentUser && !currentUser.isGuest)) {
        await setDoc(doc(db, "books", book.id), updatedBookData, { merge: true });
      }
    } catch (err) {
      console.error("Book persistence sync error:", err);
    } finally {
      setIsSyncingWithDb(false);
    }
  };

  // Toggle book publish state
  const handleTogglePublish = async () => {
    if (!currentBook) return;
    if (!currentUser) {
      setIsSignUp(false);
      setAuthError("");
      setShowAuthModal(true);
      return;
    }
    try {
      setIsSyncingWithDb(true);
      const updatedBook: Book = {
        ...currentBook,
        published: !currentBook.published,
        userId: currentUser.uid,
        creatorEmail: currentUser.email || "",
        creatorName: currentUser.displayName || currentUser.email?.split("@")[0] || "Author",
        updatedAt: new Date().toLocaleDateString()
      };
      
      await setDoc(doc(db, "books", currentBook.id), updatedBook);
      setCurrentBook(updatedBook);
      
      if (updatedBook.published) {
        alert(lang === "bn" ? "🎉 অভিনন্দন! আপনার বইটি সফলভাবে সোশ্যাল গ্যালারিতে প্রকাশিত হয়েছে।" : "🎉 Congratulations! Your book is now published to the social gallery.");
      } else {
        alert(lang === "bn" ? "বইটি সোশ্যাল গ্যালারি থেকে সরিয়ে নেওয়া হয়েছে।" : "Book removed from the social gallery.");
      }
    } catch (err) {
      console.error("Error toggling book publication:", err);
    } finally {
      setIsSyncingWithDb(false);
    }
  };

  // Client-side translate book handler
  const handleTranslateBook = async (targetLang: string) => {
    if (!currentBook) return;
    try {
      setIsTranslating(true);
      setShowTranslateModal(false);
      const response = await fetch("/api/translate-book", {
        method: "POST",
        headers: getAIHeaders(),
        body: JSON.stringify({
          book: currentBook,
          targetLanguage: targetLang
        })
      });
      if (!response.ok) {
        throw new Error("Translation request failed.");
      }
      const translatedBook = await response.json();
      setCurrentBook(translatedBook);
      
      // Save translated book to Firestore if logged in
      if (currentUser) {
        await saveBookToFirestore(translatedBook);
      }
      
      alert(lang === "bn" 
        ? `🎉 বইটি সফলভাবে "${targetLang}" ভাষায় অনুবাদ করা হয়েছে!` 
        : `🎉 The book was successfully translated into "${targetLang}"!`
      );
    } catch (err: any) {
      console.error("Translation error:", err);
      alert(lang === "bn" 
        ? "অনুবাদ করতে সমস্যা হয়েছে। দয়া করে আবার চেষ্টা করুন।" 
        : "Failed to translate book. Please try again."
      );
    } finally {
      setIsTranslating(false);
    }
  };

  // Debounced auto-save
  useEffect(() => {
    if (currentBook && currentUser) {
      const delayDebounce = setTimeout(() => {
        saveBookToFirestore(currentBook);
      }, 1500);
      return () => clearTimeout(delayDebounce);
    }
  }, [currentBook, currentUser]);

  // Fetch user's history books
  const fetchUserBooksHistory = async () => {
    if (!auth.currentUser) return;
    try {
      setIsFetchingHistory(true);
      const qFallback = query(
        collection(db, "books"),
        where("userId", "==", auth.currentUser.uid)
      );
      const querySnapshot = await getDocs(qFallback);
      const books: Book[] = [];
      querySnapshot.forEach((doc) => {
        books.push(doc.data() as Book);
      });
      // Sort in-memory to avoid requiring composite indexes in Firestore initially
      books.sort((a, b) => {
        const dateA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
        const dateB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
        return dateB - dateA;
      });
      setUserBooks(books);
    } catch (err) {
      console.error("Error fetching user books history:", err);
    } finally {
      setIsFetchingHistory(false);
    }
  };

  const handleDeleteUserBook = async (bookId: string) => {
    try {
      if (currentUser?.isGuest) {
        const localBooks = localStorage.getItem("scribemind_guest_books");
        let booksArr: Book[] = localBooks ? JSON.parse(localBooks) : [];
        booksArr = booksArr.filter(b => b.id !== bookId);
        localStorage.setItem("scribemind_guest_books", JSON.stringify(booksArr));
        setUserBooks(booksArr);
      } else {
        await deleteDoc(doc(db, "books", bookId));
        setUserBooks(prev => prev.filter(b => b.id !== bookId));
      }
      
      if (currentBook?.id === bookId) {
        setCurrentBook(null);
        localStorage.removeItem("scribemind_active_book");
      }
    } catch (err) {
      console.error("Error deleting book:", err);
    }
  };

  // Update profile photo in Firestore and local state
  const handleUpdateProfilePhoto = async (newPhotoUrl: string) => {
    if (!currentUser) return;
    try {
      if (currentUser.isGuest) {
        const updated = { ...currentUser, photoURL: newPhotoUrl };
        setCurrentUser(updated);
        localStorage.setItem("scribemind_guest_user", JSON.stringify(updated));
      } else if (auth.currentUser) {
        await updateDoc(doc(db, "users", auth.currentUser.uid), {
          photoURL: newPhotoUrl
        });
        setCurrentUser((prev: any) => ({ ...prev, photoURL: newPhotoUrl }));
      }
    } catch (err) {
      console.error("Error updating profile photo:", err);
    }
  };

  // Load user's books on startup if logged in
  useEffect(() => {
    if (currentUser) {
      if (currentUser.isGuest) {
        // Load from localStorage
        const localBooks = localStorage.getItem("scribemind_guest_books");
        const books: Book[] = localBooks ? JSON.parse(localBooks) : [];
        setUserBooks(books);
        if (books.length > 0) {
          setCurrentBook(books[0]);
        } else {
          setCurrentBook(null);
        }
      } else {
        // Load from Firestore
        const loadFirstBook = async () => {
          try {
            const q = query(collection(db, "books"), where("userId", "==", currentUser.uid), limit(1));
            const querySnapshot = await getDocs(q);
            if (!querySnapshot.empty) {
              const firstBook = querySnapshot.docs[0].data() as Book;
              setCurrentBook(firstBook);
            }
          } catch (err) {
            console.error("Error loading user book:", err);
          }
        };
        loadFirstBook();
        fetchUserBooksHistory();
      }
    } else {
      setUserBooks([]);
      setCurrentBook(null);
    }
  }, [currentUser]);

  // Fetch published books for Social
  const fetchPublishedBooks = async () => {
    try {
      const q = query(collection(db, "books"), where("published", "==", true));
      const querySnapshot = await getDocs(q);
      const booksList: Book[] = [];
      querySnapshot.forEach((doc) => {
        booksList.push(doc.data() as Book);
      });
      setPublishedBooks(booksList);
    } catch (err) {
      console.error("Error fetching published books:", err);
    }
  };

  // Admin Actions
  const fetchAdminDashboardData = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "books"));
      const booksList: Book[] = [];
      querySnapshot.forEach((doc) => {
        booksList.push(doc.data() as Book);
      });
      setAdminBooks(booksList);
    } catch (err) {
      console.error("Error loading admin stats:", err);
    }
  };

  const handleAdminLogin = async () => {
    if (adminPasswordInput === "@masud123#@") {
      setIsAdminAuthenticated(true);
      setAdminError("");
      await fetchAdminDashboardData();
    } else {
      setAdminError(lang === "bn" ? "ভুল পাসওয়ার্ড! আবার চেষ্টা করুন।" : "Incorrect password! Please try again.");
    }
  };

  const handleAdminDeleteBook = async (bookId: string) => {
    if (window.confirm(lang === "bn" ? "আপনি কি নিশ্চিতভাবে এই বইটি ডিলিট করতে চান?" : "Are you sure you want to delete this book?")) {
      try {
        await deleteDoc(doc(db, "books", bookId));
        setAdminBooks(prev => prev.filter(b => b.id !== bookId));
        alert(lang === "bn" ? "বইটি ডিলিট করা হয়েছে।" : "Book deleted successfully.");
      } catch (err) {
        console.error("Admin delete error:", err);
      }
    }
  };

  const handleAdminUnpublishBook = async (book: Book) => {
    try {
      const updatedBook = { ...book, published: false };
      await setDoc(doc(db, "books", book.id), updatedBook);
      setAdminBooks(prev => prev.map(b => b.id === book.id ? updatedBook : b));
      alert(lang === "bn" ? "বইটি আন-পাবলিশ করা হয়েছে।" : "Book unpublished successfully.");
    } catch (err) {
      console.error("Admin unpublish error:", err);
    }
  };

  useEffect(() => {
    if (activeMainTab === "social") {
      fetchPublishedBooks();
    }
  }, [activeMainTab]);

  // Reset page index on chapter change
  useEffect(() => {
    setActivePageIndex(0);
  }, [activeChapterIndex]);


  // Translation helpers
  const t = {
    appTitle: lang === "bn" ? "লেখক AI" : "Lekhok AI",
    tagline: lang === "bn" ? "আপনার ব্যক্তিগত বই লেখার এআই সহকারী" : "Conversational Book Designer & Writer",
    placeholder: lang === "bn" 
      ? "কেমন বই লিখতে চান বলুন... (যেমন: '৫ অধ্যায়ের সুন্দরবনের অ্যাডভেঞ্চার গল্প বাংলা ভাষায়')" 
      : "Ask to write any book... (e.g., 'A 3-chapter sci-fi mystery in English')",
    emptyChatHeading: lang === "bn" ? "চ্যাট বক্সে বইয়ের আইডিয়া বলুন" : "Ask the AI to start writing!",
    emptyChatSub: lang === "bn" 
      ? "কোনো ফরমাল অপশন বা জটিল সেটিং নেই। চ্যাট জিপিটি-এর মতো টাইপ করে বলুন কেমন বই চান, এআই আপনার জন্য পুরো বই, সূচিপত্র ও ছবি সহ নিখুঁতভাবে লিখে দেবে।" 
      : "No complex forms or boring dropdowns. Just type your book idea or instruction like ChatGPT, and let the AI write the outline, cover style, and beautiful detailed chapters.",
    chatBubbleTip1: lang === "bn" ? "💡 '৫ অধ্যায়ের একটি রহস্য রোমাঞ্চকর বাংলা উপন্যাস লিখে দাও।'" : "💡 'Write a 3-chapter mystery novel in Bengali.'",
    chatBubbleTip2: lang === "bn" ? "💡 'কভারের ডিজাইন পরিবর্তন করে মহাজাগতিক নীল রঙের করো।'" : "💡 'Change the cover color to cosmic deep blue gradient.'",
    chatBubbleTip3: lang === "bn" ? "💡 'অধ্যায় ২-এর কাহিনীতে আরও রোমাঞ্চকর অ্যাডভেঞ্চার যোগ করো।'" : "💡 'Expand chapter 2 to make it more exciting and detailed.'",
    activeGenerating: lang === "bn" ? "এআই লিখছে... কিছু সময় অপেক্ষা করুন।" : "AI is writing your book... Please wait.",
    previewHeading: lang === "bn" ? "লাইভ বইয়ের ক্যানভাস" : "Live Book Preview",
    noBookTitle: lang === "bn" ? "কোনো বই তৈরি হয়নি" : "No book designed yet",
    noBookDesc: lang === "bn" ? "বাম পাশে চ্যাট বক্সে এআই-কে নতুন বই লিখতে বলুন। বইটি সম্পূর্ণ তৈরি হয়ে গেলে এখানে লাইভ দেখতে এবং ডাউনলোড করতে পারবেন।" : "Instruct the AI on the left to write a book. Once generated, your dynamic layout, cover, and full text will appear here instantly.",
    tabCover: lang === "bn" ? "🎨 কভার ক্যানভাস" : "🎨 Cover Canvas",
    tabOutline: lang === "bn" ? "📋 সূচিপত্র ও ভূমিকা" : "📋 Intro & Chapters",
    tabChapters: lang === "bn" ? "✍️ অধ্যায় পাণ্ডুলিপি" : "✍️ Manuscript",
    downloadPDF: lang === "bn" ? "🖨️ PDF প্রিন্ট / সেভ" : "🖨️ Print / Save as PDF",
    downloadMD: lang === "bn" ? "Markdown ডাউনলোড" : "Download Markdown",
    downloadHTML: lang === "bn" ? "HTML ই-বুক ডাউনলোড" : "Download HTML",
    modeRead: lang === "bn" ? "পড়ার মোড" : "Reader Mode",
    modeEdit: lang === "bn" ? "এডিটর মোড" : "Editor Mode",
    words: lang === "bn" ? "শব্দ" : "words",
    genre: lang === "bn" ? "ধরণ" : "Genre",
    language: lang === "bn" ? "ভাষা" : "Language",
    chaptersCount: lang === "bn" ? "অধ্যায় সংখ্যা" : "Chapters",
    coverConcept: lang === "bn" ? "কভার ক্যানভাস আইডিয়া:" : "Cover Canvas Concept:",
    editorPlaceholder: lang === "bn" ? "পাণ্ডুলিপির মূল টেক্সট এখানে চাইলে নিজে এডিট করুন..." : "Directly modify or type additional chapter content here...",
    newBookAlert: lang === "bn" ? "নতুন বইয়ের রূপরেখা সফলভাবে তৈরি হয়েছে!" : "New book structured successfully!",
    startWritingBtn: lang === "bn" ? "পরের অধ্যায়টি লিখুন" : "Generate Next Chapter"
  };

  // Quote rotation during load
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isGenerating) {
      interval = setInterval(() => {
        setLoadingQuoteIndex((prev) => (prev + 1) % loadingQuotes.length);
      }, 4000);
    }
    return () => clearInterval(interval);
  }, [isGenerating]);

  // Auto-scroll chat to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isGenerating]);

  // Clear or reset current book state
  const handleNewBookReset = () => {
    setCurrentBook(null);
    setMessages([]);
    setActiveChapterIndex(0);
    setActivePageIndex(0);
    setPreviewTab("cover");
    setActiveMainTab("editor");
    localStorage.removeItem("scribemind_active_book");
  };

  // Main conversational handler
  const handleSendChatMessage = async (overridePrompt?: string) => {
    const text = (typeof overridePrompt === "string" ? overridePrompt : userChatPrompt).trim();
    if (!text || isGenerating) return;

    const userMsgId = `user-${Date.now()}`;
    const newMessages: ChatMessage[] = [
      ...messages,
      { id: userMsgId, role: "user", content: text, attachment: chatAttachment || undefined }
    ];

    setMessages(newMessages);
    const savedAttachment = chatAttachment;
    setChatAttachment(null);
    setUserChatPrompt("");
    setIsGenerating(true);

    let finalPrompt = text;
    if (writingSpeedMode === "extensive") {
      finalPrompt += ` [INSTRUCTION: Please write exceptionally long, rich, and deeply descriptive chapter drafts. Take your time to write fully developed paragraphs, extensive world-building, multiple scenes, dialogues, and comprehensive details. Do not summarize or keep it brief! Make sure to write as many pages as possible. Use <!-- PAGE_BREAK --> at logical points to partition the chapter into multiple structured pages. Ensure content is at least 3-4 times longer than usual.]`;
      
      setExtensiveProgress(0);
      setExtensiveStepText(lang === "bn" ? "১. গভীর প্লট ও ক্যারেক্টার ম্যাপিং করা হচ্ছে..." : "1. Deep plot and character mapping in progress...");
      
      const stepTimer = setInterval(() => {
        setExtensiveProgress(prev => {
          const next = prev + Math.floor(Math.random() * 8) + 3;
          if (next >= 100) {
            clearInterval(stepTimer);
            return 99;
          }
          if (next > 80) {
            setExtensiveStepText(lang === "bn" ? "৪. কভার ডিজাইন ও অলঙ্করণ বিন্যাস চূড়ান্ত করা হচ্ছে..." : "4. Custom artwork & typography alignment...");
          } else if (next > 50) {
            setExtensiveStepText(lang === "bn" ? "৩. প্রতিটি অধ্যায়ে বিস্তারিত ঘটনার বর্ণনা যোগ হচ্ছে..." : "3. Adding immersive detail and structural scene arcs...");
          } else if (next > 25) {
            setExtensiveStepText(lang === "bn" ? "২. বাক্য গঠন ও ব্যাকরণ নিখুঁত করা হচ্ছে..." : "2. Refining syntax and aesthetic sentence structures...");
          }
          return next;
        });
      }, 600);
      
      (window as any)._stepTimer = stepTimer;
    }

    try {
      const response = await fetch("/api/chat-book", {
        method: "POST",
        headers: getAIHeaders(),
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
          currentBook,
          userMessage: finalPrompt,
          attachment: savedAttachment ? {
            name: savedAttachment.name,
            type: savedAttachment.type,
            size: savedAttachment.size,
            dataBase64: savedAttachment.url,
            mimeType: savedAttachment.url.split(";")[0].split(":")[1] || "image/jpeg"
          } : undefined
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to process conversation.");
      }

      const data = await response.json();

      // Update states
      if (data.updatedBook) {
        const receivedBook = data.updatedBook as Book;
        
        // Add random or default ID if missing
        if (!receivedBook.id) {
          receivedBook.id = currentBook?.id || `book-${Date.now()}`;
        }
        
        // Ensure default cover color if missing
        if (!receivedBook.coverColor) {
          receivedBook.coverColor = COVER_GRADIENTS[0].css;
        }

        // Maintain status helper tags for chapters
        receivedBook.chapters = (receivedBook.chapters || []).map((ch, idx) => ({
          ...ch,
          status: ch.content ? "completed" : "idle",
          estimatedPages: ch.estimatedPages || 10
        }));

        setCurrentBook(receivedBook);
        await saveBookToFirestore(receivedBook);

        // Check if this is a newly created book that has remaining unwritten chapters
        const isNewBookCreation = !currentBook;
        const unwrittenChapters = receivedBook.chapters.filter(ch => !ch.content || ch.content.trim().length < 50);

        // Auto-switch tabs to show progress
        if (isNewBookCreation) {
          setPreviewTab("cover");
          // If there are multiple chapters and remaining ones are unwritten, seamlessly kick off auto-batch sequence!
          if (unwrittenChapters.length > 0) {
            setTimeout(() => {
              handleAutoWriteAllChapters(receivedBook);
            }, 1200);
          }
        } else {
          // If a specific chapter content was just updated or written, open that chapter
          const completedIndex = receivedBook.chapters.findIndex(ch => ch.content && (!currentBook.chapters[ch.chapterNumber - 1]?.content));
          if (completedIndex !== -1) {
            setActiveChapterIndex(completedIndex);
            setPreviewTab("chapters");
          }
        }
      }

      const assistantMsgId = `assistant-${Date.now()}`;
      setMessages(prev => [
        ...prev,
        { id: assistantMsgId, role: "assistant", content: data.chatResponse || "আমি আপনার নির্দেশটি সম্পন্ন করেছি।" }
      ]);

    } catch (error: any) {
      console.error(error);
      const assistantErrorId = `assistant-error-${Date.now()}`;
      
      let displayError = lang === "bn"
        ? "দুঃখিত, কোনো টেকনিক্যাল ত্রুটি হয়েছে। দয়া করে আবার চেষ্টা করুন।"
        : "Sorry, I encountered an error processing your request. Please try again.";
        
      if (error.message && (error.message.includes("GEMINI_API_KEY") || error.message.includes("API key"))) {
        displayError = lang === "bn"
          ? "⚠️ আপনার **GEMINI_API_KEY** সেট করা নেই বা অবৈধ। অনুগ্রহ করে AI Studio-র **Settings > Secrets** প্যানেলে গিয়ে 'GEMINI_API_KEY' কি-টি যুক্ত করুন।"
          : "⚠️ Your **GEMINI_API_KEY** is missing or invalid. Please configure it in the **Settings > Secrets** panel of AI Studio.";
      } else if (error.message) {
        displayError = lang === "bn"
          ? `❌ ত্রুটি: ${error.message}`
          : `❌ Error: ${error.message}`;
      }

      setMessages(prev => [
        ...prev,
        { 
          id: assistantErrorId, 
          role: "assistant", 
          content: displayError
        }
      ]);
    } finally {
      if ((window as any)._stepTimer) {
        clearInterval((window as any)._stepTimer);
      }
      if (writingSpeedMode === "extensive") {
        setExtensiveProgress(100);
        setExtensiveStepText(lang === "bn" ? "৫. মহাগ্রন্থটির ১ম খসড়া সম্পূর্ণ করা হলো!" : "5. First edition compiled and polished successfully!");
        setTimeout(() => {
          setIsGenerating(false);
          setExtensiveProgress(0);
        }, 1500);
      } else {
        setIsGenerating(false);
      }
    }
  };

  // Direct manual content editing
  const handleManualContentChange = (val: string) => {
    if (!currentBook) return;
    const updatedChapters = [...currentBook.chapters];
    updatedChapters[activeChapterIndex].content = val;
    updatedChapters[activeChapterIndex].status = val ? "completed" : "idle";

    setCurrentBook({
      ...currentBook,
      chapters: updatedChapters,
      updatedAt: new Date().toLocaleDateString()
    });
  };

  // Generate a specific chapter sequentially with premium slow professional writing styles
  const writeChapterWithAI = async (chNum: number) => {
    if (!currentBook) return;
    const chIndex = currentBook.chapters.findIndex(c => c.chapterNumber === chNum);
    if (chIndex === -1) return;

    setIsGeneratingChapter(true);
    setGeneratingChapterNumber(chNum);

    // Calculate previous chapters summary for cohesive storyline
    const precedingChapters = currentBook.chapters.filter(c => c.chapterNumber < chNum);
    const prevSummary = precedingChapters.length > 0
      ? precedingChapters.map(c => `Chapter ${c.chapterNumber}: "${c.title}" - ${c.summary}`).join("\n")
      : "This is the very first chapter.";

    const targetChapter = currentBook.chapters[chIndex];

    try {
      const res = await fetch("/api/generate-chapter", {
        method: "POST",
        headers: getAIHeaders(),
        body: JSON.stringify({
          bookTitle: currentBook.title,
          synopsis: currentBook.synopsis,
          chapterNumber: chNum,
          chapterTitle: targetChapter.title,
          chapterSummary: targetChapter.summary,
          previousChaptersSummary: prevSummary,
          language: currentBook.language,
          customTone: preferredTone,
          writingStyle: preferredStyle
        })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to generate chapter content");
      }

      const data = await res.json();
      
      // Update book state
      const updatedChapters = [...currentBook.chapters];
      updatedChapters[chIndex] = {
        ...updatedChapters[chIndex],
        content: data.content,
        aiNote: data.aiNote || "",
        status: "completed"
      };

      const updatedBook = {
        ...currentBook,
        chapters: updatedChapters,
        updatedAt: new Date().toLocaleDateString()
      };

      setCurrentBook(updatedBook);
      setActiveChapterIndex(chIndex);
      setPreviewTab("chapters");

      // Auto-save/sync with Firestore if logged in
      if (auth.currentUser) {
        await saveBookToFirestore(updatedBook);
      }

      // Add assistant update message
      const systemMessageId = `assistant-sys-${Date.now()}`;
      setMessages(prev => [
        ...prev,
        {
          id: systemMessageId,
          role: "assistant",
          content: lang === "bn"
            ? `📝 আমি সফলভাবে **অধ্যায় ${chNum}: ${targetChapter.title}** অত্যন্ত বিস্তারিত ও সুন্দরভাবে লিখে ফেলেছি! আপনি চাইলে এখনই পড়তে পারেন।`
            : `📝 I have successfully drafted **Chapter ${chNum}: ${targetChapter.title}** with rich details and professional content! You can read it now.`
        }
      ]);

    } catch (err: any) {
      console.error(err);
      let errorMsg = lang === "bn" ? "অধ্যায়টি তৈরি করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।" : "Failed to generate chapter. Please try again.";
      if (err.message && (err.message.includes("GEMINI_API_KEY") || err.message.includes("API key"))) {
        errorMsg = lang === "bn"
          ? "⚠️ আপনার GEMINI_API_KEY অনুপস্থিত বা ভুল। অনুগ্রহ করে Settings > Secrets প্যানেলে কি-টি চেক করুন।"
          : "⚠️ Your GEMINI_API_KEY is missing or invalid. Please configure it in the Secrets panel.";
      } else if (err.message) {
        errorMsg = `${lang === "bn" ? "ত্রুটি:" : "Error:"} ${err.message}`;
      }
      alert(errorMsg);
    } finally {
      setIsGeneratingChapter(false);
      setGeneratingChapterNumber(null);
    }
  };

  // Auto-Write All Book Chapters in Batch Sequence with Resilience, Auto-Continuation & Deep Expansion
  const handleAutoWriteAllChapters = async (targetBook?: Book) => {
    const bookToWrite = targetBook || currentBook;
    if (!bookToWrite || bookToWrite.chapters.length === 0) return;
    if (isBatchWriting) return;

    isBatchCancelledRef.current = false;
    setIsBatchWriting(true);
    setBatchProgress(0);

    const totalChapters = bookToWrite.chapters.length;
    const estSecTotal = totalChapters * 6;
    const estMin = Math.floor(estSecTotal / 60);
    const estSec = estSecTotal % 60;
    const estPages = totalChapters * 12;

    const initialEstimateNotice = lang === "bn"
      ? `🚀 ${totalChapters}টি অধ্যায় (মোট ~${estPages} পৃষ্ঠা) রচনা শুরু হয়েছে! আনুমানিক সময়: ${estMin > 0 ? `${estMin} মিনিট ` : ''}${estSec} সেকেন্ড`
      : `🚀 Writing all ${totalChapters} chapters (~${estPages} pages total)! Estimated time: ${estMin > 0 ? `${estMin}m ` : ''}${estSec}s`;

    setBatchStatusText(initialEstimateNotice);
    let updatedBook = { ...bookToWrite };

    for (let i = 0; i < totalChapters; i++) {
      if (isBatchCancelledRef.current) {
        setBatchStatusText(lang === "bn" ? "অটো-রাইটিং বন্ধ করা হয়েছে।" : "Auto-writing cancelled.");
        break;
      }

      const ch = updatedBook.chapters[i];

      // If chapter already has substantial rich content (>600 words / 2500 chars), skip unless it's empty
      if (ch.content && ch.content.trim().length > 2500) {
        setBatchProgress(Math.round(((i + 1) / totalChapters) * 100));
        continue;
      }

      setBatchStatusText(
        lang === "bn"
          ? `অধ্যায় ${ch.chapterNumber}/${totalChapters} ("${ch.title}") নিখুঁতভাবে সম্পূর্ণ লেখা হচ্ছে...`
          : `Writing Chapter ${ch.chapterNumber}/${totalChapters} ("${ch.title}") in full depth...`
      );
      setBatchProgress(Math.round((i / totalChapters) * 100));
      setActiveChapterIndex(i);

      let success = false;
      let retryCount = 0;
      const maxRetries = 3;
      let generatedChapterContent = ch.content || "";

      // Step 1: Initial Chapter Draft
      while (!success && retryCount < maxRetries && !isBatchCancelledRef.current) {
        try {
          const precedingChapters = updatedBook.chapters.filter(c => c.chapterNumber < ch.chapterNumber && c.content);
          const prevSummary = precedingChapters.length > 0
            ? precedingChapters.map(c => `Chapter ${c.chapterNumber}: "${c.title}" - ${c.summary}`).join("\n")
            : "This is the very first chapter.";

          const res = await fetch("/api/generate-chapter", {
            method: "POST",
            headers: getAIHeaders(),
            body: JSON.stringify({
              bookTitle: updatedBook.title,
              synopsis: updatedBook.synopsis,
              chapterNumber: ch.chapterNumber,
              chapterTitle: ch.title,
              chapterSummary: ch.summary,
              previousChaptersSummary: prevSummary,
              language: updatedBook.language,
              customTone: preferredTone,
              writingStyle: preferredStyle
            })
          });

          if (res.ok) {
            const data = await res.json();
            generatedChapterContent = data.content || "";
            const newChapters = [...updatedBook.chapters];
            newChapters[i] = {
              ...newChapters[i],
              content: generatedChapterContent,
              aiNote: data.aiNote || "",
              status: "completed"
            };
            updatedBook = {
              ...updatedBook,
              chapters: newChapters,
              updatedAt: new Date().toLocaleDateString()
            };
            setCurrentBook(updatedBook);
            await saveBookToFirestore(updatedBook);
            success = true;
          } else {
            retryCount++;
            if (retryCount < maxRetries) {
              setBatchStatusText(
                lang === "bn"
                  ? `অধ্যায় ${ch.chapterNumber} পুনরায় চেষ্টা করা হচ্ছে (${retryCount}/${maxRetries})...`
                  : `Retrying Chapter ${ch.chapterNumber} (${retryCount}/${maxRetries})...`
              );
              await new Promise(r => setTimeout(r, 3000));
            }
          }
        } catch (e) {
          console.warn(`Error auto-writing chapter ${ch.chapterNumber}:`, e);
          retryCount++;
          if (retryCount < maxRetries) {
            await new Promise(r => setTimeout(r, 3000));
          }
        }
      }

      // Step 2: Auto-Continuation/Deep Expansion if content is relatively brief (< 3200 chars)
      if (success && generatedChapterContent.length < 3200 && !isBatchCancelledRef.current) {
        setBatchStatusText(
          lang === "bn"
            ? `অধ্যায় ${ch.chapterNumber} এর বিস্তারিত পরবর্তী অংশ ও অনুশীলনী যুক্ত করা হচ্ছে...`
            : `Deep expanding Chapter ${ch.chapterNumber} with comprehensive details and exercises...`
        );
        try {
          const contRes = await fetch("/api/continue-chapter", {
            method: "POST",
            headers: getAIHeaders(),
            body: JSON.stringify({
              bookTitle: updatedBook.title,
              synopsis: updatedBook.synopsis,
              chapterNumber: ch.chapterNumber,
              chapterTitle: ch.title,
              chapterSummary: ch.summary,
              existingContent: generatedChapterContent,
              language: updatedBook.language,
              customTone: preferredTone,
              writingStyle: preferredStyle
            })
          });

          if (contRes.ok) {
            const contData = await contRes.json();
            if (contData.content) {
              const fullExpandedContent = `${generatedChapterContent}\n\n${contData.content}`;
              const newChapters = [...updatedBook.chapters];
              newChapters[i] = {
                ...newChapters[i],
                content: fullExpandedContent,
                aiNote: contData.aiNote || newChapters[i].aiNote || "",
                status: "completed"
              };
              updatedBook = {
                ...updatedBook,
                chapters: newChapters,
                updatedAt: new Date().toLocaleDateString()
              };
              setCurrentBook(updatedBook);
              await saveBookToFirestore(updatedBook);
            }
          }
        } catch (e) {
          console.warn("Expansion note:", e);
        }
      }

      // Pacing delay between chapters
      await new Promise(r => setTimeout(r, 1200));
    }

    setBatchProgress(100);
    setIsBatchWriting(false);
    setBatchStatusText(
      lang === "bn"
        ? "🎉 সফলভাবে বইটির প্রতিটি অধ্যায় সম্পূর্ণ ও বিস্তারিতভাবে রচিত হয়েছে!"
        : "🎉 All chapters have been fully written and saved in comprehensive depth!"
    );
    setPreviewTab("chapters");
  };

  // Cancel Batch Auto-Writing
  const handleCancelAutoWrite = () => {
    isBatchCancelledRef.current = true;
    setIsBatchWriting(false);
  };

  // Expand / Continue writing the next section of the chapter with AI (Staged continuous writing)
  const continueChapterWithAI = async (chNum: number) => {
    if (!currentBook) return;
    const chIndex = currentBook.chapters.findIndex(c => c.chapterNumber === chNum);
    if (chIndex === -1) return;

    setIsGeneratingChapter(true);
    setGeneratingChapterNumber(chNum);

    const targetChapter = currentBook.chapters[chIndex];
    const existingContent = targetChapter.content || "";

    try {
      const res = await fetch("/api/continue-chapter", {
        method: "POST",
        headers: getAIHeaders(),
        body: JSON.stringify({
          bookTitle: currentBook.title,
          synopsis: currentBook.synopsis,
          chapterNumber: chNum,
          chapterTitle: targetChapter.title,
          chapterSummary: targetChapter.summary,
          existingContent: existingContent,
          language: currentBook.language,
          customTone: preferredTone,
          writingStyle: preferredStyle
        })
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to continue chapter content");
      }

      const data = await res.json();
      
      const updatedChapters = [...currentBook.chapters];
      updatedChapters[chIndex] = {
        ...updatedChapters[chIndex],
        content: existingContent ? `${existingContent}\n\n${data.content}` : data.content,
        aiNote: data.aiNote || "",
        status: "completed"
      };

      const updatedBook = {
        ...currentBook,
        chapters: updatedChapters,
        updatedAt: new Date().toLocaleDateString()
      };

      setCurrentBook(updatedBook);
      setActiveChapterIndex(chIndex);
      setPreviewTab("chapters");

      // Sync/Save
      if (currentUser) {
        await saveBookToFirestore(updatedBook);
      }

      // Add system confirmation chat bubble
      const systemMessageId = `assistant-sys-${Date.now()}`;
      setMessages(prev => [
        ...prev,
        {
          id: systemMessageId,
          role: "assistant",
          content: lang === "bn"
            ? `✍️ আমি সফলভাবে **অধ্যায় ${chNum}: ${targetChapter.title}** এর পরবর্তী অংশ সম্পূর্ণ বিস্তারিতভাবে লিখে পূর্বের লেখার সাথে যুক্ত করেছি!`
            : `✍️ I have successfully written and seamlessly appended the next section of **Chapter ${chNum}: ${targetChapter.title}** with maximum detail!`
        }
      ]);

    } catch (err: any) {
      console.error(err);
      let errorMsg = lang === "bn" ? "অধ্যায়টি বর্ধিত করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।" : "Failed to expand chapter. Please try again.";
      if (err.message && (err.message.includes("GEMINI_API_KEY") || err.message.includes("API key"))) {
        errorMsg = lang === "bn"
          ? "⚠️ আপনার GEMINI_API_KEY অনুপস্থিত বা ভুল। অনুগ্রহ করে Settings > Secrets প্যানেলে কি-টি চেক করুন।"
          : "⚠️ Your GEMINI_API_KEY is missing or invalid. Please configure it in the Secrets panel.";
      } else if (err.message) {
        errorMsg = `${lang === "bn" ? "ত্রুটি:" : "Error:"} ${err.message}`;
      }
      alert(errorMsg);
    } finally {
      setIsGeneratingChapter(false);
      setGeneratingChapterNumber(null);
    }
  };

  // Insert custom sentence styling format tag into text area
  const insertFormattingTag = (type: string, value?: string) => {
    const textarea = textareaRef.current;
    if (!textarea || !currentBook) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selectedText = text.substring(start, end) || "text";

    let tagOpen = "";
    let tagClose = "";

    if (type === "color") {
      tagOpen = `{color:${value || "#7c2d12"}}`;
      tagClose = "{/color}";
    } else if (type === "size") {
      tagOpen = `{size:${value || "16px"}}`;
      tagClose = "{/size}";
    } else if (type === "bg") {
      tagOpen = `{bg:${value || "yellow"}}`;
      tagClose = "{/bg}";
    } else if (type === "anim") {
      tagOpen = `{anim:${value || "bounce"}}`;
      tagClose = "{/anim}";
    } else if (type === "pagebreak") {
      tagOpen = "\n<!-- PAGE_BREAK -->\n";
      tagClose = "";
    }

    const replacement = tagClose 
      ? `${tagOpen}${selectedText}${tagClose}`
      : `${tagOpen}`;

    const newText = text.substring(0, start) + replacement + text.substring(end);
    handleManualContentChange(newText);

    // Re-focus and set selection
    setTimeout(() => {
      textarea.focus();
      const selectionPos = start + tagOpen.length + (selectedText === "text" ? 0 : selectedText.length);
      textarea.setSelectionRange(selectionPos, selectionPos);
    }, 50);
  };

  // Handle client-side media attachments upload
  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingMedia(true);
    const reader = new FileReader();

    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (!result) return;

      let fileType: "image" | "video" | "document" = "document";
      if (file.type.startsWith("image/")) {
        fileType = "image";
      } else if (file.type.startsWith("video/")) {
        fileType = "video";
      }

      const newAttachment: MediaAttachment = {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
        name: file.name,
        url: result,
        type: fileType,
        size: `${(file.size / 1024).toFixed(1)} KB`,
        uploadedAt: new Date().toLocaleDateString()
      };

      setMediaVault(prev => [newAttachment, ...prev]);
      setIsUploadingMedia(false);
      
      alert(lang === "bn" 
        ? `📂 '${file.name}' সফলভাবে আপলোড হয়েছে! এটি এখন নিচের মিডিয়া ভল্ট এ এম্বেড করতে পারবেন।` 
        : `📂 '${file.name}' uploaded successfully! You can now insert it into your chapter from the media vault below.`
      );
    };

    reader.onerror = () => {
      setIsUploadingMedia(false);
      alert("Error reading file.");
    };

    reader.readAsDataURL(file);
  };

  // Handle conversational chat attachments upload
  const handleChatAttachmentUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (!result) return;

      let fileType: "image" | "video" | "document" = "document";
      if (file.type.startsWith("image/")) {
        fileType = "image";
      } else if (file.type.startsWith("video/")) {
        fileType = "video";
      }

      const attachment: MediaAttachment = {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2),
        name: file.name,
        url: result,
        type: fileType,
        size: `${(file.size / 1024).toFixed(1)} KB`,
        uploadedAt: new Date().toLocaleDateString()
      };

      setChatAttachment(attachment);
    };

    reader.onerror = () => {
      alert("Error reading file.");
    };

    reader.readAsDataURL(file);
  };

  // Download ebook as Markdown document
  const handleDownloadMarkdown = () => {
    if (!currentBook) return;
    let mdContent = `# ${currentBook.title}\n\n`;
    mdContent += `**Genre:** ${currentBook.genre}\n`;
    mdContent += `**Language:** ${currentBook.language}\n\n`;
    mdContent += `## Synopsis\n${currentBook.synopsis}\n\n---\n\n`;

    currentBook.chapters.forEach(ch => {
      mdContent += `# Chapter ${ch.chapterNumber}: ${ch.title}\n\n`;
      mdContent += `${ch.content || "*Chapter draft pending.*"}\n\n---\n\n`;
    });

    const blob = new Blob([mdContent], { type: "text/markdown" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${currentBook.title.replace(/\s+/g, "_")}.md`;
    link.click();
  };

  // Download ebook as full-styled offline A4 eBook HTML & PDF
  const handleDownloadHTML = () => {
    if (!currentBook) return;
    downloadBookAsA4HTML(currentBook, lang);
  };

  // Custom cover image management handlers
  const handleUpdateCoverImage = async (url: string) => {
    if (!currentBook) return;
    const updatedBook: Book = {
      ...currentBook,
      coverImageUrl: url,
      coverImageOpacity: currentBook.coverImageOpacity ?? 0.85,
      updatedAt: new Date().toLocaleDateString()
    };
    setCurrentBook(updatedBook);
    await saveBookToFirestore(updatedBook);
  };

  const handleRemoveCoverImage = async () => {
    if (!currentBook) return;
    const updatedBook: Book = {
      ...currentBook,
      coverImageUrl: undefined,
      updatedAt: new Date().toLocaleDateString()
    };
    setCurrentBook(updatedBook);
    await saveBookToFirestore(updatedBook);
  };

  const handleUpdateCoverOpacity = async (opacity: number) => {
    if (!currentBook) return;
    const updatedBook: Book = {
      ...currentBook,
      coverImageOpacity: opacity,
      updatedAt: new Date().toLocaleDateString()
    };
    setCurrentBook(updatedBook);
    await saveBookToFirestore(updatedBook);
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] text-slate-800 flex flex-col relative select-text">
      
      {/* DYNAMIC ANNOUNCEMENT BANNER (CONTROLLED BY ADMIN PANEL) */}
      {siteConfig.announcementActive && siteConfig.announcementText && (
        <div className={`w-full py-1.5 px-4 text-center text-xs font-bold text-white shadow-xs z-50 flex items-center justify-center gap-2 bg-gradient-to-r ${siteConfig.announcementBg || "from-amber-600 to-[#7c2d12]"}`}>
          <Sparkles size={13} className="text-amber-200 animate-pulse" />
          <span>{siteConfig.announcementText}</span>
        </div>
      )}

      {/* HEADER BRANDING */}
      <header className="sticky top-0 bg-white/95 backdrop-blur-md border-b border-[#eadeca] px-3 sm:px-6 py-2.5 z-40 shadow-sm print:hidden space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2.5 cursor-pointer group" onClick={() => setActiveMainTab("editor")}>
            <div className="relative p-2 bg-[#7c2d12] rounded-xl text-amber-50 shadow-md overflow-hidden premium-logo-glow transition-all duration-300 hover:scale-105 active:scale-95">
              {/* Rotating glowing gradient backdrop */}
              <div className="absolute inset-0 bg-gradient-to-r from-amber-400 via-amber-600 to-rose-500 opacity-25 group-hover:opacity-50 animate-spin-slow" />
              <div className="absolute inset-0.5 bg-[#7c2d12] rounded-[10px]" />
              
              <motion.div
                animate={{
                  rotateY: [0, 180, 360],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="relative z-10 flex items-center justify-center"
              >
                <BookMarked size={16} className="text-amber-100" />
              </motion.div>
            </div>
            <div>
              <h1 className="text-sm sm:text-base font-black tracking-tight text-slate-900 flex items-center gap-1 font-sans relative">
                <span className="bg-gradient-to-r from-[#7c2d12] via-[#c2410c] to-[#7c2d12] bg-[length:200%_auto] bg-clip-text text-transparent font-extrabold">
                  {siteConfig.appTitle || t.appTitle}
                </span>
                <span className="text-[8px] bg-amber-100 text-[#7c2d12] border border-amber-200 px-1.5 py-0.2 rounded-full font-black tracking-wider shadow-2xs">PRO</span>
              </h1>
              <p className="text-[8px] sm:text-[9px] text-slate-400 font-bold tracking-wide uppercase">
                {siteConfig.tagline || t.tagline}
              </p>
            </div>
          </div>

          {/* DESKTOP NAV TABS (DESKTOP MODE & WIDE SCREENS) */}
          <nav className="hidden lg:flex items-center space-x-1.5 bg-slate-100/90 p-1.5 rounded-2xl border border-slate-200/80 shadow-inner">
            <button
              onClick={() => setActiveMainTab("editor")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "editor" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Edit3 size={13} className="text-[#7c2d12]" />
              <span>{lang === "bn" ? "বইয়ের এডিটর" : "Book Editor"}</span>
            </button>
            <button
              onClick={() => setActiveMainTab("ai_chat")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "ai_chat" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <MessageSquare size={13} className="text-amber-600" />
              <span className="flex items-center gap-1">
                <span>{lang === "bn" ? "এআই চ্যাট হাব" : "AI Chat"}</span>
                <span className="text-[9px] bg-amber-100 text-amber-900 font-black px-1.5 py-0.2 rounded-md">∞</span >
              </span>
            </button>
            <button
              onClick={() => setActiveMainTab("voice_buddy")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "voice_buddy" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Mic size={13} className="text-emerald-600" />
              <span className="flex items-center gap-1">
                <span>{lang === "bn" ? "জেমিনি লাইভ" : "Gemini Live"}</span>
                <span className="text-[9px] bg-emerald-100 text-emerald-950 font-black px-1.5 py-0.2 rounded-md animate-pulse">Live</span>
              </span>
            </button>
            <button
              onClick={() => setActiveMainTab("pro_voice")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "pro_voice" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Sparkles size={13} className="text-amber-600" />
              <span className="flex items-center gap-1">
                <span>{lang === "bn" ? "প্রো ভয়েস" : "Pro Voice"}</span>
                <span className="text-[9px] bg-amber-100 text-amber-900 font-black px-1.5 py-0.2 rounded-md">3.5 Live</span>
              </span>
            </button>
            <button
              onClick={() => setActiveMainTab("code_board")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "code_board" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Code2 size={13} className="text-blue-600" />
              <span className="flex items-center gap-1">
                <span>{lang === "bn" ? "প্রিভিউ বোর্ড" : "Preview Board"}</span>
                <span className="text-[9px] bg-blue-100 text-blue-900 font-black px-1.5 py-0.2 rounded-md">Dev</span>
              </span>
            </button>
            <button
              onClick={() => setActiveMainTab("code_studio")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "code_studio" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Code2 size={13} className="text-indigo-600" />
              <span className="flex items-center gap-1">
                <span>{lang === "bn" ? "কোড স্টুডিও" : "Code Studio"}</span>
                <span className="text-[9px] bg-indigo-100 text-indigo-900 font-black px-1.5 py-0.2 rounded-md">IDE</span>
              </span>
            </button>
            <button
              onClick={() => setActiveMainTab("mind_matrix")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "mind_matrix" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Network size={13} className="text-purple-600" />
              <span className="flex items-center gap-1">
                <span>{lang === "bn" ? "মাইন্ড ম্যাট্রিক্স" : "Mind Matrix"}</span>
                <span className="text-[9px] bg-purple-100 text-purple-900 font-black px-1.5 py-0.2 rounded-md">AI Plot</span>
              </span>
            </button>
            <button
              onClick={() => setActiveMainTab("learning_chart")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "learning_chart" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <GitFork size={13} className="text-emerald-600" />
              <span className="flex items-center gap-1">
                <span>{lang === "bn" ? "শিখন চার্ট" : "Learning Chart"}</span>
                <span className="text-[9px] bg-emerald-100 text-emerald-900 font-black px-1.5 py-0.2 rounded-md">3D Tree</span>
              </span>
            </button>
            <button
              onClick={() => setActiveMainTab("social")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "social" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Globe size={13} className="text-[#7c2d12]" />
              <span>{lang === "bn" ? "সোশ্যাল গ্যালারি" : "Social Feed"}</span>
            </button>
            <button
              onClick={() => setActiveMainTab("admin")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "admin" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Lock size={13} className="text-[#7c2d12]" />
              <span>{lang === "bn" ? "অ্যাডমিন" : "Admin"}</span>
            </button>
            {currentUser && (
              <button
                onClick={() => {
                  setActiveMainTab("history");
                  fetchUserBooksHistory();
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                  activeMainTab === "history" 
                    ? "nav-tab-3d-active" 
                    : "nav-tab-3d-inactive text-slate-600"
                }`}
              >
                <History size={13} className="text-[#7c2d12]" />
                <span>{lang === "bn" ? "আর্কাইভস" : "History"}</span>
              </button>
            )}
            <button
              onClick={() => setActiveMainTab("settings")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer nav-tab-3d ${
                activeMainTab === "settings" 
                  ? "nav-tab-3d-active" 
                  : "nav-tab-3d-inactive text-slate-600"
              }`}
            >
              <Settings size={13} className="text-[#7c2d12]" />
              <span>{lang === "bn" ? "প্রোফাইল/সেটিংস" : "Profile"}</span>
            </button>

            {/* PRO VIP STORE BUTTON IN DESKTOP NAVBAR */}
            <button
              onClick={() => setIsPremiumStoreOpen(true)}
              className="px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-slate-950 shadow-md shadow-amber-500/20 hover:scale-105 active:scale-95 border border-yellow-300 animate-pulse font-sans"
              title={lang === "bn" ? "প্রো মেম্বারশিপ কিনুন" : "Buy Pro VIP Membership"}
            >
              <Crown size={13} className="text-slate-950 fill-slate-950" />
              <span>{lang === "bn" ? "👑 PRO VIP কিনুন" : "👑 BUY PRO VIP"}</span>
            </button>
          </nav>

          {/* CONTROLS RIGHT: DESKTOP MODE SWITCHER + SYNC + LANG + AUTH */}
          <div className="flex items-center space-x-1.5 sm:space-x-2">
            {/* Quick PRO VIP Trigger Button on Right Bar */}
            <button
              onClick={() => setIsPremiumStoreOpen(true)}
              className="hidden md:flex items-center gap-1 px-3 py-1.5 rounded-xl text-[11px] font-black bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 border border-yellow-400/80 shadow-xs hover:scale-105 active:scale-95 transition cursor-pointer"
              title="PRO Store"
            >
              <Crown size={12} className="fill-slate-950" />
              <span>{lang === "bn" ? "PRO VIP" : "PRO VIP"}</span>
            </button>

            {/* DESKTOP VIEW TOGGLE BUTTON */}
            <button
              onClick={() => setIsDesktopMode(!isDesktopMode)}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 cursor-pointer ${
                isDesktopMode
                  ? "btn-3d-primary"
                  : "btn-3d-secondary"
              }`}
              title={lang === "bn" ? "মোবাইল ও ডেস্কটপ ভিউ সুইচার" : "Mobile / Desktop View Switcher"}
            >
              {isDesktopMode ? <Monitor size={13} /> : <Smartphone size={13} />}
              <span className="whitespace-nowrap font-extrabold">
                {isDesktopMode 
                  ? (lang === "bn" ? "ডেস্কটপ ভিউ" : "Desktop View") 
                  : (lang === "bn" ? "মোবাইল ভিউ" : "Mobile View")
                }
              </span>
            </button>

            {/* Sync status */}
            {currentBook && currentUser && (
              <div className="flex items-center gap-1 text-[10px] bg-emerald-50 text-emerald-800 px-2.5 py-1.5 rounded-xl font-black border border-emerald-300 shadow-2xs">
                <Cloud size={11} className={isSyncingWithDb ? "animate-pulse text-emerald-600" : "text-emerald-600"} />
                <span className="hidden sm:inline">{isSyncingWithDb ? (lang === "bn" ? "সংরক্ষণ হচ্ছে..." : "Syncing...") : (lang === "bn" ? "মেঘে সংরক্ষিত" : "Cloud Saved")}</span>
              </div>
            )}

            {currentBook && activeMainTab === "editor" && (
              <button
                onClick={handleNewBookReset}
                className="px-3 py-1.5 rounded-xl text-[11px] font-black transition whitespace-nowrap cursor-pointer btn-3d-danger"
              >
                {lang === "bn" ? "নতুন বই" : "New Book"}
              </button>
            )}

            <button 
              onClick={() => setLang(lang === "bn" ? "en" : "bn")}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-[11px] font-bold text-slate-700 transition cursor-pointer btn-3d-secondary"
            >
              <Languages size={12} className="text-[#7c2d12]" />
              <span>{lang === "bn" ? "EN" : "বাংলা"}</span>
            </button>

            {/* User Auth controls */}
            {currentUser ? (
              <div className="flex items-center gap-1.5 pl-1.5 border-l border-slate-200">
                <div className="flex flex-col items-end hidden sm:flex">
                  <span className="text-[10px] font-black text-slate-800 line-clamp-1 max-w-[100px]">
                    {currentUser.displayName || currentUser.email?.split("@")[0]}
                  </span>
                </div>
                <button
                  onClick={handleLogout}
                  className="p-2 rounded-xl text-slate-600 hover:text-rose-600 transition cursor-pointer btn-3d-secondary"
                  title={lang === "bn" ? "লগআউট" : "Sign Out"}
                >
                  <LogOut size={14} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setIsSignUp(false);
                  setAuthError("");
                  setShowAuthModal(true);
                }}
                className="px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 cursor-pointer btn-3d-primary"
              >
                <User size={13} />
                <span>{lang === "bn" ? "লগইন" : "Login"}</span>
              </button>
            )}
          </div>
        </div>

        {/* MOBILE HORIZONTAL SCROLLABLE SUB-NAVBAR FOR SMALL SCREENS */}
        <div className="flex lg:hidden items-center gap-1.5 bg-amber-50/80 p-1.5 rounded-2xl border border-amber-200/90 overflow-x-auto scrollbar-none whitespace-nowrap shadow-inner">
          <button
            onClick={() => setActiveMainTab("editor")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "editor" 
                ? "btn-3d-primary" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Edit3 size={12} />
            <span>{lang === "bn" ? "বইয়ের এডিটর" : "Book Editor"}</span>
          </button>

          <button
            onClick={() => setActiveMainTab("ai_chat")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "ai_chat" 
                ? "btn-3d-primary" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <MessageSquare size={12} />
            <span>{lang === "bn" ? "এআই চ্যাট হাব" : "AI Chat"}</span>
          </button>

          <button
            onClick={() => setActiveMainTab("voice_buddy")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "voice_buddy" 
                ? "btn-3d-emerald" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Mic size={12} />
            <span>{lang === "bn" ? "জেমিনি লাইভ" : "Gemini Live"}</span>
          </button>

          <button
            onClick={() => setActiveMainTab("pro_voice")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "pro_voice" 
                ? "btn-3d-primary" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Sparkles size={12} />
            <span>{lang === "bn" ? "প্রো ভয়েস" : "Pro Voice"}</span>
          </button>

          <button
            onClick={() => setActiveMainTab("code_studio")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "code_studio" 
                ? "btn-3d-purple" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Code2 size={12} />
            <span>{lang === "bn" ? "কোড স্টুডিও" : "Code Studio"}</span>
          </button>

          <button
            onClick={() => setActiveMainTab("mind_matrix")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "mind_matrix" 
                ? "btn-3d-purple" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Network size={12} />
            <span>{lang === "bn" ? "মাইন্ড ম্যাট্রিক্স" : "Mind Matrix"}</span>
          </button>

          <button
            onClick={() => setActiveMainTab("social")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "social" 
                ? "btn-3d-primary" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Globe size={12} />
            <span>{lang === "bn" ? "সোশ্যাল গ্যালারি" : "Social Feed"}</span>
          </button>

          <button
            onClick={() => setActiveMainTab("admin")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "admin" 
                ? "btn-3d-primary" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Lock size={12} />
            <span>{lang === "bn" ? "অ্যাডমিন প্যানেল" : "Admin Panel"}</span>
          </button>

          {currentUser && (
            <button
              onClick={() => {
                setActiveMainTab("history");
                fetchUserBooksHistory();
              }}
              className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
                activeMainTab === "history" 
                  ? "btn-3d-primary" 
                  : "btn-3d-secondary text-slate-700"
              }`}
            >
              <History size={12} />
              <span>{lang === "bn" ? "আর্কাইভস" : "Book History"}</span>
            </button>
          )}

          <button
            onClick={() => setActiveMainTab("settings")}
            className={`px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer ${
              activeMainTab === "settings" 
                ? "btn-3d-primary" 
                : "btn-3d-secondary text-slate-700"
            }`}
          >
            <Settings size={12} />
            <span>{lang === "bn" ? "প্রোফাইল/সেটিংস" : "Profile & Settings"}</span>
          </button>

          {/* MOBILE PRO VIP BUTTON */}
          <button
            onClick={() => setIsPremiumStoreOpen(true)}
            className="px-3.5 py-1.5 rounded-xl text-[11px] font-black transition flex items-center gap-1 shrink-0 cursor-pointer bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 shadow-sm border border-yellow-300 animate-pulse font-bold"
          >
            <Crown size={12} className="fill-slate-950" />
            <span>{lang === "bn" ? "👑 PRO VIP কিনুন" : "👑 BUY PRO VIP"}</span>
          </button>
        </div>
      </header>

      {/* DYNAMIC INJECTED SECTIONS (BUILT BY ADMIN AI CODE ARCHITECT WITH LIVE JAVASCRIPT & DOM EXECUTION) */}
      {siteConfig.customWidgets && siteConfig.customWidgets.filter(w => w.active).length > 0 && activeMainTab === "editor" && (
        <div className="w-full max-w-7xl mx-auto px-2 sm:px-4 pt-3 pb-1 space-y-3 font-sans print:hidden">
          <div className="flex items-center justify-between px-1">
            <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1.5">
              <span>✦</span> {lang === "bn" ? "যুক্ত করা লাইভ এআই মডিউল সমূহ" : "Active Injected AI Modules"}
            </span>
            <button
              onClick={() => {
                const updatedWidgets = siteConfig.customWidgets.map(w => ({ ...w, active: false }));
                const newConfig = { ...siteConfig, customWidgets: updatedWidgets };
                setSiteConfig(newConfig);
                localStorage.setItem("lekhok_site_design_config", JSON.stringify(newConfig));
              }}
              className="text-[10px] font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg transition border border-red-200 cursor-pointer"
            >
              {lang === "bn" ? "সব মডিউল বন্ধ / রিমুভ করুন" : "Hide All Injected Modules"}
            </button>
          </div>
          {siteConfig.customWidgets.filter(w => w.active).map((widget) => (
            <div 
              key={widget.id}
              className="bg-white border-2 border-amber-200/90 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3 relative overflow-hidden transition-all duration-300 hover:shadow-md"
            >
              <div className="flex items-center justify-between border-b border-amber-100 pb-2">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 bg-amber-100/70 text-[#7c2d12] rounded-xl text-xs font-black shadow-xs">
                    ✦ {widget.icon || "Sparkles"}
                  </span>
                  <div>
                    <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 line-clamp-1">{widget.title}</h3>
                    {widget.description && (
                      <p className="text-[10px] sm:text-xs text-slate-500 font-medium">{widget.description}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-bold bg-amber-50 text-[#7c2d12] border border-amber-200 px-2 py-0.5 rounded-full shrink-0 font-mono">
                    ● AI Live Module
                  </span>
                  <button
                    onClick={() => {
                      const updatedWidgets = siteConfig.customWidgets.filter(w => w.id !== widget.id);
                      const newConfig = { ...siteConfig, customWidgets: updatedWidgets };
                      setSiteConfig(newConfig);
                      localStorage.setItem("lekhok_site_design_config", JSON.stringify(newConfig));
                    }}
                    className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                    title={lang === "bn" ? "এই সেকশনটি মুছুন" : "Remove section"}
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>

              {widget.customHtml ? (
                <div className="w-full">
                  <LiveDynamicExecutableSandbox htmlCode={widget.customHtml} />
                </div>
              ) : null}
            </div>
          ))}
        </div>
      )}

      {/* CORE WORKSPACE: CHAT (LEFT) & BOOK LAYOUT (RIGHT) */}
      {activeMainTab === "editor" && (
        <div className={`w-full ${isDesktopMode ? "overflow-x-auto pb-6" : ""}`}>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className={`flex-1 w-full max-w-7xl mx-auto px-2 sm:px-4 py-4 sm:py-6 ${
              isDesktopMode
                ? "min-w-[1020px] grid grid-cols-12 gap-6"
                : "grid grid-cols-1 lg:grid-cols-12 gap-6"
            } print:block`}
          >
          
          {/* LEFT COLUMN: CHATGPT CONVERSATIONAL INTERFACE */}
          <div className={`${isDesktopMode ? "col-span-5" : "lg:col-span-5"} flex flex-col h-[calc(100vh-140px)] min-h-[500px] bg-white rounded-2xl border border-[#eae3d2] shadow-sm overflow-hidden print:hidden relative`}>
          
            {/* Dynamic Custom Background Layer (Photo or Video) */}
            {chatBgType !== "none" && chatBgUrl && chatBgUrl.trim() !== "" && (
              <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
                {chatBgType === "video" ? (
                  <video
                    src={chatBgUrl}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                    style={{ opacity: chatBgOpacity }}
                  />
                ) : (
                  <img
                    src={chatBgUrl}
                    alt="Chat Background"
                    className="w-full h-full object-cover"
                    style={{ opacity: chatBgOpacity }}
                    referrerPolicy="no-referrer"
                  />
                )}
                {/* Subtle scrim for readability */}
                <div className="absolute inset-0 bg-white/70 backdrop-blur-[1px]" />
              </div>
            )}

          {/* Chat Settings & Mode Selector header */}
          <div className="bg-[#fdfcf9] border-b border-[#eadeca] p-3 flex items-center justify-between select-none relative z-10">
            <span className="text-[10px] font-extrabold text-[#7c2d12] uppercase tracking-wider flex items-center gap-1.5 font-sans">
              <Sparkles size={11} className="text-[#7c2d12]" />
              {lang === "bn" ? "এআই লেখা স্টাইল" : "AI Writing Style"}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsChatBgModalOpen(true)}
                className={`px-2 py-1 rounded-md text-[9px] font-extrabold transition flex items-center gap-1 border ${
                  chatBgType !== "none"
                    ? "bg-amber-100 text-[#7c2d12] border-amber-300 shadow-2xs"
                    : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50"
                }`}
                title={lang === "bn" ? "চ্যাট ব্যাকগ্রাউন্ড ছবি/ভিডিও পরিবর্তন করুন" : "Set Chat Background Image/Video"}
              >
                <Image size={10} />
                <span>{lang === "bn" ? "ব্যাকগ্রাউন্ড" : "Background"}</span>
              </button>

              <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                <button
                  onClick={() => setWritingSpeedMode("standard")}
                  className={`px-2.5 py-1 rounded-md text-[9px] font-extrabold transition flex items-center gap-1 ${
                    writingSpeedMode === "standard"
                      ? "bg-white text-[#7c2d12] shadow-2xs border border-slate-200/50"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                  title="Generates standard responses quickly"
                >
                  <Zap size={10} />
                  <span>{lang === "bn" ? "সাধারণ স্পিড" : "Standard Speed"}</span>
                </button>
                <button
                  onClick={() => setWritingSpeedMode("extensive")}
                  className={`px-2.5 py-1 rounded-md text-[9px] font-extrabold transition flex items-center gap-1 ${
                    writingSpeedMode === "extensive"
                      ? "bg-white text-emerald-700 shadow-2xs border border-slate-200/50"
                      : "text-slate-500 hover:text-slate-800"
                  }`}
                  title="Deploys advanced, detailed writing guidelines for very thick chapters"
                >
                  <Database size={10} />
                  <span>{lang === "bn" ? "বিস্তারিত মোড (বড় বই)" : "Deep Scribe (Large)"}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Chat Messages Feed */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-transparent relative z-10">
            {hasApiKey === false && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-950 flex flex-col gap-1.5 shadow-sm animate-fade-in">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping" />
                  <ShieldAlert size={15} className="text-rose-600" />
                  <span className="text-xs font-black font-sans">
                    {lang === "bn" ? "GEMINI_API_KEY অনুপস্থিত!" : "GEMINI_API_KEY Missing!"}
                  </span>
                </div>
                <p className="text-[11px] leading-relaxed text-rose-700 font-sans font-medium">
                  {lang === "bn"
                    ? "এআই কল সম্পন্ন করার জন্য অনুগ্রহ করে আপনার স্ক্রিনের উপরের ডানপাশে 'Settings > Secrets' প্যানেলে গিয়ে 'GEMINI_API_KEY' সিক্রেটটি যুক্ত করুন।"
                    : "To generate books and chapters, please configure your 'GEMINI_API_KEY' inside the Settings > Secrets panel of AI Studio."}
                </p>
              </div>
            )}

            {messages.length === 0 ? (
              /* EMPTY STATE TIPS */
              <div className="h-full flex flex-col justify-center items-center text-center p-6 space-y-6">
                <div className="p-4 bg-amber-50 rounded-full text-[#7c2d12] border border-amber-100 relative">
                  <Sparkle className="absolute top-1 right-1 text-amber-500 animate-pulse" size={16} />
                  <BookOpen size={32} />
                </div>
                <div className="space-y-2 max-w-sm">
                  <h3 className="text-sm font-bold text-slate-900 font-sans">{t.emptyChatHeading}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-sans">
                    {t.emptyChatSub}
                  </p>
                </div>

                <div className="w-full space-y-2 max-w-xs pt-4">
                  <div 
                    onClick={() => setUserChatPrompt(lang === "bn" ? "দৈনন্দিন স্পোকেন ইংলিশের জন্য ১০০০ শব্দের একটি পূর্ণাঙ্গ ভোকাবুলারি বই বানিয়ে দাও (উচ্চারণ, অর্থ, উদাহরণ বাক্য ও কুইজ সহ)।" : "Create a 1000-word daily Spoken English vocabulary book with pronunciation, Bengali meaning, example sentences, and practice quizzes.")}
                    className="p-2.5 rounded-xl border border-[#f1ebd9] bg-white hover:bg-amber-50/50 hover:border-amber-300 transition cursor-pointer text-left text-[11px] text-slate-600 leading-normal"
                  >
                    {lang === "bn" ? "💡 'দৈনন্দিন স্পোকেন ইংলিশের ১০০০ শব্দের ভোকাবুলারি বই (অর্থ, উচ্চারণ ও উদাহরণ সহ) বানিয়ে দাও।'" : "💡 'Create a 1000-word Spoken English vocabulary book with meaning & examples.'"}
                  </div>
                  <div 
                    onClick={() => setUserChatPrompt(lang === "bn" ? "সুন্দরবনের গভীরে এক প্রাচীন দুর্গের খোঁজে ৩ অধ্যায়ের একটি রহস্য বাংলা গল্প লিখে দাও।" : "Write a 3-chapter mystery novel about an ancient castle.")}
                    className="p-2.5 rounded-xl border border-[#f1ebd9] bg-white hover:bg-amber-50/50 hover:border-amber-300 transition cursor-pointer text-left text-[11px] text-slate-600 leading-normal"
                  >
                    {lang === "bn" ? "💡 'সুন্দরবনের গভীরে এক প্রাচীন দুর্গের খোঁজে ৩ অধ্যায়ের একটি রহস্য বাংলা উপন্যাস লিখে দাও।'" : "💡 'Write a 3-chapter mystery novel set in the deep Sundarbans.'"}
                  </div>
                  <div 
                    onClick={() => setUserChatPrompt(lang === "bn" ? "দৈনন্দিন জীবনে ধৈর্য ও নৈতিকতার গুরুত্ব নিয়ে ৩ অধ্যায়ের একটি ইসলামিক আত্মউন্নয়ন বই লিখে দাও।" : "Write a 3-chapter Islamic self-help book on patience and moral character.")}
                    className="p-2.5 rounded-xl border border-[#f1ebd9] bg-white hover:bg-amber-50/50 hover:border-amber-300 transition cursor-pointer text-left text-[11px] text-slate-600 leading-normal"
                  >
                    {lang === "bn" ? "💡 'ধৈর্য ও নৈতিকতার গুরুত্ব নিয়ে একটি ইসলামিক আত্মউন্নয়ন বই লিখে দাও।'" : "💡 'Write an Islamic self-help book on patience and moral character.'"}
                  </div>
                </div>
              </div>
            ) : (
              /* MESSAGE FEED */
              messages.map((m) => {
                const isUser = m.role === "user";
                return (
                  <div
                    key={m.id}
                    className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed font-sans shadow-sm ${
                        isUser
                          ? "bg-amber-50 text-slate-900 border border-amber-200 rounded-tr-none"
                          : "bg-white text-slate-800 border border-slate-100 rounded-tl-none whitespace-pre-wrap"
                      }`}
                    >
                      {isUser ? (
                        <div className="space-y-2">
                          {m.attachment && m.attachment.url && m.attachment.url.trim() !== "" && (
                            <div className="mb-2 max-w-sm rounded-lg overflow-hidden border border-amber-200 bg-white p-1">
                              {m.attachment.type === "image" ? (
                                <img 
                                  src={m.attachment.url} 
                                  alt={m.attachment.name || "Attachment"} 
                                  className="max-h-48 w-full object-cover rounded" 
                                  referrerPolicy="no-referrer"
                                />
                              ) : m.attachment.type === "video" ? (
                                <video 
                                  src={m.attachment.url} 
                                  controls 
                                  className="max-h-48 w-full object-cover rounded" 
                                />
                              ) : (
                                <div className="flex items-center gap-2 p-2 text-slate-700 bg-slate-50 rounded">
                                  <FileText size={16} className="text-[#7c2d12]" />
                                  <div className="text-[10px] truncate max-w-[150px]">
                                    <div className="font-bold">{m.attachment.name}</div>
                                    <div className="text-slate-400 font-medium">{m.attachment.size}</div>
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                          <p className="whitespace-pre-wrap">{m.content}</p>
                        </div>
                      ) : (
                        <ReactMarkdown components={markdownComponents}>{m.content}</ReactMarkdown>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            {/* GENERATING LOAD SCREEN (WITH ROTATING QUOTES) */}
            {isGenerating && (
              <div className="flex justify-start w-full">
                <div className="bg-amber-50/50 border border-amber-200 rounded-2xl rounded-tl-none p-4 w-full max-w-[90%] space-y-3.5">
                  <div className="flex items-center justify-between text-[#7c2d12] text-xs font-bold select-none">
                    <div className="flex items-center space-x-2 animate-pulse">
                      <RefreshCw size={12} className="animate-spin" />
                      <span>{t.activeGenerating}</span>
                    </div>
                    {writingSpeedMode === "extensive" && (
                      <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase">
                        Deep Scribe Active
                      </span>
                    )}
                  </div>

                  {/* EXTENSIVE DETAILED WRITING PROGRESS BAR */}
                  {writingSpeedMode === "extensive" && (
                    <div className="space-y-2.5 bg-white border border-slate-100 p-3 rounded-xl shadow-2xs font-sans">
                      <div className="flex justify-between items-center text-[10px] font-extrabold text-slate-700">
                        <span className="text-slate-500 animate-pulse truncate max-w-[180px]">{extensiveStepText || "Initiating chapter framework..."}</span>
                        <span className="text-emerald-600 font-mono text-xs">{extensiveProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200/40">
                        <div 
                          className="bg-emerald-600 h-full rounded-full transition-all duration-300 shadow-xs"
                          style={{ width: `${extensiveProgress}%` }}
                        />
                      </div>
                      <p className="text-[9px] text-slate-400 font-bold leading-normal italic">
                        {lang === "bn" 
                          ? "💡 বিস্তারিত মোডে অধ্যায়টি সম্পূর্ণ গভীর বিবরণ দিয়ে এবং বড় আকারের লেখা হচ্ছে। অনুগ্রহ করে শেষ হওয়া পর্যন্ত অপেক্ষা করুন..." 
                          : "💡 Deep Scribe mode takes slightly longer to bundle detailed narratives, complex dialog structures and large-format chapter content."}
                      </p>
                    </div>
                  )}

                  <div className="border-t border-amber-100/60 pt-2.5 space-y-1">
                    <p className="text-[11px] font-serif italic text-slate-600 leading-relaxed">
                      "{loadingQuotes[loadingQuoteIndex].text}"
                    </p>
                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                      — {loadingQuotes[loadingQuoteIndex].author}
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={chatBottomRef} />
          </div>

          {/* Chat Input Area */}
          <div className="p-3 border-t border-[#eae3d2] bg-white space-y-2">
            
            {/* Quick Conversational Select / Edit shortcut pill row */}
            {currentBook && (
              <div className="space-y-1 bg-amber-50/20 p-2 rounded-xl border border-amber-100">
                <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold px-1 select-none">
                  <span className="text-[#7c2d12] flex items-center gap-1 font-sans">
                    <Sparkles size={11} className="animate-pulse" />
                    {lang === "bn" ? "এআই দিয়ে সংশোধন শর্টকাট" : "Conversational Edit Shortcut"}
                  </span>
                  <span className="text-[9px] text-slate-400 font-medium font-sans">
                    {lang === "bn" ? "ক্লিক করলেই চ্যাটে সিলেক্ট হবে" : "Click to select chapter"}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-0.5 max-w-full no-scrollbar">
                  {currentBook.chapters.map((ch, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setActiveChapterIndex(idx);
                        setPreviewTab("chapters");
                        const editPrompt = lang === "bn"
                          ? `অধ্যায় ${ch.chapterNumber} ("${ch.title}") সংশোধন করো। নির্দেশ: `
                          : `Edit Chapter ${ch.chapterNumber} ("${ch.title}"). My instruction: `;
                        setUserChatPrompt(editPrompt);
                        textareaRef.current?.focus();
                      }}
                      className={`px-2.5 py-1 rounded-lg border text-[10px] font-bold transition shrink-0 flex items-center gap-1 font-sans ${
                        activeChapterIndex === idx
                          ? "bg-amber-100 border-amber-300 text-[#7c2d12]"
                          : "bg-white border-[#ede7db] text-slate-700 hover:bg-slate-50"
                      }`}
                    >
                      <Edit3 size={9} />
                      <span>{lang === "bn" ? `অধ্যায় ${ch.chapterNumber}` : `Ch ${ch.chapterNumber}`}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {chatAttachment && (
              <div className="mx-1 mb-2 flex items-center justify-between bg-amber-50/80 border border-amber-200/60 p-2 rounded-xl text-[10px] font-bold text-[#7c2d12] animate-slideIn select-none font-sans">
                <div className="flex items-center gap-2">
                  <div className="p-1 bg-[#7c2d12]/10 rounded-lg">
                    {chatAttachment.type === "image" ? (
                      <Image size={13} className="text-[#7c2d12]" />
                    ) : chatAttachment.type === "video" ? (
                      <Video size={13} className="text-[#7c2d12]" />
                    ) : (
                      <FileText size={13} className="text-[#7c2d12]" />
                    )}
                  </div>
                  <div className="flex flex-col">
                    <span className="truncate max-w-[180px] text-slate-800">{chatAttachment.name}</span>
                    <span className="text-[8px] text-slate-400 font-medium">({chatAttachment.size})</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setChatAttachment(null)}
                  className="p-1 hover:bg-amber-100/80 rounded-full transition text-[#7c2d12]"
                  title="Remove attachment"
                >
                  ✕
                </button>
              </div>
            )}

            <div className="relative flex items-center bg-[#faf9f5] border border-[#e4dcc9] rounded-xl focus-within:ring-2 focus-within:ring-amber-500/15 focus-within:border-amber-600 transition">
              {/* Plus icon on opposite side of Send button */}
              <button
                type="button"
                onClick={() => chatFileInputRef.current?.click()}
                className="pl-3 pr-1 py-3 text-slate-400 hover:text-[#7c2d12] transition"
                title={lang === "bn" ? "ছবি, ভিডিও বা ডকুমেন্ট যুক্ত করুন" : "Add Image, Video or Document"}
              >
                <PlusCircle size={16} />
              </button>
              <input 
                type="file"
                ref={chatFileInputRef}
                className="hidden"
                accept="image/*,video/*,application/pdf,text/*"
                onChange={handleChatAttachmentUpload}
              />

              <textarea
                ref={textareaRef}
                value={userChatPrompt}
                onChange={(e) => setUserChatPrompt(e.target.value)}
                placeholder={t.placeholder}
                rows={1}
                className="flex-1 bg-transparent px-2.5 py-3 text-xs leading-relaxed text-slate-800 placeholder-slate-400 focus:outline-none resize-none pr-20 min-h-[44px]"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendChatMessage();
                  }
                }}
              />
              <div className="absolute right-2 flex items-center gap-1">
                <button
                  type="button"
                  onClick={toggleChatDictation}
                  className={`p-2 rounded-lg transition shrink-0 cursor-pointer ${
                    isChatDictating 
                      ? "bg-rose-500 text-white animate-pulse shadow-md shadow-rose-500/30" 
                      : "bg-amber-100/80 hover:bg-amber-200 text-[#7c2d12]"
                  }`}
                  title={lang === "bn" ? "ভয়েস দিয়ে লিখুন" : "Dictate via Voice"}
                >
                  <Mic size={14} className={isChatDictating ? "animate-bounce" : ""} />
                </button>
                <button
                  onClick={() => handleSendChatMessage()}
                  disabled={(!userChatPrompt.trim() && !chatAttachment) || isGenerating}
                  className="p-2 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-lg transition disabled:opacity-30 disabled:hover:bg-[#7c2d12] shadow-sm shrink-0 cursor-pointer"
                >
                  <Send size={14} />
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: INTERACTIVE BOOK CANVAS PREVIEW */}
        <div className={`${isDesktopMode ? "col-span-7" : "lg:col-span-7"} flex flex-col space-y-4 print:block print:w-full`}>
          {currentBook ? (
            <div className="space-y-4 print:block">
              
              {/* Dynamic Book Controls Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-[#eae3d2] shadow-sm print:hidden glass-card-3d">
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    onClick={() => setPreviewTab("cover")}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer ${
                      previewTab === "cover" 
                        ? "btn-3d-amber" 
                        : "btn-3d-secondary text-slate-700"
                    }`}
                  >
                    {t.tabCover}
                  </button>
                  <button
                    onClick={() => setPreviewTab("synopsis")}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer ${
                      previewTab === "synopsis" 
                        ? "btn-3d-amber" 
                        : "btn-3d-secondary text-slate-700"
                    }`}
                  >
                    {t.tabOutline}
                  </button>
                  <button
                    onClick={() => setPreviewTab("chapters")}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition cursor-pointer ${
                      previewTab === "chapters" 
                        ? "btn-3d-amber" 
                        : "btn-3d-secondary text-slate-700"
                    }`}
                  >
                    {t.tabChapters}
                  </button>
                </div>

                <div className="flex items-center space-x-2">
                  {/* Publish Toggle Button */}
                  <button
                    onClick={handleTogglePublish}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                      currentBook.published 
                        ? "btn-3d-emerald" 
                        : "btn-3d-secondary text-slate-700"
                    }`}
                    title={lang === "bn" ? "সোশ্যাল গ্যালারিতে প্রকাশ করুন" : "Publish to Social Feed"}
                  >
                    <Globe size={13} className={currentBook.published ? "animate-pulse" : ""} />
                    <span>{currentBook.published ? (lang === "bn" ? "পাবলিশড" : "Published") : (lang === "bn" ? "পাবলিশ করুন" : "Publish")}</span>
                  </button>

                  {/* Dynamic Page Settings Toggle */}
                  <button
                    onClick={() => setIsPrintSettingsOpen(!isPrintSettingsOpen)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer ${
                      isPrintSettingsOpen 
                        ? "btn-3d-primary" 
                        : "btn-3d-secondary text-slate-700"
                    }`}
                    title={lang === "bn" ? "পিডিএফ ও পেইজ সেটআপ সেটিংস" : "PDF & Page Setup"}
                  >
                    <Sliders size={13} />
                    <span>{lang === "bn" ? "ডিজাইন স্টুডিও" : "PDF Settings"}</span>
                  </button>

                  {/* Print / PDF Trigger */}
                  <button
                    onClick={() => window.print()}
                    className="px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer btn-3d-secondary text-slate-800"
                    title={t.downloadPDF}
                  >
                    <Printer size={13} className="text-[#7c2d12]" />
                    <span>{t.downloadPDF}</span>
                  </button>

                  {/* Language Conversion Button */}
                  <button
                    onClick={() => setShowTranslateModal(true)}
                    className="px-3 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 cursor-pointer btn-3d-secondary text-slate-800"
                    title={lang === "bn" ? "বইয়ের ভাষা পরিবর্তন করুন" : "Translate Book Language"}
                  >
                    <Languages size={13} className="text-[#7c2d12]" />
                    <span>{lang === "bn" ? "অনুবাদ" : "Translate"}</span>
                  </button>

                  <div className="h-4 w-[1px] bg-slate-200" />

                  {/* Markdown backup */}
                  <button
                    onClick={handleDownloadMarkdown}
                    className="p-2 rounded-xl text-slate-600 transition cursor-pointer btn-3d-secondary"
                    title={t.downloadMD}
                  >
                    <FileText size={14} />
                  </button>

                  {/* HTML EBook backup */}
                  <button
                    onClick={handleDownloadHTML}
                    className="p-2 rounded-xl text-slate-600 transition cursor-pointer btn-3d-secondary"
                    title={t.downloadHTML}
                  >
                    <Download size={14} />
                  </button>
                </div>
              </div>

              {/* DYNAMIC INJECTED PRINTING STYLE */}
              <style dangerouslySetInnerHTML={{
                __html: `
                  @media print {
                    @page {
                      size: ${pageSize.toLowerCase() === "letter" ? "letter" : pageSize.toLowerCase() === "a5" ? "A5" : "A4"};
                      margin: ${printMargin === "narrow" ? "1.2cm" : printMargin === "wide" ? "3.2cm" : "2.2cm"} !important;
                    }
                    #print-book-wrapper {
                      font-size: ${printFontSize === "sm" ? "13px" : printFontSize === "lg" ? "18px" : "15px"} !important;
                    }
                    .print-footer-running {
                      display: ${showPageNumbers ? "flex !important" : "none !important"};
                    }
                  }
                `
              }} />

              {/* PDF & PRINT DESIGN SETUP STUDIO */}
              {isPrintSettingsOpen && (
                <div className="bg-white rounded-2xl border-2 border-amber-200 p-5 shadow-sm space-y-4 font-sans animate-fadeIn print:hidden">
                  <div className="flex items-center justify-between border-b border-amber-100 pb-2.5">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-[#7c2d12] rounded-lg text-amber-50 shadow-sm">
                        <Sliders size={14} />
                      </div>
                      <div>
                        <h3 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">
                          {lang === "bn" ? "পিডিএফ পেইজ সেটআপ ও বুক ডিজাইন স্টুডিও" : "PDF Page Setup & Book Design Studio"}
                        </h3>
                        <p className="text-[10px] text-slate-500 font-medium">
                          {lang === "bn" ? "বই ডাউনলোডের আগে সাইজ, মার্জিন ও ফন্ট কাস্টমাইজ করুন" : "Customize sizing, margins, and page layouts before downloading"}
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setIsPrintSettingsOpen(false)}
                      className="text-slate-400 hover:text-slate-600 text-xs font-bold px-2 py-1"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
                    {/* Page Size */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-[#7c2d12] block">
                        {lang === "bn" ? "📄 পেইজের মাপ (Page Size)" : "📄 Page Size"}
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(["A4", "LETTER", "A5"] as const).map((sz) => (
                          <button
                            key={sz}
                            onClick={() => setPageSize(sz)}
                            className={`py-2 px-1 rounded-xl border text-[10px] font-bold transition flex flex-col items-center justify-center gap-1 shrink-0 ${
                              pageSize === sz
                                ? "bg-amber-50 border-amber-400 text-[#7c2d12] ring-2 ring-amber-500/10"
                                : "bg-white border-[#eadeca]/80 text-slate-600 hover:bg-slate-50"
                            }`}
                          >
                            <span className="text-xs">
                              {sz === "A4" ? "📐 A4" : sz === "LETTER" ? "🇺🇸 Ltr" : "📖 A5"}
                            </span>
                            <span className="text-[8px] text-slate-400">
                              {sz === "A4" ? "21 x 29.7cm" : sz === "LETTER" ? "8.5 x 11in" : "14.8 x 21cm"}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Margin Size */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-[#7c2d12] block">
                        {lang === "bn" ? "📏 পেইজ মার্জিন (Margins)" : "📏 Margins"}
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(["normal", "narrow", "wide"] as const).map((m) => (
                          <button
                            key={m}
                            onClick={() => setPrintMargin(m)}
                            className={`py-2 px-1 rounded-xl border text-[10px] font-bold transition flex flex-col items-center justify-center gap-1 ${
                              printMargin === m
                                ? "bg-amber-50 border-amber-400 text-[#7c2d12] ring-2 ring-amber-500/10"
                                : "bg-white border-[#eadeca]/80 text-slate-600 hover:bg-slate-50"
                            }`}
                          >
                            <span className="capitalize">
                              {m === "normal" ? "Normal" : m === "narrow" ? "Narrow" : "Wide"}
                            </span>
                            <span className="text-[8px] text-slate-400">
                              {m === "normal" ? "2 cm" : m === "narrow" ? "1 cm" : "3 cm"}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Font Size Scaling */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-[#7c2d12] block">
                        {lang === "bn" ? "✍️ ফন্ট সাইজ (Font Size)" : "✍️ Font Size"}
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(["sm", "md", "lg"] as const).map((sz) => (
                          <button
                            key={sz}
                            onClick={() => setPrintFontSize(sz)}
                            className={`py-2 px-1 rounded-xl border text-[10px] font-bold transition flex flex-col items-center justify-center gap-1 ${
                              printFontSize === sz
                                ? "bg-amber-50 border-amber-400 text-[#7c2d12] ring-2 ring-amber-500/10"
                                : "bg-white border-[#eadeca]/80 text-slate-600 hover:bg-slate-50"
                            }`}
                          >
                            <span className="uppercase">{sz}</span>
                            <span className="text-[8px] text-slate-400">
                              {sz === "sm" ? "13px" : sz === "md" ? "15px" : "18px"}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Page Numbers */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold uppercase tracking-wider text-[#7c2d12] block">
                        {lang === "bn" ? "🔢 পেইজ নাম্বার (Page Numbers)" : "🔢 Page Numbers"}
                      </label>
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          onClick={() => setShowPageNumbers(true)}
                          className={`py-2 px-1 rounded-xl border text-[10px] font-bold transition ${
                            showPageNumbers
                              ? "bg-amber-50 border-amber-400 text-[#7c2d12] ring-2 ring-amber-500/10"
                              : "bg-white border-[#eadeca]/80 text-slate-600 hover:bg-slate-50"
                          }`}
                        >
                          {lang === "bn" ? "চালু (On)" : "On"}
                        </button>
                        <button
                          onClick={() => setShowPageNumbers(false)}
                          className={`py-2 px-1 rounded-xl border text-[10px] font-bold transition ${
                            !showPageNumbers
                              ? "bg-amber-50 border-amber-400 text-[#7c2d12] ring-2 ring-amber-500/10"
                              : "bg-white border-[#eadeca]/80 text-slate-600 hover:bg-slate-50"
                          }`}
                        >
                          {lang === "bn" ? "বন্ধ (Off)" : "Off"}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#faf9f5] border border-amber-100 p-3 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 text-[10px] text-slate-600">
                    <div className="flex items-center gap-1.5 font-medium leading-relaxed">
                      <span>💡</span>
                      <span>
                        {lang === "bn" 
                          ? "আপনার সিলেক্ট করা সাইজ ও ডিজাইন সরাসরি পিডিএফ প্রিন্ট ও ডাউলোডে কাজ করবে। ব্রাউজার প্রিন্ট ডায়ালগে Background Graphics অবশ্যই চালু রাখুন।"
                          : "Your selected sizing & styles are automatically injected. Make sure 'Background Graphics' is checked in your browser's Print window."}
                      </span>
                    </div>
                    <button
                      onClick={() => window.print()}
                      className="px-4 py-2 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-[10.5px] font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer shrink-0"
                    >
                      <Printer size={12} />
                      <span>{lang === "bn" ? "পিডিএফ প্রিন্ট / ডাউনলোড" : "Print to PDF Now"}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* BOOK PHYSICAL VIEWPORT CANVAS */}
              <div className="bg-white rounded-2xl border border-[#eae3d2] shadow-sm p-6 sm:p-10 relative overflow-hidden print:border-none print:shadow-none print:p-0">
                
                {/* 1. COVER CANVAS VIEW */}
                {previewTab === "cover" && (
                  <div className="space-y-6">
                    {/* Interactive Cover Page Studio Launcher */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-amber-100/90 via-orange-50/80 to-amber-100/90 p-4 rounded-2xl border-2 border-amber-300 shadow-sm">
                      <div className="flex items-center gap-3">
                        <span className="p-2.5 bg-gradient-to-br from-amber-600 to-[#7c2d12] text-white rounded-xl shadow-md text-sm font-black">
                          🎨
                        </span>
                        <div>
                          <h4 className="text-xs sm:text-sm font-extrabold text-[#7c2d12]">
                            {lang === "bn" ? "ইন্টারেক্টিভ কভার পেজ স্টুডিও (Cover Studio)" : "Interactive Book Cover Page Studio"}
                          </h4>
                          <p className="text-[10px] sm:text-xs text-slate-600 font-medium">
                            {lang === "bn" ? "নিজের পছন্দমতো ফন্ট, থিম, কালার, ব্যাজ ও ফ্রেম দিয়ে বইয়ের কভার ডিজাইন করুন" : "Customize fonts, palettes, badges, layout and 3D overlays"}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => setIsCoverStudioOpen(true)}
                        className="px-4 py-2 bg-gradient-to-r from-amber-600 to-[#7c2d12] hover:from-amber-500 hover:to-[#63220c] text-white text-xs font-black rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <Edit3 size={13} />
                        <span>{lang === "bn" ? "কভার কাস্টমাইজ করুন" : "Open Cover Studio"}</span>
                      </button>
                    </div>

                    <AnimatedCoverCanvas
                      title={currentBook.title}
                      genre={currentBook.genre}
                      authorName={currentBook.creatorName || (currentUser?.displayName || "Lekhok AI Author")}
                      synopsis={currentBook.synopsis}
                      baseGradient={currentBook.coverColor || COVER_GRADIENTS[0].css}
                      coverImageUrl={currentBook.coverImageUrl}
                      coverImageOpacity={currentBook.coverImageOpacity ?? 0.85}
                      onUploadCoverImage={handleUpdateCoverImage}
                      onRemoveCoverImage={handleRemoveCoverImage}
                      onUpdateCoverOpacity={handleUpdateCoverOpacity}
                      lang={lang}
                    />

                    {/* Meta style description below the canvas */}
                    {currentBook.suggestedCoverStyle && (
                      <div className="p-4 bg-[#fbfbf9] rounded-xl border border-[#ede7db] font-serif text-slate-600 text-xs italic leading-relaxed">
                        <span className="font-sans font-bold text-[#7c2d12] uppercase tracking-wide text-[10px] block not-italic mb-1">
                          {t.coverConcept}
                        </span>
                        {currentBook.suggestedCoverStyle}
                      </div>
                    )}
                  </div>
                )}

                {/* 2. SYNOPSIS & TABLE OF CONTENTS VIEW */}
                {previewTab === "synopsis" && (
                  <div className="space-y-6 font-serif">
                    <div className="border-b border-[#f3efe6] pb-4">
                      <h2 className="text-2xl font-extrabold font-sans text-slate-900 leading-snug">
                        {currentBook.title}
                      </h2>
                      <div className="flex flex-wrap gap-2 mt-2 text-[10px] font-sans font-bold uppercase tracking-wider text-[#7c2d12]">
                        <span>{t.genre}: {currentBook.genre}</span>
                        <span>•</span>
                        <span>{t.language}: {currentBook.language}</span>
                        <span>•</span>
                        <span>{t.chaptersCount}: {currentBook.chapters.length}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h3 className="text-xs font-sans font-extrabold uppercase tracking-widest text-slate-400">
                        {lang === "bn" ? "ভূমিকা ও সারসংক্ষেপ" : "Book Synopsis"}
                      </h3>
                      <p className="text-sm leading-relaxed text-justify text-slate-700 whitespace-pre-line bg-[#faf9f6] p-4 rounded-xl border border-[#eae3d2] italic">
                        "{currentBook.synopsis}"
                      </p>
                    </div>

                    <div className="space-y-3">
                      <h3 className="text-xs font-sans font-extrabold uppercase tracking-widest text-slate-400">
                        {lang === "bn" ? "সূচিপত্র" : "Table of Chapters"}
                      </h3>
                      
                      <div className="space-y-2 font-sans">
                        {currentBook.chapters.map((ch, idx) => (
                          <div
                            key={idx}
                            onClick={() => {
                              setActiveChapterIndex(idx);
                              setPreviewTab("chapters");
                            }}
                            className="p-3 bg-white hover:bg-amber-50/40 border border-[#ede7db] hover:border-amber-300 rounded-xl transition cursor-pointer flex items-start gap-3 text-xs"
                          >
                            <span className="w-5 h-5 rounded-full bg-[#7c2d12] text-amber-50 flex items-center justify-center font-bold shrink-0 text-[10px]">
                              {ch.chapterNumber}
                            </span>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-bold text-slate-900 truncate">{ch.title}</h4>
                              <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                                {ch.summary}
                              </p>
                            </div>
                            {ch.content ? (
                              <span className="text-[9px] bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-bold shrink-0">
                                {lang === "bn" ? "পাশ্চাত্যে সম্পূর্ণ" : "Written"}
                              </span>
                            ) : (
                              <span className="text-[9px] bg-slate-100 text-slate-500 px-2 py-0.5 rounded shrink-0 font-medium">
                                {lang === "bn" ? "অপেক্ষমান" : "Pending"}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. DETAILED CHAPTER MANUSCRIPT PAGE */}
                {previewTab === "chapters" && (
                  <div className="space-y-6">
                    
                    {/* Chapter Selector Dropdown */}
                    <div className="flex items-center justify-between gap-4 border-b border-[#f3efe6] pb-4 print:hidden">
                      <div className="flex items-center space-x-1">
                        <button
                          disabled={activeChapterIndex === 0}
                          onClick={() => setActiveChapterIndex(prev => prev - 1)}
                          className="p-1 hover:bg-slate-50 disabled:opacity-30 rounded transition"
                        >
                          <ChevronLeft size={18} />
                        </button>
                        
                        <select
                          value={activeChapterIndex}
                          onChange={(e) => {
                            setActiveChapterIndex(Number(e.target.value));
                            setEditorMode("read");
                          }}
                          className="bg-[#faf9f5] border border-[#e4dcc9] rounded-lg px-2.5 py-1 text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                        >
                          {currentBook.chapters.map((ch, idx) => (
                            <option key={idx} value={idx}>
                              {lang === "bn" ? `অধ্যায় ${ch.chapterNumber}: ${ch.title}` : `Chapter ${ch.chapterNumber}: ${ch.title}`}
                            </option>
                          ))}
                        </select>

                        <button
                          disabled={activeChapterIndex === currentBook.chapters.length - 1}
                          onClick={() => setActiveChapterIndex(prev => prev + 1)}
                          className="p-1 hover:bg-slate-50 disabled:opacity-30 rounded transition"
                        >
                          <ChevronRight size={18} />
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5 flex-wrap">
                        {/* Auto Write All Chapters */}
                        <button
                          onClick={() => handleAutoWriteAllChapters()}
                          disabled={isBatchWriting}
                          className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white text-[10px] font-extrabold shadow-xs transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                          title="Auto generate all book chapters in sequence"
                        >
                          <Sparkles size={11} className={isBatchWriting ? "animate-spin" : ""} />
                          <span>{isBatchWriting ? (lang === "bn" ? "লিখছে..." : "Writing...") : (lang === "bn" ? "⚡ সব অধ্যায় রচনা" : "⚡ Auto-Write All")}</span>
                        </button>

                        {/* Media & 3D Insert Modal Trigger */}
                        <button
                          onClick={() => setIsMediaInsertModalOpen(true)}
                          className="px-2.5 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-[#7c2d12] text-[10px] font-extrabold shadow-xs transition flex items-center gap-1 cursor-pointer"
                          title="Insert 3D interactive models, videos, photos, or diagrams"
                        >
                          <Sparkles size={11} className="text-[#7c2d12]" />
                          <span>{lang === "bn" ? "🖼️ মিডিয়া ও ৩ডি" : "🖼️ Media & 3D"}</span>
                        </button>

                        {/* Read/Edit Toggle */}
                        <div className="flex bg-[#faf9f5] border border-[#e4dcc9] rounded-lg p-0.5 shrink-0">
                          <button
                            onClick={() => setEditorMode("read")}
                            className={`px-2.5 py-1 rounded text-[10px] font-extrabold transition ${
                              editorMode === "read" ? "bg-white text-[#7c2d12] shadow-sm" : "text-slate-500"
                            }`}
                          >
                            <Eye size={11} className="inline mr-1" />
                            {t.modeRead}
                          </button>
                          <button
                            onClick={() => setEditorMode("edit")}
                            className={`px-2.5 py-1 rounded text-[10px] font-extrabold transition ${
                              editorMode === "edit" ? "bg-white text-[#7c2d12] shadow-sm" : "text-slate-500"
                            }`}
                          >
                            <Edit3 size={11} className="inline mr-1" />
                            {t.modeEdit}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Batch Generation Active Banner */}
                    {isBatchWriting && (
                      <div className="p-3 bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-xl space-y-2 font-sans animate-pulse shadow-sm">
                        <div className="flex items-center justify-between text-xs font-bold text-amber-900">
                          <div className="flex items-center gap-2">
                            <RefreshCw size={13} className="animate-spin text-amber-700" />
                            <span>{batchStatusText}</span>
                          </div>
                          <button
                            onClick={handleCancelAutoWrite}
                            className="px-2.5 py-0.5 bg-rose-500 hover:bg-rose-600 text-white rounded-md text-[10px] font-bold shadow-xs cursor-pointer"
                          >
                            {lang === "bn" ? "থামান" : "Stop"}
                          </button>
                        </div>
                        <div className="w-full bg-amber-200 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-[#7c2d12] h-full rounded-full transition-all duration-300"
                            style={{ width: `${batchProgress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {/* Chapter Title & Header */}
                    <div className="text-center space-y-2 border-b border-[#fcfaf7] pb-4">
                      <span className="text-[10px] uppercase font-bold tracking-widest text-[#7c2d12] font-sans">
                        Chapter {currentBook.chapters[activeChapterIndex]?.chapterNumber}
                      </span>
                      <h2 className="text-2xl font-bold font-serif text-slate-900">
                        {currentBook.chapters[activeChapterIndex]?.title}
                      </h2>
                    </div>

                    {/* Integrated Chapter Live Code Preview Board (Only for coding content or coding books) */}
                    <ChapterCodePreviewBoard 
                      lang={lang} 
                      chapterContent={currentBook.chapters[activeChapterIndex]?.content || ""}
                      bookGenre={currentBook.genre || ""}
                      bookTitle={currentBook.title || ""}
                    />

                    {/* Render read / edit manuscript area */}
                    {editorMode === "read" && currentBook.chapters[activeChapterIndex]?.content && (
                      <div className="space-y-4">
                        {/* Interactive Text-To-Speech (Audiobook Player) */}
                        <TTSAudioPlayer
                          text={currentBook.chapters[activeChapterIndex]?.content || ""}
                          title={currentBook.chapters[activeChapterIndex]?.title || ""}
                          chapterNumber={currentBook.chapters[activeChapterIndex]?.chapterNumber || 1}
                          language={currentBook.language || "Bengali"}
                          lang={lang}
                        />

                        <div className="flex flex-wrap justify-between items-center bg-[#fcfaf7] border border-[#f0ebde] p-3 rounded-xl mb-5 gap-3 font-sans">
                          <div className="text-[11px] text-slate-500 font-medium">
                            {lang === "bn" ? "💡 যেকোনো অংশ এডিট করতে পাশের বাটনটি চাপুন অথবা এডিটর মোড অন করুন।" : "💡 Want to edit this? Use the buttons or switch to Editor Mode."}
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => {
                                const editPrompt = lang === "bn"
                                  ? `অধ্যায় ${currentBook.chapters[activeChapterIndex].chapterNumber} ("${currentBook.chapters[activeChapterIndex].title}") সংশোধন করো। নির্দেশ: `
                                  : `Edit Chapter ${currentBook.chapters[activeChapterIndex].chapterNumber} ("${currentBook.chapters[activeChapterIndex].title}"). My instruction: `;
                                setUserChatPrompt(editPrompt);
                                textareaRef.current?.focus();
                                // Scroll chat to view if on smaller devices
                                document.querySelector("textarea")?.scrollIntoView({ behavior: "smooth" });
                              }}
                              className="px-2.5 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-[#7c2d12] text-[10px] font-bold transition flex items-center gap-1 shadow-xs cursor-pointer"
                            >
                              <Sparkles size={11} className="text-[#7c2d12]" />
                              <span>{lang === "bn" ? "এআই দিয়ে সংশোধন" : "Edit with AI"}</span>
                            </button>
                            <button
                              onClick={() => setEditorMode("edit")}
                              className="px-2.5 py-1 rounded-lg bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-[10px] font-bold transition flex items-center gap-1 shadow-xs cursor-pointer"
                            >
                              <Edit3 size={11} />
                              <span>{lang === "bn" ? "নিজে লিখুন" : "Manual Edit"}</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {editorMode === "read" ? (
                      <div className="prose prose-slate max-w-none text-justify font-serif text-sm leading-relaxed min-h-[220px]">
                        {currentBook.chapters[activeChapterIndex]?.content ? (
                          <div className="markdown-book-content space-y-4">
                            {/* PAGINATED RENDER */}
                            {(() => {
                              const pages = paginateChapterContent(currentBook.chapters[activeChapterIndex].content || "");
                              return (
                                <>
                                  <ReadingAnalyticsBar
                                    currentChapterContent={currentBook.chapters[activeChapterIndex]?.content || ""}
                                    chapterNumber={currentBook.chapters[activeChapterIndex]?.chapterNumber || 1}
                                    totalChapters={currentBook.chapters.length}
                                    lang={lang}
                                  />

                                  <ReactMarkdown components={markdownComponents}>
                                    {pages[activePageIndex] || ""}
                                  </ReactMarkdown>

                                  {/* Virtual Page Selector */}
                                  {pages.length > 1 && (
                                    <div className="flex items-center justify-between border-t border-[#f1ebd9] pt-4 mt-8 font-sans print:hidden select-none">
                                      <button
                                        disabled={activePageIndex === 0}
                                        onClick={() => setActivePageIndex(p => Math.max(0, p - 1))}
                                        className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 disabled:opacity-40 text-xs font-bold text-[#7c2d12] rounded-lg border border-amber-200 transition flex items-center gap-1 cursor-pointer"
                                      >
                                        <ChevronLeft size={13} />
                                        <span>{lang === "bn" ? "পূর্ববর্তী পেইজ" : "Prev Page"}</span>
                                      </button>
                                      <span className="text-xs text-slate-500 font-extrabold font-mono tracking-wide bg-amber-50 border border-amber-100 px-3 py-1 rounded-full">
                                        {lang === "bn" ? `পৃষ্ঠা ${activePageIndex + 1} / ${pages.length}` : `Page ${activePageIndex + 1} of ${pages.length}`}
                                      </span>
                                      <button
                                        disabled={activePageIndex >= pages.length - 1}
                                        onClick={() => setActivePageIndex(p => Math.min(pages.length - 1, p + 1))}
                                        className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 disabled:opacity-40 text-xs font-bold text-[#7c2d12] rounded-lg border border-amber-200 transition flex items-center gap-1 cursor-pointer"
                                      >
                                        <span>{lang === "bn" ? "পরবর্তী পেইজ" : "Next Page"}</span>
                                        <ChevronRight size={13} />
                                      </button>
                                    </div>
                                  )}
                                </>
                              );
                            })()}
                          </div>
                        ) : (
                          <div className="text-center py-12 px-6 bg-[#faf9f5]/80 rounded-2xl border border-[#eadecb] max-w-lg mx-auto space-y-5 shadow-xs font-sans">
                            <div className="inline-flex p-4 bg-amber-50 rounded-2xl border border-amber-200/60 text-[#7c2d12] shadow-xs">
                              {isGeneratingChapter && generatingChapterNumber === currentBook.chapters[activeChapterIndex]?.chapterNumber ? (
                                <RefreshCw size={28} className="animate-spin text-[#7c2d12]" />
                              ) : (
                                <BookOpen size={28} className="text-[#7c2d12]" />
                              )}
                            </div>
                            <div className="space-y-2 max-w-sm mx-auto">
                              <h3 className="text-sm font-black text-slate-800">
                                {lang === "bn" ? "📝 এই অধ্যায়টি এখনও ড্রাফট করা হয়নি" : "📝 This Chapter Draft is Empty"}
                              </h3>
                              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                                {lang === "bn" 
                                  ? "বইটির পেশাদার মান ও চরম বিশদ বিবরণ নিশ্চিত করতে প্রতিটি অধ্যায়কে আলাদাভাবে রচনা করা হয়। নিচের বাটনে ক্লিক করে এআই-কে দিয়ে এই অধ্যায়টি অত্যন্ত দীর্ঘ ও আকর্ষণীয় করে তৈরি করুন।" 
                                  : "To guarantee exceptional word counts, structured step-by-step detail, and professional syntax, each chapter is created individually. Click below to write this chapter now."}
                              </p>
                            </div>

                            {/* Preference Status Badges */}
                            <div className="bg-white/80 border border-[#eadecb]/50 p-3 rounded-xl grid grid-cols-2 gap-2 text-left max-w-md mx-auto">
                              <div>
                                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">{lang === "bn" ? "টোন বা ভয়েস" : "Writing Tone"}</span>
                                <span className="text-[10px] font-extrabold text-[#7c2d12] line-clamp-1">{preferredTone}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block">{lang === "bn" ? "লেখার শৈলী" : "Writing Style"}</span>
                                <span className="text-[10px] font-extrabold text-[#7c2d12] line-clamp-1">{preferredStyle}</span>
                              </div>
                            </div>

                            {isGeneratingChapter && generatingChapterNumber === currentBook.chapters[activeChapterIndex]?.chapterNumber ? (
                              <div className="space-y-3">
                                <p className="text-xs font-bold text-amber-800 animate-pulse flex items-center justify-center gap-1.5">
                                  <span>{lang === "bn" ? "এআই অধ্যায়টি রচনা করছে... অনুগ্রহ করে অপেক্ষা করুন..." : "AI Scriptor is writing detailed chapter... Please wait..."}</span>
                                </p>
                                <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden border border-slate-200">
                                  <div className="bg-[#7c2d12] h-full rounded-full animate-pulse" style={{ width: "70%" }}></div>
                                </div>
                                <span className="text-[9px] text-slate-400 font-semibold block">{lang === "bn" ? "সাধারণত ৩০ থেকে ৪৫ সেকেন্ড সময় লাগতে পারে।" : "Takes around 30-45 seconds for a complete highly detailed chapter."}</span>
                              </div>
                            ) : (
                              <button
                                onClick={() => writeChapterWithAI(currentBook.chapters[activeChapterIndex].chapterNumber)}
                                disabled={isGeneratingChapter}
                                className="w-full max-w-xs py-3 px-5 bg-[#7c2d12] hover:bg-[#62210b] disabled:opacity-50 text-amber-50 text-xs font-bold rounded-xl transition shadow-md hover:shadow-lg flex items-center justify-center gap-2 mx-auto cursor-pointer"
                              >
                                <Sparkles size={14} />
                                <span>{lang === "bn" ? "এআই দিয়ে অধ্যায়টি সম্পূর্ণ লিখুন" : "Draft Complete Chapter with AI"}</span>
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-4 font-sans print:hidden">
                        {/* STYLE TOOLBAR */}
                        <div className="flex flex-wrap items-center gap-2 bg-[#fcfaf7] border border-[#e4dcc9] p-2.5 rounded-xl text-xs font-bold select-none">
                          <span className="text-slate-500 text-[9px] font-extrabold uppercase mr-1">{lang === "bn" ? "স্টাইল:" : "Style:"}</span>
                          
                          {/* Color Select */}
                          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1 shadow-2xs">
                            <span className="text-[9px] text-slate-400 font-bold uppercase">Color:</span>
                            <select 
                              onChange={(e) => insertFormattingTag("color", e.target.value)}
                              className="bg-transparent text-xs font-extrabold outline-none cursor-pointer text-[#7c2d12]"
                              defaultValue="#7c2d12"
                            >
                              <option value="#7c2d12">Sienna Red</option>
                              <option value="#ef4444">Red</option>
                              <option value="#f59e0b">Amber</option>
                              <option value="#10b981">Emerald</option>
                              <option value="#3b82f6">Royal Blue</option>
                              <option value="#6366f1">Indigo</option>
                              <option value="#a855f7">Purple</option>
                              <option value="#090d16">Midnight</option>
                            </select>
                          </div>

                          {/* Font Size */}
                          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1 shadow-2xs">
                            <span className="text-[9px] text-slate-400 font-bold uppercase">Size:</span>
                            <select 
                              onChange={(e) => insertFormattingTag("size", e.target.value)}
                              className="bg-transparent text-xs font-extrabold outline-none cursor-pointer text-[#7c2d12]"
                              defaultValue="16px"
                            >
                              <option value="12px">Small</option>
                              <option value="16px">Normal</option>
                              <option value="20px">Subhead</option>
                              <option value="26px">Heading</option>
                              <option value="36px">Huge Title</option>
                            </select>
                          </div>

                          {/* Text Highlight / BG */}
                          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1 shadow-2xs">
                            <span className="text-[9px] text-slate-400 font-bold uppercase">BG:</span>
                            <select 
                              onChange={(e) => insertFormattingTag("bg", e.target.value)}
                              className="bg-transparent text-xs font-extrabold outline-none cursor-pointer text-[#7c2d12]"
                              defaultValue="yellow"
                            >
                              <option value="yellow">Yellow</option>
                              <option value="green">Green</option>
                              <option value="blue">Blue</option>
                              <option value="pink">Pink</option>
                            </select>
                          </div>

                          {/* Animations */}
                          <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg px-2.5 py-1 shadow-2xs">
                            <span className="text-[9px] text-slate-400 font-bold uppercase">Anim:</span>
                            <select 
                              onChange={(e) => insertFormattingTag("anim", e.target.value)}
                              className="bg-transparent text-xs font-extrabold outline-none cursor-pointer text-[#7c2d12]"
                              defaultValue="bounce"
                            >
                              <option value="none">None</option>
                              <option value="bounce">Bounce</option>
                              <option value="glow">Glow</option>
                              <option value="wave">Wave</option>
                              <option value="wiggle">Wiggle</option>
                            </select>
                          </div>

                          {/* Page Break */}
                          <button
                            onClick={() => insertFormattingTag("pagebreak")}
                            className="px-2.5 py-1 bg-amber-50 border border-amber-200 hover:bg-amber-100 text-[#7c2d12] rounded-lg text-[10px] font-extrabold shadow-2xs transition cursor-pointer"
                            title="Insert Page Break"
                          >
                            + Page Break
                          </button>
                        </div>

                        {/* MEDIA VAULT ATTACHMENT BOX */}
                        <div className="bg-[#fdfcf9] border border-[#e4dcc9] rounded-xl p-3.5 space-y-3.5 select-none">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-extrabold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                              <FileUp size={13} className="text-[#7c2d12]" />
                              {lang === "bn" ? "মিডিয়া ভল্ট (সংযুক্ত ফাইল)" : "Media Vault Attachments"}
                            </span>
                            <label className="px-3 py-1.5 bg-[#7c2d12] hover:bg-[#63220c] text-amber-50 rounded-lg text-[10px] font-extrabold cursor-pointer transition flex items-center gap-1 shadow-xs">
                              <Plus size={11} />
                              <span>{lang === "bn" ? "ফাইল যোগ করুন" : "Upload File"}</span>
                              <input 
                                type="file" 
                                accept="image/*,video/*,application/pdf"
                                onChange={handleMediaUpload}
                                className="hidden" 
                              />
                            </label>
                          </div>

                          {/* Media list & previews */}
                          {currentBook?.mediaAttachments && currentBook.mediaAttachments.length > 0 ? (
                            <div className="flex flex-wrap gap-2.5 max-h-[140px] overflow-y-auto p-1 bg-white border border-[#eadeca]/60 rounded-lg">
                              {currentBook.mediaAttachments.map((m: any, idx: number) => (
                                <div 
                                  key={idx} 
                                  onClick={() => {
                                    // Insert markdown embed tag into direct editor!
                                    const embedTag = m.type === "image" 
                                      ? `![${m.name}](${m.url})` 
                                      : m.type === "video" 
                                      ? `![video:${m.name}](${m.url})` 
                                      : `![document:${m.name}](${m.url})`;
                                    
                                    const textarea = textareaRef.current;
                                    if (textarea) {
                                      const start = textarea.selectionStart;
                                      const text = textarea.value;
                                      const newText = text.substring(0, start) + `\n${embedTag}\n` + text.substring(start);
                                      handleManualContentChange(newText);
                                    }
                                  }}
                                  className="group relative flex items-center gap-2 border border-slate-200 hover:border-amber-400 bg-slate-50 hover:bg-amber-50/20 p-2 rounded-lg text-[10px] font-bold cursor-pointer transition shrink-0 max-w-[200px]"
                                  title="Click to insert reference tag"
                                >
                                  {m.type === "image" && m.url && m.url.trim() !== "" ? (
                                    <img src={m.url} alt={m.name || "Media"} className="w-8 h-8 rounded-md object-cover border border-slate-200" />
                                  ) : m.type === "video" ? (
                                    <div className="w-8 h-8 bg-indigo-100 text-indigo-700 rounded-md flex items-center justify-center font-bold">📹</div>
                                  ) : (
                                    <div className="w-8 h-8 bg-amber-100 text-amber-950 rounded-md flex items-center justify-center font-bold">📄</div>
                                  )}
                                  <div className="text-left leading-normal overflow-hidden max-w-[120px]">
                                    <p className="font-extrabold text-slate-800 truncate">{m.name}</p>
                                    <p className="text-[8px] text-slate-400 font-bold uppercase">{m.type}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-[9px] text-slate-400 text-center py-2.5 font-bold italic bg-white border border-slate-100 rounded-lg">
                              {lang === "bn" ? "কোনো মিডিয়া ফাইল সংযুক্ত নেই। পেইজে চিত্র, ভিডিও বা ডকুমেন্ট ঢোকাতে উপরে আপলোড করুন।" : "No media files attached yet. Upload files above to insert into this chapter!"}
                            </p>
                          )}
                        </div>

                        {/* Rich Edit Textarea */}
                        <textarea
                          ref={textareaRef}
                          value={currentBook.chapters[activeChapterIndex]?.content || ""}
                          onChange={(e) => handleManualContentChange(e.target.value)}
                          placeholder={t.editorPlaceholder}
                          rows={14}
                          className="w-full bg-[#fdfcf9] border border-[#e4dcc9] p-4 text-xs font-serif leading-relaxed text-slate-800 rounded-xl focus:outline-none focus:ring-1 focus:ring-amber-500 shadow-inner"
                        />
                      </div>
                    )}

                  </div>
                )}

              </div>
            </div>
          ) : (
            /* EMPTY BOOK CANVAS VIEW */
            <div className="h-full flex flex-col justify-center items-center py-20 bg-white rounded-2xl border border-[#eae3d2] p-8 text-center space-y-4 min-h-[450px]">
              <div className="inline-flex p-4 bg-amber-50 rounded-full text-[#7c2d12] border border-amber-100">
                <BookOpen size={30} />
              </div>
              <div className="max-w-sm mx-auto space-y-2">
                <p className="text-sm font-extrabold text-slate-900 font-sans">{t.noBookTitle}</p>
                <p className="text-xs text-slate-500 leading-relaxed font-sans">
                  {t.noBookDesc}
                </p>
              </div>
            </div>
          )}
        </div>

        </motion.div>
        </div>
      )}

      {/* SECTOR 1: UNLIMITED AI CHAT HUB */}
      {activeMainTab === "ai_chat" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.3 }}
          className="flex-1 w-full flex flex-col"
        >
          <AIChatHub
            lang={lang}
            currentUser={currentUser}
            modelProvider={selectedProvider}
            customGeminiKey={geminiApiKey}
            customDeepseekKey={deepseekApiKey}
          />
        </motion.div>
      )}

      {/* SECTOR 2: UNLIMITED LIVE TWO-WAY VOICE COMPANION */}
      {activeMainTab === "voice_buddy" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.3 }}
          className="flex-1 w-full flex flex-col"
        >
          <LiveVoiceBuddy
            lang={lang}
            currentUser={currentUser}
            modelProvider={selectedProvider}
            customGeminiKey={geminiApiKey}
            customDeepseekKey={deepseekApiKey}
          />
        </motion.div>
      )}

      {/* SECTOR 2.5: ADVANCED PRO VOICE ASSISTANT (LIVE TRANSLATION & SPEECH ENGINE) */}
      {activeMainTab === "pro_voice" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.3 }}
          className="flex-1 w-full flex flex-col"
        >
          <ProVoiceAssistant
            lang={lang}
            currentUser={currentUser}
            currentBookTitle={currentBook?.title}
            modelProvider={selectedProvider}
            customGeminiKey={geminiApiKey}
            customDeepseekKey={deepseekApiKey}
            onInsertToBook={(dialogueOrText) => {
              if (currentBook && currentBook.chapters.length > 0) {
                const updatedBook = { ...currentBook };
                const currentContent = updatedBook.chapters[activeChapterIndex].content || "";
                updatedBook.chapters[activeChapterIndex].content = currentContent + "\n\n" + dialogueOrText + "\n";
                setCurrentBook(updatedBook);
                saveBookToFirestore(updatedBook);
                setActiveMainTab("editor");
              }
            }}
          />
        </motion.div>
      )}

      {/* SECTOR 2.8: FULL MULTI-FILE CODE PREVIEW BOARD */}
      {activeMainTab === "code_board" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.3 }}
          className="flex-1 w-full flex flex-col"
        >
          <CodePreviewBoard
            lang={lang}
            currentUser={currentUser}
            onInsertCodeToBook={(codeToInsert) => {
              if (currentBook && currentBook.chapters.length > 0) {
                const updatedBook = { ...currentBook };
                const currentContent = updatedBook.chapters[activeChapterIndex].content || "";
                updatedBook.chapters[activeChapterIndex].content = currentContent + "\n\n```html\n" + codeToInsert + "\n```\n";
                setCurrentBook(updatedBook);
                saveBookToFirestore(updatedBook);
                setActiveMainTab("editor");
              }
            }}
          />
        </motion.div>
      )}

      {/* SECTOR 3: UNLIMITED CODE STUDIO & LIVE PREVIEW IDE */}
      {activeMainTab === "code_studio" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.3 }}
          className="flex-1 w-full flex flex-col"
        >
          <CodeStudioPlayground
            lang={lang}
            currentUser={currentUser}
            modelProvider={selectedProvider}
            customGeminiKey={geminiApiKey}
            customDeepseekKey={deepseekApiKey}
          />
        </motion.div>
      )}

      {/* SECTOR 4: NARRATIVE MIND MATRIX (DYNAMIC STORY & PLOT ARCHITECT) */}
      {activeMainTab === "mind_matrix" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.3 }}
          className="flex-1 w-full flex flex-col"
        >
          <NarrativeMindMatrix
            lang={lang}
            currentBook={currentBook}
            modelProvider={selectedProvider}
            customGeminiKey={geminiApiKey}
            customDeepseekKey={deepseekApiKey}
            onSendToOutline={(topic, prompt) => {
              setActiveMainTab("editor");
              setUserChatPrompt(prompt);
              setTimeout(() => {
                handleSendChatMessage();
              }, 150);
            }}
          />
        </motion.div>
      )}

      {/* SECTOR 4.5: AI LEARNING CHART & HIERARCHICAL STEP-BY-STEP CONCEPT STUDIO */}
      {activeMainTab === "learning_chart" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.3 }}
          className="flex-1 w-full flex flex-col"
        >
          <LearningChartStudio
            lang={lang}
            currentUser={currentUser}
            customGeminiKey={geminiApiKey}
            customDeepseekKey={deepseekApiKey}
            onSendToBookEditor={(chartMarkdown) => {
              if (currentBook && currentBook.chapters.length > 0) {
                const updatedBook = { ...currentBook };
                const currentContent = updatedBook.chapters[activeChapterIndex].content || "";
                updatedBook.chapters[activeChapterIndex].content = currentContent + "\n\n" + chartMarkdown + "\n";
                setCurrentBook(updatedBook);
                saveBookToFirestore(updatedBook);
                setActiveMainTab("editor");
              } else {
                setUserChatPrompt(lang === "bn" 
                  ? `এই শিখন চার্টটি নিয়ে একটি সম্পূর্ণ শিক্ষামূলক অধ্যায় লিখে দাও:\n\n${chartMarkdown}` 
                  : `Please write a comprehensive educational chapter based on this learning chart:\n\n${chartMarkdown}`
                );
                setActiveMainTab("editor");
              }
            }}
          />
        </motion.div>
      )}

      {/* SOCIAL FEED TAB VIEW */}
      {activeMainTab === "social" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="flex-1 w-full max-w-7xl mx-auto px-4 py-6 flex flex-col space-y-6 font-sans print:hidden"
        >
          <div className="bg-white border border-[#eae3d2] rounded-2xl p-6 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center md:text-left">
              <h2 className="text-xl font-extrabold text-slate-900">
                {lang === "bn" ? "📖 লেখক সোশ্যাল লাইব্রেরি" : "📖 Lekhok Social Library"}
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {lang === "bn" ? "বিশ্বের অন্যান্য লেখকদের তৈরি চমৎকার সব বই পড়ুন ও শিখুন" : "Explore and read beautiful books generated by authors from all around the world"}
              </p>
            </div>
            
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={lang === "bn" ? "বইয়ের নাম, ক্যাটাগরি বা লেখক খুঁজুন..." : "Search by title, genre, author..."}
                className="w-full bg-[#faf9f5] border border-[#e4dcc9] pl-9 pr-4 py-2 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
              <Search size={14} className="absolute left-3 top-3 text-[#7c2d12]" />
            </div>
          </div>

          {/* Published Books Grid */}
          {(() => {
            const filtered = publishedBooks.filter(b => 
              b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
              b.genre.toLowerCase().includes(searchQuery.toLowerCase()) ||
              (b.creatorName && b.creatorName.toLowerCase().includes(searchQuery.toLowerCase()))
            );

            if (filtered.length === 0) {
              return (
                <div className="bg-white border border-[#eae3d2] rounded-2xl py-20 text-center space-y-4">
                  <div className="p-4 bg-amber-50 rounded-full text-[#7c2d12] inline-flex">
                    <BookOpen size={30} />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-extrabold text-slate-900">
                      {lang === "bn" ? "কোনো বই পাওয়া যায়নি" : "No books found"}
                    </p>
                    <p className="text-xs text-slate-400 font-medium">
                      {lang === "bn" ? "অনুগ্রহ করে অন্য কিছু লিখে সার্চ করুন অথবা নিজেই একটি বই লিখে পাবলিশ করুন!" : "Try searching for a different keyword or write and publish your own book!"}
                    </p>
                  </div>
                </div>
              );
            }

            return (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filtered.map((b) => (
                  <div 
                    key={b.id} 
                    className="bg-white rounded-2xl border border-[#eae3d2] overflow-hidden glass-card-3d flex flex-col h-full group"
                  >
                    {/* 3D Realistic Hardcover Cover Preview */}
                    <div 
                      className="h-48 p-4 flex flex-col justify-between text-white relative overflow-hidden book-cover-3d page-edge-thickness cursor-pointer"
                      style={{ background: b.coverColor || "linear-gradient(135deg, #0f172a, #1e293b)" }}
                      onClick={() => {
                        setSocialBookChapterIndex(0);
                        setSocialBookPageIndex(0);
                        setSelectedSocialBook(b);
                      }}
                    >
                      {/* User Custom Uploaded Cover Image */}
                      {b.coverImageUrl && (
                        <div 
                          className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                          style={{ 
                            backgroundImage: `url(${b.coverImageUrl})`,
                            opacity: b.coverImageOpacity ?? 0.9
                          }}
                        />
                      )}

                      {/* 3D Hardcover Left Spine Simulation */}
                      <div className="spine-crease-3d" />

                      {/* Dynamic High-Contrast Shadow Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-black/60 pointer-events-none" />

                      {/* Glossy Sheen Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/15 to-transparent opacity-40 group-hover:opacity-80 transition pointer-events-none" />

                      <div className="relative z-10 pl-2 flex items-center justify-between">
                        <span className="text-[9px] font-extrabold tracking-wider uppercase bg-white/25 backdrop-blur-md px-2.5 py-0.5 rounded-full border border-white/30 text-amber-200 shadow-xs">
                          {b.genre}
                        </span>
                        <span className="text-[9px] font-black uppercase text-white/80 bg-black/40 backdrop-blur-xs px-2 py-0.5 rounded-md border border-white/10">
                          {b.language || "Draft"}
                        </span>
                      </div>

                      <div className="relative z-10 pl-2 my-auto py-2">
                        <h3 className="text-sm sm:text-base font-black tracking-tight line-clamp-2 leading-snug font-serif text-white drop-shadow-md">
                          {b.title}
                        </h3>
                      </div>

                      <div className="relative z-10 pl-2 flex items-center justify-between text-[8px] font-extrabold opacity-90 border-t border-white/20 pt-2 font-sans backdrop-blur-xs">
                        <span className="text-amber-300">✨ Lekhok AI Official</span>
                        <span className="truncate max-w-[100px] text-white/90">{b.creatorName || "Author"}</span>
                      </div>
                    </div>

                    {/* Book Metadata details */}
                    <div className="p-4 flex-1 flex flex-col justify-between space-y-4 font-sans text-left">
                      <div className="space-y-2">
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                          {lang === "bn" ? "সারসংক্ষেপ" : "Synopsis"}
                        </p>
                        <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                          {b.synopsis}
                        </p>
                      </div>

                      <div className="space-y-3 pt-2 border-t border-slate-100">
                        <div className="flex items-center justify-between text-[10px] text-slate-600 font-bold">
                          <div className="flex items-center gap-1.5 overflow-hidden">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const authorBooks = publishedBooks.filter(item => (b.userId && item.userId === b.userId) || item.creatorName === b.creatorName);
                                setSelectedAuthorProfile({
                                  userId: b.userId || "guest-author",
                                  name: b.creatorName || "Anonymous Author",
                                  role: authorBooks.length >= 3 ? "Master Novelist" : "Published Author",
                                  bio: `${b.creatorName || "Author"} has published ${authorBooks.length} book(s) in Lekhok AI Social Library.`,
                                  booksCount: authorBooks.length,
                                  totalChapters: authorBooks.reduce((acc, bk) => acc + (bk.chapters?.length || 0), 0),
                                  totalWordsEstimated: authorBooks.reduce((acc, bk) => acc + (bk.chapters?.reduce((cAcc: number, ch: any) => cAcc + (ch.content?.split(/\s+/).length || 0), 0) || 0), 0),
                                  followers: []
                                });
                              }}
                              className="flex items-center gap-1 text-slate-800 hover:text-amber-800 font-extrabold truncate cursor-pointer transition"
                              title={lang === "bn" ? "লেখকের প্রোফাইল দেখুন" : "View Author Profile"}
                            >
                              <User size={12} className="text-[#7c2d12] shrink-0" />
                              <span className="truncate hover:underline decoration-amber-400">{b.creatorName || "Anonymous Author"}</span>
                            </button>
                            
                            {/* Follow Author Button */}
                            {b.userId && currentUser && currentUser.uid !== b.userId && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleFollowAuthor(b.userId, b.creatorName || "Author");
                                }}
                                className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold transition cursor-pointer shrink-0 ${
                                  currentUser?.following?.includes(b.userId)
                                    ? "bg-slate-100 text-slate-600 border border-slate-200"
                                    : "bg-[#7c2d12] text-amber-50 hover:bg-[#63220c] shadow-2xs"
                                }`}
                              >
                                {currentUser?.following?.includes(b.userId) ? "✓ Following" : "+ Follow"}
                              </button>
                            )}
                          </div>

                          <span className="flex items-center gap-1 text-slate-500 font-extrabold shrink-0">
                            <BookOpen size={11} className="text-[#7c2d12]" />
                            {lang === "bn" ? `${b.chapters.length}টি অধ্যায়` : `${b.chapters.length} Ch`}
                          </span>
                        </div>

                        {/* Card actions (Read, Like, Edit/Remix) with 3D tactile feel */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setSocialBookChapterIndex(0);
                              setSocialBookPageIndex(0);
                              setSelectedSocialBook(b);
                            }}
                            className="flex-1 py-2 bg-gradient-to-r from-amber-600 to-[#7c2d12] hover:from-amber-700 hover:to-[#64230e] text-white rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 btn-3d-primary cursor-pointer"
                          >
                            <BookOpen size={13} />
                            <span>{lang === "bn" ? "পড়ুন" : "Read"}</span>
                          </button>

                          {/* Heart / Like Button with Counter */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleLike(b, e);
                            }}
                            className={`py-2 px-3 rounded-xl border text-xs font-black transition flex items-center justify-center gap-1 cursor-pointer btn-3d-secondary ${
                              currentUser && b.likedByNames?.includes(currentUser.displayName || currentUser.email)
                                ? "bg-rose-50 border-rose-300 text-rose-600 shadow-2xs"
                                : "bg-slate-50 border-slate-200 hover:border-rose-200 text-slate-600 hover:text-rose-600"
                            }`}
                            title={
                              b.likedByNames && b.likedByNames.length > 0
                                ? `Liked by: ${b.likedByNames.join(", ")}`
                                : "Like this book"
                            }
                          >
                            <span>❤️</span>
                            <span className="font-mono text-[11px]">{b.likesCount || 0}</span>
                          </button>
                          
                          {/* EDIT / REMIX IN CANVAS BUTTON */}
                          <button
                            onClick={() => {
                              setCurrentBook(b);
                              setActiveMainTab("editor");
                              setActiveChapterIndex(0);
                              setActivePageIndex(0);
                              setPreviewTab("cover");
                            }}
                            className="px-3 py-2 border border-slate-200 hover:border-amber-400 bg-slate-50 hover:bg-amber-100/60 text-slate-700 hover:text-[#7c2d12] rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer btn-3d-secondary"
                            title={lang === "bn" ? "এডিটরে বইটি লোড বা সম্পাদনা করুন" : "Open or Edit in Book Editor"}
                          >
                            <Edit3 size={12} className="text-[#7c2d12]" />
                            <span className="text-[10px] font-extrabold">{currentUser && currentUser.uid === b.userId ? (lang === "bn" ? "এডিট" : "Edit") : (lang === "bn" ? "রিমিক্স" : "Remix")}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </motion.div>
      )}

      {/* IMMERSIVE SOCIAL BOOK READER MODAL */}
      {selectedSocialBook && (
        <div 
          className="fixed inset-0 bg-slate-950/80 backdrop-blur-md flex items-center justify-center z-50 p-2 sm:p-4 font-sans select-none animate-fadeIn"
          onKeyDown={(e) => {
            if (e.key === "ArrowRight") {
              const pages = paginateChapterContent(selectedSocialBook.chapters[socialBookChapterIndex]?.content || "");
              if (socialBookPageIndex < pages.length - 1) {
                setSocialBookPageIndex(p => p + 1);
              } else if (socialBookChapterIndex < selectedSocialBook.chapters.length - 1) {
                setSocialBookChapterIndex(c => c + 1);
                setSocialBookPageIndex(0);
              }
            } else if (e.key === "ArrowLeft") {
              if (socialBookPageIndex > 0) {
                setSocialBookPageIndex(p => p - 1);
              } else if (socialBookChapterIndex > 0) {
                setSocialBookChapterIndex(c => c - 1);
                setSocialBookPageIndex(0);
              }
            }
          }}
          tabIndex={0}
        >
          <div className={`w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[95vh] border transition-colors duration-300 ${
            socialReaderTheme === "night" 
              ? "bg-[#121826] text-slate-100 border-slate-800" 
              : socialReaderTheme === "warm" 
                ? "bg-[#faf7f0] text-[#2b261f] border-[#e8dfce]" 
                : "bg-white text-slate-900 border-slate-200"
          }`}>
            
            {/* Modal Header */}
            <div className={`px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3 border-b ${
              socialReaderTheme === "night" ? "bg-[#0f172a] border-slate-800" : "bg-white/90 border-[#eadeca]"
            }`}>
              <div className="flex items-center space-x-3 text-left">
                <div className="p-2 bg-[#7c2d12] rounded-xl text-amber-50 shadow-xs">
                  <BookOpen size={18} />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold font-serif leading-tight line-clamp-1">
                    {selectedSocialBook.title}
                  </h3>
                  <p className="text-[11px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-2">
                    <span>{selectedSocialBook.genre}</span>
                    <span>•</span>
                    <span className="text-[#7c2d12] font-extrabold">
                      {lang === "bn" ? `অধ্যায় ${socialBookChapterIndex + 1} / ${selectedSocialBook.chapters.length}` : `Chapter ${socialBookChapterIndex + 1} of ${selectedSocialBook.chapters.length}`}
                    </span>
                  </p>
                </div>
              </div>

              {/* Utility controls: A4 Download, Theme, Font Size, Close */}
              <div className="flex items-center gap-2">
                {/* 1-Click A4 Book & PDF Download Button */}
                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  onClick={() => downloadBookAsA4HTML(selectedSocialBook, lang)}
                  className="px-3 py-1.5 bg-gradient-to-r from-amber-700 to-[#7c2d12] text-amber-50 text-xs font-bold rounded-lg shadow-sm hover:shadow-md transition flex items-center gap-1.5 cursor-pointer border border-amber-600/30"
                  title={lang === "bn" ? "সম্পূর্ণ বই A4 ফরম্যাটে ও PDF ডাউনলোড করুন" : "Download complete book in A4 & PDF format"}
                >
                  <Download size={14} />
                  <span className="hidden sm:inline">{lang === "bn" ? "A4 ডাউনলোড / PDF" : "Download A4 / PDF"}</span>
                </motion.button>

                {/* Theme Selector */}
                <div className="hidden sm:flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-xs">
                  <button 
                    onClick={() => setSocialReaderTheme("light")}
                    className={`px-2 py-1 rounded-md transition ${socialReaderTheme === "light" ? "bg-white shadow-xs font-bold text-slate-900" : "text-slate-500"}`}
                    title="Light Theme"
                  >
                    ☀️
                  </button>
                  <button 
                    onClick={() => setSocialReaderTheme("warm")}
                    className={`px-2 py-1 rounded-md transition ${socialReaderTheme === "warm" ? "bg-amber-100 shadow-xs font-bold text-[#7c2d12]" : "text-slate-500"}`}
                    title="Warm Paper Theme"
                  >
                    📜
                  </button>
                  <button 
                    onClick={() => setSocialReaderTheme("night")}
                    className={`px-2 py-1 rounded-md transition ${socialReaderTheme === "night" ? "bg-slate-700 shadow-xs font-bold text-amber-300" : "text-slate-500"}`}
                    title="Night Theme"
                  >
                    🌙
                  </button>
                </div>

                {/* Font Size controls */}
                <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-lg p-0.5 text-xs">
                  <button 
                    onClick={() => setSocialReaderFontSize(s => Math.max(14, s - 1))}
                    className="px-2 py-1 text-slate-600 hover:text-slate-900 dark:text-slate-300 font-bold"
                    title="Smaller text"
                  >
                    A-
                  </button>
                  <span className="px-1 text-[10px] font-mono text-slate-400">{socialReaderFontSize}</span>
                  <button 
                    onClick={() => setSocialReaderFontSize(s => Math.min(26, s + 1))}
                    className="px-2 py-1 text-slate-600 hover:text-slate-900 dark:text-slate-300 font-bold"
                    title="Larger text"
                  >
                    A+
                  </button>
                </div>

                {/* Close Button */}
                <button 
                  onClick={() => setSelectedSocialBook(null)}
                  className="p-1.5 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full text-slate-500 transition cursor-pointer"
                  title="Close Reader"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* TOP CHAPTER SELECTOR & HIGHLIGHTED ANIMATED CHAPTER BAR */}
            <div className={`px-4 sm:px-6 py-2.5 border-b flex flex-wrap items-center justify-between gap-2 text-xs ${
              socialReaderTheme === "night" ? "bg-[#1e293b]/60 border-slate-800" : "bg-[#f5ede0]/70 border-[#e8dfce]"
            }`}>
              {/* Prev Chapter Button */}
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                disabled={socialBookChapterIndex === 0}
                onClick={() => {
                  setSocialBookChapterIndex(p => Math.max(0, p - 1));
                  setSocialBookPageIndex(0);
                }}
                className="px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 disabled:opacity-30 transition cursor-pointer bg-white dark:bg-slate-800 text-[#7c2d12] dark:text-amber-300 border border-amber-200 dark:border-slate-700 shadow-xs"
              >
                <ChevronLeft size={16} />
                <span>{lang === "bn" ? "পূর্ববর্তী অধ্যায়" : "Prev Chapter"}</span>
              </motion.button>

              {/* Quick Chapter Selector Dropdown with Active Title */}
              <div className="flex items-center gap-2 flex-1 max-w-sm justify-center">
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 hidden md:inline">
                  {lang === "bn" ? "অধ্যায় নির্বাচন:" : "Select Chapter:"}
                </span>
                <select
                  value={socialBookChapterIndex}
                  onChange={(e) => {
                    setSocialBookChapterIndex(Number(e.target.value));
                    setSocialBookPageIndex(0);
                  }}
                  className="bg-white dark:bg-slate-800 border border-amber-300 dark:border-slate-700 rounded-lg px-3 py-1.5 font-bold text-xs text-slate-800 dark:text-slate-200 outline-hidden shadow-xs cursor-pointer max-w-[220px] truncate"
                >
                  {selectedSocialBook.chapters.map((ch, idx) => (
                    <option key={idx} value={idx}>
                      {lang === "bn" ? `অধ্যায় ${ch.chapterNumber}: ${ch.title}` : `Ch ${ch.chapterNumber}: ${ch.title}`}
                    </option>
                  ))}
                </select>
              </div>

              {/* Next Chapter Button (Pulsing Animated Highlight) */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                animate={{ 
                  boxShadow: socialBookChapterIndex < selectedSocialBook.chapters.length - 1 
                    ? ["0 0 0 0 rgba(124, 45, 18, 0)", "0 0 0 6px rgba(124, 45, 18, 0.15)", "0 0 0 0 rgba(124, 45, 18, 0)"] 
                    : "none" 
                }}
                transition={{ duration: 2, repeat: Infinity }}
                disabled={socialBookChapterIndex >= selectedSocialBook.chapters.length - 1}
                onClick={() => {
                  setSocialBookChapterIndex(p => Math.min(selectedSocialBook.chapters.length - 1, p + 1));
                  setSocialBookPageIndex(0);
                }}
                className="px-3.5 py-1.5 rounded-lg font-bold flex items-center gap-1.5 disabled:opacity-30 transition cursor-pointer bg-gradient-to-r from-[#7c2d12] to-amber-700 text-amber-50 shadow-md border border-amber-600"
              >
                <span>{lang === "bn" ? "পরবর্তী অধ্যায়" : "Next Chapter"}</span>
                <ChevronRight size={16} />
              </motion.button>
            </div>

            {/* INTEGRATED READING ANALYTICS BAR */}
            <div className="px-4 sm:px-6 pt-3">
              <ReadingAnalyticsBar 
                currentChapterContent={selectedSocialBook.chapters[socialBookChapterIndex]?.content || ""} 
                lang={lang} 
                chapterNumber={socialBookChapterIndex + 1}
                totalChapters={selectedSocialBook.chapters.length}
                bookId={selectedSocialBook.id}
              />
            </div>

            {/* INTEGRATED TTS AUDIO PLAYER */}
            <div className="px-4 sm:px-6 py-2">
              <TTSAudioPlayer
                text={selectedSocialBook.chapters[socialBookChapterIndex]?.content || ""}
                title={selectedSocialBook.chapters[socialBookChapterIndex]?.title || ""}
                chapterNumber={selectedSocialBook.chapters[socialBookChapterIndex]?.chapterNumber || (socialBookChapterIndex + 1)}
                language={selectedSocialBook.language || "Bengali"}
                lang={lang}
              />
            </div>

            {/* SWIPE GESTURE & READING CONTENT CONTAINER */}
            <div 
              className="flex-1 p-4 sm:p-8 overflow-y-auto space-y-6 relative touch-pan-y"
              onTouchStart={(e) => {
                touchStartXRef.current = e.touches[0].clientX;
                touchStartYRef.current = e.touches[0].clientY;
              }}
              onTouchEnd={(e) => {
                if (touchStartXRef.current === null || touchStartYRef.current === null) return;
                const touchEndX = e.changedTouches[0].clientX;
                const touchEndY = e.changedTouches[0].clientY;
                const diffX = touchStartXRef.current - touchEndX;
                const diffY = touchStartYRef.current - touchEndY;

                // Detect distinct horizontal finger swipe (> 45px and mostly horizontal)
                if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 45) {
                  const pages = paginateChapterContent(selectedSocialBook.chapters[socialBookChapterIndex]?.content || "");
                  if (diffX > 0) {
                    // Swiped Left -> Go Next Page
                    if (socialBookPageIndex < pages.length - 1) {
                      setSocialBookPageIndex(p => p + 1);
                      setSocialSwipeNotice(lang === "bn" ? "পরবর্তী পৃষ্ঠা 👈" : "Next Page 👈");
                    } else if (socialBookChapterIndex < selectedSocialBook.chapters.length - 1) {
                      setSocialBookChapterIndex(c => c + 1);
                      setSocialBookPageIndex(0);
                      setSocialSwipeNotice(lang === "bn" ? "পরবর্তী অধ্যায় ✨" : "Next Chapter ✨");
                    }
                  } else {
                    // Swiped Right -> Go Prev Page
                    if (socialBookPageIndex > 0) {
                      setSocialBookPageIndex(p => p - 1);
                      setSocialSwipeNotice(lang === "bn" ? "👉 পূর্ববর্তী পৃষ্ঠা" : "👉 Prev Page");
                    } else if (socialBookChapterIndex > 0) {
                      setSocialBookChapterIndex(c => c - 1);
                      setSocialBookPageIndex(0);
                      setSocialSwipeNotice(lang === "bn" ? "পূর্ববর্তী অধ্যায় 🔙" : "Prev Chapter 🔙");
                    }
                  }
                  setTimeout(() => setSocialSwipeNotice(null), 1200);
                }
                touchStartXRef.current = null;
                touchStartYRef.current = null;
              }}
            >
              
              {/* Swipe Notice Toast */}
              <AnimatePresence>
                {socialSwipeNotice && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8, y: -10 }}
                    className="absolute top-4 left-1/2 transform -translate-x-1/2 z-30 bg-[#7c2d12] text-amber-50 px-4 py-1.5 rounded-full font-bold text-xs shadow-lg flex items-center gap-2 pointer-events-none"
                  >
                    <span>👆 {socialSwipeNotice}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* 3D Realistic Animated Cover Canvas (if pageIndex is 0 and chapterIndex is 0) */}
              {socialBookChapterIndex === 0 && socialBookPageIndex === 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: 10, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  className="mb-8 rounded-2xl overflow-hidden shadow-2xl border border-amber-900/20"
                >
                  <AnimatedCoverCanvas
                    title={selectedSocialBook.title}
                    genre={selectedSocialBook.genre}
                    authorName={selectedSocialBook.creatorName || "Lekhok AI Author"}
                    synopsis={selectedSocialBook.synopsis}
                    baseGradient={selectedSocialBook.coverColor || COVER_GRADIENTS[0].css}
                    coverImageUrl={selectedSocialBook.coverImageUrl}
                    coverImageOpacity={selectedSocialBook.coverImageOpacity ?? 0.85}
                    lang={lang}
                  />
                </motion.div>
              )}

              {/* Sub-header for Active Chapter title */}
              <div className="text-center space-y-1.5 border-b border-amber-900/10 pb-4">
                <span className="text-[11px] uppercase font-extrabold tracking-widest text-[#7c2d12] dark:text-amber-400">
                  {lang === "bn" ? `অধ্যায় ${selectedSocialBook.chapters[socialBookChapterIndex]?.chapterNumber}` : `Chapter ${selectedSocialBook.chapters[socialBookChapterIndex]?.chapterNumber}`}
                </span>
                <h2 className="text-xl sm:text-2xl font-bold font-serif">
                  {selectedSocialBook.chapters[socialBookChapterIndex]?.title}
                </h2>
              </div>

              {/* Render Paginated text content with custom font size */}
              <div 
                className="max-w-none text-justify font-serif leading-relaxed min-h-[260px]"
                style={{ fontSize: `${socialReaderFontSize}px` }}
              >
                {(() => {
                  const pages = paginateChapterContent(selectedSocialBook.chapters[socialBookChapterIndex]?.content || "");
                  const currentPageContent = pages[socialBookPageIndex] || "";
                  return (
                    <div className="space-y-4">
                      <ReactMarkdown components={markdownComponents}>
                        {currentPageContent}
                      </ReactMarkdown>

                      {/* Mobile Finger Swipe Hint Indicator */}
                      <div className="py-2 text-center text-[11px] text-slate-400 dark:text-slate-500 font-sans flex items-center justify-center gap-2 select-none opacity-70">
                        <span>👈 {lang === "bn" ? "আঙুল দিয়ে বামে সোয়াইপ করুন পরের পেইজে যেতে" : "Swipe left to turn next page"}</span>
                        <span>•</span>
                        <span>👉 {lang === "bn" ? "ডানে সোয়াইপ করুন আগের পেইজে যেতে" : "Swipe right for prev page"}</span>
                      </div>

                      {/* PROMINENT, ANIMATED HIGHLIGHTED PAGE NAVIGATION BUTTONS */}
                      <div className="border-t border-amber-900/15 pt-5 mt-6 font-sans">
                        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                          {/* Previous Page Button */}
                          <motion.button
                            whileHover={{ scale: 1.03 }}
                            whileTap={{ scale: 0.97 }}
                            disabled={socialBookPageIndex === 0}
                            onClick={() => setSocialBookPageIndex(p => Math.max(0, p - 1))}
                            className="w-full sm:w-auto px-4 py-2.5 bg-amber-50 hover:bg-amber-100 dark:bg-slate-800 dark:hover:bg-slate-700 disabled:opacity-40 text-xs font-extrabold text-[#7c2d12] dark:text-amber-300 rounded-xl border border-amber-300 dark:border-slate-700 transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                          >
                            <ChevronLeft size={16} />
                            <span>{lang === "bn" ? "পূর্ববর্তী পৃষ্ঠা (Prev Page)" : "Previous Page"}</span>
                          </motion.button>

                          {/* Page Indicator Badge & Progress bar */}
                          <div className="flex flex-col items-center gap-1">
                            <span className="text-xs text-slate-600 dark:text-slate-300 font-extrabold font-mono tracking-wide bg-amber-100/70 dark:bg-slate-800 border border-amber-200 dark:border-slate-700 px-4 py-1.5 rounded-full">
                              {lang === "bn" 
                                ? `পৃষ্ঠা ${socialBookPageIndex + 1} / ${pages.length}` 
                                : `Page ${socialBookPageIndex + 1} of ${pages.length}`}
                            </span>
                            <div className="w-32 bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                              <div 
                                className="bg-[#7c2d12] dark:bg-amber-400 h-full transition-all duration-300"
                                style={{ width: `${((socialBookPageIndex + 1) / pages.length) * 100}%` }}
                              />
                            </div>
                          </div>

                          {/* Next Page Button (Glowing Animation) */}
                          <motion.button
                            whileHover={{ scale: 1.04 }}
                            whileTap={{ scale: 0.96 }}
                            animate={{
                              borderColor: socialBookPageIndex < pages.length - 1 ? ["#d97706", "#7c2d12", "#d97706"] : "#e2e8f0"
                            }}
                            transition={{ duration: 2, repeat: Infinity }}
                            disabled={socialBookPageIndex >= pages.length - 1}
                            onClick={() => setSocialBookPageIndex(p => Math.min(pages.length - 1, p + 1))}
                            className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-amber-600 to-[#7c2d12] hover:from-amber-700 hover:to-[#60230e] text-white disabled:opacity-40 text-xs font-extrabold rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-md border-2 border-amber-500"
                          >
                            <span>{lang === "bn" ? "পরবর্তী পৃষ্ঠা (Next Page)" : "Next Page"}</span>
                            <ChevronRight size={16} />
                          </motion.button>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>

            </div>

            {/* Modal Bottom Chapter Navigation Footer */}
            <div className={`px-4 sm:px-6 py-3 border-t flex flex-wrap items-center justify-between gap-3 font-sans text-xs ${
              socialReaderTheme === "night" ? "bg-[#0f172a] border-slate-800" : "bg-white border-[#eadeca]"
            }`}>
              <div className="flex items-center gap-2">
                <button
                  disabled={socialBookChapterIndex === 0}
                  onClick={() => {
                    setSocialBookChapterIndex(p => p - 1);
                    setSocialBookPageIndex(0);
                  }}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-35 rounded-lg font-bold text-slate-700 dark:text-slate-200 transition cursor-pointer flex items-center gap-1"
                >
                  <ChevronLeft size={14} />
                  <span>{lang === "bn" ? "পূর্ববর্তী অধ্যায়" : "Prev Chapter"}</span>
                </button>

                <span className="text-[11px] font-extrabold text-slate-600 dark:text-slate-300 font-mono">
                  {lang === "bn" 
                    ? `অধ্যায় ${socialBookChapterIndex + 1} / ${selectedSocialBook.chapters.length}` 
                    : `Ch ${socialBookChapterIndex + 1} of ${selectedSocialBook.chapters.length}`}
                </span>

                <button
                  disabled={socialBookChapterIndex >= selectedSocialBook.chapters.length - 1}
                  onClick={() => {
                    setSocialBookChapterIndex(p => p + 1);
                    setSocialBookPageIndex(0);
                  }}
                  className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-35 rounded-lg font-bold text-slate-700 dark:text-slate-200 transition cursor-pointer flex items-center gap-1"
                >
                  <span>{lang === "bn" ? "পরবর্তী অধ্যায়" : "Next Chapter"}</span>
                  <ChevronRight size={14} />
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => downloadBookAsA4HTML(selectedSocialBook, lang)}
                  className="text-[11px] font-bold text-[#7c2d12] dark:text-amber-400 hover:underline flex items-center gap-1"
                >
                  <Download size={13} />
                  <span>{lang === "bn" ? "A4 ই-বুক ডাউনলোড" : "Download A4 Ebook"}</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ADMIN PANEL VIEW */}
      {activeMainTab === "admin" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="flex-1 w-full max-w-md mx-auto px-4 py-12 flex flex-col justify-center font-sans print:hidden text-left"
        >
          {!isAdminAuthenticated ? (
            /* ADMIN LOGIN SHIELD */
            <div className="bg-white border-2 border-amber-200 rounded-2xl p-6 shadow-md space-y-4 font-sans">
              <div className="text-center space-y-2">
                <div className="inline-flex p-3 bg-red-50 text-red-600 rounded-full border border-red-100 shadow-sm animate-pulse">
                  <Lock size={28} />
                </div>
                <h2 className="text-base font-extrabold text-slate-900 uppercase tracking-wider">
                  {lang === "bn" ? "অ্যাডমিন প্যানেল প্রবেশাধিকার" : "Admin Panel Access"}
                </h2>
                <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                  {lang === "bn" ? "মডারেশন প্যানেলে প্রবেশের জন্য পাসওয়ার্ড দিন" : "Provide system administrator credentials to configure and manage user logs"}
                </p>
              </div>

              <div className="space-y-3.5 pt-2">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Password:</label>
                  <input
                    type="password"
                    value={adminPasswordInput}
                    onChange={(e) => setAdminPasswordInput(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full bg-slate-50 border border-slate-200 p-3 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500"
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleAdminLogin();
                    }}
                  />
                </div>

                {adminError && (
                  <p className="text-[10px] text-red-600 font-bold bg-red-50 border border-red-100 p-2 rounded-lg">
                    {adminError}
                  </p>
                )}

                <button
                  onClick={handleAdminLogin}
                  className="w-full py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-amber-50 font-bold rounded-xl text-xs shadow-xs transition cursor-pointer"
                >
                  Verify Administrator Key
                </button>
              </div>
            </div>
          ) : (
            /* FULL MASTER SUPER ADMIN PANEL */
            <AdminMasterControl
              lang={lang}
              adminBooks={adminBooks}
              onDeleteBook={handleAdminDeleteBook}
              onUnpublishBook={handleAdminUnpublishBook}
              onUpdateBook={async (bookToUpdate) => {
                await saveBookToFirestore(bookToUpdate);
                fetchAdminDashboardData();
              }}
              currentUser={currentUser}
              siteConfig={siteConfig}
              onUpdateSiteConfig={handleUpdateSiteConfig}
              onClose={() => {
                setIsAdminAuthenticated(false);
                setAdminPasswordInput("");
                setActiveMainTab("editor");
              }}
            />
          )}
        </motion.div>
      )}

      {/* PRINT-ONLY PERFECT PDF LAYOUT WRAPPER (HIDDEN ON SCREEN) */}
      {currentBook && (
        <div id="print-book-wrapper" className="hidden print:block font-serif text-slate-900 bg-white">
          
          {/* Running Footer for Page Numbers in PDF print */}
          {showPageNumbers && (
            <div className="print-footer-running">
              <span className="print-footer-running-left">{currentBook.title} — {currentBook.genre}</span>
              <span className="print-footer-running-right"></span>
            </div>
          )}

          {/* Print Cover */}
          <div 
            className="print-page-cover"
            style={{ background: currentBook.coverColor || "linear-gradient(135deg, #0f172a, #1e293b)" }}
          >
            <div className="text-left">
              <span className="text-sm tracking-widest uppercase font-sans font-bold opacity-80">{currentBook.genre}</span>
            </div>
            <div className="my-auto space-y-6">
              <h1 className="text-5xl font-extrabold tracking-tight leading-tight font-sans text-white">{currentBook.title}</h1>
              <p className="text-lg max-w-xl opacity-90 leading-relaxed italic text-slate-100">
                "{currentBook.synopsis}"
              </p>
            </div>
            <div className="flex justify-between items-center border-t border-white/20 pt-8 text-xs text-slate-200">
              <div>
                <p className="font-semibold font-sans">Lekhok AI Publications</p>
                <p className="opacity-75 font-sans">{lang === "bn" ? "অত্যাধুনিক নিউরাল ইঞ্জিন দ্বারা চালিত" : "Powered by Lekhok Neural Engine"}</p>
              </div>
              <span className="font-bold tracking-wide font-sans">{currentBook.language} Draft</span>
            </div>
          </div>

          {/* Synopsis / Introduction Page */}
          <div className="print-page-content page-break">
            <div className="border-b border-slate-200 pb-4 mb-8">
              <span className="text-xs uppercase font-bold tracking-widest text-[#7c2d12] font-sans">
                {lang === "bn" ? "ভূমিকা ও সারসংক্ষেপ" : "Introduction & Synopsis"}
              </span>
              <h2 className="text-3xl font-bold font-serif text-slate-950 mt-1">
                {currentBook.title}
              </h2>
            </div>
            
            <p className="text-lg leading-relaxed text-slate-700 italic text-justify whitespace-pre-line">
              {currentBook.synopsis}
            </p>
          </div>

          {/* Chapters loop */}
          {currentBook.chapters.map((ch, idx) => (
            <div key={idx} className="print-page-content page-break">
              <div className="border-b border-slate-200 pb-4 mb-8">
                <span className="text-xs uppercase font-bold tracking-widest text-[#7c2d12] font-sans">
                  Chapter {ch.chapterNumber}
                </span>
                <h2 className="text-3xl font-bold font-serif text-slate-950 mt-1">
                  {ch.title}
                </h2>
              </div>
              
              <div className="markdown-book-content text-justify leading-relaxed">
                {ch.content ? (
                  <ReactMarkdown components={markdownComponents}>{ch.content}</ReactMarkdown>
                ) : (
                  <p className="text-slate-400 italic">This chapter was not written or generated yet.</p>
                )}
              </div>
            </div>
          ))}

        </div>
      )}

      {/* BOOK HISTORY ARCHIVE VIEW */}
      {activeMainTab === "history" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="flex-1 w-full max-w-7xl mx-auto px-6 py-8 font-sans print:hidden text-left"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-amber-200/60 pb-5 mb-8">
            <div>
              <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
                <History className="text-[#7c2d12]" size={24} />
                <span>{lang === "bn" ? "আমার বইয়ের মহাফেজখানা" : "My Book Archives"}</span>
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-1 leading-relaxed">
                {lang === "bn" 
                  ? "আপনার ইতিপূর্বে তৈরি করা ও সংরক্ষিত সকল বইয়ের তালিকা। এখান থেকে যেকোনো বই আবার লোড করে পড়তে ও এডিট করতে পারবেন অথবা ডিলিট করতে পারবেন।" 
                  : "Review, reload, edit, or permanently delete books you have written and structured in past sessions."}
              </p>
            </div>
            
            <button
              onClick={fetchUserBooksHistory}
              disabled={isFetchingHistory}
              className="px-4 py-2 bg-amber-50 hover:bg-amber-100 text-[#7c2d12] border border-amber-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 self-start md:self-center disabled:opacity-50"
            >
              <RefreshCw size={13} className={isFetchingHistory ? "animate-spin" : ""} />
              <span>{lang === "bn" ? "রিফ্রেশ করুন" : "Refresh List"}</span>
            </button>
          </div>

          {isFetchingHistory ? (
            <div className="flex flex-col items-center justify-center py-20 space-y-3">
              <RefreshCw className="animate-spin text-[#7c2d12]" size={36} />
              <p className="text-xs font-bold text-slate-500 animate-pulse">
                {lang === "bn" ? "ইতিহাস লোড হচ্ছে..." : "Fetching saved manuscript archive..."}
              </p>
            </div>
          ) : userBooks.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-24 text-center space-y-4 max-w-sm mx-auto font-sans">
              <div className="p-4 bg-amber-50 rounded-full border border-amber-100">
                <BookOpen size={40} className="text-[#7c2d12]/50" />
              </div>
              <h3 className="text-sm font-black text-slate-900">
                {lang === "bn" ? "কোনো বই পাওয়া যায়নি" : "Archive is currently empty"}
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                {lang === "bn" 
                  ? "আপনি এখনও এআই দিয়ে কোনো বই তৈরি করেননি। বইয়ের এডিটর ট্যাবে ফিরে গিয়ে প্রথম বইটি লিখে ফেলুন।" 
                  : "You haven't designed or saved any manuscripts yet. Go back to the Book Editor tab to construct your first story!"}
              </p>
              <button
                onClick={() => setActiveMainTab("editor")}
                className="px-5 py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
              >
                <span>{lang === "bn" ? "একটি নতুন বই লিখুন" : "Create My First Book"}</span>
                <ArrowRight size={13} />
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn font-sans">
              {userBooks.map((b) => (
                <div 
                  key={b.id} 
                  className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden glass-card-3d flex flex-col group relative"
                >
                  {/* 3D Realistic Cover Badge */}
                  <div 
                    className="h-36 p-4 flex flex-col justify-between text-white relative overflow-hidden book-cover-3d page-edge-thickness"
                    style={{ background: b.coverColor || "linear-gradient(135deg, #0f172a, #1e293b)" }}
                  >
                    {/* User Custom Uploaded Cover Image */}
                    {b.coverImageUrl && (
                      <div 
                        className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                        style={{ 
                          backgroundImage: `url(${b.coverImageUrl})`,
                          opacity: b.coverImageOpacity ?? 0.9
                        }}
                      />
                    )}

                    {/* 3D Spine Crease */}
                    <div className="spine-crease-3d" />

                    {/* Dark gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/50 pointer-events-none" />

                    <div className="relative z-10 pl-2 flex items-center justify-between">
                      <span className="text-[9px] uppercase font-black tracking-widest bg-white/25 px-2.5 py-0.5 rounded-full backdrop-blur-xs text-amber-200 border border-white/20">
                        {b.genre}
                      </span>
                      <span className="text-[8px] font-bold bg-black/40 px-2 py-0.5 rounded text-white/80">
                        {b.language || "Draft"}
                      </span>
                    </div>

                    <div className="relative z-10 pl-2 my-auto">
                      <h4 className="text-sm font-black line-clamp-1 drop-shadow-md text-white font-serif">{b.title}</h4>
                    </div>

                    <div className="relative z-10 pl-2 text-[8px] text-amber-300 font-bold border-t border-white/15 pt-1">
                      ✨ Lekhok Manuscript
                    </div>
                  </div>

                  {/* Body Info */}
                  <div className="p-4 flex-1 flex flex-col justify-between space-y-4">
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {b.synopsis}
                    </p>
                    
                    <div className="flex items-center justify-between text-[10px] text-slate-400 font-bold border-t border-slate-50 pt-3">
                      <span>🌐 {b.language || "English"}</span>
                      <span>📖 {b.chapters?.length || 0} {lang === "bn" ? "অধ্যায়" : "Chapters"}</span>
                      <span>📅 {b.updatedAt || b.createdAt || "Unknown"}</span>
                    </div>

                    <div className="flex items-center gap-2 pt-1 border-t border-slate-100/60">
                      <button
                        onClick={() => {
                          setCurrentBook(b);
                          setActiveChapterIndex(0);
                          setPreviewTab("cover");
                          setActiveMainTab("editor");
                        }}
                        className="flex-1 py-2 bg-gradient-to-r from-amber-600 to-[#7c2d12] hover:from-amber-700 hover:to-[#60230e] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 btn-3d-primary cursor-pointer"
                      >
                        <BookOpen size={12} />
                        <span>{lang === "bn" ? "বইটি পড়ুন / লোড করুন" : "Load Book"}</span>
                      </button>
                      
                      <button
                        onClick={() => handleDeleteUserBook(b.id)}
                        className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 rounded-xl border border-rose-200/50 transition shrink-0 cursor-pointer btn-3d-secondary"
                        title={lang === "bn" ? "বইটি ডিলিট করুন" : "Delete Book"}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      )}

      {/* AUTHOR PROFILE & SUBJECT SETTINGS VIEW */}
      {activeMainTab === "settings" && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="flex-1 w-full max-w-4xl mx-auto px-6 py-8 font-sans print:hidden text-left"
        >
          <div className="border-b border-amber-200/60 pb-5 mb-8">
            <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
              <Settings className="text-[#7c2d12]" size={24} />
              <span>{lang === "bn" ? "লেখক প্রোফাইল ও বিষয়বস্তু সেটিংস" : "Profile & Subject Control"}</span>
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1 leading-relaxed">
              {lang === "bn" 
                ? "এখানে আপনার লেখক প্রোফাইল পরিচালনা করুন এবং লেখার বিষয়বস্তু, টোন ও বিশদ বিবরণের মান নিয়ন্ত্রণ করুন।" 
                : "Manage your author credentials and control standard writing subjects, custom voice tone, and detail levels."}
            </p>
          </div>

          {/* 3D INTERACTIVE AUTHOR IDENTITY CARD */}
          {currentUser && (
            <div className="mb-8 max-w-xl mx-auto">
              <Animated3DProfileCard
                displayName={currentUser.displayName || currentUser.username || currentUser.email?.split("@")[0] || "Author"}
                loginId={currentUser.loginId || `LKH-${currentUser.uid?.substring(0, 6).toUpperCase() || '892014'}`}
                email={currentUser.email}
                role={currentUser.role || "Author"}
                photoURL={currentUser.photoURL}
                booksCount={userBooks.length}
                totalChapters={userBooks.reduce((acc, b) => acc + (b.chapters?.length || 0), 0)}
                totalWordsEstimated={userBooks.reduce((acc, b) => acc + (b.chapters?.reduce((cAcc, ch) => cAcc + (ch.content?.split(/\s+/).length || 0), 0) || 0), 0)}
                lang={lang}
                onEditName={() => {
                  setUserDisplayNameInput(currentUser.displayName || "");
                  setIsEditingProfileName(true);
                }}
                onUpdatePhoto={handleUpdateProfilePhoto}
              />
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* COLUMN 1: Profile Information */}
            <div className="bg-white border-2 border-amber-200 rounded-2xl p-5 space-y-4 shadow-sm h-fit">
              <div className="flex items-center justify-between border-b border-amber-100 pb-2.5">
                <h3 className="text-xs font-black text-[#7c2d12] uppercase tracking-wider flex items-center gap-1.5">
                  <User size={14} />
                  <span>{lang === "bn" ? "লেখক প্রোফাইল ও অ্যাকাউন্টের বিবরণ (Proof)" : "Author Profile & Account Proof"}</span>
                </h3>
                <span className="text-[9px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Verified
                </span>
              </div>
              
              {currentUser ? (
                <div className="space-y-4">
                  {/* Author Header */}
                  <div className="flex items-start space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-tr from-[#7c2d12] to-amber-600 text-amber-50 rounded-2xl flex items-center justify-center font-black text-lg shadow-md shrink-0">
                      {(currentUser.displayName || currentUser.email || "A")[0].toUpperCase()}
                    </div>
                    <div className="flex-1 overflow-hidden text-left space-y-1">
                      {isEditingProfileName ? (
                        <div className="flex items-center gap-1">
                          <input
                            type="text"
                            value={userDisplayNameInput}
                            onChange={(e) => setUserDisplayNameInput(e.target.value)}
                            className="bg-amber-50 border border-amber-300 px-2 py-1 rounded-lg text-xs font-black text-slate-900 w-full focus:outline-none"
                            placeholder="Display Name"
                          />
                          <button
                            onClick={() => handleSaveDisplayName(userDisplayNameInput)}
                            className="px-2 py-1 bg-[#7c2d12] text-white text-[10px] font-bold rounded-lg cursor-pointer"
                          >
                            Save
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <h4 className="text-sm font-black text-slate-900 truncate">
                            {currentUser.displayName || currentUser.email?.split("@")[0]}
                          </h4>
                          <button
                            onClick={() => {
                              setUserDisplayNameInput(currentUser.displayName || "");
                              setIsEditingProfileName(true);
                            }}
                            className="text-slate-400 hover:text-amber-700 transition cursor-pointer shrink-0"
                            title="Edit Name"
                          >
                            <Edit3 size={12} />
                          </button>
                        </div>
                      )}

                      <span className={`inline-block text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        currentUser.isGuest || currentUser.isDemo
                          ? "bg-amber-100 text-[#7c2d12] border border-amber-200" 
                          : "bg-emerald-100 text-emerald-800 border border-emerald-200"
                      }`}>
                        {currentUser.isGuest || currentUser.isDemo
                          ? (lang === "bn" ? "ডেমো লেখক অ্যাকাউন্ট" : "Demo Author Account") 
                          : (lang === "bn" ? "পেশাদার লেখক (Google/Gmail)" : "Cloud Pro Author (Gmail)")
                        }
                      </span>
                    </div>
                  </div>

                  {/* Followers & Likes Stat Badges */}
                  <div className="grid grid-cols-2 gap-2 bg-amber-50/60 border border-amber-200/80 p-2.5 rounded-xl text-center">
                    <div className="bg-white p-2 rounded-lg border border-amber-100 shadow-2xs">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Followers</span>
                      <span className="text-base font-black text-[#7c2d12] font-mono">{currentUser.followersCount || 0}</span>
                    </div>
                    <div className="bg-white p-2 rounded-lg border border-amber-100 shadow-2xs">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Total Likes</span>
                      <span className="text-base font-black text-rose-600 font-mono">❤️ {currentUser.totalLikesReceived || 0}</span>
                    </div>
                  </div>

                  {/* ACCOUNT PROOF DETAILS BOX */}
                  <div className="bg-[#111827] text-slate-100 p-4 rounded-2xl space-y-3 text-xs shadow-md border border-amber-500/30 text-left">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="text-[10px] font-black uppercase tracking-widest text-amber-400 flex items-center gap-1">
                        <Lock size={12} />
                        <span>{lang === "bn" ? "অ্যাকাউন্ট লগইন প্রুফ ও আইডি" : "Account Login ID & Credentials"}</span>
                      </span>
                      <span className="text-[8px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {lang === "bn" ? "যেকোনো মোবাইলে লগইনযোগ্য" : "Login Ready Anywhere"}
                      </span>
                    </div>

                    <div className="space-y-2 font-mono text-[11px]">
                      {/* LOGIN ID */}
                      <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/80 flex items-center justify-between">
                        <div>
                          <span className="text-slate-400 text-[9px] uppercase font-bold block font-sans">
                            {lang === "bn" ? "অফিসিয়াল লগইন আইডি (Login ID)" : "Official Login ID"}
                          </span>
                          <span className="text-amber-300 font-extrabold text-sm tracking-wide">
                            {currentUser.loginId || `LKH-${currentUser.uid?.substring(0, 6).toUpperCase() || '892014'}`}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            const loginIdToCopy = currentUser.loginId || `LKH-${currentUser.uid?.substring(0, 6).toUpperCase() || '892014'}`;
                            navigator.clipboard.writeText(loginIdToCopy);
                            setCopiedField("loginId");
                            setTimeout(() => setCopiedField(null), 2000);
                          }}
                          className="px-2.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-[10px] font-bold transition flex items-center gap-1 border border-amber-500/30 cursor-pointer"
                        >
                          {copiedField === "loginId" ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                          <span>{copiedField === "loginId" ? (lang === "bn" ? "কপি হয়েছে!" : "Copied!") : (lang === "bn" ? "কপি আইডি" : "Copy ID")}</span>
                        </button>
                      </div>

                      {/* USERNAME / EMAIL */}
                      <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/80 flex items-center justify-between">
                        <div>
                          <span className="text-slate-400 text-[9px] uppercase font-bold block font-sans">
                            {lang === "bn" ? "ইউজারনেম / ইমেইল" : "Username / Handle"}
                          </span>
                          <span className="text-white font-extrabold text-xs truncate max-w-[170px]">
                            {currentUser.username || currentUser.demoUsername || currentUser.email || currentUser.displayName}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            const textToCopy = currentUser.username || currentUser.demoUsername || currentUser.email || currentUser.displayName || "";
                            navigator.clipboard.writeText(textToCopy);
                            setCopiedField("username");
                            setTimeout(() => setCopiedField(null), 2000);
                          }}
                          className="px-2.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                        >
                          {copiedField === "username" ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                          <span>{copiedField === "username" ? (lang === "bn" ? "কপি!" : "Copied!") : (lang === "bn" ? "কপি" : "Copy")}</span>
                        </button>
                      </div>

                      {/* PASSWORD */}
                      <div className="bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/80 flex items-center justify-between">
                        <div>
                          <span className="text-slate-400 text-[9px] uppercase font-bold block font-sans">
                            {lang === "bn" ? "গোপন পাসওয়ার্ড" : "Secret Password"}
                          </span>
                          <span className="text-amber-200 font-extrabold text-xs">
                            {showProfilePassProof 
                              ? (currentUser.password || currentUser.demoPassword || "pass1234") 
                              : "••••••••"
                            }
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setShowProfilePassProof(!showProfilePassProof)}
                            className="p-1.5 bg-slate-700 hover:bg-slate-600 text-amber-400 rounded-lg transition cursor-pointer"
                            title="Show/Hide Password"
                          >
                            {showProfilePassProof ? <EyeOff size={13} /> : <Eye size={13} />}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const passToCopy = currentUser.password || currentUser.demoPassword || "";
                              if (passToCopy) {
                                navigator.clipboard.writeText(passToCopy);
                                setCopiedField("password");
                                setTimeout(() => setCopiedField(null), 2000);
                              } else {
                                alert(lang === "bn" ? "পাসওয়ার্ড দেখার জন্য রেজিস্ট্রেশন বা লগইন সম্পন্ন করুন।" : "Please register/sign in to see password.");
                              }
                            }}
                            className="px-2.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded-lg text-[10px] font-bold transition flex items-center gap-1 border border-amber-500/30 cursor-pointer"
                          >
                            {copiedField === "password" ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                            <span>{copiedField === "password" ? (lang === "bn" ? "কপি!" : "Copied!") : (lang === "bn" ? "পাসওয়ার্ড কপি" : "Copy Pass")}</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    <p className="text-[10px] text-slate-400 font-sans leading-relaxed pt-1">
                      💡 {lang === "bn"
                        ? "অন্য যেকোনো মোবাইল বা কম্পিউটারে লগইন করার সময় ওপরের Login ID (বা ইউজারনেম/ইমেইল) এবং পাসওয়ার্ড দিন। সাথে সাথে আপনার অ্যাকাউন্ট লোড হয়ে যাবে!"
                        : "Use the Login ID (or Username/Email) and Password shown above on any phone or browser to log in instantly!"}
                    </p>
                  </div>

                  {/* AUTHOR BIO EDITOR */}
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-bold text-[#7c2d12] uppercase tracking-wider block">
                      {lang === "bn" ? "লেখকের জীবনী / বায়ো (Author Bio)" : "Author Bio / Description"}
                    </label>
                    <textarea
                      rows={3}
                      value={userBio}
                      onChange={(e) => setUserBio(e.target.value)}
                      placeholder={lang === "bn" ? "আপনার লেখার উদ্দেশ্য, পরিচয় বা যেকোনো কিছু লিখে রাখুন..." : "Write a short bio about yourself as an author..."}
                      className="w-full bg-amber-50/40 border border-amber-200 p-2.5 rounded-xl text-xs font-serif leading-relaxed text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                    <button
                      onClick={() => handleSaveBio(userBio)}
                      className="w-full py-1.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-lg text-[10px] font-bold transition cursor-pointer shadow-2xs"
                    >
                      {lang === "bn" ? "বায়ো সেভ করুন" : "Save Bio"}
                    </button>
                  </div>

                  {/* PRO VIP UPGRADE BANNER IN PROFILE */}
                  <div className="p-3.5 bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 rounded-2xl text-slate-950 shadow-md flex items-center justify-between gap-3 border border-yellow-300">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 bg-slate-950 text-amber-300 rounded-xl shadow-xs">
                        <Crown size={20} className="fill-amber-300" />
                      </div>
                      <div>
                        <h4 className="text-xs font-black uppercase tracking-wide">
                          {lang === "bn" ? "প্রো ভিআইপি মেম্বারশিপ" : "Pro VIP Membership"}
                        </h4>
                        <p className="text-[10px] font-bold text-slate-900 leading-tight">
                          {lang === "bn" ? "আনলিমিটেড মেগা বই রচনা ও লাইভ এআই ভয়েস আনলক করুন" : "Unlock unlimited mega book creation & Live AI Voice"}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsPremiumStoreOpen(true)}
                      className="px-3.5 py-2 bg-slate-950 hover:bg-slate-900 text-amber-300 rounded-xl text-xs font-black transition whitespace-nowrap shadow-md cursor-pointer hover:scale-105 active:scale-95"
                    >
                      {lang === "bn" ? "👑 আপগ্রেড / কিনুন" : "👑 Upgrade"}
                    </button>
                  </div>

                  {currentUser.isGuest && (
                    <button
                      onClick={() => {
                        setIsSignUp(true);
                        setAuthError("");
                        setShowAuthModal(true);
                      }}
                      className="w-full py-2.5 px-3 bg-[#7c2d12] hover:bg-[#62210b] text-amber-50 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                    >
                      <Sparkles size={13} />
                      <span>{lang === "bn" ? "ক্লাউড অ্যাকাউন্টে কনভার্ট করুন" : "Convert to Cloud Account"}</span>
                    </button>
                  )}

                  <button
                    onClick={handleLogout}
                    className="w-full py-2 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200/50 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <LogOut size={13} />
                    <span>{lang === "bn" ? "লগআউট করুন" : "Sign Out"}</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-4 text-center py-4">
                  <div className="w-12 h-12 bg-slate-50 text-slate-400 border border-slate-200 rounded-full flex items-center justify-center mx-auto shadow-xs">
                    <User size={20} />
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs font-black text-slate-700">{lang === "bn" ? "লগইন করা নেই" : "Logged Out"}</p>
                    <p className="text-[10px] text-slate-500 leading-normal font-medium">
                      {lang === "bn" ? "মেঘে বই সংরক্ষণ এবং সেটিংস সিঙ্ক করতে লগইন করুন।" : "Login to persist your writings and keep preferences synced."}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <button
                      onClick={() => {
                        setIsSignUp(false);
                        setAuthError("");
                        setShowAuthModal(true);
                      }}
                      className="w-full py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
                    >
                      {lang === "bn" ? "ইমেইল দিয়ে লগইন" : "Email Sign In"}
                    </button>
                    
                    <button
                      onClick={handleGoogleSignIn}
                      className="w-full py-2.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <svg className="w-4 h-4 mr-1 inline-block" viewBox="0 0 24 24" width="16" height="16">
                        <path fill="#EA4335" d="M12 5.04c1.74 0 3.3.6 4.53 1.78l3.38-3.38C17.85 1.54 15.11 1 12 1 7.35 1 3.41 3.73 1.59 7.7l3.96 3.07C6.46 7.42 9 5.04 12 5.04z" />
                        <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.44c-.28 1.47-1.11 2.71-2.36 3.55l3.67 2.84c2.14-1.97 3.74-4.87 3.74-8.54z" />
                        <path fill="#FBBC05" d="M5.55 14.54c-.24-.7-.37-1.46-.37-2.24s.13-1.54.37-2.24L1.59 7.7C.58 9.72 0 11.97 0 14.24c0 2.27.58 4.52 1.59 6.54l3.96-3.07c-.24-.71-.37-1.47-.37-3.17z" />
                        <path fill="#34A853" d="M12 23c3.24 0 5.96-1.08 7.95-2.92l-3.67-2.84c-1.02.68-2.33 1.09-4.28 1.09-3 0-5.54-2.38-6.45-5.73L.59 15.67C2.41 19.64 6.35 23 12 23z" />
                      </svg>
                      <span>{lang === "bn" ? "গুগল দিয়ে লগইন" : "Google Sign In"}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* API Key Connection Status indicator */}
              <div className="border-t border-slate-100 pt-4 mt-4 space-y-3">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-wider">
                  {lang === "bn" ? "এআই সার্ভিস কানেকশন" : "AI Service Connection"}
                </h4>
                {hasApiKey === null ? (
                  <div className="flex items-center gap-2 text-slate-500 text-xs">
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-300 animate-pulse" />
                    <span>{lang === "bn" ? "পরীক্ষা করা হচ্ছে..." : "Checking state..."}</span>
                  </div>
                ) : hasApiKey ? (
                  <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-950 space-y-1 shadow-2xs">
                    <div className="flex items-center gap-1.5 text-xs font-black">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                      <Check size={13} className="text-emerald-600" />
                      <span>{lang === "bn" ? "GEMINI_API_KEY সক্রিয়" : "GEMINI_API_KEY Active"}</span>
                    </div>
                    <p className="text-[10px] text-emerald-700 leading-normal font-medium font-sans">
                      {lang === "bn" 
                        ? "আপনার এআই সার্ভিস কি-টি প্রস্তুত। বই এবং কন্টেন্ট তৈরিতে কোনো বাধা নেই।" 
                        : "Your Gemini AI key is correctly injected. Ready to write books!"}
                    </p>
                  </div>
                ) : (
                  <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-rose-950 space-y-2 shadow-2xs">
                    <div className="flex items-center gap-1.5 text-xs font-black">
                      <ShieldAlert size={13} className="text-rose-600 animate-bounce" />
                      <span>{lang === "bn" ? "GEMINI_API_KEY অনুপস্থিত" : "GEMINI_API_KEY Missing"}</span>
                    </div>
                    <p className="text-[10px] text-rose-700 leading-normal font-medium font-sans">
                      {lang === "bn" 
                        ? "অনুগ্রহ করে AI Studio-র 'Settings > Secrets' প্যানেলে গিয়ে 'GEMINI_API_KEY' সিক্রেটটি যুক্ত করুন।" 
                        : "Please configure 'GEMINI_API_KEY' in the 'Settings > Secrets' panel to activate AI writing features."}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* COLUMN 2 & 3: Subject & Preference Controls */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-2xs md:col-span-2 space-y-5">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider border-b border-slate-50 pb-2">
                {lang === "bn" ? "লেখার বিষয়বস্তু ও পছন্দসমূহ" : "Subject matter & Style Preferences"}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Preference 1: Subject matter */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                    {lang === "bn" ? "পছন্দের বইয়ের বিষয় (Subject Control)" : "Default Book Subject"}
                  </label>
                  <select
                    value={preferredSubject}
                    onChange={(e) => setPreferredSubject(e.target.value)}
                    className="w-full bg-[#faf9f5] border border-[#e4dcc9] p-2.5 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="All Genres / যেকোনো বিষয়">All Genres / যেকোনো বিষয় (Universal AI Author)</option>
                    <option value="Vocabulary & Language Learning">Vocabulary & Language Learning (শব্দভাণ্ডার ও ভাষা শিক্ষা)</option>
                    <option value="Fiction, Novels & Stories">Fiction, Novels & Stories (গল্প ও উপন্যাস)</option>
                    <option value="Islamic & Moral Values">Islamic & Moral Values (ইসলামিক ও নৈতিক শিক্ষা)</option>
                    <option value="Self-Help & Motivation">Self-Help & Motivation (আত্মউন্নয়ন ও অনুপ্রেরণা)</option>
                    <option value="Academic & Science Guides">Academic & Science Guides (শিক্ষা ও বিজ্ঞান)</option>
                    <option value="Poetry & Fine Literature">Poetry & Fine Literature (কবিতা ও সাহিত্য)</option>
                    <option value="Programming & Software Dev">Programming & Software Dev (প্রোগ্রামিং ও প্রযুক্তি)</option>
                    <option value="Cybersecurity & Ethical Hacking">Cybersecurity & Ethical Hacking (সাইবার নিরাপত্তা)</option>
                  </select>
                </div>

                {/* Preference 2: Writing Tone */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                    {lang === "bn" ? "লেখার টোন (Tone Preference)" : "Writing Tone / Voice"}
                  </label>
                  <select
                    value={preferredTone}
                    onChange={(e) => setPreferredTone(e.target.value)}
                    className="w-full bg-[#faf9f5] border border-[#e4dcc9] p-2.5 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="Professional & Educational">Professional & Educational</option>
                    <option value="Cyberpunk & Technical (Hacker style)">Cyberpunk & Technical (Hacker Style)</option>
                    <option value="Engaging, Literary & Immersive">Engaging, Literary & Immersive</option>
                    <option value="Poetic, Soft & Romantic">Poetic, Soft & Romantic</option>
                    <option value="Simple, Clear & For Beginners">Simple, Clear & For Beginners</option>
                    <option value="Academic, Scholarly & Detailed">Academic, Scholarly & Detailed</option>
                    <option value="Humorous & Friendly">Humorous & Friendly</option>
                  </select>
                </div>

                {/* Preference 3: Detailed style */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                    {lang === "bn" ? "লেখার গভীরতা ও বিশদ বিবরণ (Style & Deep Detail)" : "Writing Detail Level & Formatting Style"}
                  </label>
                  <select
                    value={preferredStyle}
                    onChange={(e) => setPreferredStyle(e.target.value)}
                    className="w-full bg-[#faf9f5] border border-[#e4dcc9] p-2.5 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="Detailed prose tailored precisely to book genre">
                      Auto-adaptive (Deep prose tailored precisely to chosen genre)
                    </option>
                    <option value="Structured vocabulary lists with pronunciation, Bengali meaning, example sentences, and quizzes">
                      Vocabulary format (Words, Bangla pronunciation, meanings, 2 examples, mnemonics, quizzes)
                    </option>
                    <option value="Narrative prose with heavy dialogue, scene descriptions, and deep lore">
                      Creative literary prose (Heavy dialogue, rich scenes, character arcs - No code)
                    </option>
                    <option value="Detailed step-by-step prose with rich examples, code blocks and tables">
                      Technical & Programming (Step-by-step code, tables, callouts, and explanations)
                    </option>
                    <option value="Clear, punchy, bulleted layout for quick learning and actionable advice">
                      Actionable summary style (Bulleted frameworks, daily habits, clear highlights)
                    </option>
                    <option value="Scholarly essay format with heavy footnotes and structural subdivisions">
                      Scholarly & Academic essay format (References, profound concepts, structured subheadings)
                    </option>
                  </select>
                </div>

                {/* Preference 4: Default language */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                    {lang === "bn" ? "ডিফল্ট ভাষা" : "Primary Language"}
                  </label>
                  <select
                    value={preferredLanguage}
                    onChange={(e) => setPreferredLanguage(e.target.value)}
                    className="w-full bg-[#faf9f5] border border-[#e4dcc9] p-2.5 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="Bengali">Bengali (বাংলা)</option>
                    <option value="English">English</option>
                    <option value="Spanish">Spanish (Español)</option>
                    <option value="French">French (Français)</option>
                    <option value="Arabic">Arabic (العربية)</option>
                  </select>
                </div>

                {/* Preference 5: Length preset */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                    {lang === "bn" ? "অধ্যায়ের দৈর্ঘ্য" : "Target Chapter Length"}
                  </label>
                  <select
                    value={preferredLength}
                    onChange={(e) => setPreferredLength(e.target.value as any)}
                    className="w-full bg-[#faf9f5] border border-[#e4dcc9] p-2.5 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="short">Short (~800 words)</option>
                    <option value="detailed">Detailed (~1500 words - Recommended)</option>
                    <option value="epic">Epic (~3000 words)</option>
                  </select>
                </div>

              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  onClick={() => {
                    alert(lang === "bn" 
                      ? "🎉 আপনার লেখক পছন্দসমূহ সফলভাবে সংরক্ষণ করা হয়েছে! এখন এআই দিয়ে নতুন বই লেখার সময় এই বিষয় ও স্টাইলগুলো ব্যবহৃত হবে।" 
                      : "🎉 Writing preferences updated successfully! Future books and chapters will use these customized style guidelines."
                    );
                    setActiveMainTab("editor");
                  }}
                  className="px-5 py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-amber-50 text-xs font-bold rounded-xl transition shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles size={13} />
                  <span>{lang === "bn" ? "ডিজাইন ও প্রেফারেন্স সেভ করুন" : "Save Preferences"}</span>
                </button>
              </div>

            </div>

          </div>
        </motion.div>
      )}

      {/* AUTHENTICATION MODAL */}
      <AnimatePresence>
        {showAuthModal && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4 print:hidden">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="bg-white border-2 border-amber-300 rounded-3xl p-6 shadow-2xl max-w-md w-full font-sans text-left space-y-4 relative overflow-hidden"
            >
              {/* Header */}
              <div className="text-center space-y-1.5 pt-1">
                <div className="mx-auto w-12 h-12 bg-gradient-to-tr from-[#7c2d12] to-amber-600 text-amber-50 rounded-2xl flex items-center justify-center shadow-lg mb-1.5">
                  <User size={22} />
                </div>
                <h3 className="text-xl font-extrabold text-slate-950">
                  {authTab === "demo_register" 
                    ? (lang === "bn" ? "নতুন ডেমো অ্যাকাউন্ট নিবন্ধন" : "Create Demo Author Account")
                    : authTab === "demo_login"
                    ? (lang === "bn" ? "ডেমো অ্যাকাউন্টে প্রবেশ করুন" : "Demo Author Login")
                    : isSignUp 
                    ? (lang === "bn" ? "নতুন লেখক ইমেইল অ্যাকাউন্ট" : "Create Cloud Profile")
                    : (lang === "bn" ? "লেখক পোর্টালে ইমেইল লগইন" : "Writer Email Login Portal")
                  }
                </h3>
                <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                  {authTab === "demo_register"
                    ? (lang === "bn" ? "আপনার পছন্দের নাম, ইউজারনেম ও পাসওয়ার্ড দিয়ে ডেমো অ্যাকাউন্ট খুলুন।" : "Set a custom author name, username, and password for full proof of account.")
                    : authTab === "demo_login"
                    ? (lang === "bn" ? "পূর্বে তৈরি করা ডেমো ইউজারনেম ও পাসওয়ার্ড দিয়ে প্রবেশ করুন।" : "Log back in with your demo username and password.")
                    : isSignUp
                    ? (lang === "bn" ? "ক্লাউড সিঙ্ক নিশ্চিত করতে ইমেইল দিয়ে অ্যাকাউন্ট করুন।" : "Sync all manuscripts securely across all devices.")
                    : (lang === "bn" ? "আপনার আগের ইতিহাস ও বই দেখতে ইমেইল দিয়ে লগইন করুন।" : "Sign in to access your cloud manuscript history.")
                  }
                </p>

                {/* Sub-Tabs Selector for Standard vs Demo Register vs Demo Login */}
                <div className="grid grid-cols-3 gap-1 bg-amber-50 p-1 rounded-xl border border-amber-200 mt-2">
                  <button
                    type="button"
                    onClick={() => { setAuthTab("standard"); setAuthError(""); }}
                    className={`py-1.5 px-1 rounded-lg text-[10px] font-extrabold transition cursor-pointer ${
                      authTab === "standard"
                        ? "bg-[#7c2d12] text-white shadow-xs"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {lang === "bn" ? "ইমেইল / গুগল" : "Standard Email"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAuthTab("demo_register"); setAuthError(""); }}
                    className={`py-1.5 px-1 rounded-lg text-[10px] font-extrabold transition cursor-pointer ${
                      authTab === "demo_register"
                        ? "bg-[#7c2d12] text-white shadow-xs"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {lang === "bn" ? "ডেমো সাইন-আপ" : "Demo Register"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setAuthTab("demo_login"); setAuthError(""); }}
                    className={`py-1.5 px-1 rounded-lg text-[10px] font-extrabold transition cursor-pointer ${
                      authTab === "demo_login"
                        ? "bg-[#7c2d12] text-white shadow-xs"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {lang === "bn" ? "ডেমো লগইন" : "Demo Login"}
                  </button>
                </div>
              </div>

              {/* FORM 1: STANDARD EMAIL FORM */}
              {authTab === "standard" && (
                <form onSubmit={handleAuthSubmit} className="space-y-3">
                  {isSignUp && (
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">{lang === "bn" ? "আপনার পুরো নাম" : "Full Name"}</label>
                      <input 
                        type="text" 
                        value={authName}
                        onChange={(e) => setAuthName(e.target.value)}
                        placeholder={lang === "bn" ? "যেমন: কাজী নজরুল ইসলাম" : "e.g. Kazi Nazrul"}
                        required
                        className="w-full bg-slate-50 border border-slate-200/80 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                      />
                    </div>
                  )}

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Email Address</label>
                    <input 
                      type="email" 
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      placeholder="author@lekhok.app"
                      required
                      className="w-full bg-slate-50 border border-slate-200/80 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Password</label>
                    <input 
                      type="password" 
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      placeholder="••••••••"
                      required
                      className="w-full bg-slate-50 border border-slate-200/80 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                    />
                  </div>

                  {authError && (
                    <p className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-100 p-2.5 rounded-xl text-left leading-normal">
                      ⚠️ {authError}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={isFetchingHistory}
                    className="w-full py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm disabled:opacity-50 cursor-pointer"
                  >
                    {isFetchingHistory ? (
                      <RefreshCw size={12} className="animate-spin" />
                    ) : (
                      <Zap size={12} />
                    )}
                    <span>
                      {isSignUp 
                        ? (lang === "bn" ? "অ্যাকাউন্ট তৈরি করুন" : "Register Profile") 
                        : (lang === "bn" ? "লগইন করুন" : "Sign In Now")
                      }
                    </span>
                  </button>
                </form>
              )}

              {/* FORM 2: DEMO REGISTER FORM */}
              {authTab === "demo_register" && (
                <form onSubmit={handleDemoRegister} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-[#7c2d12] uppercase tracking-wider block">{lang === "bn" ? "লেখকের নাম (Display Name)" : "Author Display Name"}</label>
                    <input 
                      type="text" 
                      value={demoName}
                      onChange={(e) => setDemoName(e.target.value)}
                      placeholder={lang === "bn" ? "যেমন: হুমায়ূন আহমেদ" : "e.g. Humayun Ahmed"}
                      required
                      className="w-full bg-amber-50/50 border border-amber-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-[#7c2d12] uppercase tracking-wider block">{lang === "bn" ? "ডেমো ইউজারনেম / আইডি" : "Demo Username / ID"}</label>
                    <input 
                      type="text" 
                      value={demoUsername}
                      onChange={(e) => setDemoUsername(e.target.value)}
                      placeholder={lang === "bn" ? "যেমন: humayun55" : "e.g. humayun55"}
                      required
                      className="w-full bg-amber-50/50 border border-amber-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-bold text-[#7c2d12] uppercase tracking-wider block">{lang === "bn" ? "পাসওয়ার্ড (নিজের পছন্দ মতো দিন)" : "Demo Password"}</label>
                      <button
                        type="button"
                        onClick={() => {
                          const randPass = Math.floor(100000 + Math.random() * 900000).toString();
                          setDemoPassword(randPass);
                        }}
                        className="text-[9px] font-bold text-amber-700 hover:underline cursor-pointer"
                      >
                        ⚡ {lang === "bn" ? "র্যান্ডম পাসওয়ার্ড দিন" : "Auto Generate"}
                      </button>
                    </div>
                    <div className="relative">
                      <input 
                        type={showDemoPassInModal ? "text" : "password"} 
                        value={demoPassword}
                        onChange={(e) => setDemoPassword(e.target.value)}
                        placeholder="e.g. pass1234"
                        required
                        className="w-full bg-amber-50/50 border border-amber-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition pr-8"
                      />
                      <button
                        type="button"
                        onClick={() => setShowDemoPassInModal(!showDemoPassInModal)}
                        className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showDemoPassInModal ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>

                  {authError && (
                    <p className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-100 p-2.5 rounded-xl text-left leading-normal">
                      ⚠️ {authError}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={isFetchingHistory}
                    className="w-full py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Sparkles size={13} />
                    <span>{lang === "bn" ? "ডেমো অ্যাকাউন্ট খুলুন" : "Create Demo Account"}</span>
                  </button>
                </form>
              )}

              {/* FORM 3: UNIVERSAL LOGIN FORM (LOGIN ID, USERNAME, EMAIL) */}
              {authTab === "demo_login" && (
                <form onSubmit={handleDemoLogin} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-[#7c2d12] uppercase tracking-wider block">
                      {lang === "bn" ? "🔑 লগইন আইডি / ইউজারনেম / ইমেইল" : "🔑 Login ID / Username / Email"}
                    </label>
                    <input 
                      type="text" 
                      value={demoUsername}
                      onChange={(e) => setDemoUsername(e.target.value)}
                      placeholder={lang === "bn" ? "যেমন: LKH-892014 অথবা humayun55" : "e.g. LKH-892014 or humayun55"}
                      required
                      className="w-full bg-amber-50/50 border border-amber-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-[#7c2d12] uppercase tracking-wider block">
                      {lang === "bn" ? "পাসওয়ার্ড" : "Password"}
                    </label>
                    <div className="relative">
                      <input 
                        type={showDemoPassInModal ? "text" : "password"} 
                        value={demoPassword}
                        onChange={(e) => setDemoPassword(e.target.value)}
                        placeholder="••••••••"
                        required
                        className="w-full bg-amber-50/50 border border-amber-200 p-2.5 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition pr-8"
                      />
                      <button
                        type="button"
                        onClick={() => setShowDemoPassInModal(!showDemoPassInModal)}
                        className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showDemoPassInModal ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>

                  {authError && (
                    <p className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-100 p-2.5 rounded-xl text-left leading-normal">
                      ⚠️ {authError}
                    </p>
                  )}

                  <button
                    type="submit"
                    disabled={isFetchingHistory}
                    className="w-full py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Zap size={13} />
                    <span>{lang === "bn" ? "অ্যাকাউন্টে প্রবেশ করুন" : "Sign In to Account"}</span>
                  </button>
                </form>
              )}

              {/* Alternative Auth options (Google & One-Click Guest) */}
              <div className="space-y-2 pt-1">
                <div className="relative flex py-1 items-center">
                  <div className="flex-grow border-t border-slate-100"></div>
                  <span className="flex-shrink mx-3 text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                    {lang === "bn" ? "অথবা বিকল্প অপশন" : "Or Alternative"}
                  </span>
                  <div className="flex-grow border-t border-slate-100"></div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleGoogleSignIn}
                    type="button"
                    className="py-2 px-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <svg className="w-3 h-3 text-red-500" viewBox="0 0 24 24" width="12" height="12">
                      <path fill="#EA4335" d="M12 5.04c1.74 0 3.3.6 4.53 1.78l3.38-3.38C17.85 1.54 15.11 1 12 1 7.35 1 3.41 3.73 1.59 7.7l3.96 3.07C6.46 7.42 9 5.04 12 5.04z" />
                      <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.51h6.44c-.28 1.47-1.11 2.71-2.36 3.55l3.67 2.84c2.14-1.97 3.74-4.87 3.74-8.54z" />
                      <path fill="#FBBC05" d="M5.55 14.54c-.24-.7-.37-1.46-.37-2.24s.13-1.54.37-2.24L1.59 7.7C.58 9.72 0 11.97 0 14.24c0 2.27.58 4.52 1.59 6.54l3.96-3.07c-.24-.71-.37-1.47-.37-3.17z" />
                      <path fill="#34A853" d="M12 23c3.24 0 5.96-1.08 7.95-2.92l-3.67-2.84c-1.02.68-2.33 1.09-4.28 1.09-3 0-5.54-2.38-6.45-5.73L.59 15.67C2.41 19.64 6.35 23 12 23z" />
                    </svg>
                    <span>{lang === "bn" ? "গুগল লগইন" : "Google Sign In"}</span>
                  </button>

                  <button
                    onClick={handleStartGuestMode}
                    type="button"
                    className="py-2 px-3 bg-amber-50 hover:bg-amber-100 border border-amber-200/50 text-[#7c2d12] rounded-xl text-[10px] font-black transition flex items-center justify-center gap-1 cursor-pointer animate-pulse"
                  >
                    <Sparkles size={11} />
                    <span>{lang === "bn" ? "গেস্ট লগইন (Demo)" : "1-Click Demo"}</span>
                  </button>
                </div>
              </div>

              {/* Mode Toggle & Cancel */}
              <div className="flex items-center justify-between pt-1 text-[10px] font-bold text-[#7c2d12] border-t border-slate-100/60">
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    setAuthError("");
                  }}
                  className="hover:underline cursor-pointer"
                >
                  {isSignUp 
                    ? (lang === "bn" ? "ইতিমধ্যে অ্যাকাউন্ট আছে? লগইন" : "Already have an account? Sign In")
                    : (lang === "bn" ? "নতুন অ্যাকাউন্ট তৈরি করুন" : "New writer? Create account")
                  }
                </button>
                <button
                  type="button"
                  onClick={() => setShowAuthModal(false)}
                  className="text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {lang === "bn" ? "বাতিল" : "Cancel"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TRANSLATION MODAL */}
      <AnimatePresence>
        {showTranslateModal && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-50 flex items-center justify-center p-4 print:hidden">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="bg-white border border-amber-200 rounded-3xl p-6 shadow-2xl max-w-sm w-full font-sans text-left space-y-4 relative"
            >
              {/* Header */}
              <div className="text-center space-y-1 pt-2">
                <div className="mx-auto w-10 h-10 bg-amber-50 text-[#7c2d12] border border-amber-200 rounded-xl flex items-center justify-center shadow-sm mb-2 animate-pulse">
                  <Languages size={20} />
                </div>
                <h3 className="text-lg font-black text-slate-950">
                  {lang === "bn" ? "বইয়ের ভাষা অনুবাদ করুন" : "Translate Your Book"}
                </h3>
                <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                  {lang === "bn" 
                    ? "আপনার সম্পূর্ণ বইটি এআই দিয়ে বিশ্বের যেকোনো ভাষায় অনুবাদ করুন। সূচিপত্র ও সকল অধ্যায় নিখুঁতভাবে অনূদিত হবে।" 
                    : "Translate your entire manuscript into any other language natively using high-fidelity translation."
                  }
                </p>
              </div>

              {/* Language selection dropdown */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  {lang === "bn" ? "লক্ষ্য ভাষা সিলেক্ট করুন" : "Select Target Language"}
                </label>
                <select
                  value={selectedTranslateLanguage}
                  onChange={(e) => setSelectedTranslateLanguage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 p-3 rounded-xl text-xs font-bold focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                >
                  <option value="Bengali">Bengali (বাংলা)</option>
                  <option value="English">English</option>
                  <option value="Spanish">Spanish (Español)</option>
                  <option value="French">French (Français)</option>
                  <option value="Arabic">Arabic (العربية)</option>
                  <option value="German">German (Deutsch)</option>
                  <option value="Hindi">Hindi (हिन्दी)</option>
                  <option value="Japanese">Japanese (日本語)</option>
                  <option value="Chinese">Chinese (中文)</option>
                  <option value="Urdu">Urdu (اردو)</option>
                </select>
              </div>

              <button
                onClick={() => handleTranslateBook(selectedTranslateLanguage)}
                className="w-full py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Languages size={13} />
                <span>{lang === "bn" ? "অনুবাদ শুরু করুন" : "Start Translation"}</span>
              </button>

              <button
                onClick={() => setShowTranslateModal(false)}
                className="w-full py-2 text-slate-500 hover:text-slate-800 rounded-xl text-xs font-bold transition block text-center cursor-pointer"
              >
                {lang === "bn" ? "বাতিল" : "Cancel"}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* GLOBAL TRANSLATING LOADER */}
      {isTranslating && (
        <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-xs z-50 flex flex-col items-center justify-center space-y-4 print:hidden">
          <div className="p-5 bg-white/95 rounded-2xl flex flex-col items-center justify-center space-y-3 shadow-2xl border border-amber-200 max-w-xs text-center font-sans">
            <RefreshCw className="animate-spin text-[#7c2d12]" size={36} />
            <h4 className="text-xs font-black text-slate-950">
              {lang === "bn" ? "অনুবাদ করা হচ্ছে..." : "Translating Manuscript..."}
            </h4>
            <p className="text-[10px] text-slate-500 leading-normal font-medium px-2">
              {lang === "bn" 
                ? "আমাদের অনুবাদক এআই পুরো বইয়ের রূপরেখা এবং সকল অধ্যায়ের টেক্সট লক্ষ্য ভাষায় রূপান্তর করছে। অনুগ্রহ করে ৩০-৪০ সেকেন্ড অপেক্ষা করুন।" 
                : "Our AI is busy rebuilding the core table of contents and translating all manuscript chapters. This might take 30-40 seconds..."}
            </p>
          </div>
        </div>
      )}

      {/* MEDIA & 3D INSERT MODAL */}
      <MediaInsertModal
        isOpen={isMediaInsertModalOpen}
        onClose={() => setIsMediaInsertModalOpen(false)}
        onInsert={(snippet) => {
          if (!currentBook) return;
          const ch = currentBook.chapters[activeChapterIndex];
          if (!ch) return;
          const newContent = (ch.content || "") + snippet;
          handleManualContentChange(newContent);
          saveBookToFirestore({
            ...currentBook,
            chapters: currentBook.chapters.map((c, i) => i === activeChapterIndex ? { ...c, content: newContent, status: "completed" } : c)
          });
        }}
        lang={lang}
      />

      {/* CHAT BACKGROUND MODAL */}
      <AnimatePresence>
        {isChatBgModalOpen && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4 print:hidden">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="bg-white border border-amber-200 rounded-3xl p-6 shadow-2xl max-w-md w-full font-sans text-left space-y-4 relative"
            >
              <div className="flex items-center justify-between border-b border-amber-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-amber-50 rounded-xl text-[#7c2d12]">
                    <Image size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900">
                      {lang === "bn" ? "চ্যাট ব্যাকগ্রাউন্ড কাস্টমাইজেশন" : "Chat Background Customization"}
                    </h3>
                    <p className="text-[10px] text-slate-500 font-medium">
                      {lang === "bn" ? "চ্যাট প্যানেলের পেছনে পছন্দের ছবি বা ভিডিও যোগ করুন" : "Set custom photo or video wallpaper for chat window"}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsChatBgModalOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition cursor-pointer"
                >
                  <Trash2 size={14} className="hidden" />
                  ✕
                </button>
              </div>

              {/* Background Type Selector */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-700">
                  {lang === "bn" ? "ব্যাকগ্রাউন্ডের ধরন" : "Background Type"}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "none", label: lang === "bn" ? "কোনটি নয়" : "None" },
                    { id: "image", label: lang === "bn" ? "ছবি (Image)" : "Image" },
                    { id: "video", label: lang === "bn" ? "ভিডিও (Video)" : "Video" }
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        setChatBgType(t.id as any);
                        localStorage.setItem("scribemind_chat_bg_type", t.id);
                      }}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition border cursor-pointer ${
                        chatBgType === t.id
                          ? "bg-[#7c2d12] text-amber-50 border-[#7c2d12] shadow-xs"
                          : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* URL or Upload Input if Image / Video */}
              {chatBgType !== "none" && (
                <div className="space-y-3 pt-1">
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-700">
                      {chatBgType === "video" 
                        ? (lang === "bn" ? "ভিডিও লিঙ্ক / MP4 URL" : "Video URL (MP4 / WebM)") 
                        : (lang === "bn" ? "ছবির লিঙ্ক / Image URL" : "Image URL (JPG / PNG / Unsplash)")}
                    </label>
                    <input
                      type="text"
                      placeholder={chatBgType === "video" ? "https://assets.mixkit.co/videos/preview/...mp4" : "https://images.unsplash.com/photo-..."}
                      value={chatBgUrl}
                      onChange={(e) => {
                        setChatBgUrl(e.target.value);
                        localStorage.setItem("scribemind_chat_bg_url", e.target.value);
                      }}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                    />
                  </div>

                  {/* Local Upload */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-700">
                      {lang === "bn" ? "অথবা ডিভাইস থেকে ফাইল আপলোড করুন" : "Or Upload From Device"}
                    </label>
                    <label className="flex items-center justify-center gap-2 p-3 border-2 border-dashed border-amber-200 hover:border-[#7c2d12] bg-amber-50/40 rounded-xl cursor-pointer transition">
                      <FileUp size={16} className="text-[#7c2d12]" />
                      <span className="text-xs font-bold text-[#7c2d12]">
                        {lang === "bn" ? "ডিভাইস থেকে ব্রাউজ করুন" : "Browse Device"}
                      </span>
                      <input
                        type="file"
                        accept={chatBgType === "video" ? "video/*" : "image/*"}
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              const result = ev.target?.result as string;
                              setChatBgUrl(result);
                              localStorage.setItem("scribemind_chat_bg_url", result);
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                  </div>

                  {/* Preset Wallpapers */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">
                      {lang === "bn" ? "রেডিমেড প্রিসেট" : "Ready-made Presets"}
                    </span>
                    <div className="grid grid-cols-3 gap-2">
                      {chatBgType === "image" ? (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              const url = "https://images.unsplash.com/photo-1507842229451-7f01be7f7b2a?q=80&w=800&auto=format&fit=crop";
                              setChatBgUrl(url);
                              localStorage.setItem("scribemind_chat_bg_url", url);
                            }}
                            className="p-1.5 border border-slate-200 rounded-lg hover:border-amber-500 text-[10px] font-bold text-slate-700 bg-white"
                          >
                            📚 Library
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const url = "https://images.unsplash.com/photo-1512820790803-83ca734da794?q=80&w=800&auto=format&fit=crop";
                              setChatBgUrl(url);
                              localStorage.setItem("scribemind_chat_bg_url", url);
                            }}
                            className="p-1.5 border border-slate-200 rounded-lg hover:border-amber-500 text-[10px] font-bold text-slate-700 bg-white"
                          >
                            📖 Bookshelf
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const url = "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=800&auto=format&fit=crop";
                              setChatBgUrl(url);
                              localStorage.setItem("scribemind_chat_bg_url", url);
                            }}
                            className="p-1.5 border border-slate-200 rounded-lg hover:border-amber-500 text-[10px] font-bold text-slate-700 bg-white"
                          >
                            🌌 Starry Sky
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              const url = "https://assets.mixkit.co/videos/preview/mixkit-set-of-plateaus-seen-from-the-sky-in-a-sunset-26070-large.mp4";
                              setChatBgUrl(url);
                              localStorage.setItem("scribemind_chat_bg_url", url);
                            }}
                            className="p-1.5 border border-slate-200 rounded-lg hover:border-amber-500 text-[10px] font-bold text-slate-700 bg-white"
                          >
                            🌄 Sunset Sky
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const url = "https://assets.mixkit.co/videos/preview/mixkit-tree-branches-in-the-breeze-1188-large.mp4";
                              setChatBgUrl(url);
                              localStorage.setItem("scribemind_chat_bg_url", url);
                            }}
                            className="p-1.5 border border-slate-200 rounded-lg hover:border-amber-500 text-[10px] font-bold text-slate-700 bg-white"
                          >
                            🍃 Nature Breeze
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const url = "https://assets.mixkit.co/videos/preview/mixkit-particles-in-light-rays-32779-large.mp4";
                              setChatBgUrl(url);
                              localStorage.setItem("scribemind_chat_bg_url", url);
                            }}
                            className="p-1.5 border border-slate-200 rounded-lg hover:border-amber-500 text-[10px] font-bold text-slate-700 bg-white"
                          >
                            ✨ Ambient Dust
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Opacity Slider */}
                  <div className="space-y-1 pt-1">
                    <div className="flex justify-between text-[11px] font-bold text-slate-700">
                      <span>{lang === "bn" ? "স্বচ্ছতা (Opacity)" : "Opacity"}</span>
                      <span className="font-mono text-amber-800">{Math.round(chatBgOpacity * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.05"
                      max="0.8"
                      step="0.05"
                      value={chatBgOpacity}
                      onChange={(e) => {
                        const op = parseFloat(e.target.value);
                        setChatBgOpacity(op);
                        localStorage.setItem("scribemind_chat_bg_opacity", op.toString());
                      }}
                      className="w-full accent-[#7c2d12] cursor-pointer"
                    />
                  </div>
                </div>
              )}

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsChatBgModalOpen(false)}
                  className="w-full py-2.5 bg-[#7c2d12] hover:bg-[#63220c] text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
                >
                  {lang === "bn" ? "সংরক্ষণ করুন" : "Save & Apply"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* PUBLIC AUTHOR PROFILE MODAL */}
      <PublicAuthorProfileModal
        isOpen={!!selectedAuthorProfile}
        onClose={() => setSelectedAuthorProfile(null)}
        author={selectedAuthorProfile}
        lang={lang}
        currentUserId={currentUser?.uid}
        authorBooks={publishedBooks.filter(bk => selectedAuthorProfile && ((bk.userId && bk.userId === selectedAuthorProfile.userId) || bk.creatorName === selectedAuthorProfile.name))}
        onSelectBook={(book) => {
          setSelectedAuthorProfile(null);
          setSelectedSocialBook(book);
          setSocialBookChapterIndex(0);
          setSocialBookPageIndex(0);
        }}
      />

      {/* AUTONOMOUS VOICE CO-PILOT (BOSS MODE EXECUTIVE ASSISTANT) */}
      <AutonomousVoiceCoPilot
        lang={lang}
        currentUser={currentUser}
        currentBook={currentBook}
        modelProvider={selectedProvider}
        customGeminiKey={geminiApiKey}
        customDeepseekKey={deepseekApiKey}
        onNavigateTab={(tab) => setActiveMainTab(tab as any)}
        onExecuteBookCreation={(topic, genre, prompt, chapterCount) => {
          setActiveMainTab("editor");
          const finalPrompt = prompt || `Create a complete comprehensive book about "${topic}", genre: "${genre || 'Fiction'}" with ${chapterCount || 3} chapters.`;
          setUserChatPrompt(finalPrompt);
          setTimeout(() => {
            handleSendChatMessage(finalPrompt);
          }, 100);
        }}
        onDownloadPdf={handleDownloadHTML}
        onPublishBook={handleTogglePublish}
        onTranslateBook={(targetLang) => handleTranslateBook(targetLang)}
      />

      {/* 🎨 INTERACTIVE COVER PAGE STUDIO MODAL */}
      <AnimatePresence>
        {isCoverStudioOpen && currentBook && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-slate-900 border-2 border-amber-500/40 rounded-3xl max-w-5xl w-full p-5 sm:p-7 text-white shadow-2xl relative my-auto max-h-[92vh] overflow-y-auto"
            >
              <button
                onClick={() => setIsCoverStudioOpen(false)}
                className="absolute top-4 right-4 p-2 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition cursor-pointer z-10"
              >
                <X size={18} />
              </button>

              <CoverPageStudio
                book={currentBook}
                onSaveCover={(updated) => {
                  setCurrentBook(updated);
                  setIsCoverStudioOpen(false);
                }}
                onClose={() => setIsCoverStudioOpen(false)}
                lang={lang}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 👑 PRO VIP STORE PURCHASE MODAL */}
      <PremiumStoreModal
        isOpen={isPremiumStoreOpen}
        onClose={() => setIsPremiumStoreOpen(false)}
        currentUser={currentUser}
        lang={lang}
        onOpenAuth={() => {
          setIsPremiumStoreOpen(false);
          setIsSignUp(false);
          setShowAuthModal(true);
        }}
      />

    </div>
  );
}
